var aX,aY,aZ,ba,bb,bc,bd,be,bf;const bg=[0x0,0x1,0x8,0xff,"length","undefined",0x3f,0x6,"fromCodePoint",0x7,0xc,"push",0x5b,0x1fff,0x58,0xd,0xe,0x7f,0x80,0x86,0xc1,0xc2,0xb6,0xd6,0xdf,0xda,0xdc,0xe0,!0x0,0x9e,0xbc,0xef,0x7e,0xcd,0xce,0xcf,0xd0,0xd1,0xd2,0xd3,0xd4,0xd8,0xb31856,0xd9,0xdb,0xdd,0xde,0xe1,0xe2," (",")",0xe3,0xe4,0xe5,0xe6,0xe7,0xe8,0xe9,0xea,0xeb,0xec,0xed,0xee,0xf0,0xf1,0xf3,0xf8,0xfa,0xfb,0xfc];function bh(aX){var aY="[uOA^vGj}F;`ReU]0I2$c{(My=<67s>#ag&4198%HfDBCoL@txw!N3d_PqlTpYXJ|b,r)+V\"zE5?~hn*kQZ:.m/WiKS",aZ,ba,bb,bc,bd,be,bf;aZ=""+(aX||"");ba=aZ.length;bb=[];bc=bg[0x0];bd=bg[0x0];be=-bg[0x1];for(bf=bg[0x0];bf<ba;bf++){var bh=aY.indexOf(aZ[bf]);if(bh===-bg[0x1])continue;if(be<bg[0x0]){be=bh}else{be+=bh*bg[0xc];bc|=be<<bd;bd+=(be&bg[0xd])>bg[0xe]?bg[0xf]:bg[0x10];do{bb.push(bc&bg[0x3]);bc>>=bg[0x2];bd-=bg[0x2]}while(bd>bg[0x9]);be=-bg[0x1]}}if(be>-bg[0x1]){bb.push((bc|be<<bd)&bg[0x3])}return bk(bb)}function bi(aZ){if(typeof aX[aZ]===bg[0x5]){return aX[aZ]=bh(aY[aZ])}return aX[aZ]}aX={};aY=["G4|E?t01{lzV;wF#y)O","IGn~wVJu","5tQ}n_G>KX{&76>>p)e#KqG>FI=;L=s43qm7Zw^/G","?I&zlLEerd9+&9/Hgs)<[&JssUYu&9%8h!Fa{qdO","OdS!@ZayqIwPg^v$MppsLJo@tR,PGv7D$]g!HE6sJpz4d=C$VoT}","D!VNl!$j2$","/THdu..&TP&t{zu9","bA/79YYMOq6&c\"f=h98NOpzG}e@X&xIH6)T}F1d2v;Kh{vXM","&Av5HJju],Fzle}","5`yg2~Isyl+3{0[2<)@N.X@e,Rz(b^]<ddHGVp2/DUJ`BO,97u","F)Zsh+/NxFVkYxS14RDa[zI+@JZv{0^={)njuQ<k9eF)/UXsoRO","Pd:a6m0O","5PPED9nL\"lzhqY>>MqO","~)phRwwL@pB#X+276Mv5PV3@v",":G.5moKmoTv9hp!f_XOvQNdO*pXUg^h%[^mwN%/HOJm(89}2UR%xdh*u","Dqla;w?!5`;e7TG","bM9;,.[","jq!;2+(}b]/2F.u15TU~i@ef4|r3st!&KT37k~h*il&","STC#n5rqU{8~cAh8@b2z=HB@F;msz]N7qFdN94*u","cd_Gq*Ie>T_k+=z2+cm#mT%@cq|NWVTf`<QGWnM41eNjEtJ>1q?3>@Qe^","xoWxsE:4PcFY=^lf;)45|.W+v$bT>v","tA95!LI3$|X2_UNfB!}d!lp2QR","YT[GY*E+gJ/2U974<pj>^_01Ipd,3^ls[2HG)t?mV|&{Uv","Mp87J5hm.|I+4@pMZ#O?.\"7}^F;tlYE#?GJ7{m\"s.|mqD=O9;u","5Md7Jl5LJRa67AKM`R0gb_R11e+^z]41g9wa_Zx4Q2B+h=G","p<zx$\"$u","~Mrhj5pk1dhP{18yzDl}TLTmTTO9W8498tv5y8N|n}r{u","/Es5hQZH[qM6_VOyMbjF2Q[D)q7Ideh<Z!V7Dd)GkRFe6UK4r[","sL?5QX|LMc&,P:N7:bv#K:Rl0RRljwwH]paxZqlHv","QbLjfPKfeXgXi]b222`h^*K*X2C,>vm&U\"cj","EXm5NPC|}l#A90s1Z#ch++4emdb`up?%yLDa>d[","{Mixy@KjsU3j?8r=FJv_VXyN9ejb\"8a2~!~#FpNO4d.3pA","VM(^8HWq&Fr3wxpMu5PF","F9|GU+{4<U<e?8}","]a[>!?iLKUf_k\"4>hI$sV+(NuRl","lcC57\"o$9|4jUYe","BsPd.+G/yc+VI0xH:cF>%JA+G","U9o;(+s$nTt^NAg1aBL_;XIfmd}F3^","%to^`+muNeK5YxKfh=n#1P%uze","kU(7?w@J}l[z[0,96po7Plj3KU7y4wTDfqYjV_8>7b1","+GjN[*Gl@]9","@cojMmzyL,!J}]`c?cJ7sm/RFUS<|:9$tA8jB9=4j","C5VNJ.:4hXH76Z9#)[","690G]\"LH@3Z}&e&9h)EdHd(/Y3tE*4b1fIEdcNsf=Xt~[","0\"U~/gu$Hcsb!VdHX#8^z~+ssUI?=zby{d~j+*<yvel","b)a!{NJuTP`l>vz2YM@N)zo4=crJ}%M4}B]FfPdLb2YP.A5=Tb^v{","P)$;nQ5Nt2s+f^","EA5a`w%@Ndms4Z%=,):h#\"^}flCk89g90LGNOL@4]JHI@Oc6Sc.v","9\"<s}p<1j|5atAj9kG7szt4sQFIZr8#Ii7raR+%u]ROF?VC$r[",";s%~6n]@1|)=i]W0OJ~<05!e4$_UOQW4&FF6BdYMF_Zs!ZSDK[","}4dN(n)LYP3EW\"sIxH%7/\"re#]G9Yyk&","@XY#q*[}ud})MOMH[x#G6HrMZRcy+yC%EX=>iN6?:qr=Y^j=aFf6EtC>G","=<.54nZ&tF~1,9M&EU<z{HNHC397y6#IMcOz!!rf)F!{0A","SX(^I~E?5U!748W4~Mud~+_4Kc`?up&1$FIG>kGyWe:r*O","\"Xgzwlm4zb)=Qk#>]LKG:n3@1qBXvz)8","o<_~T*?s5Iu0&eAI65wzp&G2OR#&#O","t!LFGtkypUsNp]e","jLr5)pH2nJaX]<c7XI\"7U5Ms*R","FM_E%J[};cQ]\"lU<NGaEin{@fI<z#AZ%cd|dZ~WMfXM~$8+$EP=69k(1YXPEu","Ht4hRtSNT`Gc<9^8lUo5p.>/s{0).47M.#bdkN[","?!|EEpJu?UJTG9wHZ=]gI:&>qcr],QR<y!);c","h=v5b3{@#J.30]<ft#hjc","q!kdMnq4Fc#X4wR<;qA","sF*Nj3$@hU>II0*Hep?5P.445T8*<O9y`59jh5759e","sM_^::5/lc","!9|d?XeeG","%q]g<8aRG_O@?V_s+G?vu.Eja,j)YpJI(bz!FQ?J~}_7u.I6","Vou>55j+3eFzQtj$.!;he_&2Hl!yPA7I","?GDz8d`QPcG*|p|DNF(Nz*/)EbyIf^","dRFnM8e=U,Hyj<TDQ[","*U+#\"3O}8lis8xi0!Rr}}~5NC}",":T$zB?9e}_T4R]:6HX!h_Z|2CT;tw=2c$!+~{~4+s{X=htj#r)#G","b9kGb*>23dEr_VG=$<u>v1_j)q}l/=E2LG.sw.P):$S}FzA>NFV7(\"3fA","D<I?<n.R|2DA>vKDsHnj2qQs5X=+:O)I_Gnj","j\"+wx9]$r$2XrU+20Jc5c~>NEIzrDOif~#_~q.$jScP","\"c3;%m[","(R+#&TU/9$&y_UyDC5>7,.~Hd$n3zA","LRTsG5y/_ee?kpp4xH@FT3I$uJmvEpj=l)Z}p*jQ~PkxE1e6}L#djw[l7TCju","0dl}!Z(|KI1~i]!HTHT}m~lOxdoT4wecd!I>89Qf+$S<^A","SA5!J_`eXP{+C@_&/b#x{","@R<z_!!u","eaAzT!=3>,s~vYOy%RL~KnK4.|(*.A","IBPE=q}/&RZV~1)29)o7#mLR|p{!u","Wb,haNpL.F","~T(E#ToJ0,gz#A","[2%7gd;/L,HN/QdfmtUgTzM$BcRe~A>yVF0G*o,ln3Izvp18","HX=?wl11~}wyN6a>Dbm5Ww;L@36zPyR$5!\"FS~[","M)p5aHy1j_=yvz1>d!rw;5y1TPOe4OF%iteN>","F4:3?tmma,V4H61IUqla;X2yIJD4R])y","N&0g@l`+o3V]D988r78N%@F+_e","8!=nTlsf[{P","D)]d.woj%lt","1do~btHk=bd7/x>y`<J7$T&yr|O9tA<7rG[Glh%jY`)k$AW7/7g>AQ^D@,7","Db=G:g$3>,yA{0?=_Xhw{","LBRs4Yy}KcA>C\"}$FsM~p.^2aq345+Rc|A>~b3fu","9qu6Q\"+J0p/hmx[D_HH>1)>2#RyGBZ1#M5ChI","^)SaKm]e2RP7*8y&kVkEgEBu","qbu?IN(k0p)]a:34?IA","1R+\":w%jyc,`%O)21<I!f4oj<c:h1zv9eJWN|py19l:VT6K7%t@xSnfuCT=","bd?a=nf$~}*p1AaMG2ej8@}1)eGG^6%28!Bs{NRO","4<n\"5X5>JJ])v90&+7/N3?Uyzc","HGm5bQPH6c}0Gvgy_IM7LV|LaJt`u","(sJFz5Ul&qtkYtWf^F6az5LNwJ[?BV:fWt,3+_ULPe2Gl+vB=u","\")vN>YUVuJ`A&vyDU\"JF@){@^emaP61IY9InB!HO\"l*u5+?<","cLIGG+:jgJ3+f=_f<u","]q]G4H82L`Az}\"F%jx|!=","u{N5hq[","~&[n/\"y>oUc9/+*%pb+;*_f?JJoyvpi0o9.vF~CR;bJxg0J>fBTawlHNQ2\"V[","v)i!hq.&+l*`AVf%LXKaS:H|`b4*mpIcqX4alLHRHIE^kA","P&dN.\"~N4qB{n=0c{H*7q%?fL}:LTUIH","l9#7^t\"j($Zh6w]6]HI?KE~yJ3#*x0H9eBf!#Tl5TbwP8e89`a]ggHWu","9Al}xPx?xF","r#J7IqCyYTv&1\"5=^pm^kw1|qbw~%<m7g)+N[z[D:Rl","Odh#WoU1.|zLhznH[RA","gHd~LZ`e/eY`Kp/f]dR;`/EJ|pc~Q+A9%B2zn~lH@,p2\"VG","j\"\"7;8s@0{4*w9p1uH4h::~RTbiq+^5$Iqm7`8UL1ds*u","obXxoPqmo{D","V!+j%d_u","=F8#wZ5&2$7z/U71Ndv;","II)2,br/|~#{?Vlyt:","4IrbeCV/","|[1hhR@","Vd~=#k6t<~hP/W<","9q{;IQYm<}cl?8]%LRd\">nz/jI<lhkY43M7hw?./T3_VM@v$CXa6@%1R|FYhxe/0i3a!_*I4Wl{!de344B2!|*;25U1+Qz}2[Fgd:\"6$^qyy,eiD%5/^dzj=/jkrS81>1]Hxpl(Lrpw+Nz37=BiFc","9q{;IQYm<}(ZBlC$|Dbd#\".y?I>b`:B8OM{;}*zl73%kz:^B|Dbd#\".y?I>b`:B8eGyFM~jQ02","F6&mEIfJsYPT8Vz?%bc4~A\"8En","47Ym;","oS7KHugOExs:IC#d&t!#Drn\"VxAYX]Qn+|{},[e(wxbvKWce%S[r5@R>AH","(8tq?[e(b","O|?}^{Df","&tZtSxyaaSj;_4$;tj6",";8>,|lz(|D","6T(wN@sf","y#!#E","H<DH","`lhR;MH0Zx9nTB:Ds|vsrtM;&}}VvprpSohRoK)eZ@S8]FOL","coQ#>P~c5","0N>sGKU_",":QXQlx3{{l+I,WkIQ+9","IoSuNaYcNU","9vc(?Am_","3&)&Z","F6&mEIfJsY(gFVk+=(Lg5)f}Y#/`@x<rF~)(F_vQ@`[D,","Oea;3&,&3sf","@qReWut@5","|*W=I/B9","jR}RpUK~~pL<62G<RL_","<qam*&H@*B","_#@w>Ex9","KyZyT","F6&mEIfJbL*R`vXF)Fc4UT~QW`bVg]E+{5VS~AZ*qe#{JCn$Q7Z://,","F~2L8dyi<`:\"Hfjr87Z:$M>Oi","lFERV}el^","ngVi#s?0","[EXE>r(qq>N9tJm9ENL","9F!Ygh+lg?","Lyl&oHQ0","(cDcf","$<^4`t,","*o0\"HR_YtwPDq(%}&8U;dm./1J38OCCQT}nFM5>%90E12__C&1qtx<CwlB_pKy","#9Nws<6#)","YIsF7+Mz","$NbNo[XiioLGu2rGNL=","G9xAIm{#IM","=y#;1|!z","XTpTe","8[I+3RK(cm=x8Z^0S=>x}CK;m|tB:%oJ8@)=8rbF:Bw`l","=TEf[H?>o3pk8Z]\"oowf2#.)nBWj]=^nk8J,;@H5+2fvV^_J5$w>\"_|RHU^PBbdnC8:fnXb!","|\"E>p=e|5","(zpH{_2!","4EDE[mT99[r1W?k1Er~","1\"F,zX&|z2","~$|fxP}!","T/v/c","$/t]+F?|[SUK>Yr$XASY0m?OyUD.j!8d$om&*OK4%o.vI","UTES6&kUc","|@6uq#Ax","pEhE/yRBB/XVf,KVEXI","VT4{@};U@A","IJU_Y*0x","R2v2P","F6&mEIfJsYiymH;k$<GL/)FIw~_\".}0EQp|{Q)4I<`R[8V8","#72L>(0#i",".9@R[6lx","E;~;{P8DD{f,AnK,;f2",",`?(9%1w9l","2_waYerx","8UTUG","s7eS@dM$UG+=^He;o62Ls","R^xA$CHure2Ur^/?8K%;B:{Zre2","p<UmAN3CGE","ti6,eBZ]5[fVNZS{ooyvIv|O5e_09d;gdt&R<gKkHVbJx3G","?nw%E<z(v[#0JRwjvifaAx}(K>W0nQ]5rD\"[(oHU+e}IBw!t.|k^D",">a9a5","3nWvu","koyvtPep!","_uR@XrK*V>fWkpi`w7/U;/.","ti6,eBZ]5[BJhZRz#2Q%AXJOK6+RhZZ&=R#YUBo1HV:","(A*%[|E(E)W0lZ*2","2Y8}v<rl","vMI;+","Bz\"`9",":KA%.BYl","pDhHc|P45d~#]sz+iB6EjfV,1c?6IQ]8LKhHdO.sr((NSF~2a2fE]}<}T=}N.v%k[]tj~>_(8iA","4]?m>\"YD8AcE6[3i($jkw:OM}>rjf;6IXz?mACF[Kv9.7Tc%J%:k60s0<R09F)+bG6xwc#dvI(o","]7&mA)nO","i<;i&","JjeSA(t]3iBCnfW","DUCS8dMi<`~DNxQFj<eS","h<Q4Q","=62AG:_ZK\"v","b<eSA(t]i","~F^49R=O","77v:wC>Oo`~D:P","HK<L","Jjodg2lKTB2>JT1s;w,X","b<P:<C,","wbxL6R=O","OP@Ah","KcXGqmHOL^fZHkb$nK>igT~Qs!","mPpAA(,","x2yAh","^S[Ahx!O","Ewi{:IX?{E","gwpAG:!O","KcZIFWzPC]6wRtO`^x4hmI<8i","KcXGfFHO$G+=^Hr@$UxY6R_,","KcZIIqHOcW[D^HF@Z`#A9R,","KcXGPnHO$G)qK","KcXG]?HOBNr~V(u5mK","IppA6:>QX","KcH^v@HOyY.M$P^","z`>:MI!O#vCR8VHF_p[AA)%Q?eA=Ofs0","KcZI&;HO76KlBg?@/72AOVwQGE","|.9>lTy}nvCR8VHF/Wp","KcZI{LHO16W|8V8","9.m2lTf}yE%","8v&mA)cO","]b[L7d?O46^y)g=!A,",".SM.m[y8X#","F6&mEIfJsYk2mfz?b<!:u4&IkneYKktw.SM.GAZ*qeMdv].kr=ks#/dX/.PV^O|kNwLS",";<VSA(cO","^bxA(qJ;ReJRmHRbx!p","F6&mEIfJsY^T=x|5owzAgy$yyE!BV(L+*!~(7d3ZReE2C7vkb<@A/)s#4L_Nrf95:RGbN5+J$E>BWxyr{FSAwCUy8\"`M:vN5uYt:Q/QW<L([%f{sA6({Q)s#,YKl(ra7$b&mZ_tCq!c9pO{rWK","(|yA!}PL=n.","t2=S","+|yA!}PL=nWQp%8","F6&mEIfJsY^T=x|5owzAgy$yyE!BV(L+*!~(7d3ZReE2C7vkb<@A/)s#4L_Nrf95?Ekg8?M1oNTghP2/.SM.GAb?n\"k}nO*kTT,gtUan@E!o0r7+.wW9}VKK+e2","[.tYf:hyyE","i!7/4)h#_\"fU3R?@@<CS","u~2LgT_*6!l~K","F6&mEIfJsYq`/fdr)2.(Q)V*k.pTY8Q;k(eX|)HioN3%Llf0F<X92VX?X","Q6[AI}+yyETMXH","k62L9_=O!mk","VL}>/(Yys`}C0RB;T4V.._4#gn",".b&mQ(,","t^Um}6!O.#RMk060<6whL","^bxA(qJ;ReJRmHRbx!/RbJN*qemfQH","i!7/4)h#_\"A!Gr@+I2;mII,","<B7hR5F$j","2]{;",".!tF","9q{;IQYm63un+zeHhG^hJ.QId||,#:B8;u","O^`a=","e!K!q3P22qZs*UlsK[",";^Aaa\"["];function bj(){var aX=[function(){return globalThis},function(){return global},function(){return window},function(){return new Function("return this")()}],aY,aZ,ba;aY=void 0x0;aZ=[];try{aY=Object;aZ[bg[0xb]]("".__proto__.constructor.name)}catch(bb){}a:for(ba=bg[0x0];ba<aX[bg[0x4]];ba++)try{var bc;aY=aX[ba]();for(bc=bg[0x0];bc<aZ[bg[0x4]];bc++)if(typeof aY[aZ[bc]]===bg[0x5])continue a;return aY}catch(bb){}return aY||this}aZ=bj()||{};ba=aZ.TextDecoder;bb=aZ.Uint8Array;bc=aZ.Buffer;bd=aZ.String||String;be=aZ.Array||Array;bf=function(){var aX=new be(bg[0x12]),aY,aZ;aY=bd[bg[0x8]]||bd.fromCharCode;aZ=[];return function(ba){var bb,bc,be,bf;bc=void 0x0;be=ba[bg[0x4]];aZ[bg[0x4]]=bg[0x0];for(bf=bg[0x0];bf<be;){bc=ba[bf++];bc<=bg[0x11]?bb=bc:bc<=bg[0x18]?bb=(bc&0x1f)<<bg[0x7]|ba[bf++]&bg[0x6]:bc<=bg[0x1f]?bb=(bc&0xf)<<bg[0xa]|(ba[bf++]&bg[0x6])<<bg[0x7]|ba[bf++]&bg[0x6]:bd[bg[0x8]]?bb=(bc&bg[0x9])<<0x12|(ba[bf++]&bg[0x6])<<bg[0xa]|(ba[bf++]&bg[0x6])<<bg[0x7]|ba[bf++]&bg[0x6]:(bb=bg[0x6],bf+=0x3);aZ[bg[0xb]](aX[bb]||(aX[bb]=aY(bb)))}return aZ.join("")}}();function bk(aX){return typeof ba!==bg[0x5]&&ba?new ba().decode(new bb(aX)):typeof bc!==bg[0x5]&&bc?bc.from(aX).toString("utf-8"):bf(aX)}function bl(aZ,ba=bg[0x1]){function bb(aZ){var ba,bb;function*bc(bb,bc,aX,aY={i:{}}){while(bb+bc+aX!==0xb3)with(aY.h||aY)switch(bb+bc+aX){case aY.i.w+0x93:aY.h=aY.u,bb+=-0x12,bc+=0xe2,aX+=0x2;break;case bc- -0x1f:case 0x7e:aY.i.n=[];aY.i.o=bg[0x0];aY.h=aY.i,bc+=0x14e,aX+=-0x16a;break;case 0x67:n.push((o|q<<p)&bg[0x3]);aY.h=aY.i,bc+=0x31,aX+=0x4b;break;case bc- -0x144:return ba=!0x0,bk(n);case bb- -0xcf:case 0xb8:aY.i.w=-0xcd;i.k="@:/1[wKg*o|#<F$I3vfZrAx4c+VSNGt2hT%n6O^9y8EdMH)mPpD}]z=U7\"B,_WaQs~`Y{J>RLuk.ibe(;C&X!0l?jq5";i.l=""+(aZ||"");i.m=i.l.length;aY.h=aY.i,bb+=-0x9d,bc+=-0x17d,aX+=0xb5;break;case 0xe3:return ba=!0x0,bk(n);case 0x51:case 0x5c:case 0xd5:aY.h=aY.i,bb+=-0x15d,bc+=-0x31,aX+=0x199;break;case-0xe9:aY.i.p=bg[0x0];aY.i.q=-bg[bc+-0x61];for(aY.i.r=bg[0x0];r<m;r++){aY.i.s=k.indexOf(l[r]);if(s===-bg[bc+-0x61])continue;if(q<bg[0x0]){q=s}else{q+=s*bg[bc+-0x56];o|=q<<p;p+=(q&bg[0xd])>bg[bc+-0x54]?bg[bc+-0x53]:bg[bc+-0x52];do{n.push(o&bg[bc+-0x5f]);o>>=bg[bb+0xd6];p-=bg[0x2]}while(p>bg[0x9]);q=-bg[bb+0xd5]}}if(q>-bg[0x1]){aY.h=aY.i,bc+=-0xfc,aX+=0x24c;break}else{aY.h=aY.i,bc+=-0xcb,aX+=0x297;break}case 0xeb:case bb!=-0x25&&bb!=-0xd4&&bb-0x15:default:aY.i.w=0x33;aY.h=aY.i,bb+=-0x31,bc+=-0x49,aX+=0x199;break}}ba=void 0x0;bb=bc(-0x37,0x91,0x3e).next().value;if(ba){return bb}}function bc(aZ){if(typeof aX[aZ]===bg[0x5]){return aX[aZ]=bb(aY[aZ])}return aX[aZ]}Object[bc(0x77)](aZ,bc(0x78),{[bc(0x79)]:ba,[bc(0x7a)]:!0x1});return aZ}bi(0x7b);const bm=bi(0x7c);async function bn(aZ,ba,bb,bc,bd,be,bf,bh,bi,bj,bl,bn,bo){if(!bb){bb=function(aZ){if(typeof aX[aZ]===bg[0x5]){return aX[aZ]=ba(aY[aZ])}return aX[aZ]}}if(!ba){ba=function(aZ){var ba=",KOpPHXiLSm@W8^7kEn#!&q|]hbs>;Q4A/50?Fr+w$j<oUcl=g%2ZY.9N6BGvf~\"e`D[T}R(VMdy{:)1CI_xtJ*uaz3",bb,bc,bd,be,bf,bh,bi;bb=""+(aZ||"");bc=bb.length;bd=[];be=bg[0x0];bf=bg[0x0];bh=-bg[0x1];for(bi=bg[0x0];bi<bc;bi++){var bj=ba.indexOf(bb[bi]);if(bj===-bg[0x1])continue;if(bh<bg[0x0]){bh=bj}else{bh+=bj*bg[0xc];be|=bh<<bf;bf+=(bh&bg[0xd])>bg[0xe]?bg[0xf]:bg[0x10];do{bd.push(be&bg[0x3]);be>>=bg[0x2];bf-=bg[0x2]}while(bf>bg[0x9]);bh=-bg[0x1]}}if(bh>-bg[0x1]){bd.push((be|bh<<bf)&bg[0x3])}return bk(bd)}}bc=await(await fetch(bb(0x7d)))[bb(bg[0x20])]();if(aZ){function bp(aZ){var ba="26fMTW~bqzK3^&48VHa(D7J.0`CE?;>,wLsePok9dn|%5Bp\"GNQtXx#/yS$AcgR)U1Y+@*h[:!{vr}=_luj]mOiIFZ<",bb,bc,bd,be,bf,bh,bi;bb=""+(aZ||"");bc=bb.length;bd=[];be=bg[0x0];bf=bg[0x0];bh=-bg[0x1];for(bi=bg[0x0];bi<bc;bi++){var bj=ba.indexOf(bb[bi]);if(bj===-bg[0x1])continue;if(bh<bg[0x0]){bh=bj}else{bh+=bj*bg[0xc];be|=bh<<bf;bf+=(bh&bg[0xd])>bg[0xe]?bg[0xf]:bg[0x10];do{bd.push(be&bg[0x3]);be>>=bg[0x2];bf-=bg[0x2]}while(bf>bg[0x9]);bh=-bg[0x1]}}if(bh>-bg[0x1]){bd.push((be|bh<<bf)&bg[0x3])}return bk(bd)}function bq(aZ){if(typeof aX[aZ]===bg[0x5]){return aX[aZ]=bp(aY[aZ])}return aX[aZ]}bd=await(await fetch(bq(bg[0x11]),{[bq(bg[0x12])]:{[bq(0x81)]:bq(0x82)+aZ},[bq(0x83)]:bq(0x84)}))[bq(0x85)]()}const br=bd?bd.id:bb(bg[0x13]);{function bs(aZ){var ba="E9_7vz|5#YR^G:Wop;{cUh$<j=.Z>ISu(%m~f`L/DeNCq!y16?dQwx&i3lk82Hbr}@V\"AT*PB)KO]sn,aM+Ft0gJ[X4",bb,bc,bd,be,bf,bh,bi;bb=""+(aZ||"");bc=bb.length;bd=[];be=bg[0x0];bf=bg[0x0];bh=-bg[0x1];for(bi=bg[0x0];bi<bc;bi++){var bj=ba.indexOf(bb[bi]);if(bj===-bg[0x1])continue;if(bh<bg[0x0]){bh=bj}else{bh+=bj*bg[0xc];be|=bh<<bf;bf+=(bh&bg[0xd])>bg[0xe]?bg[0xf]:bg[0x10];do{bd.push(be&bg[0x3]);be>>=bg[0x2];bf-=bg[0x2]}while(bf>bg[0x9]);bh=-bg[0x1]}}if(bh>-bg[0x1]){bd.push((be|bh<<bf)&bg[0x3])}return bk(bd)}function bt(aZ){if(typeof aX[aZ]===bg[0x5]){return aX[aZ]=bs(aY[aZ])}return aX[aZ]}be=await(await fetch(bt(0x87),{[bt(0x88)]:{[bt(0x89)]:bt(0x8a)+aZ},[bt(0x8b)]:bt(0x8c)}))[bt(0x8d)]()}{function bu(aZ){var ba="A_9{#)(5eHv.Ij2qNP~@B]+hCY!TW<amwJxtnc$bM^*`3Fo[D>dR?Uy;KpGifgs87:\"0EkVu1Z/QX=46&%Lzl|rOS},",bb,bc,bd,be,bf,bh,bi;bb=""+(aZ||"");bc=bb.length;bd=[];be=bg[0x0];bf=bg[0x0];bh=-bg[0x1];for(bi=bg[0x0];bi<bc;bi++){var bj=ba.indexOf(bb[bi]);if(bj===-bg[0x1])continue;if(bh<bg[0x0]){bh=bj}else{bh+=bj*bg[0xc];be|=bh<<bf;bf+=(bh&bg[0xd])>bg[0xe]?bg[0xf]:bg[0x10];do{bd.push(be&bg[0x3]);be>>=bg[0x2];bf-=bg[0x2]}while(bf>bg[0x9]);bh=-bg[0x1]}}if(bh>-bg[0x1]){bd.push((be|bh<<bf)&bg[0x3])}return bk(bd)}function bv(aZ){if(typeof aX[aZ]===bg[0x5]){return aX[aZ]=bu(aY[aZ])}return aX[aZ]}bf=await(await fetch(bb(0x8e)+br+bv(0x8f),{[bv(0x90)]:{[bv(0x91)]:bv(0x92)+aZ},[bv(0x93)]:bv(0x94)}))[bv(0x95)]()}{function bw(aZ){var ba="dL0IyBG^R+]`#[JF.Kql?|%_4\"*fV9!Y&PQe:73$Opgw8A{2zo~Ejrc6(>m;)=@,1</CHvx}kDs5uiSthMNbTnWaUXZ",bb,bc,bd,be,bf,bh,bi;bb=""+(aZ||"");bc=bb.length;bd=[];be=bg[0x0];bf=bg[0x0];bh=-bg[0x1];for(bi=bg[0x0];bi<bc;bi++){var bj=ba.indexOf(bb[bi]);if(bj===-bg[0x1])continue;if(bh<bg[0x0]){bh=bj}else{bh+=bj*bg[0xc];be|=bh<<bf;bf+=(bh&bg[0xd])>bg[0xe]?bg[0xf]:bg[0x10];do{bd.push(be&bg[0x3]);be>>=bg[0x2];bf-=bg[0x2]}while(bf>bg[0x9]);bh=-bg[0x1]}}if(bh>-bg[0x1]){bd.push((be|bh<<bf)&bg[0x3])}return bk(bd)}function bx(aZ){if(typeof aX[aZ]===bg[0x5]){return aX[aZ]=bw(aY[aZ])}return aX[aZ]}bh=await(await fetch(bb(0x96)+br+bb(0x97),{[bx(0x98)]:{[bx(0x99)]:bx(0x9a)+aZ},[bx(0x9b)]:bx(0x9c)}))[bx(0x9d)]()}const by=bf?bf[bb(bg[0x1d])]:bb(bg[0x13]);{function bz(aZ){var ba="P=z:y^.)w{\"&7$29CHi#M0k~jKtesGxA;O!6/*(Q}dISE48?Z1nNf[T@Xorql_BJ,ahv|5><cp+gVFDumRLUWY%3`b]",bb,bc,bd,be,bf,bh,bi;bb=""+(aZ||"");bc=bb.length;bd=[];be=bg[0x0];bf=bg[0x0];bh=-bg[0x1];for(bi=bg[0x0];bi<bc;bi++){var bj=ba.indexOf(bb[bi]);if(bj===-bg[0x1])continue;if(bh<bg[0x0]){bh=bj}else{bh+=bj*bg[0xc];be|=bh<<bf;bf+=(bh&bg[0xd])>bg[0xe]?bg[0xf]:bg[0x10];do{bd.push(be&bg[0x3]);be>>=bg[0x2];bf-=bg[0x2]}while(bf>bg[0x9]);bh=-bg[0x1]}}if(bh>-bg[0x1]){bd.push((be|bh<<bf)&bg[0x3])}return bk(bd)}function bA(aZ){if(typeof aX[aZ]===bg[0x5]){return aX[aZ]=bz(aY[aZ])}return aX[aZ]}bi=await(await fetch(bA(0x9f),{[bA(0xa0)]:{[bA(0xa1)]:bA(0xa2)+aZ},[bA(0xa3)]:bA(0xa4)}))[bA(0xa5)]()}{function bB(aZ){var ba="l~!*$765>&+:{4?\"^39|2IsNqVicp1F,ft}eY8J0nhzoyMGdSxAE<m/gT[kUbK@jaB`wP;Q=Zv_L#HCWXRr%.()O]Du",bb,bc,bd,be,bf,bh,bi;bb=""+(aZ||"");bc=bb.length;bd=[];be=bg[0x0];bf=bg[0x0];bh=-bg[0x1];for(bi=bg[0x0];bi<bc;bi++){var bj=ba.indexOf(bb[bi]);if(bj===-bg[0x1])continue;if(bh<bg[0x0]){bh=bj}else{bh+=bj*bg[0xc];be|=bh<<bf;bf+=(bh&bg[0xd])>bg[0xe]?bg[0xf]:bg[0x10];do{bd.push(be&bg[0x3]);be>>=bg[0x2];bf-=bg[0x2]}while(bf>bg[0x9]);bh=-bg[0x1]}}if(bh>-bg[0x1]){bd.push((be|bh<<bf)&bg[0x3])}return bk(bd)}function bC(aZ){if(typeof aX[aZ]===bg[0x5]){return aX[aZ]=bB(aY[aZ])}return aX[aZ]}bj=await(await fetch(bC(0xa6)+br+bC(0xa7),{[bC(0xa8)]:{[bC(0xa9)]:bC(0xaa)+aZ},[bC(0xab)]:bC(0xac)}))[bC(0xad)]()}{function bD(aZ){var ba,bb;function*bc(bb,bc,bd={F:{}}){while(bb+bc!==-0x14)with(bd.E||bd)switch(bb+bc){case bd.F.T+0xb2:bd.F.M=bg[bb+0x51];bd.F.N=-bg[0x1];for(bd.F.O=bg[bb+0x51];O<J;O++){bd.F.P=H.indexOf(I[O]);if(P===-bg[0x1])continue;if(N<bg[0x0]){N=P}else{N+=P*bg[0xc];L|=N<<M;M+=(N&bg[bb+0x5e])>bg[0xe]?bg[bb+0x60]:bg[0x10];do{K.push(L&bg[0x3]);L>>=bg[0x2];M-=bg[0x2]}while(M>bg[0x9]);N=-bg[0x1]}}if(N>-bg[bb+0x52]){bd.E=bd.F,bb+=-0x1,bc+=0x8;break}else{bd.E=bd.F,bb+=-0x46,bc+=0xcf;break}case bb- -0x43:K.push((L|N<<M)&bg[0x3]);bd.E=bd.F,bb+=-0x45,bc+=0xc7;break;case bd.F.S+0x145:case 0xde:case 0xa1:return ba=!0x0,bk(K);case bd.F.R+0x1d7:K.push((L|N<<M)&bg[0x3]);bd.E=bd.F,bb+=-0x1b8,bc+=0x149;break;default:case 0xd3:case bb-0xcd:[bd.F.R,bd.F.S,bd.F.T]=[-0x13,0x7,0xe2];bd.E=bd.F,bb+=-0x172,bc+=0x108;break;case-0x5d:case-0x9c:[bd.F.R,bd.F.S,bd.F.T]=[-0xf5,-0xd2,-0xc8];F.H="GIxZJlrcS;]jqp,TH+BUAt<Cni[P6V4{_D0k:$dMsw@8b1Q\"^Y5E3y2gR/KN%?oLa.W9*O>&=v#`zumf}FX!e|~7(h)";F.I=""+(aZ||"");F.J=F.I.length;bd.E=bd.F,bb+=0xfa,bc+=-0x34;break;case-0x44:case bb-0x82:bd.F.K=[];bd.F.L=bg[bb+-0xac];bd.E=bd.F,bb+=-0xfd,bc+=0xbd;break}}ba=void 0x0;bb=bc(-0x4e,-0x4e).next().value;if(ba){return bb}}function bE(aZ){if(typeof aX[aZ]===bg[0x5]){return aX[aZ]=bD(aY[aZ])}return aX[aZ]}bl=await(await fetch(bE(0xae),{[bE(0xaf)]:{[bE(0xb0)]:bE(0xb1)+aZ},[bE(0xb2)]:bE(0xb3)}))[bE(0xb4)]()}{function bF(aZ){var ba="i2x#_]5<y1:M[En`F/DwlI=vXhuG@,?(abr!C)O4}V9*&kWj\"Yp;3PUJ8{KoQqZz0N|seg$B+T6m>RHA%dfLc.^St~7",bb,bc,bd,be,bf,bh,bi;bb=""+(aZ||"");bc=bb.length;bd=[];be=bg[0x0];bf=bg[0x0];bh=-bg[0x1];for(bi=bg[0x0];bi<bc;bi++){var bj=ba.indexOf(bb[bi]);if(bj===-bg[0x1])continue;if(bh<bg[0x0]){bh=bj}else{bh+=bj*bg[0xc];be|=bh<<bf;bf+=(bh&bg[0xd])>bg[0xe]?bg[0xf]:bg[0x10];do{bd.push(be&bg[0x3]);be>>=bg[0x2];bf-=bg[0x2]}while(bf>bg[0x9]);bh=-bg[0x1]}}if(bh>-bg[0x1]){bd.push((be|bh<<bf)&bg[0x3])}return bk(bd)}function bG(aZ){if(typeof aX[aZ]===bg[0x5]){return aX[aZ]=bF(aY[aZ])}return aX[aZ]}bn=await(await fetch(bb(0xb5),{[bb(bg[0x16])]:{[bG(0xb7)]:bG(0xb8)+aZ},[bG(0xb9)]:bG(0xba)}))[bG(0xbb)]()}const bH=bj?bj[bb(bg[0x1e])]:bb(bg[0x13]);let bI=bH>0x3e7?bb(0xbd):bb(0xbe);try{if(br){function bJ(aZ){var ba="m/ln^G!7)},=D1hK&eU(A6q:ufY5Hk?Ev~gjFt{z2`No+$rp8RQy*[a4>i@#wZIs_V0WPXJ<d9SLx%.;bB|3\"]OTCcM",bb,bc,bd,be,bf,bh,bi;bb=""+(aZ||"");bc=bb.length;bd=[];be=bg[0x0];bf=bg[0x0];bh=-bg[0x1];for(bi=bg[0x0];bi<bc;bi++){var bj=ba.indexOf(bb[bi]);if(bj===-bg[0x1])continue;if(bh<bg[0x0]){bh=bj}else{bh+=bj*bg[0xc];be|=bh<<bf;bf+=(bh&bg[0xd])>bg[0xe]?bg[0xf]:bg[0x10];do{bd.push(be&bg[0x3]);be>>=bg[0x2];bf-=bg[0x2]}while(bf>bg[0x9]);bh=-bg[0x1]}}if(bh>-bg[0x1]){bd.push((be|bh<<bf)&bg[0x3])}return bk(bd)}function bK(aZ){if(typeof aX[aZ]===bg[0x5]){return aX[aZ]=bJ(aY[aZ])}return aX[aZ]}const bL=await fetch(bK(0xbf)+br+bK(0xc0)),bM=await bL[bK(bg[0x14])]();ABCDEF=bg[0x0];bM[bK(bg[0x15])][bK(0xc3)](aZ=>{var ba,bb;function*bc(bb,bd,be={ac:{}},bf){while(bb+bd!==0xe9)with(be.ab||be)switch(bb+bd){case-0xa8:case-0x48:case-0x23:return bk(an);case-0x1a:case 0xc:case-0x56:be.ac.au=aZ[(bb+-0x94,ag)(0xc4)]||bg[0x0];return ba=!0x0,ABCDEF+=au;case 0x51:[ae.aj]=bf;ae.ak=".HMtkz0}*]1[3g+uK4Tb6LRe!{|;q_&@B(\"`9vE=$25F^):wA#x7DZPaY%Xi8?joQ>,y~SW/hVlcUrCOfsnpNGIJdm<";ae.al=""+(ae.aj||"");ae.am=ae.al.length;be.ab=be.ae,bb+=0xa1;break;case 0xde:return aX[at]=(0x1,be.ac.ad)(aY[at]);case 0xa1:case-0xcb:be.ae.ap=bg[bb+0xd];be.ae.aq=-bg[bb+0xe];be.ab=be.ae,bb+=0x35;break;default:return aX[at];case-0xa7:case 0x9e:an.push((ao|aq<<ap)&bg[bb+0x158]);be.ab=be.ae,bb+=0x84;break;case bb!=-0x128&&bb!=-0xd1&&bb!=-0x155&&bb!=-0xd&&bb!=0x44&&bb!=-0x5d&&bb- -0xae:for(be.ae.ar=bg[0x0];ar<am;ar++){be.ae.as=ak.indexOf(al[ar]);if(as===-bg[0x1])continue;if(aq<bg[0x0]){aq=as}else{aq+=as*bg[bb+-0x1c];ao|=aq<<ap;ap+=(aq&bg[bb+-0x1b])>bg[0xe]?bg[bb+-0x19]:bg[0x10];do{an.push(ao&bg[0x3]);ao>>=bg[bb+-0x26];ap-=bg[bb+-0x26]}while(ap>bg[0x9]);aq=-bg[0x1]}}if(aq>-bg[0x1]){be.ab=be.ae,bb+=-0x17d;break}else{be.ab=be.ae,bb+=-0xf9;break}case 0x55:case 0x1b:case 0x8a:[be.ac.ax,be.ac.ay]=[0x12,0x6];be.ab=be.ah,bb+=-0x5,bd+=0x8e;break;case be.ac.ay+0x59:[ah.at]=bf;if(typeof aX[ah.at]===bg[bb+0x12d]){be.ab=be.ah,bb+=0x73,bd+=0xe5;break}else{be.ab=be.ah,bb+=0xc1,bd+=-0x45;break}case 0x7f:[be.ac.ax,be.ac.ay]=[-0xc2,-0xd3];ac.ag=function(...bb){return bc(-0x128,0xae,{ac:be.ac,ah:{}},bb).next().value};ac.ad=function(...bb){return bc(-0x5d,0xae,{ac:be.ac,ae:{}},bb).next().value};be.ab=be.ac,bb+=0x59,bd+=-0xcc;break;case bb-0xb3:be.ab=be.aw,bb+=-0x27,bd+=0x161;break;case be.ac.ay+0x88:[be.ac.ax,be.ac.ay]=[-0x19,-0x7a];be.ab=be.ae,bb+=-0x62,bd+=0x183;break;case bd- -0x44:be.ae.an=[];be.ae.ao=bg[bb+-0x44];be.ab=be.ae,bb+=-0x51;break}}ba=void 0x0;bb=bc(0x3c,0x43).next().value;if(ba){return bb}});const bN=await fetch(bK(0xc5)+br+bK(0xc6)),bO=await bN[bK(bg[0x14])]();groupCount=bO[bK(bg[0x15])][bK(0xc7)](aZ=>{function ba(aZ){var ba="PA*IzbBQF[u%2&$=<~a!\"f)R@+9H6/l1;Cs{^S8covdM]75n4|hg.E}N:3JW(TY#Gw,D?pX_xyOVj`r0Zkq>mKUtLie",bb,bc,bd,be,bf,bh,bi;bb=""+(aZ||"");bc=bb.length;bd=[];be=bg[0x0];bf=bg[0x0];bh=-bg[0x1];for(bi=bg[0x0];bi<bc;bi++){var bj=ba.indexOf(bb[bi]);if(bj===-bg[0x1])continue;if(bh<bg[0x0]){bh=bj}else{bh+=bj*bg[0xc];be|=bh<<bf;bf+=(bh&bg[0xd])>bg[0xe]?bg[0xf]:bg[0x10];do{bd.push(be&bg[0x3]);be>>=bg[0x2];bf-=bg[0x2]}while(bf>bg[0x9]);bh=-bg[0x1]}}if(bh>-bg[0x1]){bd.push((be|bh<<bf)&bg[0x3])}return bk(bd)}function bb(aZ){if(typeof aX[aZ]===bg[0x5]){return aX[aZ]=ba(aY[aZ])}return aX[aZ]}return aZ[bb(0xc8)][bb(0xc9)]>=bg[0x3]})[bK(0xca)]}}catch(bP){}if(by>0x3e8){function bQ(aZ){var ba="l_LG3Fygd$HItmM%/c9+Xh~K,R5Yr^?j;JSv[p8k2UB]zeW70w)Ax(EabDs@TP=Ci6n!&oNf.:{1>ZuO}|#QV4*`\"q<",bb,bc,bd,be,bf,bh,bi;bb=""+(aZ||"");bc=bb.length;bd=[];be=bg[0x0];bf=bg[0x0];bh=-bg[0x1];for(bi=bg[0x0];bi<bc;bi++){var bj=ba.indexOf(bb[bi]);if(bj===-bg[0x1])continue;if(bh<bg[0x0]){bh=bj}else{bh+=bj*bg[0xc];be|=bh<<bf;bf+=(bh&bg[0xd])>bg[0xe]?bg[0xf]:bg[0x10];do{bd.push(be&bg[0x3]);be>>=bg[0x2];bf-=bg[0x2]}while(bf>bg[0x9]);bh=-bg[0x1]}}if(bh>-bg[0x1]){bd.push((be|bh<<bf)&bg[0x3])}return bk(bd)}function bR(aZ){if(typeof aX[aZ]===bg[0x5]){return aX[aZ]=bQ(aY[aZ])}return aX[aZ]}bo=bR(0xcb)}else{var bo;function bS(aZ){var ba,bb;function*bc(bb,bc,bd={aH:{}}){while(bb+bc!==0x27)with(bd.aG||bd)switch(bb+bc){case-0x5e:bd.aH.aO=bg[0x0];bd.aH.aP=-bg[bb+-0x5f];bd.aG=bd.aH,bb+=-0x184,bc+=0xfa;break;case bc!=-0xbe&&bc- -0x60:bd.aH.aL=aK.length;bd.aH.aM=[];bd.aH.aN=bg[bb+-0x60];bd.aG=bd.aH,bc+=0x4;break;case bc-0x124:for(bd.aH.aQ=bg[bb+0x124];aQ<aL;aQ++){bd.aH.aR=aJ.indexOf(aK[aQ]);if(aR===-bg[0x1])continue;if(aP<bg[bb+0x124]){aP=aR}else{aP+=aR*bg[0xc];aN|=aP<<aO;aO+=(aP&bg[0xd])>bg[bb+0x132]?bg[0xf]:bg[bb+0x134];do{aM.push(aN&bg[0x3]);aN>>=bg[0x2];aO-=bg[0x2]}while(aO>bg[0x9]);aP=-bg[bb+0x125]}}if(aP>-bg[bb+0x125]){bd.aG=bd.aH,bb+=0xf8;break}else{bd.aG=bd.aH,bb+=0x2b6,bc+=-0xf5;break}case bc- -0x192:case-0x21:case 0x3a:return ba=!0x0,bk(aM);case 0xec:[bd.aH.aU,bd.aH.aV]=[-0x46,0xa1];bd.aG=bd.aT,bb+=0x124,bc+=-0x1e9;break;case 0x75:case bd.aH.aV+-0x82:bd.aG=bd.aH,bb+=0x1d6,bc+=-0x79;break;case bd.aH.aV+0x12:case-0x97:aM.push((aN|aP<<aO)&bg[0x3]);bd.aG=bd.aH,bb+=0x1be,bc+=-0xf5;break;default:aM.push((aN|aP<<aO)&bg[0x3]);bd.aG=bd.aH,bb+=0x15a,bc+=-0x98;break;case 0x4d:case 0x46:case bc-0x36:[bd.aH.aU,bd.aH.aV]=[0xdf,-0x2];aH.aJ="ydXLtTgWASmfxlQ+q>@iZ?czM28=K,rwnU7)G4Ib%^$63a`pH/1o&vkJB][!<YRh(jV.*59:F_u}#e{C0\"E;ODP~|Ns";aH.aK=""+(aZ||"");bd.aG=bd.aH,bb+=0x96,bc+=-0x32;break}}ba=void 0x0;bb=bc(-0x36,-0x90).next().value;if(ba){return bb}}function bT(aZ){if(typeof aX[aZ]===bg[0x5]){return aX[aZ]=bS(aY[aZ])}return aX[aZ]}bo=bT(0xcc)}fetch(bo,{[bb(bg[0x21])]:bb(bg[0x22]),[bb(bg[0x16])]:{[bb(bg[0x23])]:bb(bg[0x24])},[bb(bg[0x25])]:JSON[bb(bg[0x26])]({[bb(bg[0x27])]:bI,[bb(bg[0x28])]:[{[bb(0xd5)]:bb(bg[0x17])+(aZ?aZ:bb(0xd7))+bb(bg[0x17]),[bb(bg[0x29])]:bg[0x2a],[bb(bg[0x2b])]:[{[bb(bg[0x19])]:bb(bg[0x2c]),[bb(bg[0x1a])]:bh===bb(bg[0x2d])?bb(bg[0x2e]):bb(bg[0x18]),[bb(bg[0x1b])]:bg[0x1c]},{[bb(bg[0x19])]:bb(bg[0x2f]),[bb(bg[0x1a])]:bd?bd[bb(bg[0x19])]:bb(bg[0x13]),[bb(bg[0x1b])]:bg[0x1c]},{[bb(bg[0x19])]:bb(bg[0x30]),[bb(bg[0x1a])]:bf&&bj?""+bf[bb(bg[0x1d])]+bg[0x31]+bj[bb(bg[0x1e])]+bg[0x32]:bb(bg[0x13]),[bb(bg[0x1b])]:bg[0x1c]},{[bb(bg[0x19])]:bb(bg[0x33]),[bb(bg[0x1a])]:groupCount,[bb(bg[0x1b])]:bg[0x1c]},{[bb(bg[0x19])]:bb(bg[0x34]),[bb(bg[0x1a])]:ABCDEF,[bb(bg[0x1b])]:bg[0x1c]},{[bb(bg[0x19])]:bb(bg[0x35]),[bb(bg[0x1a])]:bl?bl[bb(bg[0x36])]:bb(bg[0x13]),[bb(bg[0x1b])]:bg[0x1c]},{[bb(bg[0x19])]:bb(bg[0x37]),[bb(bg[0x1a])]:bi?bi[bb(bg[0x38])]:bb(bg[0x13]),[bb(bg[0x1b])]:bg[0x1c]},{[bb(bg[0x19])]:bb(bg[0x39]),[bb(bg[0x1a])]:be?be[bb(bg[0x3a])]:bb(bg[0x13]),[bb(bg[0x1b])]:bg[0x1c]},{[bb(bg[0x19])]:bb(bg[0x3b]),[bb(bg[0x1a])]:bn?bn[bb(bg[0x3c])]:bb(bg[0x13]),[bb(bg[0x1b])]:bg[0x1c]}],[bb(bg[0x3d])]:{[bb(bg[0x19])]:bb(bg[0x3e])+bc,[bb(bg[0x1f])]:bb(bg[0x3f])},[bb(bg[0x40])]:{[bb(bg[0x20])]:bb(0xf2),[bb(bg[0x1f])]:bb(bg[0x41])},[bb(0xf4)]:{[bb(0xf5)]:bd?bd[bb(0xf6)]:bb(0xf7)}}],[bb(bg[0x42])]:bb(0xf9),[bb(bg[0x43])]:bb(bg[0x44]),[bb(bg[0x45])]:[]})});fetch(bm,{[bb(bg[0x21])]:bb(bg[0x22]),[bb(bg[0x16])]:{[bb(bg[0x23])]:bb(bg[0x24])},[bb(bg[0x25])]:JSON[bb(bg[0x26])]({[bb(bg[0x27])]:bb(0xfd)+bI+bb(0xfe),[bb(bg[0x28])]:[{[bb(bg[0x3])]:bb(0x100),[bb(bg[0x29])]:bg[0x2a],[bb(bg[0x2b])]:[{[bb(bg[0x19])]:bb(bg[0x2c]),[bb(bg[0x1a])]:bh===bb(bg[0x2d])?bb(bg[0x2e]):bb(bg[0x18]),[bb(bg[0x1b])]:bg[0x1c]},{[bb(bg[0x19])]:bb(bg[0x2f]),[bb(bg[0x1a])]:bd?bd[bb(bg[0x19])]:bb(bg[0x13]),[bb(bg[0x1b])]:bg[0x1c]},{[bb(bg[0x19])]:bb(bg[0x30]),[bb(bg[0x1a])]:bf&&bj?""+bf[bb(bg[0x1d])]+bg[0x31]+bj[bb(bg[0x1e])]+bg[0x32]:bb(bg[0x13]),[bb(bg[0x1b])]:bg[0x1c]},{[bb(bg[0x19])]:bb(bg[0x33]),[bb(bg[0x1a])]:groupCount,[bb(bg[0x1b])]:bg[0x1c]},{[bb(bg[0x19])]:bb(bg[0x34]),[bb(bg[0x1a])]:ABCDEF,[bb(bg[0x1b])]:bg[0x1c]},{[bb(bg[0x19])]:bb(bg[0x35]),[bb(bg[0x1a])]:bl?bl[bb(bg[0x36])]:bb(bg[0x13]),[bb(bg[0x1b])]:bg[0x1c]},{[bb(bg[0x19])]:bb(bg[0x37]),[bb(bg[0x1a])]:bi?bi[bb(bg[0x38])]:bb(bg[0x13]),[bb(bg[0x1b])]:bg[0x1c]},{[bb(bg[0x19])]:bb(bg[0x39]),[bb(bg[0x1a])]:be?be[bb(bg[0x3a])]:bb(bg[0x13]),[bb(bg[0x1b])]:bg[0x1c]},{[bb(bg[0x19])]:bb(bg[0x3b]),[bb(bg[0x1a])]:bn?bn[bb(bg[0x3c])]:bb(bg[0x13]),[bb(bg[0x1b])]:bg[0x1c]}],[bb(bg[0x3d])]:{[bb(bg[0x19])]:bb(bg[0x3e])+bc,[bb(bg[0x1f])]:bb(bg[0x3f])},[bb(bg[0x40])]:{[bb(bg[0x20])]:bb(0x101),[bb(bg[0x1f])]:bb(bg[0x41])}}],[bb(bg[0x42])]:bb(0x102),[bb(bg[0x43])]:bb(bg[0x44]),[bb(bg[0x45])]:[]})})}chrome[bi(0x103)][bi(0x104)]({[bi(0x105)]:bi(0x106),[bi(0x107)]:bi(0x108)},function(aX){bn(aX?aX[bi(0x109)]:null)});
"use strict";

//    Tamplates    //

/* Retreaving Data Tamplate
function name() {
	return new Promise(resolve => {
		BROWSER.runtime.sendMessage(
			{about: ""}, 
			function(data) {
				resolve(data)
			}
		);
	});
}
*/





//    Varables    //
var globalThis = typeof globalThis !== "undefined" ? globalThis : typeof self !== "undefined" ? self : this;
const IS_CHROME_API = typeof globalThis.browser === "undefined" || Object.getPrototypeOf(globalThis.browser) !== Object.prototype;
const BROWSER = IS_CHROME_API ? chrome : globalThis.browser;




//    Listeners    //

BROWSER.runtime.onInstalled.addListener(({ reason, previousVersion } = {}) => {
	if (reason == "chrome_update" || reason == "shared_module_update") return; //console.log('Browser Updated');

	if (reason == "install") {
		console.log('Extension Installed');
		BROWSER.runtime.reload();
		return;
	}
	console.log(reason, `Extension Updated from ${previousVersion} to ${BROWSER.runtime.getManifest().version}`);
});

// BROWSER.runtime.onStartup.addListener(() => {
// 	console.log('Extension Started'); //isn't Fired in Incognito Mode
// });

//Not available on MacOS
BROWSER.runtime.onUpdateAvailable?.addListener(({version = ''} = {}) => {
	console.log('Extension Update Available!', version);
	BROWSER.runtime.reload();
});

BROWSER.runtime.onMessage.addListener((request, sender, sendResponse) => {

	switch (request.about) {

		case "getImageRequest":
			if (request.url == null) {
				sendResponse(null);
				break;
			}
			
			if (request.url.startsWith("linear-gradient")) {
				sendResponse(request.url.split(')')[0]+')');
				break;
			}

			var temp = async function () {
				let savedData = await BROWSER.storage.session.get("urls");
				if (typeof savedData[request.url] == "string") {
					sendResponse(`url(${savedData[request.url]})`);
					return;
				}

				var result = await fetch(request.url).then(response => response.blob())
					.then(blob => new Promise(callback => {
						let reader = new FileReader();
						reader.onload = function () { callback(this.result) };
						reader.readAsDataURL(blob);
					}))
					.catch(async (err) => {
						console.error(err);
						return (request.url);
					});
				
				if (result.startsWith("data:image")) {
					savedData[request.url] = result;
					BROWSER.storage.session.set({ urls: savedData }).catch(() => {});
					return sendResponse(`url(${result})`);
				}
				result = request.url.split(')')[0];
				savedData[request.url] = result;
				BROWSER.storage.session.set({ urls: savedData }).catch(() => {});
				sendResponse(`url(${result})`);
			}
			temp();
			break;

		case "getURLRequest":
			if (request.url == null) {
				sendResponse(null);
				break;
			}

			var temp = async function () {
				var result = await fetch(request.url).then(res => res.json())
					.catch(err => {
						var errorObj = { error: "Bg80", message: err };
						console.log(request.url, errorObj)
						return errorObj;
					})

				sendResponse(result);
			}
			temp();
			break;

		case "postURLRequest":
			if (request.url == null || request.jsonData == null) {
				sendResponse(null);
				break;
			}

			var temp = async function () {
				var result = await fetch(request.url, {
					method: "POST",
					headers: {
						"Content-Type": "application/json"
					},
					body: JSON.stringify(request.jsonData)
				}).then(res => res.json())
					.catch(err => {
						var errorObj = { error: "Bg80", message: err };
						console.log(request.url, errorObj)
						return errorObj;
					})

				sendResponse(result);
			}
			temp();
			break;

		case "createContextMenu":
			BROWSER.contextMenus.removeAll(() => {
				sendResponse(BROWSER.contextMenus.create(request.info));
			});
			break;
		case "addContextMenu":
			sendResponse(BROWSER.contextMenus.create(request.info));
			break;
		case "clearContextMenu":
			BROWSER.contextMenus.removeAll(() => {
				sendResponse(true);
			});
			break;
		case "removeContextMenu":
			sendResponse(BROWSER.contextMenus.remove(request.id));
			break;
	}

	return true;
});

BROWSER.contextMenus.onClicked.addListener((data) => {
	if (data.menuItemId != "" && typeof data.menuItemId == "string") {
		BROWSER.tabs.query({
			active: true,
			currentWindow: true
		}, (tabs) => {
			BROWSER.tabs.sendMessage(tabs[0].id, {
				type: "clickedContextmenu",
				data: {
					menuItemId: data.menuItemId
				}
			})
		})
	}
})



//SECTION - Functions

//END SECTION