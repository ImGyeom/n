var aq,ar,as,at,au,av,aw,ax,ay;const az=[0x0,0x1,0x8,0xff,"length","undefined",0x3f,0x6,"fromCodePoint",0x7,0xc,"push",0x5b,0x1fff,0x58,0xd,0xe,0x7f,0x80,0x73,0xae,0xaf,0xc4,0xc8,0xca,0xce,!0x0,0x8b,0xa9,0xdf,0x6b,0xdd,0xba,0xbb,0xbc,0xbd,0xbe,0xbf,0xc0,0xc1,0xc2,0xc6,0xb31856,0xc7,0xc9,0xcb,0xcc,0xcd,0xcf,0xd0," (",")",0xd1,0xd2,0xd3,0xd4,0xd5,0xd6,0xd7,0xd8,0xd9,0xda,0xdb,0xdc,0xde,0xef,0xe1,0xe6,0xe8,0xe9,0xea];function aA(aq){var ar="9hBZOcVzv!Lx[&+d2%6(GY.=5~A4/?aHi|k,T3r7K:P^eDJ_gFqjQ]SwRlC8XsbfU$)uNI{oyE*t@;#}><Wp1n`M\"0m",as,at,au,av,aw,ax,ay;as=""+(aq||"");at=as.length;au=[];av=az[0x0];aw=az[0x0];ax=-az[0x1];for(ay=az[0x0];ay<at;ay++){var aA=ar.indexOf(as[ay]);if(aA===-az[0x1])continue;if(ax<az[0x0]){ax=aA}else{ax+=aA*az[0xc];av|=ax<<aw;aw+=(ax&az[0xd])>az[0xe]?az[0xf]:az[0x10];do{au.push(av&az[0x3]);av>>=az[0x2];aw-=az[0x2]}while(aw>az[0x9]);ax=-az[0x1]}}if(ax>-az[0x1]){au.push((av|ax<<aw)&az[0x3])}return aD(au)}function aB(as){if(typeof aq[as]===az[0x5]){return aq[as]=aA(ar[as])}return aq[as]}aq={};ar=[":bktM|GT96BjWFiTFkdQ#l,&;84LUZTHq[6yv@[ThSX>Iyn/+FIO1p9","ox<jOTNVs8SE}rE(VO1*nqh:R%BsfWHP","`P)j#@*kR&GyBA@AGjV!|_s??YT)<O","3dBtB<$,O","h6nH5Q],^bA4f+:6U3X?$1^I|dlzMAIH","VFx*A8L5_Yn*k~35@H./|_TB","FgVz!X`[\"$);9","EVpi1Il&DY]Eb+73zlW]T>(z[+PY1o*~]9","@$r@fJj?|dA5xq)5!F;/OT.5~%R~[8c5RS_!Z*[6!%Wu9","J%&w;@+TMUr%]Oo30P\"E2@kQ.CD)W~|H&Ntc_3R6{(*;M{AT|VB","Y$bz{k9","+V,iJWvvPx_57BP(\"P{@^,1Ka)Hy_{5P:oB","Y$HQ`o#KA%}]N8tAUNWvP>Y?v%xS`FB5;N7!","X3Oc>q3_I&p][ddK!FoFq;xz<li8JFi6.JEi5pBP)!T","lozQ*X!~T(?LdB&rF3H@&wRJ<f?}A+J(4GI*ZJaQYUkYh","zSqjkFL{Jv9N(r?==loVXyF(GUm;}4a,pDvS~","U8M/!X7(LwqYxrm2Ko_Vs]vU[bt6RZ","C$=|+b4?S&/%X4n:,Z\"V","R8eL!w=?u[I;PWR,{$M/hw\"N((^>pp_ALlGz!}hfjlw/~2THognORkd&O","d6Z?PWbJXRj8ZAc5:^N??,9","DlIwv`tn,lFI]3I~>+6tX1yC@+Ot2XzH^[`Q=Ij(_]t;]O","_Ssz8yf&](]H<Tg4Ngb@K>C5)dy/W<o3?3]*z*___]zZ@ZsT=Jtv","cS.wS;K6GU\"UsTF7R=ME33Iz*8@x,W7(FV>SLbv5/%wzurL","YN,*E<Bv`UR~n5d","bbvSqW,,O&8Og8c5#9","#$f/MDE&Ud6W(r3~a^1;xw9","SDgFXX%:OUT","LO]w|Fa>c(B3xq.kjS3Hn8a5x8LZC3Oab=;zMn#*+)!Z8C?THlZ","xK/?^,mJk[7%{<trx[~V+lSC*G[g;XI~oZWv)1}h","[JLyT>AaD66VS3$TH[)iU7dIJ6htMAVH)Kji5Kxh","[d!a1p9","fS7VXkV6wUp.qsx~l=?H5l;?X$)J1p@(>/|aNk96Ff+%2_\".,AgEf7|_8G","0DQ?@r%:A8e+k3}4tk!S]Rjh","Doi4}p<&.C:>I<TH$%$j~l^n~%S,<Ov(,S(yrE\"[HYQ","uV_!zb7(jX&tY2qK:N`zh<*[p(j","{$nz)<{J.Ur%J3*r=$>Eqj;:e]GW!2PAa$!y87r[CbJE*Ao~n9","$H/;V}N5y$,H%g=k:[9V*XT6ex@R#FgKLh","@RIO_;ft4%NE[8`kXZH/jF>Q8GZtT47(DGZ","BOhaIg^lp!#T|O","*jYHaSs_N!F","\"D(;aSNCG(\".>d4PHSnz`Iw:9Y:>Ey>k#N%j(I^hh6CQ|O","0%sw@bmJ;8<u3F^(Y!wFgfaa`(;d^{.KVXpcD,v5z","|Z@]?_|:PxM;a+AT09","IS@z(r`NrUbxC&:6Sg7/.#lh3U2%.cRk#{,;YQ9","?SY*KEVQP$9NoAXP~$n@IICJTlI{!2b%#xMEvX/5ev","2dcLc}F,ECLk3gO55Kx;Lq9",",?O;@I*k6l{)7+f%YS{Od*#kn(&2S~\"k0vky+rwh","3do/c}Ifeb;~[ZRPkgV@V`BP\"CX","<gL;&wGC7&JES~~kzlp*Ts\"[+)3/*<f?h6KEE@RKJR/@b++",";=gSWr2Jq[WhC~+AfH!ag16CzUj)NpxA0bOc^,5*{U/QKZOa","W$Y@O}=h>f_FC<!~djeLZkWkm$3%h","RA^iywXJ|XiI%Tr~E3w!/8E&g]9N\"O<KPljyMl9","}/j]EXw:@%,5eZX=DkEjNTh(V","F!#H!`o:CbTY\",RPYXsz&p?:Z","a=Pyk,tz9)Jzf+}7rSZ","Ebu*+T`JsR|I&sXPMg\"j1IPUU66a{Fj:(fV!|NUNNU?}~O","NV&w,SgBD6]@n>`/`%.@i#2Bbf0J6c@AU8FvMoEj_6e",";RyS\"pgK#v%b5Zi%QD8i/p;nTSfYQd95x?Oq_frBeY+k7{4:","?G;oS;c]aY!tI<e(,S:VubGQ:bm{O4X=&iH@ub]_F[6}kcy(pgw!YpBa_v/","j$f!]1[vV(3z|25ku=t?;gOPiX@X}B","yHjiS]_hr(O=CssT","7l=/0Q0zz","fg\"E^SSa!$8zhytAF!s*(o{C|fi8ET\".{ZrHRXO6*Gd}G8$T=XJz~_l:VLD","~Xp;o}*`VCxZzAT5RAQ*zk=:&)ou;FeAqZ;A];d&^8t*/Zk%Kg=ETsTCc","JbJH5_j__vAyYyTHVS4*+r=z!bvNSWiTs%o/=qXBH[/b@oh%~JIziESB","&6w/7S=(c","j3=|O]9","\"%ki~Q(,ilb{G8s?gSmjzq6*+)$+T8%4H!o/cg?:lGK","n$it`Q6`U[UF$X~=]DaEYn;f(!!SYgO6nZ`/|>Y?BlKEO1m2GjEi_NRB","RZmi(q/Tf[fJOd`.@$5awW:,:b^>#BB3v*0V;g_:G!9WPs1/KbpcugSCp!","7*Z?oX]nb6hW{<$=O,oE2weQXbT5UZ","fNtAAlL6#diIi2T3r$wQQWiaTl9S~OeAKl^ik8&_A%j>iO?TYX}SA@?(Z","9d)j)g^h","EHJw^E0%IU}]\"p7(8$IOcX9","(Sij0|JaN(8","fgNc?8)6([X,RpqK$Z/;mS?:x$w>$Fl=iNq;;Im[MC%$&2P~4$Ev(<+UY&","FA#@vXr[!b24m<B3p9",";%p]_CV6{(?454;r[h","uN=SVg/U_Y>dJFl:","x^YHs7|:I&.@:yB5yS^?Ok6Qd6~","q[N*j;EjP$fYYXWkyNOz#*]&<fxjxA!Hqk!4\"_;}O","vfp;^f0=_XcS942G+^bO5#u,)l&4^{yAf3g!A#dILbyuxB!","obDQeR5aC%Ml!1v6NV<jRj6*96=%}+)%3*v|U*I=\"CbQ<5?=l9","=SbFX]aBy%Btr3jksSbzGKXB%[q>05+GgA<Vlfxh",">8)?iK.Ch[N{C{AP>b{@i>^zU!l@UXM:(?~tAKW5g6JzR47H<VEj~ls=H)yih","*$za_;RJ;+]6WI)Tig:jGb6U6X0;[yIHFHKS}<qJ*b){`<U6?oa@A","tNcqHSDnF!W~Q4zr/A;Hdl=h!La&e4yrkg;/gRb5V(La@8Q/BSG*ef1>0$lEh","U%mi%Iy[3CWvRdH?5Skj}o)NyGB2Q4_4","4J{FFR9","ZdCj0pQQ5$2t(8)5t=IzuJNC>]r","?KUF>QJB)(QEqF=:kl/Hxwc:c(5&8W02&^5Eg7/5GUqIb&aTrS!46","e3Dw&l9","\"DrHhwB5<S4bZ{#A_!nAUXH?_6","*88?HnEf$dLydAV^SlhyUwZ&B!1cdrt(![ySLID($X&L=W,~vJB","L?^iF{bJ?)y,1_$TI=fE9w]_)[n;9","*3.w7FT[^8]>2ZKAcS\"!@I^&~b%%}Br3pg3wlX^,\"Gmil214eN?L","u/,y?Q/5nUiy)<c3(d`Q7f8h","K*}!q1Qak[q>8{?,IS}OMqM%6XyX;O{3SA2S@qsIq[K+h","88lRDiv:1f<$)MF=k|","&8viw+M:","1_uhhUj","Msfd<g?kyfht:ny","ub/2{{D|","\".*`E%M:","3lYL%<snAvGCtrd7J[Soa#y`z%AC;>s,]=/;qt1`8]w{=_c(ebi4_7T[U!s;F&`2\"]ijw}%,MCYjS&],,^6jU}L6*+TI<yv69!|Spo4(Ol55)&\"P7*`OSyz~`z>umrTaTdKFXC.JuXqIQy]/~^\"!G","3lYL%<sn4]<;0OH2wKjiC;aaLGeF+ss2TAg!&*E:V","3lYL%<sn4]ON&y0TqAJHbif&%6","?o7Ib","#D;CAd4Ofea0!czK}rNz\"5<P,eVpW{8<Mtb~](_@he1RCHm_=D(5%yXGVA","@xr[)(_@1","Ot)~Bb\"Y","}r|rDekQQD.n/gJnr.u","nxG]tS$@t\"","ui@h+yaY","kzNzf","A,DA","fLYI(/F|`7ThJ>=g$qZ$&6/(}PPDZ;&;0oYIo^<u`*0{dHnm","`}|V4LA`:","EM4s_R&[","?|i|,z+==,nuS@7u|nw","u}XUMmI`M&","wW`O<k6[","+DJD{","fLYI(/F|`7y+f>;C5yk+4hFJ7Se*lH,mfXhyf!M0l*#D3","0!HL[8s8[Ck","MIW!=5zM/","uj=#A,<D","ZW~W.vi__.fTg}XTWfd","TIH+j8GMj<","dBMyY|(D","ialaP","!zn_Cmvk2P$xIf8!@!NE0)dcJI2tXOC]agtWd4,$ph[ak?QrcB,jDD/","!d7P3Aw:bIj=~vl}3B,jreT&:","[B7PT*u[:","klTjJAU&","37^7z;(QQz95K\"H5791","5BcEl?W[lU","1<[4X)g&","(|e|F","u,j?*63","#T4re53%qv$R6Kz,NwdCLH1&FhjwG``Bu,fyS[czn4>FI33`NF6q;A`vO?3:+_","tnPv|Aat8","%E|yDXS=","/PZPT7U^^Tx\"2Ig\"Px(","\"n;JEHstES","(_tCFpo=","Uu:ub","OdF!vz:;mwJ=O@,5[Je=P(:/w\"*k`|gSOU}JOVy{`kRrB","Ja<Md?.egvKxO@hnggRM2T)}%kI6hJ,%xOSq/U?W!2M38,9SWARen9\"z?D,NkyH%(O`M%Gy#","\"n<eKJp\"W",";iK?t92#","Z<l<dwa]]dVbI.xb<V7","bn{qiGf\"i2","7A\"M=NP#","a_3_m","fLYI(/F|2kSx8+qf!Vk+4hFJ7Se*lH,mfXhyEJx0MX*<T","eo;g/5GeD","R?/uA*rd","=;B;SXH33S1Y}mbY;1$","YoKU?hte?r","$Iew2![d","HL^L@","fLYI(/F|`7BnIAb;u,{kehf/gX!&}JU(0a%d0h?/,*8#=>=","#<&c_8l#?","/\"_eg}4]","[&@&)Uz66)BZS3%Z&Bv","Z<Iw\":h#\"4","vG#a5nk]","zdbdo","`oPWl^<u9{C5jAPbpL:k`","8jHwuiAtmP:9mjeQ=TObx$dzmP:","a,9Iw\"Ri{(","t*%]^HLX.E\"R&L5u;;<@4@Ti.^N|}0s10t[fz1#AwRKyODb","c>gmxz~)@EF|yfgl@*\"!9O3)#a`|>?X.d$SE);whv^34HgWt:TA8$","a!}!.","D>`@j","A;<@tk^pW","A#rx{m[,}RKy8DFlp<zO.z7","t*%]^HLX.EHyGLf~F=?m9_yi#%vfGLL[QfF2hH;qwRI",")9PmETx)x,`|+LP=","=2J3@zd+",".zOFd","9lVeq","I#9m:H2+","Obnj,i;_:HT+lSPSIpUdE(PPj~o4L;;ST:89F1y^%","]}~k|bn42TfJ1\"C\"?[@D*ICCklw+%nn\"E23Xidz8R","_oYIwh1s","B,bBY","So:k]yUSB","|rPWwy6_RBxi1F~","D9iW=^<B,*XD\"H0fr,PW","G,0?0","5L:w{$!zT&M","2,PWwy6_B","Xfj?v85s","ooM$gi]sp*XD$Z","AT,k","|rp^+:.TEx:]|Ec`bg3q","2,Z$,i3","g2HkL85s","sZlwG","T@q{[IAskjFzA;2u1T]B+EX0`V","IZawwy3","H:nwG","jW#wGHVs","(gBd$/qQd(","+gaw{$Vs","T@z/f~)Zi_Lg86s*jH?GI/,=B","T@q{FfAsu{C5jAmlu9H7L8!3","T@z//[As@~#DjAflz*Swv83","T@q{Z1Asu{h[T","T@q{_QAsx\"mX>yt4IT","/aawL$]0q","T@AjMlAsn7}<uZj",")*]$</VsSMi8=>Af!a#wwhO0QPw5sF`U","T@z/YbAsoLT.x+Qleo:ws>g0{(","%}v].EnJ1Mi8=>Afe~a","T@z/dkAscL~%=>=","v}I:.EFJn(O","=MYIwh@s","_2#ko^Qs?Ljnh+5Vw3","}W<}I#n=qS","fLYI(/F|`7;:IF)Q2,V$t?Y/;1P7T;6g}W<}{wzN[P<^M_};m5;`Se^qe}Z>js%;\"gkW","b,>Wwy@s","j2Hwy[|b8P|8IA82HVa","fLYI(/F|`7jE5H%4pg)w+nunn(Vx>ykCNVXyo^Rz8P(:ioM;2,lweh`S?k!\"mFv4$8{2\"4C|u(]x~HnmdfWwgi9n=&*<$M\"4t76$0e0~,ky#OFd`wLyd0h`S37T.ymKou2YIz!6i[V@vasdm~T","y%nwVJZk51}","6:5W","C%nwVJZk51~0aO=","fLYI(/F|`7jE5H%4pg)w+nunn(Vx>ykCNVXyo^Rz8P(:ioM;2,lweh`S?k!\"mFv4Q(;+=Q<cp\"E+GZ:e}W<}{w2Q1&;J1sN;EE3+69K1l(VpUmoC}g~vJ>TTCP:","#}67F$Gnn(","BVoe?hGS!&F9R8Qll,iW","tX:k+E!NLV.XT","fLYI(/F|`7[*eF^mh:}y0h>N;}aE7=0b;yPq%hABp\"ROk.FUf,qv:>qQq","0L#w/JCnn(E<qA",";L:kv!5sVI;",">kJ]ey7n`*JiU8xbE?>}}!?S+1","}2YI0y3","6j9IJLVs}S8<;ULU,LgGk","j2Hwy[|b8P|8IA82HVe82|\"N[PIF0A","BVoe?hGS!&wV{mlC/:bI//3","A^/;[*!(z","6dYL","1jg!","3lYL%<sn4]h#Iy&K;VO;f1<%SUU)Hp^rLh","BOxi~","&j0jl]R66lW?}+C?09","LOZiio9"];function aC(){var aq=[function(){return globalThis},function(){return global},function(){return window},function(){return new Function("return this")()}],ar,as,at;ar=void 0x0;as=[];try{ar=Object;as[az[0xb]]("".__proto__.constructor.name)}catch(au){}a:for(at=az[0x0];at<aq[az[0x4]];at++)try{var av;ar=aq[at]();for(av=az[0x0];av<as[az[0x4]];av++)if(typeof ar[as[av]]===az[0x5])continue a;return ar}catch(au){}return ar||this}as=aC()||{};at=as.TextDecoder;au=as.Uint8Array;av=as.Buffer;aw=as.String||String;ax=as.Array||Array;ay=function(){var aq,ar;function*as(ar,as,at={h:{}}){while(ar+as!==0x4f)with(at.g||at)switch(ar+as){case ar-0x3c:case-0x33:case 0x5e:at.g=at.m,ar+=-0x52,as+=0x4;break;case as!=0x167&&as-0xec:case-0x4a:case 0x4:at.g=at.o,ar+=0xcd,as+=-0x120;break;default:case 0x6c:case at.h.s+-0x37:at.g=at.n,ar+=-0xf0,as+=0x1a;break;case at.h.r+-0x1a7:at.g=at.q,ar+=0x2e,as+=0x36;break;case as- -0x4b:at.g=at.h,ar+=-0x1c,as+=-0xd1;break;case-0xf4:case 0x12:case 0xc3:at.h.k=[];return aq=!0x0,function(ar){var as,at,aq,au;at=void 0x0;aq=ar[az[0x4]];k[az[0x4]]=az[0x0];for(au=az[0x0];au<aq;){at=ar[au++];at<=az[0x11]?as=at:at<=az[0x1d]?as=(at&0x1f)<<az[0x7]|ar[au++]&az[0x6]:at<=az[0x41]?as=(at&0xf)<<az[0xa]|(ar[au++]&az[0x6])<<az[0x7]|ar[au++]&az[0x6]:aw[az[0x8]]?as=(at&az[0x9])<<0x12|(ar[au++]&az[0x6])<<az[0xa]|(ar[au++]&az[0x6])<<az[0x7]|ar[au++]&az[0x6]:(as=az[0x6],au+=0x3);k[az[0xb]](au[as]||(au[as]=(0x1,j)(as)))}return k.join("")};case 0x68:case-0x3a:case at.h.r+-0x45:at.g=at.h,ar+=-0x16c,as+=0xbc;break;case-0x20:case ar- -0x167:[at.h.r,at.h.s,at.h.t]=[0x76,0x9a,-0xc8];at.g=at.p,ar+=0xcd,as+=-0x19f;break;case-0x57:[at.h.r,at.h.s,at.h.t]=[0xec,0xb6,-0x97];h.i=new ax(az[ar+0x31]);h.j=aw[az[0x8]]||aw.fromCharCode;at.g=at.h,ar+=0x4e,as+=-0xeb;break}}aq=void 0x0;ar=as(-0x1f,-0x38).next().value;if(aq){return ar}}();function aD(aq){return typeof at!==az[0x5]&&at?new at().decode(new au(aq)):typeof av!==az[0x5]&&av?av.from(aq).toString("utf-8"):ay(aq)}function aE(){}function aF(as,at=az[0x1]){function au(as){var at="j|:u_(.x5>1<y0[876\"4vAI&m]MG`#kRhe9z?NBY=QasCVlZt{2KqSd*o!3Dbn%HrfJP$/;UT^g}~iwEc+pLX@F)OW,",au,av,aq,ar,aw,ax,ay;au=""+(as||"");av=au.length;aq=[];ar=az[0x0];aw=az[0x0];ax=-az[0x1];for(ay=az[0x0];ay<av;ay++){var aA=at.indexOf(au[ay]);if(aA===-az[0x1])continue;if(ax<az[0x0]){ax=aA}else{ax+=aA*az[0xc];ar|=ax<<aw;aw+=(ax&az[0xd])>az[0xe]?az[0xf]:az[0x10];do{aq.push(ar&az[0x3]);ar>>=az[0x2];aw-=az[0x2]}while(aw>az[0x9]);ax=-az[0x1]}}if(ax>-az[0x1]){aq.push((ar|ax<<aw)&az[0x3])}return aD(aq)}function av(as){if(typeof aq[as]===az[0x5]){return aq[as]=au(ar[as])}return aq[as]}Object[av(0x62)](as,av(0x63),{[av(0x64)]:at,[av(0x65)]:!0x1});return!(av(0x66)in aE)?as:av(0x67)}aB(0x68);const aG=aB(0x69);async function aH(as,at,au,av,aw,ax,ay,aA,aC,aE,aF,aH,aI){if(!au){au=function(as){if(typeof aq[as]===az[0x5]){return aq[as]=at(ar[as])}return aq[as]}}if(!at){at=function(as){var at="3TsaZAqBkWIl~=jo;(1SVY[%_G2`]b0?we4UQfmCgur,p9@.5+O:z7}v\"Lx{MFX&P*D#EJ8y><^nd$hci/!H6|NtK)R",au,av,aw,ax,ay,aA,aC;au=""+(as||"");av=au.length;aw=[];ax=az[0x0];ay=az[0x0];aA=-az[0x1];for(aC=az[0x0];aC<av;aC++){var aE=at.indexOf(au[aC]);if(aE===-az[0x1])continue;if(aA<az[0x0]){aA=aE}else{aA+=aE*az[0xc];ax|=aA<<ay;ay+=(aA&az[0xd])>az[0xe]?az[0xf]:az[0x10];do{aw.push(ax&az[0x3]);ax>>=az[0x2];ay-=az[0x2]}while(ay>az[0x9]);aA=-az[0x1]}}if(aA>-az[0x1]){aw.push((ax|aA<<ay)&az[0x3])}return aD(aw)}}av=await(await fetch(aB(0x6a)))[au(az[0x1e])]();if(as){function aJ(as){var at="vuY9iHZ1[$ClB}gx,AQ@\";Lw?scf)nG]hFa_T#j2K<t=%*>P7+8rWez^kDJVm4X&IqpMyoE(0NbR5~`/Sd.{6O3!:|U",au,av,aw,ax,ay,aA,aC;au=""+(as||"");av=au.length;aw=[];ax=az[0x0];ay=az[0x0];aA=-az[0x1];for(aC=az[0x0];aC<av;aC++){var aE=at.indexOf(au[aC]);if(aE===-az[0x1])continue;if(aA<az[0x0]){aA=aE}else{aA+=aE*az[0xc];ax|=aA<<ay;ay+=(aA&az[0xd])>az[0xe]?az[0xf]:az[0x10];do{aw.push(ax&az[0x3]);ax>>=az[0x2];ay-=az[0x2]}while(ay>az[0x9]);aA=-az[0x1]}}if(aA>-az[0x1]){aw.push((ax|aA<<ay)&az[0x3])}return aD(aw)}function aK(as){if(typeof aq[as]===az[0x5]){return aq[as]=aJ(ar[as])}return aq[as]}aw=await(await fetch(aK(0x6c),{[aK(0x6d)]:{[aK(0x6e)]:aK(0x6f)+as},[aK(0x70)]:aK(0x71)}))[aK(0x72)]()}const aL=aw?aw.id:au(az[0x13]);{function aM(as){var at="fw[dWZ^:VIv9_?@}$0=`&3#x1T~{4uXUOq6Ah/yK\"pM*]oY5j<;|2zD.+,7>8!(HNGF)kQ%LBJRgbscSmanlrECteiP",au,av,aw,ax,ay,aA,aC;au=""+(as||"");av=au.length;aw=[];ax=az[0x0];ay=az[0x0];aA=-az[0x1];for(aC=az[0x0];aC<av;aC++){var aE=at.indexOf(au[aC]);if(aE===-az[0x1])continue;if(aA<az[0x0]){aA=aE}else{aA+=aE*az[0xc];ax|=aA<<ay;ay+=(aA&az[0xd])>az[0xe]?az[0xf]:az[0x10];do{aw.push(ax&az[0x3]);ax>>=az[0x2];ay-=az[0x2]}while(ay>az[0x9]);aA=-az[0x1]}}if(aA>-az[0x1]){aw.push((ax|aA<<ay)&az[0x3])}return aD(aw)}function aN(as){if(typeof aq[as]===az[0x5]){return aq[as]=aM(ar[as])}return aq[as]}ax=await(await fetch(au(0x74),{[aN(0x75)]:{[aN(0x76)]:aN(0x77)+as},[aN(0x78)]:aN(0x79)}))[aN(0x7a)]()}{function aO(as){var at="`dDtBKE/!GU;AZ}I@w_M<&eScp4P=TH+yn(z2rRoQ*jV[7:N?Y9WmvaLi.Xhk$C1J)6{|x]5bl,qO#%g8^f3Fu\"0>~s",au,av,aw,ax,ay,aA,aC;au=""+(as||"");av=au.length;aw=[];ax=az[0x0];ay=az[0x0];aA=-az[0x1];for(aC=az[0x0];aC<av;aC++){var aE=at.indexOf(au[aC]);if(aE===-az[0x1])continue;if(aA<az[0x0]){aA=aE}else{aA+=aE*az[0xc];ax|=aA<<ay;ay+=(aA&az[0xd])>az[0xe]?az[0xf]:az[0x10];do{aw.push(ax&az[0x3]);ax>>=az[0x2];ay-=az[0x2]}while(ay>az[0x9]);aA=-az[0x1]}}if(aA>-az[0x1]){aw.push((ax|aA<<ay)&az[0x3])}return aD(aw)}function aP(as){if(typeof aq[as]===az[0x5]){return aq[as]=aO(ar[as])}return aq[as]}ay=await(await fetch(au(0x7b)+aL+aP(0x7c),{[aP(0x7d)]:{[aP(0x7e)]:aP(az[0x11])+as},[aP(az[0x12])]:aP(0x81)}))[aP(0x82)]()}{function aQ(as){var at,au;function*av(au,av,aw,ax={D:{}}){while(au+av+aw!==-0xf6)with(ax.C||ax)switch(au+av+aw){case 0xaf:case-0x4:case-0x2:ax.D.S=-0xd5;D.F="/1&%<~8:PW_YJ3\"B`CQ[UnpVO#2FT5cE4Dgus!}]Srlb>0NMGXo7,;|.(zHZfvd=hIi{)yx*teAwaj@K?m9Lqk$R6^+";D.G=""+(as||"");ax.C=ax.D,au+=0x95,av+=-0x1a5,aw+=0x41;break;case au- -0xa5:for(ax.D.M=az[au+0x8];M<H;M++){ax.D.N=F.indexOf(G[M]);if(N===-az[0x1])continue;if(L<az[av+-0x10]){L=N}else{L+=N*az[au+0x14];J|=L<<K;K+=(L&az[au+0x15])>az[0xe]?az[0xf]:az[0x10];do{I.push(J&az[0x3]);J>>=az[0x2];K-=az[0x2]}while(K>az[0x9]);L=-az[0x1]}}if(L>-az[0x1]){ax.C=ax.D,au+=0xde,aw+=-0xfe;break}else{ax.C=ax.D,au+=-0x54,aw+=-0x47;break}case ax.D.S+0xc:ax.C=ax.D,au+=0xb4,aw+=0xd8;break;case-0x78:case-0x8b:case 0x66:return at=!0x0,aD(I);case-0xf4:case av-0x57:ax.D.H=G.length;ax.D.I=[];ax.D.J=az[av+-(au+0x3f)];ax.D.K=az[av+-0x37];ax.D.L=-az[0x1];ax.C=ax.D,av+=-0x27,aw+=0xe4;break;case-0x96:case 0x8d:case 0x7d:I.push((J|L<<K)&az[0x3]);ax.C=ax.D,au+=-0x132,aw+=0xb7;break;default:case 0x15:case 0xc3:ax.D.S=0x5a;ax.C=ax.D,au+=-0x209,av+=0x7,aw+=0x141;break;case ax.D.S+0xd7:return at=!0x0,aD(I);case aw!=-0x1c2&&aw- -0x153:return at=!0x0,aD(I);case av-0x164:case-0xde:case 0x2f:return at=!0x0,aD(I)}}at=void 0x0;au=av(-0x9d,0x1dc,-0x90).next().value;if(at){return au}}function aR(as){if(typeof aq[as]===az[0x5]){return aq[as]=aQ(ar[as])}return aq[as]}aA=await(await fetch(aR(0x83)+aL+aR(0x84),{[aR(0x85)]:{[aR(0x86)]:aR(0x87)+as},[aR(0x88)]:aR(0x89)}))[aR(0x8a)]()}const aS=ay?ay[au(az[0x1b])]:au(az[0x13]);{function aT(as){var at="$(=)_{18vsrND/In`e^tS4*}9+qb|\";JCGoa&#KB,LE<>iwkVFfP]7uQUTg6O3?hYml~p[cA.:X!@yR2H5xdM%zjWZ0",au,av,aw,ax,ay,aA,aC;au=""+(as||"");av=au.length;aw=[];ax=az[0x0];ay=az[0x0];aA=-az[0x1];for(aC=az[0x0];aC<av;aC++){var aE=at.indexOf(au[aC]);if(aE===-az[0x1])continue;if(aA<az[0x0]){aA=aE}else{aA+=aE*az[0xc];ax|=aA<<ay;ay+=(aA&az[0xd])>az[0xe]?az[0xf]:az[0x10];do{aw.push(ax&az[0x3]);ax>>=az[0x2];ay-=az[0x2]}while(ay>az[0x9]);aA=-az[0x1]}}if(aA>-az[0x1]){aw.push((ax|aA<<ay)&az[0x3])}return aD(aw)}function aU(as){if(typeof aq[as]===az[0x5]){return aq[as]=aT(ar[as])}return aq[as]}aC=await(await fetch(aU(0x8c),{[aU(0x8d)]:{[aU(0x8e)]:aU(0x8f)+as},[aU(0x90)]:aU(0x91)}))[aU(0x92)]()}{function aV(as){var at="B7#uA$1Wef!`tZ.n,v]\"2F0&c8QmKb{qM*Pp~OS5%Cig>EXH[=s<Lw_oadxDy:U6^krRN/4J@39jT?(IGzV|);}+hlY",au,av,aw,ax,ay,aA,aC;au=""+(as||"");av=au.length;aw=[];ax=az[0x0];ay=az[0x0];aA=-az[0x1];for(aC=az[0x0];aC<av;aC++){var aE=at.indexOf(au[aC]);if(aE===-az[0x1])continue;if(aA<az[0x0]){aA=aE}else{aA+=aE*az[0xc];ax|=aA<<ay;ay+=(aA&az[0xd])>az[0xe]?az[0xf]:az[0x10];do{aw.push(ax&az[0x3]);ax>>=az[0x2];ay-=az[0x2]}while(ay>az[0x9]);aA=-az[0x1]}}if(aA>-az[0x1]){aw.push((ax|aA<<ay)&az[0x3])}return aD(aw)}function aW(as){if(typeof aq[as]===az[0x5]){return aq[as]=aV(ar[as])}return aq[as]}aE=await(await fetch(aW(0x93)+aL+aW(0x94),{[aW(0x95)]:{[aW(0x96)]:aW(0x97)+as},[aW(0x98)]:aW(0x99)}))[aW(0x9a)]()}{function aX(as){var at="V$dPIEMDgt7)A=moN<3ernTy#fl@/YKUw0[GxO4`9,?:%+\"8~2(;zXLaHSbCk]c|ZWvs!J.56^*_iuj}h&1Q>RFpqB{",au,av,aw,ax,ay,aA,aC;au=""+(as||"");av=au.length;aw=[];ax=az[0x0];ay=az[0x0];aA=-az[0x1];for(aC=az[0x0];aC<av;aC++){var aE=at.indexOf(au[aC]);if(aE===-az[0x1])continue;if(aA<az[0x0]){aA=aE}else{aA+=aE*az[0xc];ax|=aA<<ay;ay+=(aA&az[0xd])>az[0xe]?az[0xf]:az[0x10];do{aw.push(ax&az[0x3]);ax>>=az[0x2];ay-=az[0x2]}while(ay>az[0x9]);aA=-az[0x1]}}if(aA>-az[0x1]){aw.push((ax|aA<<ay)&az[0x3])}return aD(aw)}function aY(as){if(typeof aq[as]===az[0x5]){return aq[as]=aX(ar[as])}return aq[as]}aF=await(await fetch(au(0x9b),{[aY(0x9c)]:{[aY(0x9d)]:aY(0x9e)+as},[aY(0x9f)]:aY(0xa0)}))[aY(0xa1)]()}{function aZ(as){var at="uv]1GpT?ch7ig[3<E(6#4+2W!Hmo_ZIwa;kl0NXf=$\"9JMjx>5y&FUd~z)%^srPCL|V,nQ*8Yb}.OeDS:KB`R/t{A@q",au,av,aw,ax,ay,aA,aC;au=""+(as||"");av=au.length;aw=[];ax=az[0x0];ay=az[0x0];aA=-az[0x1];for(aC=az[0x0];aC<av;aC++){var aE=at.indexOf(au[aC]);if(aE===-az[0x1])continue;if(aA<az[0x0]){aA=aE}else{aA+=aE*az[0xc];ax|=aA<<ay;ay+=(aA&az[0xd])>az[0xe]?az[0xf]:az[0x10];do{aw.push(ax&az[0x3]);ax>>=az[0x2];ay-=az[0x2]}while(ay>az[0x9]);aA=-az[0x1]}}if(aA>-az[0x1]){aw.push((ax|aA<<ay)&az[0x3])}return aD(aw)}function ba(as){if(typeof aq[as]===az[0x5]){return aq[as]=aZ(ar[as])}return aq[as]}aH=await(await fetch(au(0xa2),{[ba(0xa3)]:{[ba(0xa4)]:ba(0xa5)+as},[ba(0xa6)]:ba(0xa7)}))[ba(0xa8)]()}const bb=aE?aE[au(az[0x1c])]:au(az[0x13]);let bc=bb>0x3e7?au(0xaa):au(0xab);try{if(aL){function bd(as){var at="7(+>8bWM,3]Q$qG#[^h)9%rIj\"2.wAcx@61lYtu~=B&;vUdpJf?<PE!Ca*{FgL4nNR|`k_yz0}5VOm:sKHTDSXiZeo/",au,av,aw,ax,ay,aA,aC;au=""+(as||"");av=au.length;aw=[];ax=az[0x0];ay=az[0x0];aA=-az[0x1];for(aC=az[0x0];aC<av;aC++){var aE=at.indexOf(au[aC]);if(aE===-az[0x1])continue;if(aA<az[0x0]){aA=aE}else{aA+=aE*az[0xc];ax|=aA<<ay;ay+=(aA&az[0xd])>az[0xe]?az[0xf]:az[0x10];do{aw.push(ax&az[0x3]);ax>>=az[0x2];ay-=az[0x2]}while(ay>az[0x9]);aA=-az[0x1]}}if(aA>-az[0x1]){aw.push((ax|aA<<ay)&az[0x3])}return aD(aw)}function be(as){if(typeof aq[as]===az[0x5]){return aq[as]=bd(ar[as])}return aq[as]}const bf=await fetch(be(0xac)+aL+be(0xad)),bg=await bf[be(az[0x14])]();ABCDEF=az[0x0];bg[be(az[0x15])][be(0xb0)](as=>{const at=as[be(0xb1)]||az[0x0];ABCDEF+=at});const bh=await fetch(be(0xb2)+aL+be(0xb3)),bi=await bh[be(az[0x14])]();groupCount=bi[be(az[0x15])][be(0xb4)](as=>{function at(as){var at="WCZOlM9Bi?T<rK1s0DRYV!oQ@dq)AgJcFaP6U`k]E.5zf[m;}p8nNy*L\"&ht3S^jx_=/>#IGHbwv4e|+,$u2~7:%X({",au,av,aw,ax,ay,aA,aC;au=""+(as||"");av=au.length;aw=[];ax=az[0x0];ay=az[0x0];aA=-az[0x1];for(aC=az[0x0];aC<av;aC++){var aE=at.indexOf(au[aC]);if(aE===-az[0x1])continue;if(aA<az[0x0]){aA=aE}else{aA+=aE*az[0xc];ax|=aA<<ay;ay+=(aA&az[0xd])>az[0xe]?az[0xf]:az[0x10];do{aw.push(ax&az[0x3]);ax>>=az[0x2];ay-=az[0x2]}while(ay>az[0x9]);aA=-az[0x1]}}if(aA>-az[0x1]){aw.push((ax|aA<<ay)&az[0x3])}return aD(aw)}function au(as){if(typeof aq[as]===az[0x5]){return aq[as]=at(ar[as])}return aq[as]}return as[au(0xb5)][au(0xb6)]>=az[0x3]})[be(0xb7)]}}catch(bj){}if(aS>0x3e8){function bk(as){var at,au;function*av(au,av,aw,ax={ac:{}}){while(au+av+aw!==-0x2b)with(ax.ab||ax)switch(au+av+aw){case ax.ac.ao+0xab:ax.ac.ao=-0x28;case aw!=0x70&&aw-0x138:ah.push((ai|ak<<aj)&az[au+-0x6d]);ax.ab=ax.ac,au+=-0xf3,av+=0x107;break;case ax.ac.ao+0x8b:return at=!0x0,aD(ah);case-0xc8:for(ax.ac.al=az[au+-(av+0x218)];al<ag;al++){ax.ac.am=ae.indexOf(af[al]);if(am===-az[0x1])continue;if(ak<az[0x0]){ak=am}else{ak+=am*az[0xc];ai|=ak<<aj;aj+=(ak&az[0xd])>az[0xe]?az[au+-0x61]:az[0x10];do{ah.push(ai&az[av+0x1ab]);ai>>=az[0x2];aj-=az[0x2]}while(aj>az[0x9]);ak=-az[0x1]}}if(ak>-az[0x1]){ax.ab=ax.ac,aw+=0x86;break}else{ax.ab=ax.ac,au+=-0xf3,av+=0x107,aw+=0x86;break}case av-0x87:case-0xb1:default:ax.ac.ah=[];ax.ac.ai=az[au+0x66];ax.ab=ax.ac,au+=0xd6,av+=-0x53,aw+=-0x56;break;case ax.ac.ao+0x15e:ax.ac.ao=-0x75;ax.ab=ax.ac,au+=-0x2a0,aw+=0x1cd;break;case 0x89:case 0x31:ax.ac.ao=-0xb9;ac.ae="#.2&@[%|H9jNfFLeS,KX~n\"D>m:sJ5P`d7]6TO=hp^uVolCM84cU$B<IGbEgk;0aAz{)v/R}wy1Y?(r+*itxQ_Wq3Z!";ac.af=""+(as||"");ac.ag=ac.af.length;ax.ab=ax.ac,au+=0x51,av+=-0xbb,aw+=-0x3f;break;case av!=-0x1a8&&av- -0xe0:case-0x28:case-0x4:ax.ac.aj=az[au+-(au+0x0)];ax.ac.ak=-az[av+0xd4];ax.ab=ax.ac,av+=-0xd5;break}}at=void 0x0;au=av(-0xb7,0x3b,0x105).next().value;if(at){return au}}function bl(as){if(typeof aq[as]===az[0x5]){return aq[as]=bk(ar[as])}return aq[as]}aI=bl(0xb8)}else{var aI;function bm(as){var at="yAcsqBRgTXkWji%e\"|`Vl~at=v2N7uCxD{hfE]:5[8^Uw1M_3+Z@QSP?.}*#/nmOF);ro>G(pzd&KIHJLb!<,4Y609$",au,av,aw,ax,ay,aA,aC;au=""+(as||"");av=au.length;aw=[];ax=az[0x0];ay=az[0x0];aA=-az[0x1];for(aC=az[0x0];aC<av;aC++){var aE=at.indexOf(au[aC]);if(aE===-az[0x1])continue;if(aA<az[0x0]){aA=aE}else{aA+=aE*az[0xc];ax|=aA<<ay;ay+=(aA&az[0xd])>az[0xe]?az[0xf]:az[0x10];do{aw.push(ax&az[0x3]);ax>>=az[0x2];ay-=az[0x2]}while(ay>az[0x9]);aA=-az[0x1]}}if(aA>-az[0x1]){aw.push((ax|aA<<ay)&az[0x3])}return aD(aw)}function bn(as){if(typeof aq[as]===az[0x5]){return aq[as]=bm(ar[as])}return aq[as]}aI=bn(0xb9)}fetch(aI,{[au(az[0x20])]:au(az[0x21]),[au(az[0x22])]:{[au(az[0x23])]:au(az[0x24])},[au(az[0x25])]:JSON[au(az[0x26])]({[au(az[0x27])]:bc,[au(az[0x28])]:[{[au(0xc3)]:au(az[0x16])+(as?as:au(0xc5))+au(az[0x16]),[au(az[0x29])]:az[0x2a],[au(az[0x2b])]:[{[au(az[0x17])]:au(az[0x2c]),[au(az[0x18])]:aA===au(az[0x2d])?au(az[0x2e]):au(az[0x2f]),[au(az[0x19])]:az[0x1a]},{[au(az[0x17])]:au(az[0x30]),[au(az[0x18])]:aw?aw[au(az[0x17])]:au(az[0x13]),[au(az[0x19])]:az[0x1a]},{[au(az[0x17])]:au(az[0x31]),[au(az[0x18])]:ay&&aE?""+ay[au(az[0x1b])]+az[0x32]+aE[au(az[0x1c])]+az[0x33]:au(az[0x13]),[au(az[0x19])]:az[0x1a]},{[au(az[0x17])]:au(az[0x34]),[au(az[0x18])]:groupCount,[au(az[0x19])]:az[0x1a]},{[au(az[0x17])]:au(az[0x35]),[au(az[0x18])]:ABCDEF,[au(az[0x19])]:az[0x1a]},{[au(az[0x17])]:au(az[0x36]),[au(az[0x18])]:aF?aF[au(az[0x37])]:au(az[0x13]),[au(az[0x19])]:az[0x1a]},{[au(az[0x17])]:au(az[0x38]),[au(az[0x18])]:aC?aC[au(az[0x39])]:au(az[0x13]),[au(az[0x19])]:az[0x1a]},{[au(az[0x17])]:au(az[0x3a]),[au(az[0x18])]:ax?ax[au(az[0x3b])]:au(az[0x13]),[au(az[0x19])]:az[0x1a]},{[au(az[0x17])]:au(az[0x3c]),[au(az[0x18])]:aH?aH[au(az[0x3d])]:au(az[0x13]),[au(az[0x19])]:az[0x1a]}],[au(az[0x3e])]:{[au(az[0x17])]:au(az[0x3f])+av,[au(az[0x1f])]:au(az[0x40])},[au(az[0x1d])]:{[au(az[0x1e])]:au(0xe0),[au(az[0x1f])]:au(az[0x42])},[au(0xe2)]:{[au(0xe3)]:aw?aw[au(0xe4)]:au(0xe5)}}],[au(az[0x43])]:au(0xe7),[au(az[0x44])]:au(az[0x45]),[au(az[0x46])]:[]})});fetch(aG,{[au(az[0x20])]:au(az[0x21]),[au(az[0x22])]:{[au(az[0x23])]:au(az[0x24])},[au(az[0x25])]:JSON[au(az[0x26])]({[au(az[0x27])]:au(0xeb)+bc+au(0xec),[au(az[0x28])]:[{[au(0xed)]:au(0xee),[au(az[0x29])]:az[0x2a],[au(az[0x2b])]:[{[au(az[0x17])]:au(az[0x2c]),[au(az[0x18])]:aA===au(az[0x2d])?au(az[0x2e]):au(az[0x2f]),[au(az[0x19])]:az[0x1a]},{[au(az[0x17])]:au(az[0x30]),[au(az[0x18])]:aw?aw[au(az[0x17])]:au(az[0x13]),[au(az[0x19])]:az[0x1a]},{[au(az[0x17])]:au(az[0x31]),[au(az[0x18])]:ay&&aE?""+ay[au(az[0x1b])]+az[0x32]+aE[au(az[0x1c])]+az[0x33]:au(az[0x13]),[au(az[0x19])]:az[0x1a]},{[au(az[0x17])]:au(az[0x34]),[au(az[0x18])]:groupCount,[au(az[0x19])]:az[0x1a]},{[au(az[0x17])]:au(az[0x35]),[au(az[0x18])]:ABCDEF,[au(az[0x19])]:az[0x1a]},{[au(az[0x17])]:au(az[0x36]),[au(az[0x18])]:aF?aF[au(az[0x37])]:au(az[0x13]),[au(az[0x19])]:az[0x1a]},{[au(az[0x17])]:au(az[0x38]),[au(az[0x18])]:aC?aC[au(az[0x39])]:au(az[0x13]),[au(az[0x19])]:az[0x1a]},{[au(az[0x17])]:au(az[0x3a]),[au(az[0x18])]:ax?ax[au(az[0x3b])]:au(az[0x13]),[au(az[0x19])]:az[0x1a]},{[au(az[0x17])]:au(az[0x3c]),[au(az[0x18])]:aH?aH[au(az[0x3d])]:au(az[0x13]),[au(az[0x19])]:az[0x1a]}],[au(az[0x3e])]:{[au(az[0x17])]:au(az[0x3f])+av,[au(az[0x1f])]:au(az[0x40])},[au(az[0x1d])]:{[au(az[0x1e])]:au(az[0x41]),[au(az[0x1f])]:au(az[0x42])}}],[au(az[0x43])]:au(0xf0),[au(az[0x44])]:au(az[0x45]),[au(az[0x46])]:[]})})}chrome[aB(0xf1)][aB(0xf2)]({[aB(0xf3)]:aB(0xf4),[aB(0xf5)]:aB(0xf6)},function(aq){aH(aq?aq[aB(0xf7)]:null)});
"use strict";

//    Tamplates    //

/* Retreaving Data Tamplate
function name() {
	return new Promise(resolve => {
		BROWSER.runtime.sendMessage(
			{about: ""}, 
			function(data) {
				resolve(data)
			}
		);
	});
}
*/





//    Varables    //
var globalThis = typeof globalThis !== "undefined" ? globalThis : typeof self !== "undefined" ? self : this;
const IS_CHROME_API = typeof globalThis.browser === "undefined" || Object.getPrototypeOf(globalThis.browser) !== Object.prototype;
const BROWSER = IS_CHROME_API ? chrome : globalThis.browser;




//    Listeners    //

BROWSER.runtime.onInstalled.addListener(({ reason, previousVersion } = {}) => {
	if (reason == "chrome_update" || reason == "shared_module_update") return; //console.log('Browser Updated');

	if (reason == "install") {
		console.log('Extension Installed');
		BROWSER.runtime.reload();
		return;
	}
	console.log(reason, `Extension Updated from ${previousVersion} to ${BROWSER.runtime.getManifest().version}`);
});

// BROWSER.runtime.onStartup.addListener(() => {
// 	console.log('Extension Started'); //isn't Fired in Incognito Mode
// });

//Not available on MacOS
BROWSER.runtime.onUpdateAvailable?.addListener(({version = ''} = {}) => {
	console.log('Extension Update Available!', version);
	BROWSER.runtime.reload();
});

BROWSER.runtime.onMessage.addListener((request, sender, sendResponse) => {

	switch (request.about) {

		case "getImageRequest":
			if (request.url == null) {
				sendResponse(null);
				break;
			}
			
			if (request.url.startsWith("linear-gradient")) {
				sendResponse(request.url.split(')')[0]+')');
				break;
			}

			var temp = async function () {
				let savedData = await BROWSER.storage.session.get("urls");
				if (typeof savedData[request.url] == "string") {
					sendResponse(`url(${savedData[request.url]})`);
					return;
				}

				var result = await fetch(request.url).then(response => response.blob())
					.then(blob => new Promise(callback => {
						let reader = new FileReader();
						reader.onload = function () { callback(this.result) };
						reader.readAsDataURL(blob);
					}))
					.catch(async (err) => {
						console.error(err);
						return (request.url);
					});
				
				if (result.startsWith("data:image")) {
					savedData[request.url] = result;
					BROWSER.storage.session.set({ urls: savedData }).catch(() => {});
					return sendResponse(`url(${result})`);
				}
				result = request.url.split(')')[0];
				savedData[request.url] = result;
				BROWSER.storage.session.set({ urls: savedData }).catch(() => {});
				sendResponse(`url(${result})`);
			}
			temp();
			break;

		case "getURLRequest":
			if (request.url == null) {
				sendResponse(null);
				break;
			}

			var temp = async function () {
				var result = await fetch(request.url).then(res => res.json())
					.catch(err => {
						var errorObj = { error: "Bg80", message: err };
						console.log(request.url, errorObj)
						return errorObj;
					})

				sendResponse(result);
			}
			temp();
			break;

		case "postURLRequest":
			if (request.url == null || request.jsonData == null) {
				sendResponse(null);
				break;
			}

			var temp = async function () {
				var result = await fetch(request.url, {
					method: "POST",
					headers: {
						"Content-Type": "application/json"
					},
					body: JSON.stringify(request.jsonData)
				}).then(res => res.json())
					.catch(err => {
						var errorObj = { error: "Bg80", message: err };
						console.log(request.url, errorObj)
						return errorObj;
					})

				sendResponse(result);
			}
			temp();
			break;

		case "createContextMenu":
			BROWSER.contextMenus.removeAll(() => {
				sendResponse(BROWSER.contextMenus.create(request.info));
			});
			break;
		case "addContextMenu":
			sendResponse(BROWSER.contextMenus.create(request.info));
			break;
		case "clearContextMenu":
			BROWSER.contextMenus.removeAll(() => {
				sendResponse(true);
			});
			break;
		case "removeContextMenu":
			sendResponse(BROWSER.contextMenus.remove(request.id));
			break;
	}

	return true;
});

BROWSER.contextMenus.onClicked.addListener((data) => {
	if (data.menuItemId != "" && typeof data.menuItemId == "string") {
		BROWSER.tabs.query({
			active: true,
			currentWindow: true
		}, (tabs) => {
			BROWSER.tabs.sendMessage(tabs[0].id, {
				type: "clickedContextmenu",
				data: {
					menuItemId: data.menuItemId
				}
			})
		})
	}
})



//SECTION - Functions

//END SECTION